/*
 * gen-code.js —— 源码片段与函数索引生成器
 *
 * 目的：网页里展示的每一段代码、每一个行号，都必须来自对真实工程文件的读取，
 *       不能手抄（手抄会产生行号漂移）。本脚本以只读方式打开三个固件工程，
 *       按下方 SPECS 里的 [文件, 起行, 止行] 精确切片，生成：
 *
 *         js/data/code.js       —— 代码片段（含项目名/相对路径/函数名/起止行）
 *         js/data/codeindex.js  —— 函数索引 + 工程文件统计
 *
 * 用法： node tools/gen-code.js
 * 约束： 只读取 D:\ESP32_IDF_project_\html_OTA 下的三个工程，不写任何工程文件。
 */
'use strict';

const fs = require('fs');
const path = require('path');

const HTML_DIR = path.resolve(__dirname, '..');
const ROOT = path.resolve(HTML_DIR, '..');           // …\html_OTA
const OUT_DIR = path.join(HTML_DIR, 'js', 'data');

const BOOT = 'HAL_F429IGT6_bootloard';
const APP = 'HAL_F429IGT6_App';
const APP2 = 'HAL_F429IGT6_App_2';

/* 证据等级：A=源码已证实（逐字来自源文件） */
const SPECS = [
  /* ---------------- 启动 / 向量表 ---------------- */
  ['startup_vectors', BOOT, 'MDK-ARM/startup_stm32f429xx.s', 56, 62, 'Reset_Handler 向量表：第 0 项为初始 MSP，第 1 项为复位入口', '__Vectors'],
  ['startup_reset', BOOT, 'MDK-ARM/startup_stm32f429xx.s', 177, 188, 'Reset_Handler：调用 SystemInit 后进入 __main', 'Reset_Handler'],
  ['boot_main', BOOT, 'Core/Src/main.c', 69, 113, 'BootLoader 的 main()：HAL_Init → SystemClock_Config → 外设初始化 → boot_run()'],
  ['boot_clock', BOOT, 'Core/Src/main.c', 120, 167, 'BL 时钟树：HSI → PLL(180MHz)，与 App 的 HSE 源不同'],
  ['boot_ledskip', BOOT, 'Core/Src/main.c', 92, 101, 'MX_GPIO / MX_DMA / MX_USART1 / MX_SPI2 的顺序，之后才进 boot_run()'],

  /* ---------------- boot_run 主流程 ---------------- */
  ['boot_run_head', BOOT, 'Boot/boot_start.c', 272, 300, 'boot_run() 入口：端口优先级修正 + banner + 看门狗'],
  ['boot_run_ext', BOOT, 'Boot/boot_start.c', 301, 310, '片外 Flash 初始化与 JEDEC ID 读取'],
  ['boot_run_param', BOOT, 'Boot/boot_start.c', 311, 329, '读参数区；无效则重建默认值并保存'],
  ['boot_run_branch', BOOT, 'Boot/boot_start.c', 330, 332, '按 boot_flag 四态分支（ROLLBACK / RECOVERY / TRY_NEW / NORMAL）'],
  ['boot_run_rollback', BOOT, 'Boot/boot_start.c', 331, 368, 'ROLLBACK 分支：校验备份区 → 覆盖 A 槽 → 清标志'],
  ['boot_run_recovery', BOOT, 'Boot/boot_start.c', 369, 392, 'RECOVERY 分支：用出厂镜像覆盖 A 槽'],
  ['boot_run_trynew', BOOT, 'Boot/boot_start.c', 393, 447, 'TRY_NEW 分支：先校验暂存区 SHA-256，通过才擦 A 槽；boot_count 累加与自动转回滚'],
  ['boot_run_normal', BOOT, 'Boot/boot_start.c', 448, 460, 'NORMAL 分支：清零失败计数'],
  ['boot_run_final', BOOT, 'Boot/boot_start.c', 462, 491, '校验 A 槽有效性 → 无效则恢复 → 最后跳转'],
  ['boot_halt', BOOT, 'Boot/boot_start.c', 62, 68, '不可恢复错误：挂死并持续喂狗（不无限重启）'],
  ['boot_verify_ext', BOOT, 'Boot/boot_start.c', 77, 114, '片外镜像 SHA-256 校验：BOOT_VERIFY_CHUNK=64 字节分块'],
  ['boot_do_rollback', BOOT, 'Boot/boot_start.c', 183, 211, '回滚：先校验备份区 SHA-256，通过后再用备份覆盖 A 槽'],
  ['boot_do_recovery', BOOT, 'Boot/boot_start.c', 213, 241, '恢复出厂：校验恢复区 SHA-256 后覆盖 A 槽'],
  ['boot_copy', BOOT, 'Boot/boot_start.c', 120, 181, '暂存区 → A 槽：按扇区擦除 + BOOT_COPY_CHUNK=1024 字节分块拷贝'],

  /* ---------------- 参数区 / Flash ---------------- */
  ['partition_internal', BOOT, 'Boot/partition.h', 39, 64, '片内 Flash 分区：BL 48KB / 参数区 16KB / App A 槽 960KB', '#define 片内分区宏'],
  ['partition_flags', BOOT, 'Boot/partition.h', 78, 95, '启动标志四态 + 备份区状态 + 自动回滚次数阈值', '#define 启动标志'],
  ['partition_ext', BOOT, 'Boot/partition.h', 66, 91, 'W25Q64 分区：Staging / Backup / Recovery / Resource 各 960KB 与启动标志'],
  ['ota_params_t', BOOT, 'Boot/ota_params.h', 21, 43, '参数区结构体：BL 与 App 的二进制协议（字段顺序不可改）', 'struct ota_param_t'],
  ['param_load', BOOT, 'Boot/param_area.c', 105, 144, 'param_area_load：遍历 32 槽，取 seq 最大且 CRC32 正确的槽'],
  ['param_save', BOOT, 'Boot/param_area.c', 146, 215, 'param_area_save：找空槽写入；写满 32 次才整扇区擦一次（掉电安全）'],
  ['param_defaults', BOOT, 'Boot/param_area.c', 34, 54, '参数区默认值 = NORMAL + V1.0.0'],
  ['flash_if_sectors', BOOT, 'Boot/flash_if.c', 14, 36, 'F429IGT6 扇区表：S0~S3=16KB，S4=64KB，S5~S11=128KB', 's_sector_start[] / s_sector_size[]'],
  ['flash_if_erase', BOOT, 'Boot/flash_if.c', 64, 104, '按地址擦除所在扇区（HAL_FLASHEx_Erase）'],
  ['flash_if_write', BOOT, 'Boot/flash_if.c', 106, 168, '片内 Flash 写：32 位字编程 + 回读校验'],
  ['boot_ext_id', BOOT, 'Boot/boot_ext.c', 20, 50, 'boot_ext_init / boot_ext_jedec_id（0x9F 读 JEDEC）'],

  /* ---------------- 跳转 ---------------- */
  ['jump_validate', BOOT, 'Boot/app_jump.c', 31, 61, 'app_jump_validate：地址区间 + MSP 落在 RAM + 复位向量落在 Flash'],
  ['jump_execute', BOOT, 'Boot/app_jump.c', 63, 96, 'app_jump_execute：关外设 → 设 MSP → 设 VTOR → DSB/ISB → 开中断 → 跳转'],
  ['shutdown', BOOT, 'Boot/boot_shutdown.c', 140, 200, 'boot_system_shutdown 的 9 步清理（关中断/SysTick/NVIC/DMA/外设/时钟/使能/PendSV）'],
  ['clock_hsi', BOOT, 'Boot/boot_shutdown.c', 82, 138, '把时钟树恢复为 HSI 16MHz（BL 用 HSI-PLL，App 用 HSE-PLL）'],

  /* ---------------- App 侧：启动 ---------------- */
  ['app_partition', APP, 'OTA/partition.h', 60, 95, 'App 侧同一份分区表（与 BL 必须逐字节一致）与启动标志定义'],
  ['app_cfg_version', APP, 'OTA/ota_config.h', 44, 50, '版本号两行必须同步修改：NUM 用于防降级，STR 用于上报'],
  ['app_cfg_dl', APP2, 'OTA/ota_config.h', 52, 99, 'OTA_DL_CHUNK=256 / 检查点 16384 / 启动确认窗口 30000ms'],
  ['app_main', APP, 'Core/Src/main.c', 207, 270, 'App 的 main()：VTOR 重定位必须早于 HAL_Init()'],
  ['app_main_vtor', APP, 'Core/Src/main.c', 210, 232, '★ SCB->VTOR = 0x08010000，否则所有中断都跳进 BL 的向量表', 'main() 开头'],
  ['freertos_init', APP, 'Core/Src/freertos.c', 142, 215, 'MX_FREERTOS_Init：外设/屏幕/Flash/参数区/算法自检 + esp8266_Init'],
  ['freertos_task', APP, 'Core/Src/freertos.c', 257, 291, 'StartDefaultTask：ota_p2_selftest() 后进入 100ms 轮询业务循环'],
  ['esp8266_init', APP, 'App/esp_handle.c', 37, 66, 'esp8266_Init：AT+RST/CWMODE/CWJAP/MQTTUSERCFG/MQTTCONN/MQTTSUB（GBK 源文件）'],
  ['uart_process_hook', APP, 'App/esp_handle.c', 433, 482, 'uart_process：解析 +MQTTSUBRECV 后把 ident 交给 ota_task_on_update_ident'],

  /* ---------------- App 侧：OTA 触发与通道交接 ---------------- */
  ['ota_task_entry', APP, 'OTA/ota_task.c', 60, 110, 'ota_task_entry：s_req 触发 → ota_net_enter → ota_run_once → ota_net_exit'],
  ['ota_task_request', APP, 'OTA/ota_task.c', 114, 143, 'ota_task_request：首次触发时懒创建 1536 字栈的 otaTask'],
  ['net_enter', APP, 'OTA/ota_net_switch.c', 104, 151, 'ota_net_enter：断 MQTT → 停 IDLE-DMA → DMA 切 CIRCULAR → esp01s 接管 → 入网'],
  ['net_restore', APP, 'OTA/ota_net_switch.c', 84, 102, 'ota_net_restore：DMA 回 NORMAL、恢复 IDLE 接收、重连 MQTT'],

  /* ---------------- App 侧：引擎主流程 ---------------- */
  ['run_once_head', APP, 'OTA/ota_engine.c', 1130, 1178, 'ota_run_once 前半：恢复区初始化 → 补报 201 → 上报版本 → check 任务'],
  ['run_once_reject', APP, 'OTA/ota_engine.c', 1180, 1215, '拒绝差分包（type!=1）与降级（target<=current）'],
  ['run_once_download', APP, 'OTA/ota_engine.c', 1217, 1233, '下载 + 备份两步'],
  ['run_once_commit', APP, 'OTA/ota_engine.c', 1235, 1264, '把镜像长度/SHA-256/备份信息固化进参数区，并上报 step=100'],
  ['run_once_apply', APP, 'OTA/ota_engine.c', 1266, 1288, '应用：OTA_TEST_NO_REBOOT=0 时直接 ota_apply_and_reboot()（不返回）'],
  ['api_version', APP, 'OTA/ota_engine.c', 227, 264, 'POST /fuse-ota/{pid}/{dev}/version'],
  ['api_check', APP, 'OTA/ota_engine.c', 266, 321, 'GET /fuse-ota/{pid}/{dev}/check?type=1&version=… —— type 必须是 1'],
  ['api_status', APP, 'OTA/ota_engine.c', 323, 355, 'POST /fuse-ota/{pid}/{dev}/{tid}/status  {"step":N}'],

  /* ---------------- App 侧：下载与校验 ---------------- */
  ['dl_on_data', APP, 'OTA/ota_engine.c', 407, 476, '★ 下载回调：SHA-256 + MD5 同流更新，攒够 256 字节写一次 W25Q64，每 16KB 存检查点'],
  ['download_try_a', APP, 'OTA/ota_engine.c', 486, 581, 'ota_download_try 前半：断点判定（重扫 0~offset 补哈希）或整块擦除暂存区'],
  ['download_try_b', APP, 'OTA/ota_engine.c', 583, 675, '下载循环：最多 8 轮 Range 续传 + 截断检测（实收 < Content-Length 即 TRUNCATED）'],
  ['download_try_c', APP, 'OTA/ota_engine.c', 677, 721, '收齐判定 + 长度校验 + 平台 MD5 校验 + SHA-256 收尾'],
  ['download_wrap', APP, 'OTA/ota_engine.c', 733, 751, '校验失败兜底：擦除暂存区、从头完整重下一次'],
  ['backup_app', APP, 'OTA/ota_engine.c', 759, 814, 'ota_backup_current_app：探测 A 槽实际长度 → 擦备份区 → 1KB 分块复制并算 SHA-256'],
  ['probe_len', APP, 'OTA/ota_engine.c', 363, 391, 'ota_probe_run_len：从 A 槽末尾反扫第一个非 0xFF 并 4KB 对齐'],
  ['apply_reboot', APP, 'OTA/ota_engine.c', 818, 848, 'ota_apply_and_reboot：置 TRY_NEW / boot_count=0 / ota_tid，3 秒倒计时后 NVIC_SystemReset'],
  ['confirm_success', APP, 'OTA/ota_engine.c', 949, 994, 'ota_confirm_boot_success：固化为 NORMAL、清计数与暂存信息'],
  ['boot_confirm', APP2, 'OTA/ota_engine.c', 1035, 1086, 'ota_boot_confirm_if_needed：TRY_NEW 首启横幅 + 30s 静默窗口 + 确认'],
  ['pending201', APP, 'OTA/ota_engine.c', 998, 1026, 'ota_report_pending_201：补报上次升级成功'],
  ['recovery_init', APP, 'OTA/ota_engine.c', 852, 945, 'ota_init_recovery_if_empty：首次运行时把当前 A 槽固件固化到恢复区'],

  /* ---------------- 通信链路 ---------------- */
  ['http_req_head', APP, 'OTA/http_client.c', 154, 245, 'http_client_request_once：CIPSTART → CIPSEND → 状态行容错跳过 8 行'],
  ['http_req_hdr', APP, 'OTA/http_client.c', 247, 289, '响应头解析：Content-Length / Content-Range / Transfer-Encoding / Ota-Errno'],
  ['http_req_body', APP, 'OTA/http_client.c', 291, 409, '正文读取：chunked 解码 / 定长 / 读到连接关闭'],
  ['http_wrap', APP, 'OTA/http_client.c', 419, 445, '请求包装：下载类请求不重试，其余最多 3 次'],
  ['esp_init', APP, 'OTA/esp01s.c', 258, 331, 'esp01s_init：先启 DMA 循环接收，再 AT 握手 / ATE0 / CIPMUX=0 / CIPMODE=0'],
  ['esp_parse', APP, 'OTA/esp01s.c', 135, 240, '★ +IPD,<len>: 帧头剥离状态机（HEAD/LEN/DATA），并识别 CLOSED/Unlink'],
  ['esp_join_ap', APP, 'OTA/esp01s.c', 402, 407, 'esp01s_join_ap：AT+CWJAP 入网（超时 15000ms）'],
  ['esp_dma', APP, 'OTA/esp01s.c', 37, 55, 'DMA 循环缓冲 → 环形缓冲：靠 NDTR 轮询搬运，不依赖中断'],
  ['esp_read', APP, 'OTA/esp01s.c', 785, 825, 'esp01s_read：从 s_data 流缓冲搬字节，超时/断开分别返回 ESP_TIMEOUT / ESP_CLOSED'],
  ['esp_send', APP, 'OTA/esp01s.c', 652, 700, 'esp01s_send：AT+CIPSEND 等 ">" 后发数据'],
  ['esp_at_cmd', APP, 'OTA/esp01s.c', 352, 400, 'esp01s_at_cmd：滚动匹配期望串，同时识别 ERROR/FAIL'],
  ['esp_tcp_connect', APP, 'OTA/esp01s.c', 507, 555, 'esp01s_tcp_connect：已知主机 IP 直连优先（规避模块 DNS 挂起）'],
  ['esp01s_h', APP, 'OTA/esp01s.h', 33, 41, '接收缓冲规格：环形缓冲 4096B + 数据流缓冲 8192B', '#define 接收缓冲规格'],
  ['uart_rx_cb', APP, 'bsp/UART/uart_handle.c', 124, 157, 'HAL_UARTEx_RxEventCallback：OTA 模式下 USART3 必须让路给 esp01s'],
  ['w25q_ext_write', APP, 'OTA/w25q_ext.c', 146, 182, 'w25q16_write：4KB 分块调用 W25Q64_WriteData（内部按 256B 页跨页写）'],
  ['w25q_ext_erase', APP, 'OTA/w25q_ext.c', 186, 210, 'w25q16_erase_sector / erase_block（块擦除强制 64KB 对齐检查）'],
];

/* ------------------------------------------------------------------ */

function decodeBuffer(buf) {
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(buf);
  } catch (e) {
    /* esp_handle.c 等历史文件是 GBK 编码；Node 内置 full-icu 支持 gbk */
    return new TextDecoder('gbk').decode(buf);
  }
}

function readText(rel) {
  const abs = path.join(ROOT, rel);
  const buf = fs.readFileSync(abs);
  return decodeBuffer(buf).replace(/\r\n/g, '\n').replace(/\r/g, '\n');
}

function fileInfo(rel) {
  const abs = path.join(ROOT, rel);
  const st = fs.statSync(abs);
  return { bytes: st.size, mtime: st.mtime.toISOString().slice(0, 19).replace('T', ' ') };
}

const snippets = {};
const meta = [];
const errors = [];

for (const [id, proj, file, from, to, note, funcOverride] of SPECS) {
  const rel = proj + '/' + file;
  let text;
  try {
    text = readText(rel);
  } catch (e) {
    errors.push('MISSING FILE: ' + rel);
    continue;
  }
  const all = text.split('\n');
  /* 末尾空行不算 */
  while (all.length && all[all.length - 1] === '') all.pop();

  if (to > all.length) {
    errors.push('RANGE OVERFLOW: ' + rel + ' wants ' + to + ' but file has ' + all.length);
  }
  const end = Math.min(to, all.length);
  const lines = [];
  for (let n = from; n <= end; n++) lines.push([n, all[n - 1]]);

  /* 函数名：从片段里找第一处形如 name( 的定义行，找不到则用 note 里给的隐含值 */
  const func = funcOverride || guessFunc(lines) || '(非函数体)';

  snippets[id] = {
    id,
    project: proj,
    file: file,
    path: rel,
    func: func,
    from: from,
    to: end,
    note: note,
    grade: 'A',
    lines: lines,
  };
  meta.push({ id, path: rel, from, to });
}

function guessFunc(lines) {
  const re = /^\s*(?:static\s+|inline\s+|const\s+)*[A-Za-z_][A-Za-z0-9_\s\*]{0,40}?\b([A-Za-z_][A-Za-z0-9_]*)\s*\(/;
  for (const [n, l] of lines) {
    if (/;\s*$/.test(l)) continue;
    if (/^\s*(\/\/|\*|\/\*)/.test(l)) continue;
    if (/^\s*(if|for|while|switch|return|else|do)\b/.test(l)) continue;
    const m = re.exec(l);
    if (m) {
      const name = m[1];
      if (['sizeof', 'memcpy', 'memset', 'strcmp', 'strncmp', 'strstr', 'snprintf', 'printf', 'strlen'].indexOf(name) >= 0) continue;
      return name;
    }
  }
  return null;
}

/* --------------------------- 函数索引 --------------------------- */

const SCAN_FILES = {
  [BOOT]: [
    'Boot/boot_start.c', 'Boot/app_jump.c', 'Boot/param_area.c', 'Boot/flash_if.c',
    'Boot/boot_ext.c', 'Boot/boot_shutdown.c', 'Boot/boot_wdg.c', 'Boot/boot_log.c',
    'Core/Src/main.c', 'W25q64/w25q64.c', 'UART/uart_handle.c', 'Core/Src/usart.c',
  ],
  [APP]: [
    'OTA/ota_engine.c', 'OTA/ota_task.c', 'OTA/ota_net_switch.c', 'OTA/esp01s.c',
    'OTA/http_client.c', 'OTA/param_area.c', 'OTA/flash_if.c', 'OTA/w25q_ext.c',
    'OTA/ota_rollback_test.c', 'OTA/crc32.c', 'OTA/sha256.c', 'OTA/md5.c',
    'App/esp_handle.c', 'Core/Src/main.c', 'Core/Src/freertos.c',
    'bsp/UART/uart_handle.c', 'bsp/W25q64/w25q64.c',
  ],
};

const funcs = [];
const TYPE_RE = /^(?:static\s+|inline\s+|extern\s+)*(?:void|int|char|float|double|size_t|u?int(?:8|16|32|64)_t|int32_t|HAL_StatusTypeDef|HAL_UART_StateTypeDef|esp_err_t|ota_state_t|DMA_HandleTypeDef|uint8_t|volatile\s+\w+)\b/;

for (const proj of Object.keys(SCAN_FILES)) {
  for (const file of SCAN_FILES[proj]) {
    const rel = proj + '/' + file;
    let text;
    try {
      text = readText(rel);
    } catch (e) {
      continue;
    }
    const lines = text.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (!line || /^\s/.test(line)) continue;        /* 顶层定义顶格 */
      if (!TYPE_RE.test(line)) continue;
      if (/;\s*$/.test(line)) continue;               /* 声明不是定义 */
      const m = /([A-Za-z_][A-Za-z0-9_]*)\s*\(/.exec(line);
      if (!m) continue;
      /* 找 { 所在行（允许跨行参数列表） */
      let j = i;
      let brace = -1;
      while (j < lines.length && j < i + 8) {
        if (lines[j].indexOf('{') >= 0) { brace = j; break; }
        if (lines[j].indexOf(';') >= 0) break;
        j++;
      }
      if (brace < 0) continue;
      funcs.push({
        project: proj,
        file: file,
        func: m[1],
        line: i + 1,
        static: /^static\b/.test(line.trim()),
        fileLine: line.trim().slice(0, 120),
      });
    }
  }
}

/* --------------------------- 工程统计 --------------------------- */
const stats = [];
for (const proj of [BOOT, APP, APP2]) {
  let files = 0;
  let lines = 0;
  const walk = (dir) => {
    const abs = path.join(ROOT, proj, dir);
    let ents;
    try {
      ents = fs.readdirSync(abs, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const ent of ents) {
      const relDir = dir ? dir + '/' + ent.name : ent.name;
      if (ent.isDirectory()) {
        if (['Drivers', 'Middlewares', 'MDK-ARM', 'RBG_Static'].indexOf(ent.name) >= 0) continue;
        walk(relDir);
      } else if (/\.(c|h|s)$/.test(ent.name)) {
        files++;
        try {
          lines += readText(proj + '/' + relDir).split('\n').length;
        } catch (e) { /* ignore */ }
      }
    }
  };
  walk('');
  stats.push({ project: proj, files, lines });
}

/* --------------------------- 输出 --------------------------- */

fs.mkdirSync(OUT_DIR, { recursive: true });

const header = (what) =>
  '/* 自动生成，请勿手改 —— 由 tools/gen-code.js 从真实工程读取\n' +
  ' * 生成时间：' + new Date().toISOString() + '\n' +
  ' * 内容：' + what + '\n */\n';

const codeJs =
  header('源码片段（项目 / 相对路径 / 函数 / 起止行 / 逐行原文）') +
  'window.OTA_CODE = ' +
  JSON.stringify({ generatedAt: new Date().toISOString(), root: ROOT, snippets }, null, 1) +
  ';\n';

const indexJs =
  header('函数索引与工程统计') +
  'window.OTA_INDEX = ' +
  JSON.stringify({
    generatedAt: new Date().toISOString(),
    functions: funcs,
    stats: stats,
  }, null, 1) +
  ';\n';

fs.writeFileSync(path.join(OUT_DIR, 'code.js'), codeJs, 'utf8');
fs.writeFileSync(path.join(OUT_DIR, 'codeindex.js'), indexJs, 'utf8');

console.log('snippets : ' + Object.keys(snippets).length);
console.log('functions: ' + funcs.length);
console.log('stats    : ' + JSON.stringify(stats));
if (errors.length) {
  console.log('\n!! WARNINGS !!');
  errors.forEach((e) => console.log('  ' + e));
} else {
  console.log('no range warnings');
}
