/*
 * cdp-test.js —— 用 Chrome DevTools Protocol 真实驱动页面做交互测试
 *
 * 为什么不用“截图看看”就算完：
 *   需求要求“播放、暂停、继续、重新开始、上下场景、单步、拖动时间轴、倍速”都必须真正
 *   作用在同一条时间轴上，并且拖动后代码/变量/日志/Flash 状态要同步恢复。
 *   这里通过 CDP 直接点击页面控件、派发鼠标拖动事件、读取页面内部状态来验证。
 *
 * 用法： node tools/cdp-test.js
 * 输出： 每个用例 PASS/FAIL，最后打印 SELFTEST 汇总；进程退出码 0/1。
 */
'use strict';

const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');
const path = require('path');

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const PORT = 9333;
const PROFILE = path.join(__dirname, '..', 'shots', '.cdp-profile');
const PAGE = 'file:///D:/ESP32_IDF_project_/html_OTA/html/expert.html';

const results = [];
function ok(name, cond, detail) {
  results.push({ name, pass: !!cond, detail: detail === undefined ? '' : String(detail) });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function httpJson(url) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, (res) => {
      let d = '';
      res.on('data', (c) => { d += c; });
      res.on('end', () => {
        try { resolve(JSON.parse(d)); } catch (e) { reject(e); }
      });
    });
    req.on('error', reject);
    req.setTimeout(3000, () => { req.destroy(new Error('timeout')); });
  });
}

async function waitFor(cond, ms, step) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    if (await cond()) return true;
    await sleep(step || 120);
  }
  return false;
}

/* ---------------- CDP 客户端（最小实现） ---------------- */
class CDP {
  constructor(ws) {
    this.ws = ws;
    this.id = 0;
    this.pending = new Map();
    ws.addEventListener('message', (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch (e) { return; }
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        if (msg.error) reject(new Error(JSON.stringify(msg.error)));
        else resolve(msg.result);
      }
    });
  }
  send(method, params) {
    const id = ++this.id;
    const p = new Promise((resolve, reject) => this.pending.set(id, { resolve, reject }));
    this.ws.send(JSON.stringify({ id, method, params: params || {} }));
    return p;
  }
  async eval(expr) {
    const r = await this.send('Runtime.evaluate', {
      expression: expr, returnByValue: true, awaitPromise: true
    });
    if (r.exceptionDetails) {
      throw new Error('EVAL ERROR: ' + (r.exceptionDetails.exception
        ? r.exceptionDetails.exception.description : r.exceptionDetails.text));
    }
    return r.result.value;
  }
  async mouse(type, x, y) {
    await this.send('Input.dispatchMouseEvent', {
      type, x, y, button: 'left', clickCount: 1, buttons: type === 'mouseReleased' ? 0 : 1
    });
  }
}

(async function main() {
  fs.mkdirSync(PROFILE, { recursive: true });

  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-sandbox', '--hide-scrollbars',
    '--remote-debugging-port=' + PORT,
    '--user-data-dir=' + PROFILE,
    '--window-size=1680,1000',
    '--no-first-run', '--no-default-browser-check',
    'about:blank'
  ], { stdio: 'ignore' });

  let closed = false;
  const kill = () => { if (!closed) { closed = true; try { chrome.kill(); } catch (e) {} } };
  process.on('exit', kill);

  try {
    /* 等 DevTools 端口就绪 */
    const up = await waitFor(async () => {
      try { await httpJson('http://127.0.0.1:' + PORT + '/json/version'); return true; } catch (e) { return false; }
    }, 15000, 200);
    if (!up) throw new Error('DevTools 端口未就绪');
    ok('Chrome DevTools 端口已就绪', true);

    /* 新版 Chrome 的 /json/new 只接受 PUT，改为复用启动时的 about:blank 页再导航 */
    const list = await httpJson('http://127.0.0.1:' + PORT + '/json/list');
    const target = list.find((t) => t.type === 'page');
    if (!target) throw new Error('找不到可用的 page target');
    const wsUrl = target.webSocketDebuggerUrl;
    const ws = new WebSocket(wsUrl);
    await new Promise((res, rej) => {
      ws.addEventListener('open', res);
      ws.addEventListener('error', rej);
    });
    const cdp = new CDP(ws);
    await cdp.send('Runtime.enable');
    await cdp.send('Page.enable');
    await cdp.send('Page.navigate', { url: PAGE + '?scenario=normal&t=0' });

    /* 等页面 ready（app.js 会加 body.ready） */
    const ready = await waitFor(async () => {
      try { return await cdp.eval('document.body.classList.contains("ready")'); } catch (e) { return false; }
    }, 15000, 150);
    ok('页面初始化完成（body.ready）', ready);

    /* ---------- 1. 基本结构 ---------- */
    const struct = await cdp.eval(`(function(){
      return {
        blocks: document.querySelectorAll('.s-block').length,
        scenes: document.querySelectorAll('#sceneList .scene-chip').length,
        bands: document.querySelectorAll('#trackBands .band').length,
        marks: document.querySelectorAll('#trackMarks .mark').length,
        codeRows: document.querySelectorAll('#codeBody .cl').length,
        tabs: document.querySelectorAll('#tabs [data-tab]').length,
        duration: window.OTA_TIMELINE.duration,
        stepCount: document.querySelectorAll('#trackMarks .mark').length
      };
    })()`);
    ok('主画面含 ≥10 个芯片模块', struct.blocks >= 10, struct.blocks);
    ok('时间轴含 18 个场景带', struct.bands === 18, struct.bands);
    ok('时间轴含事件标记', struct.marks > 10, struct.marks);
    ok('总时长约 214s', Math.abs(struct.duration - 214200) < 2000, struct.duration);
    ok('5 个面板标签', struct.tabs === 5, struct.tabs);

    /* ---------- 2. 播放 / 暂停 ---------- */
    await cdp.eval('document.querySelector("#btnPlay").click()');
    await sleep(700);
    const playing = await cdp.eval('window.OTA_TIMELINE.playing');
    const tA = await cdp.eval('window.OTA_TIMELINE.time');
    ok('点击播放后进入播放态', playing === true, playing);
    ok('播放后时间在推进', tA > 300, tA.toFixed(0));

    await cdp.eval('document.querySelector("#btnPlay").click()');
    await sleep(500);
    const tB = await cdp.eval('window.OTA_TIMELINE.time');
    await sleep(500);
    const tC = await cdp.eval('window.OTA_TIMELINE.time');
    ok('点击暂停后时间冻结', Math.abs(tC - tB) < 1, (tC - tB).toFixed(3));
    ok('暂停态 playing=false', (await cdp.eval('window.OTA_TIMELINE.playing')) === false);

    /* ---------- 3. 倍速 ---------- */
    await cdp.eval('window.OTA_TIMELINE.seek(0,"test")');
    await cdp.eval('document.querySelector("[data-speed=\\"2\\"]").click()');
    await cdp.eval('document.querySelector("#btnPlay").click()');
    await sleep(900);
    const tSpeed = await cdp.eval('window.OTA_TIMELINE.time');
    await cdp.eval('document.querySelector("#btnPlay").click()');
    ok('2× 倍速下同样 0.9s 走过的时间约 1.8s', tSpeed > 1300 && tSpeed < 2600, tSpeed.toFixed(0));
    await cdp.eval('document.querySelector("[data-speed=\\"1\\"]").click()');
    ok('倍速控件 active 状态同步', await cdp.eval('document.querySelector("[data-speed=\\"1\\"]").classList.contains("active")'));

    /* ---------- 4. 单步 / 场景跳转 ---------- */
    await cdp.eval('window.OTA_TIMELINE.seek(0,"test")');
    const step0 = await cdp.eval('window.OTA_STATE.stepAt(window.OTA_TIMELINE.scenario, window.OTA_TIMELINE.time).id');
    await cdp.eval('document.querySelector("#btnNextStep").click()');
    await sleep(200);
    const step1 = await cdp.eval('window.OTA_STATE.stepAt(window.OTA_TIMELINE.scenario, window.OTA_TIMELINE.time).id');
    ok('单步前进切换到下一步骤', step0 !== step1, step0 + ' → ' + step1);

    await cdp.eval('document.querySelector("#btnNextScene").click()');
    await sleep(200);
    const scene1 = await cdp.eval('window.OTA_STATE.sceneAt(window.OTA_TIMELINE.scenario, window.OTA_TIMELINE.time).title');
    ok('下一场景跳转到第 2 个场景', scene1 === 'BootLoader 初始化', scene1);

    await cdp.eval('document.querySelector("#btnPrevScene").click()');
    await sleep(200);
    const scene0 = await cdp.eval('window.OTA_STATE.sceneAt(window.OTA_TIMELINE.scenario, window.OTA_TIMELINE.time).title');
    ok('上一场景回到第 1 个场景', scene0 === '上电与复位', scene0);

    /* ---------- 5. 拖动时间轴（真实鼠标事件） ---------- */
    const box = await cdp.eval(`(function(){
      var r = document.getElementById('track').getBoundingClientRect();
      return {x:r.left, y:r.top + r.height/2, w:r.width};
    })()`);
    await cdp.mouse('mousePressed', box.x + box.w * 0.70, box.y);
    await cdp.mouse('mouseReleased', box.x + box.w * 0.70, box.y);
    await sleep(300);
    const dragT = await cdp.eval('window.OTA_TIMELINE.time');
    ok('拖动到 70% 位置后时间 ≈ 70% 总长', Math.abs(dragT / struct.duration - 0.70) < 0.02, (dragT / struct.duration).toFixed(3));

    /* 拖动后三面板必须与时间一致 */
    const sync = await cdp.eval(`(function(){
      var S = window.OTA_STATE.build(window.OTA_TIMELINE.scenario, window.OTA_TIMELINE.time);
      var stepFunc = document.getElementById('stageStepTitle').textContent;
      var codeFunc = document.querySelector('#codeMeta .badge-func');
      var logCount = document.querySelectorAll('#logBody .lg').length || 0;
      var varsFlag = document.querySelector('#varBody .vr[data-vk="boot_flag"] .vv');
      return {
        stepId: S.step.id, stepLabel: S.step.label,
        headerStep: stepFunc,
        codeFunc: codeFunc ? codeFunc.textContent : '',
        snipFunc: S.step.code && window.OTA_CODE.snippets[S.step.code] ? window.OTA_CODE.snippets[S.step.code].func + '()' : '',
        logCount: logCount, stateLogs: S.logs.length,
        flagText: varsFlag ? varsFlag.textContent : '',
        stateFlag: S.vars.boot_flag
      };
    })()`);
    ok('拖动后主画面步骤标题与状态机一致', sync.headerStep === sync.stepLabel, sync.headerStep + ' / ' + sync.stepLabel);
    ok('拖动后代码面板函数与状态机一致', !sync.snipFunc || sync.codeFunc === sync.snipFunc,
      sync.codeFunc + ' / ' + sync.snipFunc);

    /* ---------- 6. 跳跃 == 顺序重放（状态恢复正确性） ---------- */
    const eq = await cdp.eval(`(function(){
      var scn = window.OTA_TIMELINE.scenario;
      var T = Math.floor(scn.total * 0.63);
      var a = JSON.stringify(window.OTA_STATE.build(scn, T));
      window.OTA_TIMELINE.seek(0,'t');
      window.OTA_TIMELINE.seek(T,'t');
      var b = JSON.stringify(window.OTA_STATE.build(scn, T));
      return { same: a === b, len: a.length };
    })()`);
    ok('任意时刻跳转后状态与顺序重放完全一致', eq.same, 'len=' + eq.len);

    /* ---------- 7. 代码行点击 → 跳到对应步骤 ---------- */
    /* 先跳到接近片尾并等一帧渲染完成，再点一行不属于当前步骤高亮区的代码 */
    await cdp.eval('window.OTA_TIMELINE.seek(window.OTA_TIMELINE.duration * 0.99, "t")');
    await sleep(300);
    const lineJump = await cdp.eval(`(function(){
      var before = window.OTA_TIMELINE.time;
      var rows = Array.prototype.slice.call(document.querySelectorAll('#codeBody .cl[data-line]'));
      var plain = rows.filter(function(r){ return !r.classList.contains('hl'); });
      var row = plain.length ? plain[0] : rows[0];
      if (!row) return {ok:false, why:'no code row'};
      row.click();
      var after = window.OTA_TIMELINE.time;
      var st = window.OTA_STATE.stepAt(window.OTA_TIMELINE.scenario, after);
      return { ok: after !== before, line: row.getAttribute('data-line'),
               before: Math.round(before), after: Math.round(after), step: st.id };
    })()`);
    ok('点击代码行可定位到对应动画步骤', lineJump.ok, JSON.stringify(lineJump));

    /* ---------- 8. 面板切换 ---------- */
    for (const tab of ['vars', 'log', 'flash', 'index', 'code']) {
      await cdp.eval('window.OTA_PANELS.switchTab("' + tab + '")');
      const active = await cdp.eval('document.querySelector(".panel[data-body=\\"" + "' + tab + '" + "\\"]").classList.contains("active")');
      const hasContent = await cdp.eval(
        'document.querySelector(".panel[data-body=\\"" + "' + tab + '" + "\\"]").innerHTML.length'
      );
      ok('面板 ' + tab + ' 可切换且有内容', active && hasContent > 50, hasContent);
    }

    /* ---------- 9. 场景切换下拉 ---------- */
    await cdp.eval(`(function(){
      var sel = document.getElementById('scenarioSel');
      sel.value = 'fail-staging-sha';
      sel.dispatchEvent(new Event('change'));
    })()`);
    await sleep(600);
    const switched = await cdp.eval(`(function(){
      return {
        id: window.OTA_TIMELINE.scenario.id,
        badge: document.getElementById('modeBadge').textContent,
        steps: window.OTA_TIMELINE.scenario.steps.length
      };
    })()`);
    ok('切换场景到 fail-staging-sha', switched.id === 'fail-staging-sha', switched.id);

    const rb = await cdp.eval(`(function(){
      var scn = window.OTA_TIMELINE.scenario;
      var S = window.OTA_STATE.build(scn, scn.total);
      return { ver: S.vars.version, flag: S.vars.boot_flag, bk: S.vars.backup_status, staging: S.ext.staging.mode };
    })()`);
    ok('回滚场景终态：版本回到 1.0.0 且 flag=NORMAL',
      rb.ver === 0x010000 && rb.flag === 0, JSON.stringify(rb));
    ok('回滚场景终态：暂存区标记损坏', rb.staging === 'corrupt', rb.staging);

    /* ---------- 10. 建议方案模式的显式标识 ---------- */
    await cdp.eval(`(function(){
      var sel = document.getElementById('scenarioSel');
      sel.value = 'suggest-ab';
      sel.dispatchEvent(new Event('change'));
    })()`);
    await sleep(500);
    const sg = await cdp.eval(`(function(){
      return {
        badge: document.getElementById('modeBadge').textContent,
        isSuggest: document.body.classList.contains('is-suggest'),
        grade: document.getElementById('hGrade').textContent,
        overlay: getComputedStyle(document.querySelector('.stage-frame'), '::after').content
      };
    })()`);
    ok('建议方案模式有"非现有实现"标识', /建议方案模拟/.test(sg.badge) && /非现有实现/.test(sg.badge), sg.badge);
    ok('建议方案模式有视觉区分（is-suggest）', sg.isSuggest === true);
    ok('建议方案模式步骤等级为 C', /^C/.test(sg.grade), sg.grade);

    /* ---------- 11. 控制台错误检查 ---------- */
    const errs = await cdp.eval('window.__errs ? window.__errs.length : 0');
    ok('页面无未捕获脚本错误', errs === 0, errs);

  } catch (e) {
    ok('测试执行异常', false, e.message);
  } finally {
    kill();
    /* 清理浏览器临时 profile，不给交付目录留垃圾 */
    await sleep(400);
    try { fs.rmSync(PROFILE, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  }

  let pass = 0, fail = 0;
  results.forEach((r) => {
    if (r.pass) pass++; else fail++;
    console.log((r.pass ? 'PASS  ' : 'FAIL  ') + r.name + (r.detail ? '   [' + r.detail + ']' : ''));
  });
  console.log('\nSELFTEST pass=' + pass + ' fail=' + fail);
  process.exit(fail === 0 ? 0 : 1);
})();
