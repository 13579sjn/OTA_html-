/*
 * cdp-story-test.js —— 新手讲解版（index.html）的交互测试
 *
 * 验证的是"像视频一样"这件事本身：
 *   播放/暂停/拖时间轴/换节/倍速/字幕/源码抽屉，以及"拖动后画面与字幕是否回到该时刻"。
 *
 * 用法：node tools/cdp-story-test.js
 */
'use strict';

const { spawn } = require('child_process');
const http = require('http');
const path = require('path');
const fs = require('fs');

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const PORT = 9336;
const PROFILE = path.join(__dirname, '..', 'shots', '.cdp-story');
const PAGE = 'file:///D:/ESP32_IDF_project_/html_OTA/html/index.html';

const out = [];
const ok = (n, c, d) => out.push({ n, p: !!c, d: d === undefined ? '' : String(d) });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function httpJson(url) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, (res) => {
      let s = '';
      res.on('data', (c) => { s += c; });
      res.on('end', () => { try { resolve(JSON.parse(s)); } catch (e) { reject(e); } });
    });
    req.on('error', reject);
    req.setTimeout(3000, () => req.destroy(new Error('timeout')));
  });
}

(async function () {
  fs.mkdirSync(PROFILE, { recursive: true });
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-sandbox', '--hide-scrollbars',
    '--remote-debugging-port=' + PORT, '--user-data-dir=' + PROFILE,
    '--window-size=1680,1000', '--no-first-run', 'about:blank'
  ], { stdio: 'ignore' });

  let killed = false;
  const kill = () => { if (!killed) { killed = true; try { chrome.kill(); } catch (e) { } } };

  try {
    for (let i = 0; i < 80; i++) {
      try { await httpJson('http://127.0.0.1:' + PORT + '/json/version'); break; } catch (e) { await sleep(200); }
    }
    const list = await httpJson('http://127.0.0.1:' + PORT + '/json/list');
    const target = list.find((t) => t.type === 'page');
    const ws = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej); });

    let id = 0;
    const pending = new Map();
    ws.addEventListener('message', (ev) => {
      const m = JSON.parse(ev.data);
      if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
    });
    const send = (method, params) => new Promise((res) => {
      const i = ++id; pending.set(i, res);
      ws.send(JSON.stringify({ id: i, method, params: params || {} }));
    });
    const ev = async (expr) => {
      const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
      const v = r.result && r.result.result;
      if (v && v.subtype === 'error') throw new Error(v.description);
      if (r.result && r.result.exceptionDetails) throw new Error(r.result.exceptionDetails.text);
      return v ? v.value : undefined;
    };

    await send('Page.enable');
    await send('Runtime.enable');
    await send('Page.navigate', { url: PAGE });
    for (let i = 0; i < 100; i++) {
      if (await ev('document.body.classList.contains("ready")')) break;
      await sleep(150);
    }
    ok('页面初始化完成', await ev('document.body.classList.contains("ready")'));

    /* 1. 结构 */
    const st = await ev(`(function(){
      return {
        acts: window.STORY_PLAYER.acts.length,
        total: window.STORY_PLAYER.total,
        dots: document.querySelectorAll('#dots .adot').length,
        bands: document.querySelectorAll('#bands .aband').length,
        blocks: document.querySelectorAll('#world .node').length,
        capText: document.getElementById('capText').textContent.length
      };
    })()`);
    ok('共 14 节', st.acts === 14, st.acts);
    ok('总时长约 362 秒', Math.abs(st.total - 362000) < 3000, st.total);
    ok('章节点与时间轴分段都渲染出来了', st.dots === 14 && st.bands === 14, st.dots + '/' + st.bands);
    ok('主画面四个部件都在（云/模块/单片机/仓库）', st.blocks === 4, st.blocks);
    ok('首屏有字幕', st.capText > 4, st.capText);

    /* 2. 播放 / 暂停 */
    await ev('STORY_PLAYER.seek(0)');
    await ev('document.getElementById("btnPlay").click()');
    await sleep(900);
    const p1 = await ev('STORY_PLAYER.time');
    ok('点播放后时间在走', p1 > 400, Math.round(p1));
    await ev('document.getElementById("btnPlay").click()');
    await sleep(400);
    const a = await ev('STORY_PLAYER.time');
    await sleep(500);
    const b = await ev('STORY_PLAYER.time');
    ok('暂停后时间冻结', Math.abs(b - a) < 1, (b - a).toFixed(3));

    /* 3. 字幕随播放推进（打字机） */
    await ev('STORY_PLAYER.seek(0)');
    await ev('STORY_PLAYER.play()');
    await sleep(300);
    const c1 = await ev('document.getElementById("capText").textContent.length');
    await sleep(900);
    const c2 = await ev('document.getElementById("capText").textContent.length');
    await ev('STORY_PLAYER.pause()');
    ok('播放时字幕逐字出现', c2 > c1 && c2 > 3, c1 + ' → ' + c2);

    /* 4. 拖动时间轴（真实鼠标事件） */
    const box = await ev(`(function(){var r=document.getElementById('track').getBoundingClientRect();
      return {x:r.left,y:r.top+r.height/2,w:r.width};})()`);
    const cx = box.x + box.w * 0.5, cy = box.y;
    await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: cx, y: cy, button: 'left', clickCount: 1, buttons: 1 });
    await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: cx, y: cy, button: 'left', clickCount: 1, buttons: 0 });
    await sleep(400);
    const after = await ev(`(function(){
      var S = STORY_PLAYER.state;
      return { t: STORY_PLAYER.time, total: STORY_PLAYER.total,
               act: S.act.no, actTitle: S.act.title,
               cap: document.getElementById('capText').textContent.trim(),
               headAct: document.getElementById('actTitle').textContent };
    })()`);
    ok('拖动到 50% 时间正确', Math.abs(after.t / after.total - 0.5) < 0.02, (after.t / after.total).toFixed(3));
    ok('拖动后顶栏节标题与状态一致', after.headAct === after.actTitle, after.headAct + ' / ' + after.actTitle);
    ok('拖动后字幕切到该时刻的句子', after.cap.length > 4 && after.cap.indexOf('｜') < 0, after.cap.slice(0, 26));

    /* 5. 跳到指定节 */
    await ev('document.querySelectorAll("#dots .adot")[6].click()');
    await sleep(300);
    const act7 = await ev(`(function(){ return {no: STORY_PLAYER.state.act.no,
      t: STORY_PLAYER.time, cap: document.getElementById('capText').textContent.length}; })()`);
    ok('点第 7 个章节点跳到第 7 节', act7.no === 7, act7.no);
    ok('跳节后字幕立即更新', act7.cap > 4, act7.cap);

    /* 6. 倍速 */
    await ev('STORY_PLAYER.seek(0)');
    await ev('document.querySelector("[data-s=\\"2\\"]").click()');
    await ev('STORY_PLAYER.play()');
    await sleep(900);
    const fast = await ev('STORY_PLAYER.time');
    await ev('STORY_PLAYER.pause()');
    ok('2× 倍速下 0.9 秒走过约 1.8 秒', fast > 1300 && fast < 2600, Math.round(fast));
    await ev('document.querySelector("[data-s=\\"1\\"]").click()');

    /* 7. 状态可复现（拖回去画面要一样） */
    const same = await ev(`(function(){
      function snap(){ var S = STORY_PLAYER.state;
        return JSON.stringify({a:S.act.id, p:Math.round(S.p*1000), appVer:S.appVer,
          flag:S.paramFlag, stg:Math.round(S.stg.fill*100), bk:Math.round(S.bk.fill*100),
          cam:[Math.round(S.cam.x),Math.round(S.cam.y),+S.cam.s.toFixed(3)],
          bubbles:(S.bubbles||[]).map(function(b){return b.text;})}); }
      STORY_PLAYER.seek(150000); var x = snap();
      STORY_PLAYER.seek(30000); STORY_PLAYER.seek(150000); var y = snap();
      return { same: x === y, x: x };
    })()`);
    ok('同一时刻的画面状态可完全复现', same.same, same.x.slice(0, 90));

    /* 8. 源码抽屉 */
    await ev('STORY_PLAYER.seek(262000)');
    await ev('document.getElementById("btnCode").click()');
    await sleep(400);
    const code = await ev(`(function(){
      var d = document.getElementById('codeDrawer');
      return { open: d.classList.contains('open'),
               lines: d.querySelectorAll('.code-pre span').length,
               hl: d.querySelectorAll('.code-pre span.hl').length,
               file: (d.querySelector('.cf')||{}).textContent || '' };
    })()`);
    ok('源码抽屉能打开', code.open === true);
    ok('抽屉里是真实代码且带行号高亮', code.lines > 10 && code.hl > 0, code.lines + ' 行 / 高亮 ' + code.hl);
    ok('抽屉显示源文件路径', /\.(c|h|s)$/.test(code.file), code.file);

    /* 9. 没有脚本错误 */
    const errs = await ev('window.__err || 0');
    ok('无未捕获脚本错误', errs === 0, errs);

  } catch (e) {
    ok('测试执行异常', false, e.message);
  } finally {
    kill();
    await sleep(400);
    try { fs.rmSync(PROFILE, { recursive: true, force: true }); } catch (e) { }
  }

  let pass = 0, fail = 0;
  out.forEach((r) => {
    if (r.p) pass++; else fail++;
    console.log((r.p ? 'PASS  ' : 'FAIL  ') + r.n + (r.d ? '   [' + r.d + ']' : ''));
  });
  console.log('\nSELFTEST pass=' + pass + ' fail=' + fail);
  process.exit(fail === 0 ? 0 : 1);
})();
