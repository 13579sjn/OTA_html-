/* cdp-dbg.js —— 调试用：打印某个元素的计算样式与位置 */
'use strict';
const { spawn } = require('child_process');
const http = require('http');
const path = require('path');
const fs = require('fs');

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const PORT = 9341;
const PROFILE = path.join(__dirname, '..', 'shots', '.cdp-dbg');
const URL_ = process.argv[2] || 'file:///D:/ESP32_IDF_project_/html_OTA/html/index.html';
const SEL = process.argv[3] || '#codeDrawer';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const get = (u) => new Promise((res, rej) => {
  http.get(u, (r) => { let d = ''; r.on('data', (c) => d += c); r.on('end', () => { try { res(JSON.parse(d)); } catch (e) { rej(e); } }); }).on('error', rej);
});

(async () => {
  fs.mkdirSync(PROFILE, { recursive: true });
  const c = spawn(CHROME, ['--headless=new', '--disable-gpu', '--no-sandbox',
    '--remote-debugging-port=' + PORT, '--user-data-dir=' + PROFILE, '--window-size=1680,1000', 'about:blank'], { stdio: 'ignore' });
  try {
    for (let i = 0; i < 80; i++) { try { await get('http://127.0.0.1:' + PORT + '/json/version'); break; } catch (e) { await sleep(200); } }
    const list = await get('http://127.0.0.1:' + PORT + '/json/list');
    const t = list.find((x) => x.type === 'page');
    const ws = new WebSocket(t.webSocketDebuggerUrl);
    await new Promise((r) => ws.addEventListener('open', r));
    let id = 0; const pend = new Map();
    ws.addEventListener('message', (e) => { const m = JSON.parse(e.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } });
    const send = (m, p) => new Promise((r) => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); });
    const ev = async (x) => {
      const r = await send('Runtime.evaluate', { expression: x, returnByValue: true });
      if (r.result && r.result.exceptionDetails) return 'EXC: ' + r.result.exceptionDetails.text;
      return r.result && r.result.result ? r.result.result.value : null;
    };
    await send('Page.enable');
    await send('Page.navigate', { url: URL_ });
    for (let i = 0; i < 80; i++) { if (await ev('document.body.classList.contains("ready")')) break; await sleep(150); }
    await sleep(700);
    const info = await ev(`(function(){
      var el = document.querySelector(${JSON.stringify(SEL)});
      if (!el) return 'NOT FOUND';
      var cs = getComputedStyle(el), r = el.getBoundingClientRect();
      return JSON.stringify({
        cls: el.className,
        transform: cs.transform, right: cs.right, width: cs.width, display: cs.display,
        opacity: cs.opacity, zIndex: cs.zIndex, visibility: cs.visibility,
        rect: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)],
        bodyCls: document.body.className,
        childCount: el.children.length,
        textLen: el.textContent.length
      }, null, 1);
    })()`);
    console.log(info);
  } finally {
    try { c.kill(); } catch (e) { }
    await sleep(400);
    try { fs.rmSync(PROFILE, { recursive: true, force: true }); } catch (e) { }
  }
})();
