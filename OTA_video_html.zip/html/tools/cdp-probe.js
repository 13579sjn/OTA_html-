/*
 * cdp-probe.js —— 用 CDP 打开任意 URL 并输出页面内计算出的状态
 * 用法: node tools/cdp-probe.js "scenario=truncate&t=131000"
 */
'use strict';
const { spawn } = require('child_process');
const http = require('http');
const path = require('path');
const fs = require('fs');

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const PORT = 9335;
const PROFILE = path.join(__dirname, '..', 'shots', '.cdp-probe');
const PAGE = 'file:///D:/ESP32_IDF_project_/html_OTA/html/expert.html';
const q = process.argv[2] || '';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function httpJson(url) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, (res) => {
      let d = '';
      res.on('data', (c) => { d += c; });
      res.on('end', () => { try { resolve(JSON.parse(d)); } catch (e) { reject(e); } });
    });
    req.on('error', reject);
    req.setTimeout(3000, () => req.destroy(new Error('timeout')));
  });
}

(async function () {
  fs.mkdirSync(PROFILE, { recursive: true });
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-sandbox',
    '--remote-debugging-port=' + PORT,
    '--user-data-dir=' + PROFILE,
    '--window-size=1680,1000', '--no-first-run', 'about:blank'
  ], { stdio: 'ignore' });

  try {
    for (let i = 0; i < 80; i++) {
      try { await httpJson('http://127.0.0.1:' + PORT + '/json/version'); break; } catch (e) { await sleep(200); }
    }
    const list = await httpJson('http://127.0.0.1:' + PORT + '/json/list');
    const t = list.find((x) => x.type === 'page');
    const ws = new WebSocket(t.webSocketDebuggerUrl);
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej); });
    let id = 0;
    const pending = new Map();
    ws.addEventListener('message', (ev) => {
      const m = JSON.parse(ev.data);
      if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
    });
    const send = (method, params) => new Promise((res) => {
      const i = ++id; pending.set(i, res);
      ws.send(JSON.stringify({ id: i, method, params: params || {} }));
    });
    const ev = async (expr) => {
      const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true });
      return r.result && r.result.result ? r.result.result.value : r.result;
    };

    await send('Page.enable');
    await send('Page.navigate', { url: PAGE + (q ? '?' + q : '') });
    for (let i = 0; i < 100; i++) {
      const r = await ev('document.body.classList.contains("ready")');
      if (r === true) break;
      await sleep(150);
    }
    const out = await ev(`(function(){
      var S = window.OTA_STATE.build(window.OTA_TIMELINE.scenario, window.OTA_TIMELINE.time);
      return JSON.stringify({
        t: window.OTA_TIMELINE.time,
        scenario: window.OTA_TIMELINE.scenario.id,
        step: S.step.id,
        counters: S.counters,
        staging: S.ext.staging,
        dl: S.vars.dl_offset,
        ctxCountersText: document.getElementById('ctxCounters').textContent
      });
    })()`);
    console.log(out);
  } finally {
    try { chrome.kill(); } catch (e) { /* ignore */ }
    await sleep(400);
    try { fs.rmSync(PROFILE, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  }
})();
