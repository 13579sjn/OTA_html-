/* =============================================================================
 * acts-1.js —— 新手讲解版剧本（第 1–7 幕）
 *
 * 每一幕 = 一次"分镜"：
 *   cam    镜头关键帧 [进度0~1, 焦点x, 焦点y, 放大倍数]
 *   caps   字幕（at = 该幕内的相对进度）
 *   init   进入这一幕时把状态摆好
 *   tick   幕内随进度变化的状态（必须只依赖 p，才能拖时间轴）
 * ========================================================================== */
'use strict';

window.STORY_ACTS = [];

(function () {

  const A = window.STORY_ACTS;

  /* ---------------------------------------------------------------- */
  /* 第 1 幕：什么是 OTA                                              */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a1', no: 1, title: '什么是 OTA', short: '什么是 OTA', dur: 17000,
    cam: [[0, 600, 350, 0.94], [1, 600, 350, 1.04]],
    caps: [
      { at: 0.00, text: '先说结论：OTA 就是让设备自己上网，把里面的程序换成新的。', hl: ['自己上网'] },
      { at: 0.34, text: '不用拆机，不用插电脑，也不用派人到现场。', hl: [] },
      { at: 0.62, text: '你手机上"系统更新"，用的是同一套思路。', hl: [] },
      { at: 0.82, text: '这次讲的，是一台 STM32 单片机怎么通过 WiFi 把自己升级掉。', hl: ['WiFi'] }
    ],
    init(S) {
      S.lit.cloud = true; S.lit.mcu = true;
      S.led.mcu = true;
      S.statusText = '一台装在现场的单片机';
    },
    tick(S, p) {
      if (p > 0.28) {
        S.flow = [{ id: 'ota', path: 'cloudToMcu', n: 4, color: '#60a5fa', speed: 0.5, dir: 1, size: 15 }];
      }
      if (p > 0.6) {
        S.bubbles = [{ id: 'new', text: '新程序 → 设备', x: 470, y: 200, color: '#7dd3fc' }];
      }
    }
  });

  /* ---------------------------------------------------------------- */
  /* 第 2 幕：设备里长什么样                                          */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a2', no: 2, title: '设备里的三块存储', short: '三块存储', dur: 27000,
    cam: [[0, 600, 350, 1.0], [0.14, 250, 480, 1.66], [0.86, 250, 480, 1.66], [1, 300, 462, 1.46]],
    caps: [
      { at: 0.00, text: '要搞懂 OTA，先看清设备里的存储被切成了三块。', hl: [] },
      { at: 0.16, text: '第一块：引导程序 Bootloader。只有 48KB，永远第一个跑。', hl: ['Bootloader'] },
      { at: 0.40, text: '第二块：参数区，16KB。专门存一张小纸条 —— 这次该启动谁。', hl: ['小纸条'] },
      { at: 0.62, text: '第三块：舞台，也就是 App，960KB。你写的业务程序住在这里。', hl: ['舞台'] },
      { at: 0.84, text: '三块加起来正好 1MB，就是单片机内部那块 Flash。', hl: ['1MB'] }
    ],
    init(S) {
      S.lit.flash = true; S.lit.mcu = true;
      S.statusText = '三块存储，各管一件事';
    },
    tick(S, p) {
      S.lit.bl = p >= 0.14;
      S.lit.param = p >= 0.38;
      S.lit.app = p >= 0.60;
      S.bubbles = [];
      if (p >= 0.16 && p < 0.38) {
        S.bubbles = [{ id: 'b1', text: '开机第一个跑的就是它', x: 133, y: 442, color: '#7dd3fc' }];
      } else if (p >= 0.40 && p < 0.60) {
        S.bubbles = [{ id: 'b2', text: '启动哪个程序，就看它', x: 204, y: 442, color: '#c4b5fd' }];
      } else if (p >= 0.62 && p < 0.84) {
        S.bubbles = [{ id: 'b3', text: '你的业务代码住这里', x: 331, y: 442, color: '#6ee7b7' }];
      }
    }
  });

  /* ---------------------------------------------------------------- */
  /* 第 3 幕：为什么程序不能自己换自己                                */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a3', no: 3, title: '为什么不能自己改自己', short: '为什么要引导程序', dur: 25000,
    cam: [[0, 300, 462, 1.55], [0.30, 600, 350, 1.15], [1, 600, 350, 1.02]],
    caps: [
      { at: 0.00, text: '有人会问：App 自己下载、自己覆盖自己，行不行？', hl: [] },
      { at: 0.24, text: '不行。程序是"站"在 Flash 上跑的，你把它脚下那块擦掉，它当场就死了。', hl: ['当场就死了'] },
      { at: 0.52, text: '所以必须有一个不参与业务的小程序，专门负责"换人"。', hl: ['专门负责'] },
      { at: 0.76, text: '它就是 Bootloader：不联网、不管业务，只决定启动谁，然后跳过去。', hl: ['Bootloader'] }
    ],
    init(S) {
      S.lit.flash = true; S.lit.app = true; S.lit.mcu = true;
      S.statusText = '正在运行的 App 不能擦掉自己';
    },
    tick(S, p) {
      S.bubbles = [];
      if (p < 0.30) {
        S.appWarn = true;
        S.bubbles = [{ id: 'x', text: '✗ 擦掉它 = 设备当场停机', x: 331, y: 620, color: '#f87171' }];
      } else {
        S.appWarn = false;
        S.lit.bl = true;
        S.bubbles = [{ id: 'g', text: '✓ 由它来动手换', x: 133, y: 442, color: '#4ade80' }];
      }
    }
  });

  /* ---------------------------------------------------------------- */
  /* 第 4 幕：上电先跑谁                                              */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a4', no: 4, title: '上电，先跑谁？', short: '启动流程', dur: 28000,
    cam: [[0, 600, 350, 1.05], [0.28, 250, 455, 1.55], [0.66, 205, 470, 1.78], [1, 300, 455, 1.55]],
    caps: [
      { at: 0.00, text: '每次上电，CPU 都从 0x08000000 取第一条指令 —— 那里放的正是 Bootloader。', hl: ['0x08000000'] },
      { at: 0.26, text: '所以顺序是：先跑 Bootloader，它去参数区读那张小纸条。', hl: ['小纸条'] },
      { at: 0.48, text: '纸条上是个数字，叫 boot_flag。0 正常启动，1 试试新固件，2 回滚，3 恢复出厂。', hl: ['boot_flag'] },
      { at: 0.72, text: '现在纸条是 0，Bootloader 就跳到 App，让业务程序跑起来。', hl: ['0'] },
      { at: 0.90, text: '这就是日常开机，你平时完全感觉不到。', hl: [] }
    ],
    init(S) {
      S.lit.mcu = true; S.lit.flash = true;
      S.paramFlag = 0;
      S.statusText = '上电复位';
      S.led.mcu = true;
    },
    tick(S, p) {
      S.bubbles = [];
      if (p < 0.24) {
        S.lit.bl = true;
        S.bubbles = [{ id: 'v', text: '从这里开始执行', x: 133, y: 442, color: '#7dd3fc' }];
      } else if (p < 0.48) {
        S.lit.param = true;
        S.paramPulse = true;
        S.bubbles = [{ id: 'f', text: '读纸条：boot_flag', x: 204, y: 442, color: '#c4b5fd' }];
      } else if (p < 0.72) {
        S.paramPulse = p < 0.58;
        S.bubbles = [{ id: 'd', text: '0 = 正常启动', x: 204, y: 442, color: '#4ade80' }];
      } else {
        S.lit.app = true;
        S.lit.cpu = true;
        S.appVer = '1.0.0';
        S.statusText = 'App 1.0.0 正在运行';
        S.bubbles = [{ id: 'j', text: '跳过去 → 开始跑业务', x: 331, y: 442, color: '#6ee7b7' }];
      }
    }
  });

  /* ---------------------------------------------------------------- */
  /* 第 5 幕：App 连网                                                */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a5', no: 5, title: 'App 连网', short: '连网', dur: 20000,
    cam: [[0, 600, 350, 1.05], [0.45, 400, 150, 1.50], [1, 520, 220, 1.28]],
    caps: [
      { at: 0.00, text: 'App 跑起来后的第一件事，是联网。', hl: [] },
      { at: 0.18, text: '单片机自己不会上网，中间这个 ESP8266 模块负责。', hl: ['ESP8266'] },
      { at: 0.44, text: 'App 用几条 AT 指令，让它连上路由器、再连上服务器。', hl: ['AT 指令'] },
      { at: 0.68, text: '连上以后，服务器就能给设备下发命令了。', hl: [] }
    ],
    init(S) {
      S.lit.mcu = true; S.lit.esp = true; S.lit.uart = true; S.lit.uartBox = true;
      S.led.mcu = true; S.led.esp = true;
      S.appVer = '1.0.0';
      S.statusText = 'App 1.0.0 正在运行';
    },
    tick(S, p) {
      S.bubbles = [];
      if (p > 0.40) {
        S.lit.wifi = true;
        S.lit.cloud = true;
        S.flow = [{ id: 'w', path: 'uart', n: 3, color: '#38bdf8', speed: 0.8, dir: 1, size: 12 },
                  { id: 'w2', path: 'wifi', n: 3, color: '#60a5fa', speed: 0.8, dir: -1, size: 12 }];
      }
      if (p > 0.66) {
        S.bubbles = [{ id: 'ok', text: '✓ 已连上服务器', x: 400, y: 145, color: '#4ade80' }];
        S.statusText = '联网成功，等服务器命令';
      }
    }
  });

  /* ---------------------------------------------------------------- */
  /* 第 6 幕：触发升级                                                */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a6', no: 6, title: '升级是怎么被触发的', short: '触发升级', dur: 16000,
    cam: [[0, 400, 105, 1.60], [0.55, 400, 150, 1.42], [1, 480, 230, 1.30]],
    caps: [
      { at: 0.00, text: '在服务器后台，运维点一下"下发升级"。', hl: [] },
      { at: 0.30, text: '设备收到一个属性：Update = 1。', hl: ['Update = 1'] },
      { at: 0.62, text: '看到这个 1，App 就知道：该干活了。', hl: ['该干活了'] }
    ],
    init(S) {
      S.lit.cloud = true; S.lit.esp = true; S.led.esp = true;
      S.statusText = '联网成功，等服务器命令';
    },
    tick(S, p) {
      S.bubbles = [];
      if (p > 0.26) {
        S.lit.wifi = true;
        S.flow = [{ id: 'cmd', path: 'wifi', n: 2, color: '#fbbf24', speed: 0.9, dir: 1, size: 16 }];
        S.bubbles = [{ id: 'u', text: 'Update = 1', x: 470, y: 150, color: '#fbbf24' }];
      }
      if (p > 0.62) {
        S.lit.uart = true; S.lit.uartBox = true; S.lit.mcu = true;
        S.statusText = '收到升级命令，开始 OTA';
        S.bubbles = [{ id: 'go', text: '② 开始 OTA', x: 560, y: 250, color: '#fbbf24' }];
      }
    }
  });

  /* ---------------------------------------------------------------- */
  /* 第 7 幕：下载 —— 新固件先进仓库                                  */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a7', no: 7, title: '下载：新固件先进仓库', short: '下载', dur: 34000,
    cam: [[0, 600, 350, 1.0], [0.16, 420, 200, 1.30], [0.42, 600, 352, 1.00], [0.72, 950, 410, 1.45], [1, 950, 410, 1.45]],
    caps: [
      { at: 0.00, text: '接下来是最关键的一步：新固件不能直接写进舞台，得先放进"仓库"。', hl: ['仓库'] },
      { at: 0.15, text: '仓库就是右边这块外挂芯片，8MB，比内部 Flash 大八倍。', hl: ['8MB'] },
      { at: 0.31, text: '服务器把固件切成小块，通过 WiFi → 模块 → 串口，一块块送进来。', hl: ['一块块'] },
      { at: 0.49, text: '单片机收到一块，就写进仓库的"暂存区"，顺手算一下指纹。', hl: ['暂存区'] },
      { at: 0.69, text: '整包 94824 字节，大概 9 秒。', hl: ['94824'] },
      { at: 0.84, text: '看，暂存区一格一格被填满了。', hl: [] }
    ],
    init(S) {
      S.lit.cloud = true; S.lit.esp = true; S.lit.mcu = true; S.lit.store = true;
      S.led.esp = true; S.led.mcu = true;
      S.stg.fill = 0; S.stg.text = '空'; S.stg.state = '';
      S.statusText = '正在下载新固件…';
    },
    tick(S, p) {
      /* 流水线开启 */
      if (p > 0.28) {
        S.lit.wifi = true; S.lit.uart = true; S.lit.spi = true;
        S.lit.stg = p > 0.45;
        S.flow = [
          { id: 'p1', path: 'cloudToStore', n: 5, color: '#60a5fa', speed: 0.5, dir: 1, size: 15 }
        ];
      }
      /* 写入进度 */
      const dl = Math.max(0, Math.min(1, (p - 0.44) / 0.42));
      S.stg.fill = dl;
      if (dl <= 0) { S.stg.text = '空'; S.stg.state = ''; }
      else if (dl < 1) { S.stg.text = '写入 ' + Math.round(dl * 100) + '%'; S.stg.state = 'warn'; }
      else { S.stg.text = '✓ 已写完'; S.stg.state = 'ok'; }

      S.bubbles = [];
      if (p > 0.30 && p < 0.44) {
        S.bubbles = [{ id: 't1', text: '一小块一小块地传', x: 600, y: 686, color: '#93c5fd' }];
      } else if (p >= 0.44 && dl < 1) {
        S.bubbles = [{ id: 't2', text: '正在写入暂存区 ' + Math.round(dl * 100) + '%', x: 600, y: 686, color: '#c4b5fd' }];
      } else if (dl >= 1) {
        S.bubbles = [{ id: 't3', text: '✓ 全部收下：94824 字节', x: 600, y: 686, color: '#4ade80' }];
        S.statusText = '新固件已存进仓库';
      }
    }
  });

})();
