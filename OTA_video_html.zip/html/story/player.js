/* =============================================================================
 * player.js —— 新手讲解版：时间轴、字幕、镜头、播放控制
 *
 * 核心原则和进阶版一致：状态 = f(时间)。所以拖时间轴时，
 * 画面、字幕、进度、镜头位置都会"回到该时刻应有的样子"，不会错位。
 * ========================================================================== */
'use strict';

window.STORY_PLAYER = (function () {

  const ACTS = () => window.STORY_ACTS;

  let acts = [];
  let total = 0;
  let t = 0;
  let speed = 1;
  let playing = false;
  let raf = 0;
  let lastTs = 0;
  let current = null;
  let dom = {};
  let dragging = false;

  /* 每一幕对应哪段真实源码（点"看源码"才展开） */
  const ACT_CODE = {
    a1: { snip: 'partition_internal', hl: [59, 64], why: '这套 OTA 的存储划分就写在这个头文件里（BL / 参数区 / App 槽）' },
    a2: { snip: 'partition_internal', hl: [47, 64], why: '三块存储的地址和大小，是 BootLoader 与 App 共用的同一份定义' },
    a3: { snip: 'boot_main', hl: [99, 101], why: 'BL 的 main() 里只有一句 boot_run()，它不返回 —— 要么跳转成功，要么挂死' },
    a4: { snip: 'boot_run_param', hl: [312, 321], why: 'BL 读参数区，然后按 boot_flag 决定启动谁' },
    a5: { snip: 'esp8266_init', hl: [49, 63], why: 'App 用 6 条 AT 指令让 ESP8266 连 WiFi、连 MQTT 服务器' },
    a6: { snip: 'ota_task_request', hl: [126, 143], why: '收到 Update 属性后，创建一个独立任务去跑 OTA' },
    a7: { snip: 'dl_on_data', hl: [424, 462], why: '下载回调：边收边算指纹，攒够 256 字节就写一次外部 Flash' },
    a8: { snip: 'download_try_c', hl: [694, 710], why: '长度、MD5、SHA-256 三道校验，任何一道不过就返回 -5' },
    a9: { snip: 'backup_app', hl: [783, 807], why: '把当前 A 槽的固件拷到片外备份区，并算它的 SHA-256' },
    a10: { snip: 'apply_reboot', hl: [823, 837], why: '置 TRY_NEW、清 boot_count、记下任务号，然后 NVIC_SystemReset()' },
    a11: { snip: 'boot_copy', hl: [151, 178], why: 'BL 按扇区擦 A 槽，再把暂存区 1KB 一块搬过去' },
    a12: { snip: 'boot_confirm', hl: [1071, 1080], why: '新固件首启：打印横幅、静默 30 秒、把 flag 固化为 NORMAL' },
    a13: { snip: 'boot_do_rollback', hl: [186, 200], why: '回滚：先校验备份区 SHA-256，通过后才覆盖 A 槽' },
    a14: { snip: 'partition_flags', hl: [80, 91], why: '四个启动标志 + 自动回滚阈值，就是整套机制的"旋钮"' }
  };

  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  /* ---------------- 状态 ---------------- */
  function fresh() {
    return {
      t: 0, p: 0, act: null, cam: { x: 600, y: 350, s: 1 },
      lit: {}, led: {},
      paramFlag: 0, paramPulse: false,
      appVer: '1.0.0', appNote: '960KB · 正在运行', appFill: 1, appIsNew: false, appWarn: false,
      stg: { fill: 0, text: '空', state: '' },
      bk: { fill: 0, text: '空', state: '' },
      rc: { fill: 0, text: '空', state: '' },
      statusText: '', flow: [], bubbles: [], reboot: false
    };
  }

  /* 每幕开始前要清掉的"瞬态"字段：否则上一幕的粒子/气泡会飘到下一幕 */
  const TRANSIENT = ['flow', 'bubbles', 'appWarn', 'paramPulse', 'reboot'];

  function build(tt) {
    const S = fresh();
    S.t = tt;
    let cur = null;
    for (let i = 0; i < acts.length; i++) {
      const a = acts[i];
      if (a.t1 <= tt) {
        S.p = 1; S.act = a;
        TRANSIENT.forEach((k) => { S[k] = Array.isArray(S[k]) ? [] : (k === 'paramPulse' || k === 'reboot' || k === 'appWarn' ? false : S[k]); });
        a.init(S);
        if (a.tick) safe(a, S, 1);
      } else if (a.t0 <= tt) {
        const p = Math.max(0, Math.min(1, (tt - a.t0) / a.dur));
        S.p = p; S.act = a;
        TRANSIENT.forEach((k) => { S[k] = Array.isArray(S[k]) ? [] : (k === 'paramPulse' || k === 'reboot' || k === 'appWarn' ? false : S[k]); });
        a.init(S);
        if (a.tick) safe(a, S, p);
        cur = a;
      } else break;
    }
    if (!cur) cur = acts[acts.length - 1];
    S.act = cur;
    S.cam = camera(cur, S.p);
    S.t = tt;
    return S;
  }

  function safe(a, S, p) {
    try { a.tick(S, p); } catch (e) { /* 单幕异常不影响其它 */ }
  }

  function camera(act, p) {
    const cam = act.cam || [[0, 600, 350, 1], [1, 600, 350, 1]];
    let A = cam[0], B = cam[cam.length - 1];
    for (let i = 0; i < cam.length - 1; i++) {
      if (p >= cam[i][0] && p <= cam[i + 1][0]) { A = cam[i]; B = cam[i + 1]; break; }
    }
    const span = (B[0] - A[0]) || 1;
    const k0 = Math.max(0, Math.min(1, (p - A[0]) / span));
    const k = k0 < 0.5 ? 2 * k0 * k0 : 1 - Math.pow(-2 * k0 + 2, 2) / 2;
    return {
      x: A[1] + (B[1] - A[1]) * k,
      y: A[2] + (B[2] - A[2]) * k,
      s: A[3] + (B[3] - A[3]) * k
    };
  }

  /* ---------------- 编译时间轴 ---------------- */
  function compile() {
    acts = ACTS().slice();
    let acc = 0;
    acts.forEach((a) => {
      a.t0 = acc; a.t1 = acc + a.dur; acc += a.dur;
    });
    total = acc;
  }

  function actAt(tt) {
    for (let i = 0; i < acts.length; i++) {
      if (tt >= acts[i].t0 && tt < acts[i].t1) return acts[i];
    }
    return acts[acts.length - 1];
  }

  /* ---------------- 字幕 ---------------- */
  function captionFor(act, tt) {
    let cap = null, capT0 = act.t0;
    for (let i = 0; i < act.caps.length; i++) {
      if (tt >= act.t0 + act.caps[i].at * act.dur) {
        cap = act.caps[i];
        capT0 = act.t0 + act.caps[i].at * act.dur;
      }
    }
    return cap ? { cap: cap, t0: capT0 } : null;
  }

  function renderCaption(S) {
    const box = dom.capText;
    const info = captionFor(S.act, S.t);
    if (!info) { box.innerHTML = ''; return; }
    const cap = info.cap;
    /* 打字机：每秒 30 字；暂停时直接显示整句（像视频暂停看到完整字幕） */
    const chars = playing ? Math.max(0, Math.floor(((S.t - info.t0) / 1000) * 30)) : 1e9;
    const totalChars = cap.text.length;
    const shown = Math.min(totalChars, chars);

    const segs = splitHL(cap.text, cap.hl || []);
    let html = '';
    let used = 0;
    let done = false;
    for (let i = 0; i < segs.length && !done; i++) {
      const s = segs[i];
      let part = s.text;
      if (used + part.length >= shown) {
        part = part.slice(0, Math.max(0, shown - used));
        done = true;
      }
      used += s.text.length;
      if (!part) break;
      html += s.hl ? '<em>' + esc(part) + '</em>' : esc(part);
    }
    const typing = shown < totalChars;
    box.innerHTML = html + (typing ? '<span class="caret">｜</span>' : '');
  }

  function splitHL(text, hls) {
    if (!hls || !hls.length) return [{ text: text, hl: false }];
    const marks = [];
    hls.forEach((w) => {
      let i = text.indexOf(w);
      while (i >= 0) { marks.push([i, i + w.length]); i = text.indexOf(w, i + w.length); }
    });
    marks.sort((a, b) => a[0] - b[0]);
    const merged = [];
    marks.forEach((m) => {
      const last = merged[merged.length - 1];
      if (last && m[0] <= last[1]) last[1] = Math.max(last[1], m[1]);
      else merged.push([m[0], m[1]]);
    });
    const out = [];
    let pos = 0;
    merged.forEach((m) => {
      if (m[0] > pos) out.push({ text: text.slice(pos, m[0]), hl: false });
      out.push({ text: text.slice(m[0], m[1]), hl: true });
      pos = m[1];
    });
    if (pos < text.length) out.push({ text: text.slice(pos), hl: false });
    return out;
  }

  /* ---------------- 时钟 ---------------- */
  function frame(ts) {
    if (!playing) return;
    if (!lastTs) lastTs = ts;
    let dt = ts - lastTs;
    lastTs = ts;
    if (dt > 250) dt = 250;
    t += dt * speed;
    if (t >= total) { t = total; playing = false; emit('end'); return; }
    emit('tick');
    raf = requestAnimationFrame(frame);
  }

  const listeners = [];
  function on(fn) { listeners.push(fn); }
  function emit(reason) {
    const s = { t: t, playing: playing, speed: speed, reason: reason };
    listeners.forEach((f) => { try { f(s); } catch (e) { } });
  }

  function play() {
    if (playing) return;
    if (t >= total - 1) t = 0;
    playing = true; lastTs = 0;
    raf = requestAnimationFrame(frame);
    emit('play');
  }
  function pause() {
    if (!playing) return;
    playing = false;
    cancelAnimationFrame(raf);
    emit('pause');
  }
  function toggle() { playing ? pause() : play(); }
  function seek(tt, why) {
    t = Math.max(0, Math.min(total, tt));
    lastTs = 0;
    emit(why || 'seek');
  }
  function setSpeed(s) { speed = s; emit('speed'); }

  function jumpAct(dir) {
    const a = actAt(t);
    const i = acts.indexOf(a);
    if (dir > 0) seek(acts[Math.min(i + 1, acts.length - 1)].t0, 'act');
    else if (t - a.t0 > 800) seek(a.t0, 'act');
    else seek(acts[Math.max(i - 1, 0)].t0, 'act');
  }

  function seekAct(idx) {
    const a = acts[idx];
    if (a) { seek(a.t0, 'act'); pause(); }
  }

  /* ---------------- 渲染 ---------------- */
  function render() {
    const S = build(t);
    current = S;

    STORY_SCENE.render(S);
    renderCaption(S);

    /* 顶栏 / 章节点 */
    const a = S.act;
    if (dom.actNo) dom.actNo.textContent = String(a.no).padStart(2, '0');
    if (dom.actTitle) dom.actTitle.textContent = a.title;
    if (dom.status) dom.status.textContent = S.statusText || '';

    /* 进度条 */
    const ratio = total > 0 ? Math.min(1, t / total) : 0;
    if (dom.fill) dom.fill.style.width = (ratio * 100).toFixed(3) + '%';
    if (dom.head) dom.head.style.left = (ratio * 100).toFixed(3) + '%';
    if (dom.tCur) dom.tCur.textContent = fmt(t);
    if (dom.pct) dom.pct.textContent = Math.round(ratio * 100) + '%';

    /* 章节点高亮 */
    if (dom.dots) {
      const nodes = dom.dots.children;
      for (let i = 0; i < nodes.length; i++) {
        nodes[i].classList.toggle('on', i === acts.indexOf(a));
        nodes[i].classList.toggle('done', i < acts.indexOf(a));
      }
    }

    /* 播放按钮 */
    if (dom.btnPlay) {
      dom.btnPlay.classList.toggle('playing', playing);
      dom.btnPlay.querySelector('.ico').textContent = playing ? '❚❚' : '▶';
    }
    if (dom.speeds) {
      dom.speeds.querySelectorAll('[data-s]').forEach((b) => {
        b.classList.toggle('on', parseFloat(b.getAttribute('data-s')) === speed);
      });
    }
    /* 源码抽屉 */
    if (dom.codeDrawer && dom.codeDrawer.classList.contains('open')) renderCode(a);
  }

  function fmt(ms) {
    const s = Math.max(0, Math.floor(ms / 1000));
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  }

  /* ---------------- 源码抽屉 ---------------- */
  function renderCode(act) {
    const map = ACT_CODE[act.id];
    if (!dom.codeBody) return;
    if (!map) {
      dom.codeBody.innerHTML = '<div class="code-empty">这一幕是概念讲解，没有对应的源码片段。</div>';
      return;
    }
    const snip = window.OTA_CODE && window.OTA_CODE.snippets ? window.OTA_CODE.snippets[map.snip] : null;
    if (!snip) {
      dom.codeBody.innerHTML = '<div class="code-empty">找不到源码片段（' + esc(map.snip) + '）。</div>';
      return;
    }
    const h0 = Math.min(map.hl[0], map.hl[1] === undefined ? map.hl[0] : map.hl[1]);
    const h1 = Math.max(map.hl[0], map.hl[1] === undefined ? map.hl[0] : map.hl[1]);
    const proj = snip.project === 'HAL_F429IGT6_bootloard' ? 'BootLoader'
      : (snip.project === 'HAL_F429IGT6_App' ? 'App 1.0.0' : 'App 1.0.1');
    let html = '<div class="code-head">' +
      '<span class="cp">' + esc(proj) + '</span>' +
      '<span class="cf">' + esc(snip.file) + '</span>' +
      '<span class="cl">L' + snip.from + '–' + snip.to + '</span>' +
      '<span class="cg">A · 源码已证实</span></div>' +
      '<div class="code-why">' + esc(map.why) + '</div>' +
      '<pre class="code-pre">';
    snip.lines.forEach(([no, text]) => {
      const on = no >= h0 && no <= h1 ? ' class="hl"' : '';
      html += '<span' + on + '>' + String(no).padStart(4, ' ') + '  ' + esc(text) + '</span>\n';
    });
    html += '</pre>';
    dom.codeBody.innerHTML = html;
    /* 滚动到高亮 */
    const first = dom.codeBody.querySelector('.hl');
    if (first && first.scrollIntoView) {
      try { first.scrollIntoView({ block: 'center' }); } catch (e) { }
    }
  }

  /* ---------------- 初始化 ---------------- */
  function init(d) {
    dom = d;
    compile();

    /* 章节点 */
    if (dom.dots) {
      dom.dots.innerHTML = acts.map((a, i) =>
        '<button class="adot" data-i="' + i + '" title="' + a.no + '. ' + esc(a.title) + '">' +
        '<i></i><b>' + a.no + '</b></button>').join('');
      dom.dots.addEventListener('click', (ev) => {
        const b = ev.target.closest('.adot');
        if (b) seekAct(parseInt(b.getAttribute('data-i'), 10));
      });
    }

    if (dom.tTot) dom.tTot.textContent = fmt(total);

    /* 时间轴 */
    if (dom.bands) {
      dom.bands.innerHTML = acts.map((a) => {
        const l = (a.t0 / total) * 100, w = (a.dur / total) * 100;
        return '<div class="aband" style="left:' + l.toFixed(4) + '%;width:' + w.toFixed(4) + '%" title="' + a.no + '. ' + esc(a.title) + '"></div>';
      }).join('');
    }

    dom.btnPlay.addEventListener('click', toggle);
    dom.btnPrev.addEventListener('click', () => jumpAct(-1));
    dom.btnNext.addEventListener('click', () => jumpAct(1));
    if (dom.speeds) {
      dom.speeds.addEventListener('click', (ev) => {
        const b = ev.target.closest('[data-s]');
        if (b) setSpeed(parseFloat(b.getAttribute('data-s')));
      });
    }
    if (dom.btnCode) {
      dom.btnCode.addEventListener('click', () => {
        const open = dom.codeDrawer.classList.toggle('open');
        document.body.classList.toggle('code-open', open);
        dom.btnCode.classList.toggle('on', open);
        if (open) renderCode(actAt(t));
      });
    }
    if (dom.btnCloseCode) {
      dom.btnCloseCode.addEventListener('click', () => {
        dom.codeDrawer.classList.remove('open');
        document.body.classList.remove('code-open');
        dom.btnCode.classList.remove('on');
      });
    }

    /* 拖时间轴 */
    const seekFrom = (ev) => {
      const r = dom.track.getBoundingClientRect();
      if (r.width <= 0) return;
      const x = Math.max(0, Math.min(r.width, ev.clientX - r.left));
      seek((x / r.width) * total, 'drag');
    };
    dom.track.addEventListener('pointerdown', (ev) => {
      dragging = true;
      pause();
      dom.track.setPointerCapture(ev.pointerId);
      dom.track.classList.add('dragging');
      seekFrom(ev);
    });
    dom.track.addEventListener('pointermove', (ev) => { if (dragging) seekFrom(ev); });
    const end = (ev) => {
      if (!dragging) return;
      dragging = false;
      dom.track.classList.remove('dragging');
      try { dom.track.releasePointerCapture(ev.pointerId); } catch (e) { }
    };
    dom.track.addEventListener('pointerup', end);
    dom.track.addEventListener('pointercancel', end);

    document.addEventListener('keydown', (ev) => {
      const tag = (ev.target.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea') return;
      if (ev.key === ' ') { ev.preventDefault(); toggle(); }
      else if (ev.key === 'ArrowRight') { ev.preventDefault(); seek(t + 3000, 'k'); }
      else if (ev.key === 'ArrowLeft') { ev.preventDefault(); seek(t - 3000, 'k'); }
      else if (ev.key === 'PageDown') { ev.preventDefault(); jumpAct(1); }
      else if (ev.key === 'PageUp') { ev.preventDefault(); jumpAct(-1); }
      else if (ev.key === 'Home') seek(0, 'k');
      else if (ev.key === 'End') seek(total, 'k');
    });

    on(() => render());

    /* 起播位置：?t= 指定绝对毫秒（优先），?act= 指定第几节（1 起） */
    const q = new URLSearchParams(location.search);
    if (q.get('t') !== null) {
      t = Math.max(0, Math.min(total, parseFloat(q.get('t')) || 0));
    } else if (q.get('act')) {
      const idx = Math.max(0, Math.min(acts.length - 1, parseInt(q.get('act'), 10) - 1));
      t = acts[idx].t0;
    }
    render();
    /* ?code=1 直接展开源码抽屉，方便分享"这一幕的代码" */
    if (q.get('code') === '1') {
      /* 深链直接展开：关掉过渡，避免"刚打开就被截图"停在半路 */
      dom.codeDrawer.style.transition = 'none';
      dom.codeDrawer.classList.add('open');
      document.body.classList.add('code-open');
      dom.btnCode.classList.add('on');
      renderCode(actAt(t));
    }
    if (q.get('autoplay') === '1') play();
  }

  return {
    init, play, pause, toggle, seek, setSpeed, seekAct, jumpAct,
    get time() { return t; },
    get total() { return total; },
    get acts() { return acts; },
    get state() { return current; }
  };
})();
