/* =============================================================================
 * scene.js —— 新手讲解版的"舞台"
 *
 * 和进阶版的区别：
 *   · 只画 4 个东西：服务器、WiFi 模块、单片机、外挂存储器（仓库）
 *   · 一切都是"大块头 + 中文人话"，不画寄存器、不画总线、不画时序
 *   · 每一个状态都由 S（时间 t 的函数）驱动，所以拖时间轴不会错位
 *   · 支持"镜头"：整幅画面可以推近到某个部件，形成视频感
 * ========================================================================== */
'use strict';

window.STORY_SCENE = (function () {

  const NS = 'http://www.w3.org/2000/svg';

  /* ---------- 场景坐标（viewBox 1200 × 700） ---------- */
  const GEO = {
    view: { w: 1200, h: 700 },
    cloud: { x: 280, y: 20, w: 240, h: 100 },     /* 服务器 */
    esp: { x: 300, y: 176, w: 200, h: 90 },       /* WiFi 模块 */
    mcu: { x: 70, y: 300, w: 380, h: 350 },       /* 单片机 */
    store: { x: 700, y: 300, w: 430, h: 350 },    /* 仓库 */
    /* 内部 Flash 的三段 */
    flash: { x: 86, y: 432, w: 348, h: 156 },
    bl: { x: 94, y: 474, w: 78, h: 104 },
    param: { x: 176, y: 474, w: 56, h: 104 },
    app: { x: 236, y: 474, w: 190, h: 104 },
    /* 仓库四格 */
    stg: { x: 716, y: 344, w: 398, h: 74 },
    bk: { x: 716, y: 426, w: 398, h: 74 },
    rc: { x: 716, y: 508, w: 398, h: 74 },
    free: { x: 716, y: 590, w: 398, h: 50 }
  };

  /* ---------- 数据流动路径（折线，用于粒子） ---------- */
  const PATHS = {
    wifi: [[400, 120], [400, 176]],
    uart: [[400, 266], [400, 300]],
    spi: [[450, 470], [700, 470]],
    cloudToMcu: [[400, 120], [400, 300], [260, 430]],
    cloudToStore: [[400, 120], [400, 300], [260, 470], [450, 470], [700, 470], [905, 420]],
    storeToApp: [[905, 420], [700, 470], [450, 470], [330, 500]]
  };

  let root = null;
  let world = null;
  let refs = {};
  let bubbles = {};   /* id -> <g> */
  let packets = {};   /* id -> <g> */

  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  /* ================================================================
   * 构建
   * ================================================================ */
  function build(container) {
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 ' + GEO.view.w + ' ' + GEO.view.h);
    svg.setAttribute('class', 'story-svg');
    svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');

    /* 关键：clipPath 必须套在一个"没有 transform"的外层 g 上，
       否则相机一推近，裁剪框会跟着一起被缩放平移，等于没裁。
       套在外层后，裁剪范围永远是 viewBox 的 0,0,1200,700，
       镜头推到哪都不会把画面外的卡片边缘漏到黑边里。 */
    svg.innerHTML = defs() + '<g id="clipper" clip-path="url(#vp)"><g id="world">' +
      links() + cloudNode() + espNode() + mcuNode() + storeNode() +
      '</g></g>' + '<g id="bubbles"></g>';

    container.appendChild(svg);
    root = svg;
    world = svg.querySelector('#world');
    cacheRefs();
    return svg;
  }

  function defs() {
    return `<defs>
      <clipPath id="vp"><rect x="0" y="0" width="1200" height="700"/></clipPath>
      <linearGradient id="gCloud" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#1e3a6b"/><stop offset="1" stop-color="#152747"/></linearGradient>
      <linearGradient id="gMcu" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#123039"/><stop offset="1" stop-color="#0d222a"/></linearGradient>
      <linearGradient id="gStore" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#2a2148"/><stop offset="1" stop-color="#1d1734"/></linearGradient>
      <linearGradient id="gBl" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#2f6f8f"/><stop offset="1" stop-color="#245468"/></linearGradient>
      <linearGradient id="gParam" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#7c5aa6"/><stop offset="1" stop-color="#5d427f"/></linearGradient>
      <linearGradient id="gApp" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#2f8f6a"/><stop offset="1" stop-color="#246b51"/></linearGradient>
      <linearGradient id="gAppNew" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#3fae7f"/><stop offset="1" stop-color="#2d825f"/></linearGradient>
      <filter id="glow" x="-40%" y="-40%" width="180%" height="180%">
        <feGaussianBlur stdDeviation="7" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      <filter id="soft" x="-20%" y="-20%" width="140%" height="140%">
        <feDropShadow dx="0" dy="6" stdDeviation="10" flood-color="#000" flood-opacity=".45"/></filter>
    </defs>`;
  }

  function box(id, x, y, w, h, r, fill, stroke, extra) {
    return `<rect id="${id}" x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="${fill}" stroke="${stroke}" stroke-width="1.5" ${extra || ''}/>`;
  }

  function links() {
    return `<g id="links">
      <path id="wifiLink" class="lnk" d="M400 120 L400 176"/>
      <path id="uartLink" class="lnk" d="M400 266 L400 300"/>
      <path id="spiLink" class="lnk" d="M450 470 L700 470"/>
      <text class="lnk-t" x="412" y="152">WiFi</text>
      <text class="lnk-t" x="412" y="288">串口</text>
      <text class="lnk-t" x="575" y="460">SPI 总线（数据通道）</text>
    </g>`;
  }

  function cloudNode() {
    const c = GEO.cloud;
    return `<g id="cloud" class="node">
      ${box('cloudBox', c.x, c.y, c.w, c.h, 16, 'url(#gCloud)', '#3b6ea5', 'filter="url(#soft)"')}
      <text class="t-title" x="${c.x + 18}" y="${c.y + 34}">服务器</text>
      <text class="t-sub" x="${c.x + 18}" y="${c.y + 56}">OneNET 平台</text>
      <text class="t-sub" x="${c.x + 18}" y="${c.y + 76}">放着新固件 1.0.1</text>
      <g id="cloudPkg" transform="translate(${c.x + c.w - 56},${c.y + 34})">
        <rect x="0" y="0" width="34" height="34" rx="6" fill="#2f5f9e" stroke="#7db4ee" stroke-width="1.5"/>
        <text class="t-pkg" x="17" y="23" text-anchor="middle">固</text>
      </g>
    </g>`;
  }

  function espNode() {
    const e = GEO.esp;
    return `<g id="esp" class="node">
      ${box('espBox', e.x, e.y, e.w, e.h, 14, '#12283a', '#2f5f7a', 'filter="url(#soft)"')}
      <text class="t-title" x="${e.x + 16}" y="${e.y + 30}">WiFi 模块</text>
      <text class="t-sub" x="${e.x + 16}" y="${e.y + 52}">ESP8266</text>
      <text class="t-sub" x="${e.x + 16}" y="${e.y + 72}">负责上网</text>
      <circle id="espLed" class="led" cx="${e.x + e.w - 20}" cy="${e.y + 22}" r="6"/>
    </g>`;
  }

  function mcuNode() {
    const m = GEO.mcu;
    const f = GEO.flash;
    return `<g id="mcu" class="node">
      ${box('mcuBox', m.x, m.y, m.w, m.h, 18, 'url(#gMcu)', '#2f7a86', 'filter="url(#soft)"')}
      <text class="t-title" x="${m.x + 20}" y="${m.y + 30}">单片机 STM32F429</text>
      <circle id="mcuLed" class="led" cx="${m.x + m.w - 22}" cy="${m.y + 22}" r="6"/>

      ${box('cpuBox', 90, 342, 110, 56, 10, '#173a44', '#2f7a86')}
      <text class="t-mid" x="145" y="368">CPU</text>
      <text class="t-tiny" x="145" y="386">大脑</text>

      ${box('uartBox', 212, 342, 92, 56, 10, '#173a44', '#2f7a86')}
      <text class="t-mid" x="258" y="368">串口</text>
      <text class="t-tiny" x="258" y="386">对接 WiFi</text>

      ${box('spiBox', 316, 342, 84, 56, 10, '#173a44', '#2f7a86')}
      <text class="t-mid" x="358" y="368">SPI</text>
      <text class="t-tiny" x="358" y="386">对接仓库</text>

      ${box('flashFrame', f.x, f.y, f.w, f.h, 12, '#0c1d24', '#2f7a86')}
      <text class="t-flash-title" x="${f.x + 12}" y="${f.y + 24}">内部闪存 Flash 1MB —— 程序住在里面</text>

      <g id="blGroup">
        ${box('blBox', GEO.bl.x, GEO.bl.y, GEO.bl.w, GEO.bl.h, 8, 'url(#gBl)', '#4a94b4')}
        <text class="t-seg-t" x="${GEO.bl.x + GEO.bl.w / 2}" y="${GEO.bl.y + 22}" text-anchor="middle">引导</text>
        <text class="t-seg-t" x="${GEO.bl.x + GEO.bl.w / 2}" y="${GEO.bl.y + 40}" text-anchor="middle">程序</text>
        <text class="t-seg-s" x="${GEO.bl.x + GEO.bl.w / 2}" y="${GEO.bl.y + 62}" text-anchor="middle">48KB</text>
        <text class="t-seg-s" x="${GEO.bl.x + GEO.bl.w / 2}" y="${GEO.bl.y + 82}" text-anchor="middle">Boot</text>
      </g>

      <g id="paramGroup">
        ${box('paramBox', GEO.param.x, GEO.param.y, GEO.param.w, GEO.param.h, 8, 'url(#gParam)', '#a483cc')}
        <text class="t-seg-t" x="${GEO.param.x + GEO.param.w / 2}" y="${GEO.param.y + 22}" text-anchor="middle">小纸条</text>
        <text id="paramVal" class="t-param-val" x="${GEO.param.x + GEO.param.w / 2}" y="${GEO.param.y + 58}" text-anchor="middle">0</text>
        <text class="t-seg-s" x="${GEO.param.x + GEO.param.w / 2}" y="${GEO.param.y + 84}" text-anchor="middle">16KB</text>
      </g>

      <g id="appGroup">
        ${box('appBox', GEO.app.x, GEO.app.y, GEO.app.w, GEO.app.h, 8, '#132a24', '#2f8f6a')}
        <rect id="appFill" x="${GEO.app.x}" y="${GEO.app.y}" width="${GEO.app.w}" height="${GEO.app.h}" rx="8" fill="url(#gApp)"/>
        <text class="t-seg-t" x="${GEO.app.x + GEO.app.w / 2}" y="${GEO.app.y + 30}" text-anchor="middle">舞台 · App</text>
        <text id="appVer" class="t-app-ver" x="${GEO.app.x + GEO.app.w / 2}" y="${GEO.app.y + 62}" text-anchor="middle">1.0.0</text>
        <text id="appNote" class="t-seg-s" x="${GEO.app.x + GEO.app.w / 2}" y="${GEO.app.y + 86}" text-anchor="middle">960KB · 正在运行</text>
      </g>

      <text id="mcuStatus" class="t-status" x="${m.x + m.w / 2}" y="${m.y + m.h - 14}" text-anchor="middle">上电中…</text>
    </g>`;
  }

  function storeNode() {
    const s = GEO.store;
    const seg = [
      { id: 'stg', g: GEO.stg, title: '暂存区', sub: '新固件先放这里', color: '#8b5cf6' },
      { id: 'bk', g: GEO.bk, title: '备份区', sub: '放旧固件（后悔药）', color: '#f59e0b' },
      { id: 'rc', g: GEO.rc, title: '出厂区', sub: '最保险的那一份', color: '#38bdf8' }
    ];
    let inner = '';
    seg.forEach((it) => {
      const g = it.g;
      inner += `<g id="${it.id}Group">
        ${box(it.id + 'Box', g.x, g.y, g.w, g.h, 10, '#171233', '#4c3f7a')}
        <rect id="${it.id}Fill" x="${g.x}" y="${g.y}" width="0" height="${g.h}" rx="10" fill="${it.color}" opacity=".55"/>
        <rect x="${g.x}" y="${g.y}" width="6" height="${g.h}" fill="${it.color}" opacity=".9"/>
        <text class="t-store-t" x="${g.x + 18}" y="${g.y + 28}">${it.title}</text>
        <text class="t-store-s" x="${g.x + 18}" y="${g.y + 50}">${it.sub}</text>
        <text id="${it.id}State" class="t-store-st" x="${g.x + g.w - 16}" y="${g.y + 30}" text-anchor="end">空</text>
      </g>`;
    });
    return `<g id="store" class="node">
      ${box('storeBox', s.x, s.y, s.w, s.h, 18, 'url(#gStore)', '#4c3f7a', 'filter="url(#soft)"')}
      <text class="t-title" x="${s.x + 20}" y="${s.y + 30}">外挂存储器 W25Q64</text>
      <text class="t-sub" x="${s.x + s.w - 20}" y="${s.y + 30}" text-anchor="end">8MB · 相当于"仓库"</text>
      ${inner}
      ${box('freeBox', GEO.free.x, GEO.free.y, GEO.free.w, GEO.free.h, 10, '#141026', '#3a3160')}
      <text class="t-store-s" x="${GEO.free.x + 18}" y="${GEO.free.y + 30}">（还空着 4MB 多，暂时用不到）</text>
    </g>`;
  }

  function cacheRefs() {
    const q = (id) => root.querySelector('#' + id);
    refs = {
      world: world,
      wifiLink: q('wifiLink'), uartLink: q('uartLink'), spiLink: q('spiLink'),
      cloud: q('cloud'), cloudBox: q('cloudBox'), cloudPkg: q('cloudPkg'),
      esp: q('esp'), espBox: q('espBox'), espLed: q('espLed'),
      mcu: q('mcu'), mcuBox: q('mcuBox'), mcuLed: q('mcuLed'), mcuStatus: q('mcuStatus'),
      cpuBox: q('cpuBox'), uartBox: q('uartBox'), spiBox: q('spiBox'),
      flashFrame: q('flashFrame'),
      blGroup: q('blGroup'), blBox: q('blBox'),
      paramGroup: q('paramGroup'), paramBox: q('paramBox'), paramVal: q('paramVal'),
      appGroup: q('appGroup'), appBox: q('appBox'), appFill: q('appFill'),
      appVer: q('appVer'), appNote: q('appNote'),
      store: q('store'), storeBox: q('storeBox'),
      stgGroup: q('stgGroup'), stgBox: q('stgBox'), stgFill: q('stgFill'), stgState: q('stgState'),
      bkGroup: q('bkGroup'), bkBox: q('bkBox'), bkFill: q('bkFill'), bkState: q('bkState'),
      rcGroup: q('rcGroup'), rcBox: q('rcBox'), rcFill: q('rcFill'), rcState: q('rcState'),
      packetLayer: null
    };
    /* 数据块与气泡层 */
    const pkt = document.createElementNS(NS, 'g');
    pkt.setAttribute('id', 'packets');
    world.appendChild(pkt);
    refs.packetLayer = pkt;
  }

  /* ================================================================
   * 渲染
   * ================================================================ */
  function setText(node, v) {
    if (node && node.textContent !== v) node.textContent = v;
  }
  function lit(node, on) {
    if (!node) return;
    const has = node.classList.contains('lit');
    if (has !== !!on) node.classList.toggle('lit', !!on);
  }
  function setAttr(node, k, v) {
    if (node && node.getAttribute(k) !== String(v)) node.setAttribute(k, String(v));
  }

  /* ---------- 镜头 ---------- */
  function lerp(a, b, p) { return a + (b - a) * p; }
  function ease(p) { return p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2; }

  /* cam = { x, y, s } —— 已经由 player 按关键帧插值过（带缓动） */
  function applyCamera(cam) {
    if (!cam) return;
    const s = cam.s || 1;
    const tx = 600 - cam.x * s;
    const ty = 350 - cam.y * s;
    world.setAttribute('transform',
      'translate(' + tx.toFixed(2) + ' ' + ty.toFixed(2) + ') scale(' + s.toFixed(4) + ')');
  }

  /* ---------- 数据块 ---------- */
  function renderPackets(list, t) {
    const layer = refs.packetLayer;
    if (!layer) return;
    const want = {};
    (list || []).forEach((f) => { want[f.id] = f; });

    /* 删除不再需要的 */
    Object.keys(packets).forEach((id) => {
      if (!want[id]) { layer.removeChild(packets[id]); delete packets[id]; }
    });

    Object.keys(want).forEach((id) => {
      const f = want[id];
      const pts = PATHS[f.path];
      if (!pts) return;
      const n = f.n || 4;
      let g = packets[id];
      if (!g || g.childNodes.length !== n) {
        if (g) layer.removeChild(g);
        g = document.createElementNS(NS, 'g');
        for (let i = 0; i < n; i++) {
          const r = document.createElementNS(NS, 'rect');
          r.setAttribute('width', f.size || 14);
          r.setAttribute('height', f.size || 14);
          r.setAttribute('rx', 3);
          r.setAttribute('fill', f.color || '#60a5fa');
          g.appendChild(r);
        }
        layer.appendChild(g);
        packets[id] = g;
      }
      /* 累计长度 */
      let total = 0;
      const seg = [];
      for (let i = 1; i < pts.length; i++) {
        const d = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
        seg.push(d); total += d;
      }
      const speed = f.speed || 0.5;
      const base = (t / 1000) * speed;
      for (let i = 0; i < n; i++) {
        let u = (base + i / n) % 1;
        if (u < 0) u += 1;
        if (f.dir < 0) u = 1 - u;
        let dist = u * total, px = pts[0][0], py = pts[0][1];
        for (let s = 0; s < seg.length; s++) {
          if (dist <= seg[s] || s === seg.length - 1) {
            const fr = seg[s] > 0 ? Math.min(1, dist / seg[s]) : 0;
            px = lerp(pts[s][0], pts[s + 1][0], fr);
            py = lerp(pts[s][1], pts[s + 1][1], fr);
            break;
          }
          dist -= seg[s];
        }
        const node = g.childNodes[i];
        const sz = f.size || 14;
        node.setAttribute('x', (px - sz / 2).toFixed(1));
        node.setAttribute('y', (py - sz / 2).toFixed(1));
        node.setAttribute('opacity', (0.35 + 0.65 * Math.sin(Math.PI * u)).toFixed(2));
      }
    });
  }

  /* ---------- 气泡（文字标签） ---------- */
  /*
   * 气泡 = 画面底部的"注解条"。
   * 它放在 world 之外，所以不跟随镜头缩放 —— 无论推得多近，注解都保持同样的字号、
   * 待在画面最下方，绝不会压住正在讲的主体。
   */
  function renderBubbles(list) {
    const layer = root.querySelector('#bubbles');
    if (!layer) return;
    const want = (list || []).filter((b) => b && b.text);
    const ids = want.map((b) => b.id);

    Object.keys(bubbles).forEach((id) => {
      if (ids.indexOf(id) < 0) { layer.removeChild(bubbles[id]); delete bubbles[id]; }
    });

    const H = 34, GAP = 12, BASE_Y = 678;
    const widths = want.map((b) => Math.max(70, b.text.length * 14.5 + 28));
    const sum = widths.reduce((a, v) => a + v, 0) + GAP * Math.max(0, want.length - 1);
    let x = 600 - sum / 2;

    want.forEach((b, i) => {
      const w = widths[i];
      let g = bubbles[b.id];
      if (!g) {
        g = document.createElementNS(NS, 'g');
        g.innerHTML = '<rect x="0" y="0" rx="9" height="34" fill="#0a1220" stroke="#3b6ea5" stroke-width="1.5"/>' +
          '<text class="t-bubble" x="14" y="23"></text>';
        layer.appendChild(g);
        bubbles[b.id] = g;
      }
      const rect = g.childNodes[0];
      const text = g.childNodes[1];
      setAttr(rect, 'width', w);
      setAttr(rect, 'stroke', b.color || '#3b6ea5');
      setText(text, b.text);
      setAttr(text, 'fill', b.color || '#cfe6ff');
      g.setAttribute('transform', 'translate(' + (x + w / 2) + ',' + BASE_Y + ') translate(' + (-w / 2) + ',' + (-H / 2) + ')');
      x += w + GAP;
    });
  }

  /* ---------- 主渲染 ---------- */
  function render(S) {
    if (!root) return;

    applyCamera(S.cam);

    /* 连线 */
    lit(refs.wifiLink, S.lit.wifi);
    lit(refs.uartLink, S.lit.uart);
    lit(refs.spiLink, S.lit.spi);

    /* 节点 */
    lit(refs.cloudBox, S.lit.cloud);
    lit(refs.espBox, S.lit.esp);
    lit(refs.mcuBox, S.lit.mcu);
    lit(refs.storeBox, S.lit.store);
    lit(refs.cpuBox, S.lit.cpu);
    lit(refs.uartBox, S.lit.uartBox);
    lit(refs.spiBox, S.lit.spiBox);
    lit(refs.espLed, S.led.esp);
    lit(refs.mcuLed, S.led.mcu);
    setAttr(refs.espLed, 'class', 'led' + (S.led.esp ? ' on' : '') + (S.led.espBlink ? ' blink' : ''));
    setAttr(refs.mcuLed, 'class', 'led' + (S.led.mcu ? ' on' : '') + (S.led.mcuBlink ? ' blink' : ''));

    /* 内部 Flash */
    lit(refs.flashFrame, S.lit.flash);
    lit(refs.blGroup, S.lit.bl);
    lit(refs.paramGroup, S.lit.param);
    lit(refs.appGroup, S.lit.app);
    setAttr(refs.paramVal, 'class', 't-param-val f' + S.paramFlag + (S.paramPulse ? ' pulse' : ''));
    setText(refs.paramVal, String(S.paramFlag));
    setText(refs.appVer, S.appVer || '—');
    setText(refs.appNote, S.appNote || '');
    /* 危险状态：舞台被红框标出来（“正在跑的程序不能擦”） */
    if (refs.appBox) {
      refs.appBox.setAttribute('stroke', S.appWarn ? '#f87171' : '#2f8f6a');
      refs.appBox.setAttribute('stroke-width', S.appWarn ? '2.6' : '1.5');
    }
    /* 重启：MCU 指示灯闪 */
    if (S.reboot && refs.mcuLed) refs.mcuLed.classList.add('blink');

    /* A 槽填充（擦除时高度收起，写入时长高） */
    const af = Math.max(0, Math.min(1, S.appFill === undefined ? 1 : S.appFill));
    setAttr(refs.appFill, 'height', (GEO.app.h * af).toFixed(1));
    setAttr(refs.appFill, 'y', (GEO.app.y + GEO.app.h * (1 - af)).toFixed(1));
    setAttr(refs.appFill, 'fill', S.appIsNew ? 'url(#gAppNew)' : 'url(#gApp)');
    setAttr(refs.appFill, 'opacity', af > 0.02 ? 1 : 0);

    /* 仓库三格 */
    setFill(refs.stgFill, GEO.stg, S.stg.fill);
    setFill(refs.bkFill, GEO.bk, S.bk.fill);
    setFill(refs.rcFill, GEO.rc, S.rc.fill);
    setText(refs.stgState, S.stg.text);
    setText(refs.bkState, S.bk.text);
    setText(refs.rcState, S.rc.text);
    setAttr(refs.stgState, 'class', 't-store-st ' + S.stg.state);
    setAttr(refs.bkState, 'class', 't-store-st ' + S.bk.state);
    setAttr(refs.rcState, 'class', 't-store-st ' + S.rc.state);
    lit(refs.stgBox, S.lit.stg);
    lit(refs.bkBox, S.lit.bk);
    lit(refs.rcBox, S.lit.rc);

    /* 状态文字 */
    setText(refs.mcuStatus, S.statusText || '');

    /* 粒子与气泡 */
    renderPackets(S.flow, S.t);
    renderBubbles(S.bubbles);
  }

  function setFill(node, g, v) {
    const w = Math.max(0, Math.min(1, v || 0)) * g.w;
    setAttr(node, 'width', w.toFixed(1));
    setAttr(node, 'opacity', w > 1 ? 0.55 : 0);
  }

  return { build, render, GEO, PATHS };
})();
