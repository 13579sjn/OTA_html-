/* =============================================================================
 * acts-2.js —— 新手讲解版剧本（第 8–14 幕）
 * ========================================================================== */
'use strict';

window.STORY_ACTS = window.STORY_ACTS || [];

(function () {

  const A = window.STORY_ACTS;

  /* ---------------------------------------------------------------- */
  /* 第 8 幕：校验指纹（含真机上真实发生的"重下一次"）                 */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a8', no: 8, title: '校验：指纹对不上就别用', short: '校验指纹', dur: 27000,
    cam: [[0, 950, 410, 1.45], [1, 950, 410, 1.42]],
    caps: [
      { at: 0.00, text: '下完了，但先别急着用 —— 得核对指纹。', hl: ['指纹'] },
      { at: 0.13, text: '服务器给的 MD5，和本地算出来的必须一模一样。', hl: ['MD5'] },
      { at: 0.32, text: '真机上这里踩过坑：网速快的时候串口会丢字节，字节数够了，指纹对不上。', hl: ['指纹对不上'] },
      { at: 0.54, text: '对不上就把暂存区擦掉，从头再下一次。宁可多花 9 秒，也不能装个坏固件。', hl: ['从头再下'] },
      { at: 0.78, text: '指纹通过，才算"这块货是真的"。', hl: ['真的'] }
    ],
    init(S) {
      S.lit.store = true; S.lit.stg = true;
      S.stg.fill = 1; S.stg.text = '✓ 已写完'; S.stg.state = 'ok';
      S.statusText = '正在核对指纹';
    },
    tick(S, p) {
      S.bubbles = [];
      if (p < 0.32) {
        S.stg.fill = 1; S.stg.text = '核对指纹…'; S.stg.state = 'warn';
        S.bubbles = [{ id: 'c1', text: '服务器 MD5  vs  本地 MD5', x: 905, y: 326, color: '#c4b5fd' }];
      } else if (p < 0.54) {
        S.stg.fill = 1; S.stg.text = '✗ 指纹不符'; S.stg.state = 'err';
        S.bubbles = [{ id: 'c2', text: '✗ 字节数对了，但内容错了', x: 905, y: 326, color: '#f87171' }];
        S.statusText = '校验失败：数据中间丢了字节';
      } else if (p < 0.78) {
        /* 擦掉重下 */
        const w = (p - 0.54) / 0.24;
        S.stg.fill = w < 0.5 ? (1 - w * 2) : (w - 0.5) * 2;
        S.stg.text = w < 0.5 ? '擦除中…' : '重新下载 ' + Math.round((w - 0.5) * 200) + '%';
        S.stg.state = 'warn';
        S.lit.spi = true;
        S.flow = [{ id: 're', path: 'cloudToStore', n: 5, color: '#fbbf24', speed: 0.6, dir: 1, size: 15 }];
        S.bubbles = [{ id: 'c3', text: '擦掉，重下一遍', x: 905, y: 326, color: '#fbbf24' }];
      } else {
        S.stg.fill = 1; S.stg.text = '✓ 指纹通过'; S.stg.state = 'ok';
        S.flow = [];
        S.bubbles = [{ id: 'c4', text: '✓ MD5 + SHA-256 全部通过', x: 905, y: 326, color: '#4ade80' }];
        S.statusText = '新固件已确认无误';
      }
    }
  });

  /* ---------------------------------------------------------------- */
  /* 第 9 幕：备份旧版本                                              */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a9', no: 9, title: '备份：留一颗后悔药', short: '备份旧版本', dur: 23000,
    cam: [[0, 300, 470, 1.55], [0.35, 620, 450, 1.15], [0.7, 950, 410, 1.45], [1, 950, 410, 1.42]],
    caps: [
      { at: 0.00, text: '新固件准备好了，但先别急 —— 旧版本得留一份。', hl: [] },
      { at: 0.20, text: '把舞台上的 App 1.0.0，完整复制到仓库的"备份区"。', hl: ['备份区'] },
      { at: 0.46, text: '为什么？因为新固件有可能一开机就崩。那时候你只会想一件事：怎么退回去。', hl: ['退回去'] },
      { at: 0.74, text: '备份区，就是你的后悔药。', hl: ['后悔药'] }
    ],
    init(S) {
      S.lit.mcu = true; S.lit.store = true; S.lit.app = true;
      S.appVer = '1.0.0';
      S.bk.fill = 0; S.bk.text = '空'; S.bk.state = '';
      S.statusText = '正在备份旧固件';
    },
    tick(S, p) {
      const cp = Math.max(0, Math.min(1, (p - 0.24) / 0.42));
      S.bk.fill = cp;
      if (cp <= 0) { S.bk.text = '空'; S.bk.state = ''; }
      else if (cp < 1) { S.bk.text = '复制 ' + Math.round(cp * 100) + '%'; S.bk.state = 'warn'; }
      else { S.bk.text = '✓ 备份好了'; S.bk.state = 'ok'; }

      if (p > 0.2 && cp < 1) {
        S.lit.bk = true; S.lit.spi = true;
        /* 从舞台流到备份区：dir=-1 让方块从仓库走向设备，这里反过来用 */
        S.flow = [{ id: 'bk', path: 'storeToApp', n: 4, color: '#f59e0b', speed: 0.55, dir: -1, size: 14 }];
      } else if (cp >= 1) {
        S.flow = [];
      }
      S.bubbles = [];
      if (cp >= 1) {
        S.bubbles = [{ id: 'b', text: '✓ 旧版 1.0.0 已存好', x: 905, y: 413, color: '#fbbf24' }];
        S.statusText = '旧固件已备份';
      }
    }
  });

  /* ---------------------------------------------------------------- */
  /* 第 10 幕：改小纸条，然后重启                                     */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a10', no: 10, title: '改小纸条，然后重启', short: '写标志 + 重启', dur: 23000,
    cam: [[0, 950, 410, 1.42], [0.28, 210, 480, 1.55], [0.82, 210, 480, 1.55], [1, 300, 462, 1.46]],
    caps: [
      { at: 0.00, text: '货齐了，App 做最后一件事：改小纸条。', hl: ['小纸条'] },
      { at: 0.17, text: 'boot_flag 从 0 改成 1，意思是"下次开机，试试新固件"。', hl: ['0 改成 1'] },
      { at: 0.42, text: '顺手记下：新固件多长、它的 SHA-256 指纹、旧固件备份在哪。', hl: ['SHA-256'] },
      { at: 0.64, text: '然后 —— 它自己重启。', hl: [] },
      { at: 0.82, text: '注意：到这一刻，舞台上的 App 还是旧的，一个字节都没动。', hl: ['一个字节都没动'] }
    ],
    init(S) {
      S.lit.param = true; S.lit.mcu = true;
      S.paramFlag = 0;
      S.statusText = 'App 正在写参数区';
    },
    tick(S, p) {
      S.bubbles = [];
      if (p < 0.17) {
        S.bubbles = [{ id: 'p0', text: 'boot_flag = 0', x: 204, y: 442, color: '#c4b5fd' }];
      } else if (p < 0.62) {
        S.paramFlag = 1;
        S.paramPulse = true;
        S.bubbles = [{ id: 'p1', text: 'boot_flag = 1  → 试试新固件', x: 204, y: 442, color: '#fbbf24' }];
        S.statusText = '已标记：下次开机试新固件';
      } else {
        S.paramFlag = 1;
        S.paramPulse = p < 0.72;
        S.reboot = true;
        S.lit.cpu = true;
        S.statusText = '设备重启中…';
        if (p > 0.8) {
          S.bubbles = [{ id: 'p2', text: '舞台上的 App 1.0.0 完好无损', x: 331, y: 620, color: '#6ee7b7' }];
        }
      }
    }
  });

  /* ---------------------------------------------------------------- */
  /* 第 11 幕：Bootloader 搬货                                        */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a11', no: 11, title: 'Bootloader 搬货', short: '搬运固件', dur: 35000,
    cam: [[0, 300, 462, 1.50], [0.18, 950, 410, 1.45], [0.44, 950, 410, 1.42], [0.6, 290, 470, 1.62], [1, 300, 462, 1.50]],
    caps: [
      { at: 0.00, text: '重启了，又回到 Bootloader。', hl: ['Bootloader'] },
      { at: 0.11, text: '它读小纸条：flag = 1，意思是"试试新固件"。', hl: ['flag = 1'] },
      { at: 0.26, text: '但它不会马上擦舞台 —— 先去仓库验货，算一遍 SHA-256。', hl: ['先去仓库验货'] },
      { at: 0.44, text: '验过了，才敢动手：把舞台擦干净。', hl: ['擦干净'] },
      { at: 0.61, text: '然后一块块把新固件从仓库搬到舞台上。', hl: ['一块块'] },
      { at: 0.83, text: '搬完再校验一次：舞台上的程序，能不能跑？', hl: ['能不能跑'] }
    ],
    init(S) {
      S.lit.mcu = true; S.lit.flash = true; S.lit.bl = true;
      S.paramFlag = 1;
      S.appVer = '1.0.0'; S.appFill = 1; S.appIsNew = false;
      S.statusText = 'Bootloader 正在工作';
      S.led.mcu = true;
    },
    tick(S, p) {
      S.bubbles = [];
      if (p < 0.11) {
        S.bubbles = [{ id: 'b0', text: '又是我，先跑', x: 133, y: 442, color: '#7dd3fc' }];
      } else if (p < 0.26) {
        S.lit.param = true; S.paramPulse = true;
        S.bubbles = [{ id: 'b1', text: 'flag = 1 → 试新固件', x: 204, y: 442, color: '#fbbf24' }];
      } else if (p < 0.44) {
        S.lit.store = true; S.lit.stg = true;
        S.stg.text = '验货中…'; S.stg.state = 'warn';
        S.bubbles = [{ id: 'b2', text: 'SHA-256 对得上才敢动', x: 905, y: 326, color: '#c4b5fd' }];
        S.statusText = '校验仓库里的新固件';
      } else if (p < 0.61) {
        S.lit.app = true;
        S.stg.text = '✓ 验货通过'; S.stg.state = 'ok';
        const e = (p - 0.44) / 0.17;
        S.appFill = 1 - e;
        S.appWarn = true;
        S.bubbles = [{ id: 'b3', text: '擦除舞台（A 槽）', x: 331, y: 442, color: '#f87171' }];
        S.statusText = '擦除 A 槽…';
      } else if (p < 0.83) {
        const w = (p - 0.61) / 0.22;
        S.appFill = w;
        S.appIsNew = true;
        S.appVer = '1.0.1';
        S.appWarn = false;
        S.lit.spi = true; S.lit.store = true;
        S.flow = [{ id: 'mv', path: 'storeToApp', n: 5, color: '#a78bfa', speed: 0.55, dir: 1, size: 14 }];
        S.bubbles = [{ id: 'b4', text: Math.round(w * 100) + '%  仓库 → 舞台', x: 560, y: 430, color: '#a78bfa' }];
        S.statusText = '搬运中…';
      } else {
        S.appFill = 1; S.appIsNew = true; S.appVer = '1.0.1';
        S.flow = [];
        S.bubbles = [{ id: 'b5', text: '✓ 能跑，准备跳过去', x: 331, y: 442, color: '#4ade80' }];
        S.statusText = '新固件已就位';
      }
    }
  });

  /* ---------------------------------------------------------------- */
  /* 第 12 幕：新固件的 30 秒试用期                                   */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a12', no: 12, title: '新固件的 30 秒试用期', short: '启动确认', dur: 27000,
    cam: [[0, 300, 462, 1.55], [0.45, 230, 470, 1.68], [1, 450, 370, 1.38]],
    caps: [
      { at: 0.00, text: '跳过去以后，跑的是新固件 1.0.1。', hl: ['1.0.1'] },
      { at: 0.15, text: '但 Bootloader 留了个心眼：它把 boot_count 加了 1。', hl: ['boot_count'] },
      { at: 0.32, text: '新固件必须自己证明"我能跑"：稳定运行 30 秒，然后把 flag 改回 NORMAL。', hl: ['30 秒'] },
      { at: 0.56, text: '改了，才算正式转正。', hl: ['转正'] },
      { at: 0.74, text: '同时向服务器报一个 201 —— 服务器那边就显示"升级成功"。', hl: ['201'] }
    ],
    init(S) {
      S.lit.mcu = true; S.lit.app = true; S.lit.cpu = true;
      S.appVer = '1.0.1'; S.appFill = 1; S.appIsNew = true;
      S.paramFlag = 1;
      S.statusText = 'App 1.0.1 正在运行';
      S.led.mcu = true;
    },
    tick(S, p) {
      S.bubbles = [];
      if (p < 0.32) {
        S.bubbles = [{ id: 'c0', text: 'boot_count: 0 → 1', x: 133, y: 442, color: '#fbbf24' }];
      } else if (p < 0.56) {
        const sec = Math.round(Math.min(30, ((p - 0.32) / 0.24) * 30));
        S.bubbles = [{ id: 'c1', text: '稳定运行 ' + sec + ' / 30 秒…', x: 331, y: 442, color: '#fbbf24' }];
        S.statusText = '试用期：' + sec + ' / 30 秒';
      } else if (p < 0.74) {
        S.paramFlag = 0;
        S.paramPulse = true;
        S.lit.param = true;
        S.bubbles = [{ id: 'c2', text: 'flag = NORMAL  正式转正 ✓', x: 204, y: 442, color: '#4ade80' }];
        S.statusText = '新固件已确认，正式生效';
      } else {
        S.paramFlag = 0;
        S.lit.cloud = true; S.lit.esp = true; S.lit.wifi = true;
        S.flow = [{ id: 'rep', path: 'wifi', n: 2, color: '#4ade80', speed: 0.9, dir: -1, size: 16 }];
        S.bubbles = [{ id: 'c3', text: '上报 201 升级成功', x: 560, y: 150, color: '#4ade80' }];
        S.statusText = '升级成功，业务继续运行';
      }
    }
  });

  /* ---------------------------------------------------------------- */
  /* 第 13 幕：出问题会怎样（四种坏结果）                              */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a13', no: 13, title: '出问题会怎样？', short: '出问题会怎样', dur: 42000,
    cam: [[0, 600, 350, 1.0], [1, 600, 350, 1.0]],
    caps: [
      { at: 0.00, text: '最后说说：如果出问题了，会怎么样。', hl: [] },
      { at: 0.07, text: '情况一：下载时指纹不对 → 什么都不改，还是旧版本。设备甚至不知道你来过。', hl: ['什么都不改'] },
      { at: 0.29, text: '情况二：新固件一启动就崩，连续三次 → Bootloader 自动回滚到备份区，设备还能用。', hl: ['自动回滚'] },
      { at: 0.53, text: '情况三：备份也坏了 → 用出厂区那份最保险的固件。', hl: ['出厂区'] },
      { at: 0.73, text: '情况四：连出厂区都坏了 → 设备卡在 Bootloader 里不动，这才是真正的"变砖"。', hl: ['变砖'] },
      { at: 0.90, text: '所以记住：备份区和出厂区，就是设备的两条命。', hl: ['两条命'] }
    ],
    init(S) {
      S.lit.mcu = true; S.lit.store = true;
      S.statusText = '如果升级失败，会怎样？';
    },
    tick(S, p) {
      S.bubbles = [];
      const stage = p < 0.29 ? 1 : (p < 0.53 ? 2 : (p < 0.73 ? 3 : 4));
      S.stg.text = '✓ 已写完'; S.stg.state = 'ok';
      S.stg.fill = 1;
      S.bk.text = '✓ 旧版 1.0.0'; S.bk.state = 'ok'; S.bk.fill = 1;
      S.rc.text = '✓ 出厂版'; S.rc.state = 'ok'; S.rc.fill = 1;
      S.appFill = 1; S.appIsNew = false; S.appVer = '1.0.0';

      if (stage === 1) {
        S.stg.text = '✗ 指纹不符'; S.stg.state = 'err';
        S.bubbles = [{ id: 'f1', text: '结果：还是 1.0.0，什么都没变', x: 600, y: 690, color: '#4ade80' }];
        S.statusText = '情况一：下载校验失败 → 保持旧版本';
      } else if (stage === 2) {
        S.lit.bk = true;
        S.appIsNew = true; S.appVer = '1.0.1';
        S.bubbles = [
          { id: 'f2a', text: '新固件崩 3 次', x: 331, y: 442, color: '#f87171' },
          { id: 'f2b', text: '→ 自动换回备份区', x: 905, y: 413, color: '#fbbf24' }
        ];
        S.statusText = '情况二：启动失败 → 回滚到 1.0.0';
      } else if (stage === 3) {
        S.lit.rc = true;
        S.bk.text = '✗ 备份坏了'; S.bk.state = 'err';
        S.bubbles = [{ id: 'f3', text: '备份坏了 → 用出厂版', x: 905, y: 495, color: '#38bdf8' }];
        S.statusText = '情况三：回滚失败 → 恢复出厂固件';
      } else {
        S.lit.mcu = true; S.lit.bl = true;
        S.rc.text = '✗ 出厂区也坏了'; S.rc.state = 'err';
        S.appFill = 0; S.appVer = '—'; S.appNote = '没有可用的程序';
        S.bubbles = [{ id: 'f4', text: '卡在这里不动 = 变砖', x: 300, y: 690, color: '#f87171' }];
        S.statusText = '情况四：全部失效 → 停在 Bootloader';
      }
    }
  });

  /* ---------------------------------------------------------------- */
  /* 第 14 幕：一句话总结                                             */
  /* ---------------------------------------------------------------- */
  A.push({
    id: 'a14', no: 14, title: '一句话总结', short: '总结', dur: 18000,
    cam: [[0, 600, 350, 1.06], [1, 600, 350, 0.92]],
    caps: [
      { at: 0.00, text: '把整件事压缩成一句话：', hl: [] },
      { at: 0.16, text: '新固件先进仓库 → 验指纹 → 备份旧版 → 改小纸条 → 重启 → Bootloader 验货、擦舞台、搬货 → 新固件试跑 30 秒转正。', hl: ['仓库', '验指纹', '备份', '搬货'] },
      { at: 0.58, text: '全程不用拆机，不用插电脑。这就是 OTA。', hl: ['OTA'] },
      { at: 0.78, text: '想一步步对照真实代码，点右上角的"进阶版"。', hl: ['进阶版'] }
    ],
    init(S) {
      S.lit.cloud = true; S.lit.esp = true; S.lit.mcu = true; S.lit.store = true;
      S.lit.flash = true; S.lit.bl = true; S.lit.param = true; S.lit.app = true;
      S.lit.stg = true; S.lit.bk = true; S.lit.rc = true;
      S.lit.wifi = true; S.lit.uart = true; S.lit.spi = true;
      S.led.mcu = true; S.led.esp = true;
      S.statusText = 'OTA 完成';
    },
    tick(S, p) {
      S.paramFlag = 0;
      S.appVer = '1.0.1'; S.appFill = 1; S.appIsNew = true;
      S.stg.fill = 1; S.stg.text = '✓'; S.stg.state = 'ok';
      S.bk.fill = 1; S.bk.text = '✓'; S.bk.state = 'ok';
      S.rc.fill = 1; S.rc.text = '✓'; S.rc.state = 'ok';
      if (p > 0.2) {
        S.flow = [{ id: 'sum', path: 'cloudToStore', n: 4, color: '#60a5fa', speed: 0.42, dir: 1, size: 14 }];
      }
      S.bubbles = [];
      if (p > 0.6) {
        S.bubbles = [{ id: 'end', text: '✓ 升级成功：1.0.0 → 1.0.1', x: 600, y: 690, color: '#4ade80' }];
      }
    }
  });

})();
