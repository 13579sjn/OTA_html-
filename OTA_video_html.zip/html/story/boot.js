/* boot.js —— 把舞台、剧本、播放器接起来 */
'use strict';

(function () {
  function boot() {
    const stage = document.getElementById('stage');
    STORY_SCENE.build(stage);

    STORY_PLAYER.init({
      actNo: document.getElementById('actNo'),
      actTitle: document.getElementById('actTitle'),
      status: document.getElementById('status'),
      dots: document.getElementById('dots'),
      capText: document.getElementById('capText'),
      track: document.getElementById('track'),
      bands: document.getElementById('bands'),
      fill: document.getElementById('fill'),
      head: document.getElementById('head'),
      tCur: document.getElementById('tCur'),
      tTot: document.getElementById('tTot'),
      pct: document.getElementById('pct'),
      btnPlay: document.getElementById('btnPlay'),
      btnPrev: document.getElementById('btnPrev'),
      btnNext: document.getElementById('btnNext'),
      speeds: document.getElementById('speeds'),
      btnCode: document.getElementById('btnCode'),
      btnCloseCode: document.getElementById('btnCloseCode'),
      codeDrawer: document.getElementById('codeDrawer'),
      codeBody: document.getElementById('codeBody')
    });

    document.body.classList.add('ready');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
