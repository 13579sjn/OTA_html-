/* =============================================================================
 * state.js —— 统一执行状态模型
 *
 * 设计要点（对应“时间轴拖到任意位置都必须完整恢复画面”的要求）：
 *   状态是时间 t 的纯函数：build(scn, t) = 新建空状态 + 依序重放所有 t0 <= t 的
 *   step.apply() + 用当前 step 的 live(p) 做段内插值。
 *   因此不存在“累加器漂移”，也不存在“跳转后重复触发”——拖到任何位置都等价于
 *   从 0 播到该位置。播放是同一函数的连续求值，跳转是同一函数的离散求值。
 *
 * 状态里只放“可显示量”，不放 DOM 引用；渲染层单向读取。
 * ========================================================================== */
'use strict';

window.OTA_STATE = (function () {

  const STATE_NAME = {
    OTA_ST_IDLE: 'IDLE 空闲',
    OTA_ST_CHECKING: 'CHECKING 查询',
    OTA_ST_DOWNLOADING: 'DOWNLOADING 下载',
    OTA_ST_VERIFYING: 'VERIFYING 校验',
    OTA_ST_BACKUPING: 'BACKUPING 备份',
    OTA_ST_READY_REBOOT: 'READY 待重启',
    OTA_ST_NONE: 'NONE 无任务',
    OTA_ST_ERROR: 'ERROR 出错'
  };

  const FLAG_NAME = ['NORMAL', 'TRY_NEW', 'ROLLBACK', 'RECOVERY'];
  const BK_NAME = ['EMPTY', 'DOWNLOADING', 'VALID'];

  function create() {
    const f = window.OTA_FACTS;
    return {
      t: 0,
      step: null,
      p: 0,
      scene: null,
      vars: Object.assign({}, f.initialState),
      ctx: {
        cpu: 'reset',        /* reset | bl | app | halt */
        image: 'BL',         /* BL | APP1 | APP2 */
        func: '—',
        addr: '—',
        msp: '—',
        vtor: '0x08000000',
        clk: '—'
      },
      intf: {
        bl: { state: 'idle' },
        param: { state: 'idle', seq: 2 },
        app: { state: 'old', fill: 1, ver: '1.0.0', erase: 0 },
        usart1: 'idle', usart3: 'idle', spi2: 'idle', dma: 'normal',
        iwdg: 'off', rtos: 'idle', cloud: 'off'
      },
      ext: {
        staging: { mode: 'idle', frac: 0 },
        backup: { mode: 'idle', frac: 0 },
        recovery: { mode: 'idle', frac: 0 }
      },
      prog: { dl: 0, bk: 0 },
      counters: { uart3: 0, spi: 0, fl: 0 },
      logs: [],
      frame: null,
      http: null,
      ipd: null,
      task: null,
      esp: { mode: 'off', link: '—' },
      check: {},
      slotTable: null,
      /* 一句话状态标记 */
      branch: null, failKind: null, done: false, halted: false,
      suggestMode: false, otaActive: false, otaMode: 0,
      truncated: false, md5Fail: false, shaVerified: false,
      rebootCountdown: 0, confirmWaited: 0,
      verifyProg: 0, eraseProg: 0, copyProg: 0, rollbackProg: 0
    };
  }

  function log(S, text, cls) {
    S.logs.push({ text: text, cls: cls || 'info', t: S.t });
  }

  function applyStep(S, st) {
    S.t = st.t0;
    S.step = st;
    if (typeof st.apply === 'function') {
      try {
        st.apply(S);
      } catch (e) {
        log(S, '[demo] step "' + st.id + '" apply 异常: ' + e.message, 'err');
      }
    }
  }

  /**
   * 求 t 时刻的完整状态。
   * @param {object} scn 已编译的 scenario（含 steps / scenes / total）
   * @param {number} t   毫秒
   */
  function build(scn, t) {
    const S = create();
    const tt = Math.max(0, Math.min(t, scn.total));
    S.t = tt;
    S.scenario = scn;

    let cur = null;
    for (let i = 0; i < scn.steps.length; i++) {
      const st = scn.steps[i];
      if (st.t1 <= tt) {
        /* 已经完全播完的步骤：apply 之后再按 p=1 收尾一次，
           否则"只在 live(1) 里才成立"的状态（如某区写入完成转为 VALID）
           会在进入下一步后回退。这一步必须幂等。 */
        applyStep(S, st);
        if (typeof st.live === 'function') {
          try { st.live(S, 1); } catch (e) { /* 收尾异常不影响后续 */ }
        }
      } else if (st.t0 <= tt) {
        applyStep(S, st);
        cur = st;
      } else {
        break;
      }
    }

    if (cur) {
      const p = cur.dur > 0 ? Math.min(1, (tt - cur.t0) / cur.dur) : 1;
      S.p = p;
      if (typeof cur.live === 'function') {
        try {
          cur.live(S, p);
        } catch (e) {
          log(S, '[demo] step "' + cur.id + '" live 异常: ' + e.message, 'err');
        }
      }
      /* 段内插值后再夹一次，避免 apply() 与 live() 不一致 */
      S.vars.dl_offset = Math.min(S.vars.dl_offset, S.vars.dl_total || S.vars.dl_offset);
    }

    /* 当前场景 */
    S.scene = sceneAt(scn, tt);
    /* 总进度 */
    S.overall = scn.total > 0 ? tt / scn.total : 0;
    return S;
  }

  function sceneAt(scn, t) {
    const list = scn.scenes;
    for (let i = 0; i < list.length; i++) {
      if (t >= list[i].t0 && t < list[i].t1) return list[i];
    }
    return list[list.length - 1] || null;
  }

  function stepAt(scn, t) {
    let cur = null;
    for (let i = 0; i < scn.steps.length; i++) {
      if (scn.steps[i].t0 <= t) cur = scn.steps[i];
      else break;
    }
    return cur || scn.steps[0];
  }

  /* ---------- 格式化 ---------- */
  function pad(n, w) {
    let s = String(n);
    while (s.length < w) s = '0' + s;
    return s;
  }

  function fmtTime(ms) {
    const s = Math.max(0, Math.floor(ms / 1000));
    return pad(Math.floor(s / 60), 2) + ':' + pad(s % 60, 2);
  }

  function fmtTimeMs(ms) {
    const total = Math.max(0, Math.floor(ms));
    const s = Math.floor(total / 1000);
    return pad(Math.floor(s / 60), 2) + ':' + pad(s % 60, 2) + '.' + pad(total % 1000, 3);
  }

  function fmtVer(v) {
    return 'V' + ((v >> 16) & 0xFF) + '.' + ((v >> 8) & 0xFF) + '.' + (v & 0xFF) +
      '  (0x' + (v >>> 0).toString(16).toUpperCase().padStart(6, '0') + ')';
  }

  function fmtBytes(n) {
    if (n >= 1024) return (n / 1024).toFixed(1) + ' KB';
    return n + ' B';
  }

  function flagName(v) { return FLAG_NAME[v] || ('?' + v); }
  function bkName(v) { return BK_NAME[v] || ('?' + v); }
  function stateName(k) { return STATE_NAME[k] || k; }

  return {
    create, build, sceneAt, stepAt, log,
    fmtTime, fmtTimeMs, fmtVer, fmtBytes,
    flagName, bkName, stateName,
    FLAG_NAME, BK_NAME
  };
})();
