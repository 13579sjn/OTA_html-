/* =============================================================================
 * timeline.js —— 唯一的播放时钟
 *
 * 播放、暂停、倍速、拖动、单步、场景跳转全部只改这一个 clock 的 t，
 * 然后广播给所有订阅者。因此不存在“动画走一套时间、进度条走另一套时间”。
 * ========================================================================== */
'use strict';

window.OTA_TIMELINE = (function () {

  const listeners = [];
  let scn = null;
  let t = 0;
  let speed = 1;
  let playing = false;
  let raf = 0;
  let lastTs = 0;

  function emit(reason) {
    const snapshot = { t: t, playing: playing, speed: speed, reason: reason, duration: scn ? scn.total : 0 };
    for (let i = 0; i < listeners.length; i++) {
      try { listeners[i](snapshot); } catch (e) { /* 单个订阅者异常不影响其它 */ }
    }
  }

  function load(scenario, startT) {
    scn = scenario;
    t = Math.max(0, Math.min(startT || 0, scenario.total));
    playing = false;
    cancelAnimationFrame(raf);
    emit('load');
  }

  function frame(ts) {
    if (!playing || !scn) return;
    if (!lastTs) lastTs = ts;
    let dt = ts - lastTs;
    lastTs = ts;
    /* 标签页切回来时 dt 会很大，夹一下避免一次跳过整段 */
    if (dt > 250) dt = 250;
    t += dt * speed;

    if (t >= scn.total) {
      t = scn.total;
      playing = false;
      emit('end');
      return;
    }
    emit('tick');
    raf = requestAnimationFrame(frame);
  }

  function play() {
    if (!scn) return;
    if (t >= scn.total - 1) t = 0;
    if (playing) return;
    playing = true;
    lastTs = 0;
    raf = requestAnimationFrame(frame);
    emit('play');
  }

  function pause() {
    if (!playing) return;
    playing = false;
    cancelAnimationFrame(raf);
    emit('pause');
  }

  function toggle() {
    if (playing) pause(); else play();
  }

  function restart() {
    seek(0);
    play();
  }

  function seek(ms, reason) {
    if (!scn) return;
    const nt = Math.max(0, Math.min(ms, scn.total));
    if (Math.abs(nt - t) < 0.5 && reason !== 'force') return;
    t = nt;
    lastTs = 0;
    emit(reason || 'seek');
  }

  function nudge(deltaMs) {
    if (!scn) return;
    seek(t + deltaMs, 'nudge');
  }

  function setSpeed(s) {
    speed = s;
    emit('speed');
  }

  function getSpeed() { return speed; }

  function jumpScene(dir) {
    if (!scn) return;
    const scenes = scn.scenes;
    const cur = window.OTA_STATE.sceneAt(scn, t);
    let i = scenes.indexOf(cur);
    if (i < 0) i = 0;
    if (dir > 0) {
      if (i >= scenes.length - 1) { seek(scn.total, 'scene'); return; }
      seek(scenes[i + 1].t0, 'scene');
    } else {
      /* 已在场景中段：先回到本场景起点；否则退到上一场景起点 */
      if (cur && t - cur.t0 > 600) {
        seek(cur.t0, 'scene');
        return;
      }
      seek(scenes[Math.max(i - 1, 0)].t0, 'scene');
    }
  }

  function jumpStep(dir) {
    if (!scn) return;
    const steps = scn.steps;
    const cur = window.OTA_STATE.stepAt(scn, t);
    let i = steps.indexOf(cur);
    if (i < 0) i = 0;
    if (dir > 0) {
      if (t - cur.t0 < cur.dur - 60 && t > cur.t0 + 40) {
        seek(cur.t1 - 1, 'step');   /* 先跳到本步末尾 */
        return;
      }
      const n = steps[Math.min(i + 1, steps.length - 1)];
      seek(n.t0, 'step');
    } else {
      if (t - cur.t0 > 400) {
        seek(cur.t0, 'step');
        return;
      }
      const p = steps[Math.max(i - 1, 0)];
      seek(p.t0, 'step');
    }
  }

  function jumpToStep(id) {
    if (!scn) return;
    const s = scn.steps.find((x) => x.id === id);
    if (s) {
      seek(s.t0, 'step-id');
      pause();
    }
  }

  function on(fn) {
    listeners.push(fn);
    return () => {
      const i = listeners.indexOf(fn);
      if (i >= 0) listeners.splice(i, 1);
    };
  }

  return {
    load, play, pause, toggle, restart, seek, nudge, setSpeed, getSpeed,
    jumpScene, jumpStep, jumpToStep, on,
    get time() { return t; },
    get duration() { return scn ? scn.total : 0; },
    get playing() { return playing; },
    get scenario() { return scn; }
  };
})();
