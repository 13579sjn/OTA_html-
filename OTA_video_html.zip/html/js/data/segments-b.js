/* =============================================================================
 * segments-b.js —— 场景分段时间轴（下半程：下载 → 校验 → 备份 → 复位 → BL → 首启）
 *                   以及所有异常分支段
 * ========================================================================== */
'use strict';

window.OTA_SEG = window.OTA_SEG || {};

(function () {

  const V6 = (v) => '0x' + (v >>> 0).toString(16).toUpperCase().padStart(6, '0');
  const L = (S, t, c) => OTA_STATE.log(S, t, c || 'info');

  const TASK_SIZE = 94824;   /* App_2 bin 实测字节数 */

  /* ==================================================================
   * 场景 11：固件下载
   * ================================================================== */
  OTA_SEG.download = function (opts) {
    opts = opts || {};
    const total = TASK_SIZE;
    const list = [
      {
        id: 'd-erase', scene: 'download', label: '擦除暂存区（15×64KB）', dur: 3000,
        code: 'download_try_a', hl: [553, 570],
        call: ['ota_download()', 'ota_download_try()', 'w25q16_erase_block()'],
        mods: ['core', 'spi2', 'w25q'], flows: ['spi-w'],
        g: 'A',
        note: '为什么一定要先擦？w25q64.c 的 WriteDataInternal() 在写之前会读回检查目标字节是不是 0xFF；只要有一个字节不是 0xFF，就会走“读整扇区→改→擦扇区→写回”的慢路径。不擦干净，第一次写就退化成整扇区读改写。',
        apply(S) {
          S.ctx.func = 'ota_download_try()';
          S.ctx.addr = '0x0801EF59';
          S.vars.state = 'OTA_ST_DOWNLOADING';
          S.ext.staging.mode = 'erase';
          S.ext.staging.frac = 0;
          L(S, '[OTA] erase staging area (960 KB)...', 'ota');
        },
        live(S, p) {
          S.ext.staging.frac = p;
          S.counters.spi = Math.round(p * 15);
        }
      },
      {
        id: 'd-saveparam', scene: 'download', label: '标记下载中 + 记录 tid', dur: 2000,
        code: 'download_try_a', hl: [572, 580],
        call: ['ota_download_try()', 'param_area_load()', 'param_area_save()'],
        mods: ['core', 'param'], flows: ['flash-int'],
        g: 'A',
        note: '把 backup_status 置为 DOWNLOADING、dl_tid 记录本次任务号、resume_offset 归零。这是断点续传的判据：只有 dl_tid 相同且状态仍是 DOWNLOADING 才会续传。',
        apply(S) {
          S.vars.backup_status = 1;
          S.vars.resume_offset = 0;
          S.vars.image_len = 0;
          S.ext.staging.mode = 'ready';
          S.ext.staging.frac = 0;
          S.intf.param.seq = 3;
          L(S, '[OTA] param: backup_status=DOWNLOADING dl_tid=1529128', 'ota');
        }
      },
      {
        id: 'd-get', scene: 'download', label: 'GET download + Range: bytes=0-', dur: 2600,
        code: 'download_try_b', hl: [603, 621],
        call: ['ota_download_try()', 'snprintf(Range)', 'http_client_request(on_data=dl_on_data)'],
        mods: ['core', 'esp', 'cloud', 'usart3'], flows: ['uart3-tx', 'wifi-dn'],
        g: 'A',
        note: '★ 必须始终带 Range，即使从头下也是 bytes=0-。实测不带 Range 时服务端一个字节都不回，30 秒超时（r=-2）。带上之后立刻变成 status=206。',
        apply(S) {
          S.http = { method: 'GET', path: '/fuse-ota/FRfr9m3Ppg/OTA_Test_drive/1529128/download', body: 'Range: bytes=0-' };
          S.frame = { title: '下载请求头', lines: [
            'GET /fuse-ota/FRfr9m3Ppg/OTA_Test_drive/1529128/download HTTP/1.1',
            'Host: iot-api.heclouds.com',
            'Authorization: version=2018-10-31&…',
            'Range: bytes=0-',
            'Connection: close'
          ] };
          L(S, '[OTA] GET (try 0) Range: bytes=0- / 94824', 'http');
        }
      },
      {
        id: 'd-resp', scene: 'download', label: '206 + Content-Length 头', dur: 2400,
        code: 'http_req_hdr', hl: [248, 289],
        call: ['http_client_request_once()', 'http_read_line()'],
        mods: ['core', 'esp', 'usart3'], flows: ['uart3-rx'],
        g: 'A',
        note: '响应头里四个字段会被解析：Content-Length（本轮应到多少字节，用来判断截断）、Content-Range、Transfer-Encoding（是否 chunked）、Ota-Errno（平台业务错误）。',
        apply(S) {
          S.frame = { title: '响应头（逐行）', lines: [
            'HTTP/1.1 206 Partial Content',
            'Content-Range: bytes 0-94823/94824',
            'Content-Length: 94824',
            'Ota-Errno: 0',
            'Content-Disposition: attachment; filename="OTA1"'
          ] };
          S.httpResp = { status: 206, contentLen: total, errno: 0 };
          L(S, 'HTTP/1.1 206 Partial Content  Content-Length: 94824  Ota-Errno: 0', 'http');
        }
      },
      {
        id: 'd-ipd', scene: 'download', label: '+IPD 帧 → DMA → 环形缓冲', dur: 3000,
        code: 'esp_parse', hl: [135, 240],
        call: ['esp01s_read()', 'esp01s_parse()', 'esp01s_dma_to_ring()', 'esp01s_feed_byte()'],
        mods: ['core', 'usart3', 'esp', 'dma', 'sram'], flows: ['uart3-rx'],
        g: 'A',
        note: '★ 这是整条链最脆弱的一环。模块发来的不是裸字节，而是 "+IPD,<len>:" 帧头 + 二进制 payload。解析器是个三态机（HEAD/LEN/DATA）。另外 AT 固件会在帧之间塞 \\r\\n，旧逻辑把它当正文推进流缓冲，结果在 body 偏移 0x0A07 处插入 4 个字节，MD5 必错 —— 现在 HEAD 态直接丢弃 \\r\\n。',
        apply(S) {
          S.ctx.func = 'esp01s_parse()';
          S.ctx.addr = '0x0801CE21';
          S.ipd = { len: 1024, head: '+IPD,1024:', payload: true };
          S.frame = { title: 'USART3 接收通路', lines: [
            'DMA1_Stream1 (CIRCULAR, 4096B) ── NDTR 轮询 ──▶ s_ring[4096]',
            's_ring ── 三态机剥离 +IPD ──▶ s_data[8192]',
            's_data ── esp01s_read() ──▶ http_read_body() ──▶ dl_on_data()'
          ] };
          S.counters.uart3 += 1024;
          L(S, '+IPD,1024:  (二进制载荷，已剥离帧头)', 'rx');
        }
      },
      {
        id: 'd-hash', scene: 'download', label: '双哈希同流更新', dur: 2400,
        code: 'dl_on_data', hl: [420, 423],
        call: ['dl_on_data()', 'sha256_update()', 'md5_update()'],
        mods: ['core', 'sram'], flows: [],
        g: 'A',
        note: 'MD5 给平台比对（传输完整性），SHA-256 留给 BL 二次校验（落地完整性）。两者在同一次遍历里算完，不额外多读一遍数据。',
        apply(S) {
          S.ctx.func = 'dl_on_data()';
          S.ctx.addr = '0x0801C8E5';
          S.vars.md5 = '计算中…';
          S.vars.sha = '计算中…';
          L(S, 'sha256_update() + md5_update() 同流更新', 'ota');
        }
      },
      {
        id: 'd-chunk', scene: 'download', label: '攒 256B → 写 W25Q64', dur: 3200,
        code: 'dl_on_data', hl: [424, 462],
        call: ['dl_on_data()', 'w25q16_write()', 'W25Q64_WriteData()', 'page program(0x02)'],
        mods: ['core', 'spi2', 'w25q'], flows: ['spi-w'],
        g: 'A',
        note: '★ 写粒度是性能的核心。W25Q64 每次 page program 典型忙等 0.4ms：4 字节一写，960KB 要 245,760 次 ≈ 98 秒；256 字节（正好一页）只需 3,840 次 ≈ 1.5 秒。改成 256 还降低了单次阻塞时长（约 0.5ms），减少串口丢字节概率。',
        apply(S) {
          S.ctx.func = 'w25q16_write()';
          S.ctx.addr = '0x08021319';
          S.ext.staging.mode = 'write';
          S.ipd = null;
          S.frame = { title: '写入路径（攒块 → 页编程）', lines: [
            'dl_on_data(): blen 满 OTA_DL_CHUNK(256)',
            '→ w25q16_write(EXT_STAGING + offset, buf, 256)',
            '→ W25Q64_WriteData(): 0xFF 预检 + 按 256B 页拆分',
            '→ page program 0x02, 忙等 SR1.BUSY'
          ] };
          L(S, 'w25q16_write(STAGING + offset, buf, 256) → page program', 'spi');
        },
        live(S, p) {
          const done = Math.floor(p * total / 256) * 256;
          S.vars.dl_offset = Math.min(done, total);
          S.vars.blen = p < 1 ? Math.min(255, Math.floor(p * 256 * 7) % 256) : 0;
          S.ext.staging.frac = S.vars.dl_offset / total;
          S.prog.dl = S.vars.dl_offset / total;
          S.counters.spi = Math.round(S.vars.dl_offset / 256);
        }
      },
      {
        id: 'd-checkpoint', scene: 'download', label: '每 16KB 存检查点', dur: 2200,
        code: 'dl_on_data', hl: [447, 459],
        call: ['dl_on_data()', 'param_area_load()', 'param_area_save()'],
        mods: ['core', 'param'], flows: ['flash-int'],
        g: 'A',
        note: '每 16KB 把 resume_offset 写进参数区。断点续传的前提不只是偏移量 —— 哈希上下文无法跨断电保存，所以续传时必须把 0~offset 的数据从片外 Flash 重扫一遍补进哈希。',
        apply(S) {
          S.vars.resume_offset = 65536;
          S.intf.param.state = 'ok';
          S.intf.param.seq = 4;
          L(S, '[OTA] checkpoint: resume_offset=65536 已写入参数区', 'ota');
        }
      },
      {
        id: 'd-tail', scene: 'download', label: '本轮零头落盘', dur: 2400,
        code: 'download_try_b', hl: [622, 638],
        call: ['ota_download_try()', 'w25q16_write(剩余 blen)'],
        mods: ['core', 'spi2', 'w25q'], flows: ['spi-w'],
        g: 'A',
        note: '一轮结束（正常收齐或被截断）后，必须把缓冲里不足 256 字节的零头也写下去，并同步 c.offset —— 否则下一轮 Range 的起点会与实际写入位置对不上。',
        apply(S) {
          S.vars.dl_offset = total;
          S.vars.blen = 0;
          S.ext.staging.frac = 1;
          S.prog.dl = 1;
          S.vars.resume_offset = 0;
          L(S, '[OTA] try 0: ret=0 status=206 len=94824 errno=0 got=94824/94824', 'ok');
        }
      },
      {
        id: 'd-ok', scene: 'download', label: '收齐 94,824 字节', dur: 2000,
        code: 'download_try_c', hl: [688, 689],
        call: ['ota_download_try()'],
        mods: ['core', 'w25q'], flows: [],
        g: 'A',
        note: 'c.offset >= t.size 即认为收齐。注意这里用的是平台返回的 t.size（权威值），不依赖 Content-Range 解析 —— 实测 total_size 解析出来是 0，不能作判据。',
        apply(S) {
          S.ctx.func = 'ota_download_try()';
          S.ext.staging.mode = 'valid';
          S.vars.state = 'OTA_ST_VERIFYING';
          S.prog.dl = 1;
          L(S, '[OTA] got=94824/94824  → 收齐', 'ok');
        }
      }
    ];

    if (opts.truncate) {
      /* 插入到 d-tail 之前：截断 → 续传 → MD5 失败 → 整体重下 */
      const idx = list.findIndex((s) => s.id === 'd-tail');
      const tr = OTA_SEG._truncateBranch();
      list.splice(idx, 0, ...tr);
    }
    return list;
  };

  /* 真实发生过的“截断自愈”分支（实施文档 5.4 的实测日志） */
  OTA_SEG._truncateBranch = function () {
    return [
      {
        id: 'd-trunc', scene: 'download', label: '★ 本轮超时：实收 93,511 / 94,824', dur: 2800,
        code: 'download_try_b', hl: [636, 647],
        call: ['http_client_request()', '→ ret=-2 (ESP_TIMEOUT)', 'TRUNCATED 检测'],
        mods: ['core', 'esp', 'usart3'], flows: [],
        g: 'A',
        note: '这是真机必现的现象：ESP8266 在 115200 批量接收时偶发一次 UART overrun，就让 "+IPD,<len>:" 帧头错位，之后不再输出数据，http_client 一直等到超时。代码用“实收 < Content-Length”判定 TRUNCATED —— 丢的字节在中间，后面的数据整体前移。',
        apply(S) {
          S.vars.dl_offset = 93511;
          S.ext.staging.frac = 93511 / TASK_SIZE;
          S.prog.dl = 93511 / TASK_SIZE;
          S.truncated = true;
          L(S, '[OTA] try 0: ret=-2 status=206 len=94824 errno=0 got=93511/94824', 'err');
          L(S, '[OTA] try 0 TRUNCATED: 93511 of 94824 bytes (data shifted!)', 'err');
        }
      },
      {
        id: 'd-retry', scene: 'download', label: '第 2 轮 Range 续传补尾', dur: 2600,
        code: 'download_try_b', hl: [668, 673],
        call: ['ota_download_try()', 'Range: bytes=93511-'],
        mods: ['core', 'esp', 'usart3', 'w25q'], flows: ['uart3-rx', 'spi-w'],
        g: 'A',
        note: '每轮以当前 c.offset 作为新的 Range 起点，最多 8 轮；只要本轮还有进展就继续。字节数最终会补齐，但正确性只能靠 MD5 兜底。',
        apply(S) {
          S.frame = { title: '续传请求', lines: ['Range: bytes=93511-', '→ 206  Content-Length: 1313'] };
          L(S, '[OTA] GET (try 1) Range: bytes=93511- / 94824', 'http');
        },
        live(S, p) {
          const off = 93511 + Math.floor(p * 1313);
          S.vars.dl_offset = off;
          S.vars.resume_offset = 93511;
          S.ext.staging.frac = off / TASK_SIZE;
          S.prog.dl = off / TASK_SIZE;
        }
      },
      {
        id: 'd-md5fail', scene: 'download', label: 'MD5 不匹配（字节数却对了）', dur: 2800,
        code: 'download_try_c', hl: [703, 710],
        call: ['ota_download_try()', 'md5_final()', 'md5_hex_equal()', 'OTA_REPORT_FAIL(205)'],
        mods: ['core'], flows: [],
        g: 'A',
        note: '★ 这是最能说明“为什么必须双哈希”的一幕：字节数完全正确（94824），但 MD5 错 —— 因为丢的 1313 字节在中间，后面的数据整体前移，续传只能补长度补不了位置。',
        apply(S) {
          S.vars.dl_offset = TASK_SIZE;
          S.vars.md5 = '41e52aea… ✗ 不匹配';
          S.vars.state = 'OTA_ST_ERROR';
          S.md5Fail = true;
          L(S, '[OTA] MD5 mismatch (expect 41e52aea...)', 'err');
          L(S, '[OTA] (skip fail report step=205)  ← OTA_REPORT_FAIL_TO_PLATFORM=0', 'warn');
        }
      },
      {
        id: 'd-redownload', scene: 'download', label: '兜底：擦除后完整重下', dur: 3000,
        code: 'download_wrap', hl: [733, 751],
        call: ['ota_download()', 'ota_download_try(force_restart=1)'],
        mods: ['core', 'spi2', 'w25q'], flows: ['spi-w'],
        g: 'A',
        note: '哈希上下文无法回退，所以校验失败只能整体重来：擦除暂存区、哈希上下文一并重置、force_restart=1 忽略断点。代价是多下一次，换来的是数据绝对正确。',
        apply(S) {
          S.ctx.func = 'ota_download()';
          S.md5Fail = false;
          S.truncated = false;
          S.vars.md5 = '重新计算…';
          S.vars.dl_offset = 0;
          S.ext.staging.mode = 'erase';
          S.ext.staging.frac = 0;
          S.prog.dl = 0;
          L(S, '[OTA] verify FAILED, erase staging and re-download from 0 ...', 'warn');
        },
        live(S, p) {
          if (p < 0.35) {
            S.ext.staging.mode = 'erase';
            S.ext.staging.frac = p / 0.35;
          } else {
            S.ext.staging.mode = 'write';
            const f = (p - 0.35) / 0.65;
            S.vars.dl_offset = Math.floor(f * TASK_SIZE / 256) * 256;
            S.ext.staging.frac = S.vars.dl_offset / TASK_SIZE;
            S.prog.dl = S.vars.dl_offset / TASK_SIZE;
            S.counters.spi = Math.round(S.vars.dl_offset / 256);
          }
        }
      },
      {
        id: 'd-second-ok', scene: 'download', label: '第 2 遍：一次收全', dur: 2400,
        code: 'download_wrap', hl: [744, 748],
        call: ['ota_download()', '→ "re-download OK on 2nd pass"'],
        mods: ['core', 'w25q'], flows: [],
        g: 'A',
        note: '第二遍拿到的是一次连续数据流，MD5 通过。整条自愈链——截断 → 续传补尾 → MD5 抓住 → 擦除重下 → 成功——完整跑通。代价是每次可能下两遍。',
        apply(S) {
          S.vars.dl_offset = TASK_SIZE;
          S.ext.staging.mode = 'valid';
          S.ext.staging.frac = 1;
          S.prog.dl = 1;
          S.vars.md5 = '41e52aea… ✓';
          L(S, '[OTA] try 0: ret=0 status=206 len=94824 errno=0 got=94824/94824', 'ok');
          L(S, '[OTA] download OK: 94824 bytes', 'ok');
          L(S, '[OTA] re-download OK on 2nd pass', 'ok');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 12：完整性校验
   * ================================================================== */
  OTA_SEG.verify = function () {
    return [
      {
        id: 'v-size', scene: 'verify', label: '长度校验', dur: 2200,
        code: 'download_try_c', hl: [694, 701],
        call: ['ota_download_try()', 'c.offset != t.size ? -5'],
        mods: ['core'], flows: [],
        g: 'A',
        note: '长度是第一道：只有 c.offset 与平台声明的 size 完全相等才继续。不等就上报 206 并返回 -5。',
        apply(S) {
          S.vars.state = 'OTA_ST_VERIFYING';
          S.check = { size: true, md5: null, sha: null };
          L(S, '[OTA] size check: 94824 == 94824 ✓', 'ok');
        }
      },
      {
        id: 'v-md5', scene: 'verify', label: '平台 MD5 比对', dur: 2600,
        code: 'download_try_c', hl: [703, 710],
        call: ['ota_download_try()', 'md5_final()', 'md5_hex_equal(t.md5, digest)'],
        mods: ['core', 'sram'], flows: [],
        g: 'A',
        note: 'MD5 校验的是“从服务器到 MCU 的字节流”。比较时大小写不敏感（平台可能返回大写十六进制）。失败会走 ota_download() 的兜底：擦除后从头重下。',
        apply(S) {
          S.vars.md5 = '41e52aea… ✓ 匹配';
          S.check.md5 = true;
          L(S, '[OTA] MD5 ✓  41e52aea…', 'ok');
        }
      },
      {
        id: 'v-sha', scene: 'verify', label: 'SHA-256 收尾（交给 BL）', dur: 2600,
        code: 'download_try_c', hl: [712, 720],
        call: ['sha256_final()', '*sha_out', '*len_out'],
        mods: ['core', 'sram', 'param'], flows: [],
        g: 'A',
        note: 'SHA-256 不是给平台看的，是写给参数区、留给 BootLoader 的。BL 没有网络，无法知道平台的 MD5，所以它必须有一个“自己算得出来”的摘要来验证暂存区的数据。',
        apply(S) {
          S.vars.sha = '9c3b7f1e…（写入 image_sha[32]）';
          S.check.sha = true;
          L(S, '[OTA] SHA-256 计算完成 → 待写入参数区 image_sha[32]', 'ok');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 13：备份旧固件
   * ================================================================== */
  OTA_SEG.backup = function () {
    return [
      {
        id: 'b-probe', scene: 'backup', label: '探测 A 槽实际长度', dur: 2400,
        code: 'probe_len', hl: [368, 390],
        call: ['ota_backup_current_app()', 'ota_probe_run_len()', 'flash_if_read()'],
        mods: ['core', 'int-flash'], flows: ['flash-int'],
        g: 'A',
        note: '从 A 槽末尾按 256 字节往回扫，找第一个非 0xFF 的字节，再向上 4KB 对齐 —— 因为片内 Flash 未使用区是 0xFF。这样备份长度就是“真实固件长度”，不必固定拷 960KB。',
        apply(S) {
          S.ctx.func = 'ota_probe_run_len()';
          S.vars.state = 'OTA_ST_BACKUPING';
          S.backupLen = 94820;
          L(S, '[OTA] current app length = 94820 bytes', 'ota');
        }
      },
      {
        id: 'b-erase', scene: 'backup', label: '擦除备份区', dur: 2600,
        code: 'backup_app', hl: [772, 781],
        call: ['ota_backup_current_app()', 'w25q16_erase_block() × 15'],
        mods: ['core', 'spi2', 'w25q'], flows: ['spi-w'],
        g: 'A',
        note: '备份区也是 15 个 64KB 块。擦除是块级操作，最坏约 2s 一块，所以每个块擦完都要喂一次狗（boot_wdg_feed / ota_feed_watchdog）。',
        apply(S) {
          S.ctx.func = 'ota_backup_current_app()';
          S.ctx.addr = '0x0801EA85';
          S.ext.backup.mode = 'erase';
          S.ext.backup.frac = 0;
          L(S, '[OTA] erase backup area (960 KB)...', 'ota');
        },
        live(S, p) { S.ext.backup.frac = p; }
      },
      {
        id: 'b-copy', scene: 'backup', label: '1KB 分块复制 + 算 SHA-256', dur: 3200,
        code: 'backup_app', hl: [783, 807],
        call: ['flash_if_read(A 槽)', 'w25q16_write(BACKUP)', 'sha256_update()'],
        mods: ['core', 'int-flash', 'spi2', 'w25q'], flows: ['flash-int', 'spi-w'],
        g: 'A',
        note: '边拷边算，一份数据两用：既完成备份，又得到 backup_sha。注意方向是“片内 → 片外”，与稍后 BL 的“片外 → 片内”正好相反。',
        apply(S) {
          S.ext.backup.mode = 'write';
          S.ext.backup.frac = 0;
          S.prog.bk = 0;
          L(S, 'flash_if_read(A) → w25q16_write(BACKUP) + sha256_update()', 'ota');
        },
        live(S, p) {
          S.ext.backup.frac = p;
          S.prog.bk = p;
          S.counters.spi = Math.round(p * 93);
        }
      },
      {
        id: 'b-done', scene: 'backup', label: '备份完成', dur: 2000,
        code: 'backup_app', hl: [808, 813],
        call: ['ota_backup_current_app()', '→ 0'],
        mods: ['core', 'w25q'], flows: [],
        g: 'A',
        note: '此刻片外已经有“新固件（暂存区）+ 旧固件（备份区）”两份，片内 A 槽还是旧的 —— 这是整个流程里最安全的一个时间点。',
        apply(S) {
          S.ext.backup.mode = 'valid';
          S.ext.backup.frac = 1;
          S.prog.bk = 1;
          L(S, '[OTA] backup done: 94820 bytes', 'ok');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 14：写参数并复位
   * ================================================================== */
  OTA_SEG.commit = function () {
    return [
      {
        id: 'm-param', scene: 'commit', label: '组装新参数结构体', dur: 2600,
        code: 'run_once_commit', hl: [1236, 1251],
        call: ['ota_run_once()', 'p.image_len / p.image_sha / p.backup_*'],
        mods: ['core', 'param'], flows: [],
        g: 'A',
        note: '把两件事固化下来：① 新固件在暂存区的长度 + SHA-256（给 BL 校验用）；② 旧固件的版本、长度、SHA-256（给回滚用）。backup_status 置 VALID 表示备份可信。',
        apply(S) {
          S.ctx.func = 'ota_run_once()';
          S.vars.image_len = TASK_SIZE;
          S.vars.backup_status = 2;
          S.vars.resume_offset = 0;
          S.frame = { title: '参数区待写入字段', lines: [
            'image_len      = 94824',
            'image_sha[32]  = 9c3b7f1e…',
            'backup_version = 0x010000 (V1.0.0)',
            'backup_len     = 94820',
            'backup_sha[32] = …',
            'backup_status  = 2 (VALID)'
          ] };
          L(S, '[OTA] param: image_len=94824 backup_len=94820 backup_status=VALID', 'ota');
        }
      },
      {
        id: 'm-save', scene: 'commit', label: 'param_area_save() 写槽', dur: 2400,
        code: 'param_save', hl: [175, 212],
        call: ['param_area_save()', 'crc32_calc()', 'flash_if_write(新空槽)'],
        mods: ['core', 'param', 'int-flash'], flows: ['flash-int'],
        g: 'A',
        note: '不擦除，只写下一个空槽（seq = 当前最大值 + 1）。写满 32 次才整扇区擦一次 —— 把“擦除风险”从每次保存降到 1/32，这是参数区掉电安全的核心。',
        apply(S) {
          S.ctx.func = 'param_area_save()';
          S.intf.param.seq = 5;
          L(S, '[OTA] param saved → slot[5] seq=5 crc32 OK', 'ok');
        }
      },
      {
        id: 'm-100', scene: 'commit', label: '上报 step=100（下载完成）', dur: 2200,
        code: 'run_once_commit', hl: [1262, 1263],
        call: ['ota_api_report_status(tid, 100)'],
        mods: ['core', 'esp', 'cloud', 'usart3'], flows: ['uart3-tx', 'wifi-dn'],
        g: 'A',
        note: 'step 语义：100=下载完成，201=升级成功，205=MD5 失败，206=升级失败，207=下载失败。注意这里报的是 100 不是 201 —— 201 要等新固件真正跑起来之后才报。',
        apply(S) {
          S.frame = { title: 'POST /{tid}/status', lines: ['{"step":100}'] };
          L(S, '[HTTP] POST /fuse-ota/…/1529128/status  {"step":100}', 'http');
        }
      },
      {
        id: 'm-trynew', scene: 'commit', label: '置 TRY_NEW 并保存', dur: 2400,
        code: 'apply_reboot', hl: [823, 837],
        call: ['ota_apply_and_reboot()', 'boot_flag=TRY_NEW', 'param_area_save()'],
        mods: ['core', 'param', 'int-flash'], flows: ['flash-int'],
        g: 'A',
        note: '这是“交棒”的一刻：App 把 boot_flag 从 NORMAL 改成 TRY_NEW、boot_count 清零、ota_tid 记下任务号、dl_tid 清零。从这一刻起，下一次上电由 BootLoader 说了算。',
        apply(S) {
          S.ctx.func = 'ota_apply_and_reboot()';
          S.vars.boot_flag = 1;
          S.vars.boot_count = 0;
          S.vars.ota_tid = 1529128;
          S.vars.dl_tid = 0;
          S.vars.state = 'OTA_ST_READY_REBOOT';
          S.intf.param.seq = 6;
          L(S, '[OTA] boot_flag = TRY_NEW(1)  boot_count = 0  ota_tid = 1529128', 'ok');
          L(S, '[OTA] param_area_save() OK', 'ok');
        }
      },
      {
        id: 'm-reboot', scene: 'commit', label: '3 秒倒计时 → NVIC_SystemReset', dur: 3000,
        code: 'apply_reboot', hl: [838, 848],
        call: ['ota_apply_and_reboot()', 'HAL_Delay(1000) × 3', 'NVIC_SystemReset()'],
        mods: ['core', 'nvic'], flows: [],
        g: 'A',
        note: '倒计时期间持续喂狗，然后软件复位。复位后 CPU 又从 0x08000000 开始跑 BootLoader —— 回到场景 2，但这一次参数区里的 boot_flag 已经是 1。',
        apply(S) {
          S.ctx.func = 'ota_apply_and_reboot()';
          S.ctx.addr = '0x0801E9C5';
          S.rebootCountdown = 3;
          L(S, '[OTA] set TRY_NEW, reboot in 3s...', 'warn');
        },
        live(S, p) { S.rebootCountdown = Math.max(0, 3 - Math.floor(p * 3)); }
      }
    ];
  };

  /* ==================================================================
   * 场景 15：BootLoader 执行 TRY_NEW
   * ================================================================== */
  OTA_SEG.blTryNew = function () {
    return [
      {
        id: 'n-reset', scene: 'bl-trynew', label: '复位 → BL 读到 flag=1', dur: 2400,
        code: 'boot_run_param', hl: [311, 329],
        call: ['硬件复位', 'boot_run()', 'param_area_load()'],
        mods: ['core', 'int-flash', 'param'], flows: ['flash-int'],
        g: 'A',
        note: '同一个 boot_run()，同样的 param_area_load()，只是这一次读到的 boot_flag 是 1。BL 里没有“OTA 模式”这种额外状态，全部靠参数区这一份数据决策。',
        apply(S) {
          S.ctx.cpu = 'bl';
          S.ctx.image = 'BL';
          S.ctx.func = 'boot_run()';
          S.ctx.addr = '0x08004DBD';
          S.ctx.msp = '0x20000E00';
          S.ctx.vtor = '0x08000000';
          S.intf.app.state = 'old';
          S.branch = 'TRY_NEW';
          S.otaActive = false;
          L(S, '[BL] flag=1 count=0 ver=0x010000 img_len=94824 bk_st=2', 'boot');
          L(S, '[BL] >>> TRY_NEW', 'boot');
        }
      },
      {
        id: 'n-verify', scene: 'bl-trynew', label: '★ 校验暂存区 SHA-256', dur: 3000,
        code: 'boot_verify_ext', hl: [84, 113],
        call: ['boot_run()', 'boot_verify_ext_image(STAGING, len, sha)'],
        mods: ['core', 'spi2', 'w25q'], flows: ['spi-r'],
        g: 'A',
        note: '★ 这是整条链上最重要的一道闸门：先校验、后擦写。SHA-256 不过就绝不碰 A 槽。校验用 64 字节分块从片外读入，边读边喂狗。',
        apply(S) {
          S.ctx.func = 'boot_verify_ext_image()';
          S.ctx.addr = '0x08005571';
          S.verifyProg = 0;
          S.frame = { title: '暂存区校验', lines: ['boot_ext_read(STAGING + done, chunk, 64)', 'sha256_update(&ctx, chunk, take)', 'len = 94824  分块 = 64 B'] };
          L(S, '[BL] verify staging SHA-256 (len=94824)...', 'boot');
        },
        live(S, p) { S.verifyProg = p; }
      },
      {
        id: 'n-verify-ok', scene: 'bl-trynew', label: '校验通过，允许擦 A 槽', dur: 2200,
        code: 'boot_run_trynew', hl: [399, 401],
        call: ['boot_run()', 'boot_copy_ext_to_run()'],
        mods: ['core', 'w25q', 'int-flash'], flows: [],
        g: 'A',
        note: '只有走到这里，A 槽才第一次被允许擦除。如果校验失败，代码直接转到 ROLLBACK，用备份区覆盖 —— 绝不拿一个“可能坏了”的镜像去擦正在用的槽。',
        apply(S) {
          S.verifyProg = 1;
          S.shaVerified = true;
          L(S, '[BL] staging OK, copy staging -> A', 'ok');
        }
      },
      {
        id: 'n-erase', scene: 'bl-trynew', label: '按扇区擦除 A 槽', dur: 3000,
        code: 'boot_copy', hl: [132, 149],
        call: ['boot_copy_ext_to_run()', 'flash_if_sector_size()', 'flash_if_erase_addr()'],
        mods: ['core', 'int-flash'], flows: ['flash-int'],
        g: 'A',
        note: 'A 槽的扇区大小不均匀：S4 是 64KB，S5~S11 各 128KB。所以必须循环查表、按每个地址所在扇区的真实大小步进，不能假设等大小。',
        apply(S) {
          S.ctx.func = 'boot_copy_ext_to_run()';
          S.ctx.addr = '0x08004911';
          S.intf.app.state = 'erasing';
          S.intf.app.erase = 0;
          S.eraseProg = 0;
          L(S, '[BL] flash_if_erase_addr(0x08010000) … S4 64KB', 'boot');
        },
        live(S, p) {
          S.eraseProg = p;
          S.intf.app.erase = p;
          /* 擦除的视觉：旧内容逐扇区消失 */
          S.intf.app.fill = Math.max(0, 1 - p);
        }
      },
      {
        id: 'n-copy', scene: 'bl-trynew', label: '分块搬运 片外 → 片内', dur: 3200,
        code: 'boot_copy', hl: [151, 178],
        call: ['boot_ext_read(1024B)', 'flash_if_write(1024B, 32 位字)'],
        mods: ['core', 'w25q', 'spi2', 'int-flash'], flows: ['spi-r', 'flash-int'],
        g: 'A',
        note: 'BOOT_COPY_CHUNK=1024。片内写是按 32 位字编程，每写一次都会回读校验（flash_if_write 的隐式自检），能提前发现擦除不干净或电压异常。',
        apply(S) {
          S.ctx.func = 'flash_if_write()';
          S.ctx.addr = '0x080056FD';
          S.intf.app.state = 'writing';
          S.intf.app.fill = 0;
          S.copyProg = 0;
          L(S, '[BL] copy STAGING → 0x08010000 (1KB/块)', 'boot');
        },
        live(S, p) {
          S.copyProg = p;
          S.intf.app.fill = p;
          S.counters.spi = Math.round(p * 93);
          S.counters.fl = Math.round(p * 93);
        }
      },
      {
        id: 'n-count', scene: 'bl-trynew', label: 'boot_count++ 并保存', dur: 2400,
        code: 'boot_run_trynew', hl: [402, 433],
        call: ['boot_run()', 'param.boot_count++', 'param_area_save()'],
        mods: ['core', 'param', 'int-flash'], flows: ['flash-int'],
        g: 'A',
        note: '★ 关键机制：拷贝成功后 boot_count 立刻 +1 并保存。如果新固件启动后没有在 3 次之内调用 ota_confirm_boot_success() 把 flag 改回 NORMAL，BL 第 3 次就会自动转 ROLLBACK。这就是“启动确认超时”的真实实现。',
        apply(S) {
          S.vars.boot_count = 1;
          S.vars.boot_flag = 1;
          S.intf.app.state = 'ok';
          S.intf.app.fill = 1;
          S.intf.app.ver = '1.0.1';
          S.intf.param.seq = 7;
          L(S, '[BL] boot_count 0 → 1（未达 OTA_BOOT_MAX_TRIES=3，保持 TRY_NEW）', 'warn');
          L(S, '[BL] param_area_save() OK', 'boot');
        }
      },
      {
        id: 'n-validate', scene: 'bl-trynew', label: '校验新 A 槽向量表', dur: 2200,
        code: 'jump_validate', hl: [36, 58],
        call: ['boot_run()', 'app_jump_validate(0x08010000)', 'boot_dump_vectors()'],
        mods: ['core', 'int-flash', 'sram'], flows: ['flash-int'],
        g: 'A',
        note: '三道闸门再走一遍。这次 A 槽里是新固件，但初始 MSP 与复位向量都还是同一个值 —— 因为 App 与 App_2 的 IROM1 完全相同，只有版本号不同。',
        apply(S) {
          S.ctx.func = 'app_jump_validate()';
          S.frame = { title: 'A 槽向量表（新固件）', lines: ['vec[0] = 0x20014E38', 'vec[1] = 0x080103F9', '—— 与前一次相同：同一镜像布局'] };
          L(S, '[BL] vec[0]=0x20014E38 vec[1]=0x080103F9 ✓', 'ok');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 16：跳转到新固件
   * ================================================================== */
  OTA_SEG.blJump2 = function () {
    return [
      {
        id: 'n-shutdown', scene: 'bl-jump2', label: '拆外设 + 时钟回 HSI', dur: 2600,
        code: 'shutdown', hl: [147, 200],
        call: ['app_jump_execute()', 'boot_system_shutdown()', 'boot_restore_clock_to_hsi()'],
        mods: ['core', 'nvic', 'dma', 'usart1', 'spi2'], flows: [],
        g: 'A',
        note: '与第一次跳转完全相同的九步清理。之所以“完全相同”而不是“复用上一次的结果”，是因为中间 App 已经把外设、NVIC、时钟全部重新配过一遍。',
        apply(S) {
          S.ctx.func = 'boot_system_shutdown()';
          S.intf.usart1 = 'off'; S.intf.spi2 = 'off'; S.intf.dma = 'off';
          L(S, '[BL] shutdown peripherals, restore RCC to HSI...', 'boot');
        }
      },
      {
        id: 'n-mspvtor', scene: 'bl-jump2', label: 'MSP + VTOR', dur: 2400,
        code: 'jump_execute', hl: [76, 90],
        call: ['app_jump_execute()', '__set_MSP()', 'SCB->VTOR'],
        mods: ['core', 'nvic', 'sram'], flows: [],
        g: 'A',
        note: '同样的三行代码，这一次指向的是刚刚搬进去的 1.0.1。',
        apply(S) {
          S.ctx.msp = '0x20014E38';
          S.ctx.vtor = '0x08010000';
          L(S, '[BL] __set_MSP(0x20014E38)  SCB->VTOR = 0x08010000', 'boot');
        }
      },
      {
        id: 'n-jump', scene: 'bl-jump2', label: '控制权转移 → 新固件', dur: 2600,
        code: 'jump_execute', hl: [88, 90],
        call: ['app_jump_execute()', 'entry()', 'App_2 Reset_Handler'],
        mods: ['core', 'int-flash'], flows: ['flash-int'],
        g: 'A',
        note: '从 0x08010004 取出 0x080103F9 并调用。地址没变，内容已经换成 1.0.1 了 —— 这就是“单 A 槽 + 覆盖式升级”的本质。',
        apply(S) {
          S.ctx.cpu = 'app';
          S.ctx.image = 'APP2';
          S.ctx.func = 'Reset_Handler (App 1.0.1)';
          S.ctx.addr = '0x080103F9';
          S.intf.bl.state = 'idle';
          S.intf.app.state = 'run';
          S.jumpFlash = 2;
          L(S, '[BL] jump to app @0x08010000', 'ok');
          L(S, '>>> 控制权转移：BootLoader → App 1.0.1（新固件）', 'ok');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 17：新固件首启确认
   * ================================================================== */
  OTA_SEG.confirm = function () {
    return [
      {
        id: 'f-banner', scene: 'confirm', label: '首启横幅（flag=TRY_NEW）', dur: 2800,
        code: 'boot_confirm', hl: [1040, 1069],
        call: ['StartDefaultTask()', 'ota_p2_selftest()', 'ota_boot_confirm_if_needed()'],
        mods: ['core', 'usart1', 'param'], flows: ['uart1-tx'],
        g: 'A',
        note: '条件判断只有一句：p.boot_flag == TRY_NEW。为真才打印横幅并进入 30 秒静默窗口；否则只同步版本号后立刻返回（普通启动不花这 30 秒）。',
        apply(S) {
          S.ctx.func = 'ota_boot_confirm_if_needed()';
          S.ctx.addr = '0x0801EBF1';
          S.frame = { title: 'USART1 首启横幅', lines: [
            '[OTA] ##################################################',
            '[OTA] #     NEW FIRMWARE FIRST BOOT  (boot_flag=TRY_NEW)',
            '[OTA] #     version : 1.0.1',
            '[OTA] #     build   : ...',
            '[OTA] #     silent  : 30000 ms',
            '[OTA] ##################################################'
          ] };
          L(S, '[OTA] # NEW FIRMWARE FIRST BOOT (boot_flag=TRY_NEW)  version 1.0.1', 'ok');
        }
      },
      {
        id: 'f-wait', scene: 'confirm', label: '30 秒静默窗口（持续喂狗）', dur: 3200,
        code: 'boot_confirm', hl: [1071, 1079],
        call: ['ota_boot_confirm_if_needed()', 'ota_feed_watchdog()', 'HAL_Delay(100) × 300'],
        mods: ['core', 'iwdg', 'rtos'], flows: [],
        g: 'A',
        note: '★ 这 30 秒就是“启动确认超时”机制的实体：期间任何崩溃/看门狗复位都会让下一次上电的 boot_count +1，连续 3 次就自动回滚。注意它是“时间”判断 —— 不是功能判断：新固件只要能撑过 30 秒就会被确认，哪怕业务功能全坏。',
        apply(S) {
          S.ctx.func = 'ota_boot_confirm_if_needed()';
          S.confirmWaited = 0;
          L(S, '[OTA] 静默窗口开始（30000ms），期间 ota_feed_watchdog()', 'warn');
        },
        live(S, p) { S.confirmWaited = Math.round(p * 30); }
      },
      {
        id: 'f-confirm', scene: 'confirm', label: 'ota_confirm_boot_success()', dur: 2600,
        code: 'confirm_success', hl: [975, 994],
        call: ['ota_confirm_boot_success()', 'param_area_save()'],
        mods: ['core', 'param', 'int-flash'], flows: ['flash-int'],
        g: 'A',
        note: '一次性把状态收敛：flag 改 NORMAL、boot_count 清零、version 同步为 0x010001、resume_offset 清零、backup_status 保持 VALID、image_len 与 image_sha 清空（暂存区已经“用掉”了）。',
        apply(S) {
          S.ctx.func = 'ota_confirm_boot_success()';
          S.ctx.addr = '0x0801EDF5';
          S.vars.boot_flag = 0;
          S.vars.boot_count = 0;
          S.vars.version = 0x010001;
          S.vars.image_len = 0;
          S.vars.sha = '已清零';
          S.vars.resume_offset = 0;
          S.vars.backup_status = 2;
          S.intf.param.seq = 8;
          S.confirmWaited = 30;
          L(S, '[OTA] boot confirmed, flag=NORMAL, ver=0x010001', 'ok');
        }
      },
      {
        id: 'f-201', scene: 'confirm', label: '补报 201 + 上报新版本', dur: 2800,
        code: 'pending201', hl: [1015, 1025],
        call: ['ota_p2_selftest()', 'ota_net_enter()', 'ota_report_pending_201()', 'ota_report_version()'],
        mods: ['core', 'esp', 'cloud', 'usart3'], flows: ['uart3-tx', 'wifi-dn'],
        g: 'A',
        note: '为什么必须补报：App 在置 TRY_NEW 之后立刻复位了，根本没机会报 201。所以 201 只能由“新固件首启”来报 —— 这也是为什么 ota_tid 要保存在参数区里。',
        apply(S) {
          S.ctx.func = 'ota_report_pending_201()';
          S.vars.ota_tid = 1529128;
          S.frame = { title: '首启补报', lines: ['POST /{tid}/status   {"step":201}', 'POST /version        {"s_version":"1.0.1",…}'] };
          L(S, '[OTA] reported 201 to platform', 'ok');
          L(S, '[OTA] first-boot: version 1.0.1 reported', 'ok');
        }
      },
      {
        id: 'f-mqtt', scene: 'confirm', label: '交还串口 + 重连 MQTT', dur: 2600,
        code: 'net_restore', hl: [84, 102],
        call: ['ota_net_exit()', 'ota_net_restore()', 'uart_start_receive()', 'esp8266_Init()'],
        mods: ['core', 'usart3', 'esp', 'cloud', 'dma'], flows: ['uart3-tx'],
        g: 'A',
        note: 'DMA 切回 NORMAL、恢复 IDLE 接收、重发整套 MQTT 配置。因为 AT+RST 把模块的 MQTT 配置清空了，这一步不能省。',
        apply(S) {
          S.ctx.func = 'ota_net_exit()';
          S.vars.ota_tid = 0;
          S.esp.mode = 'mqtt';
          S.intf.cloud = 'mqtt';
          S.intf.dma = 'normal';
          S.intf.usart3 = 'idle-rx';
          S.otaMode = 0;
          L(S, '[OTA] back to MQTT mode', 'at');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 18：升级成功
   * ================================================================== */
  OTA_SEG.done = function () {
    return [
      {
        id: 'g-summary', scene: 'done', label: '状态收敛：全部落定', dur: 2800,
        code: 'confirm_success', hl: [990, 993],
        call: ['ota_confirm_boot_success()', '→ 0'],
        mods: ['core', 'param', 'w25q', 'int-flash'], flows: [],
        g: 'A',
        note: '终态：片内 A 槽 = 1.0.1；参数区 version=0x010001、boot_flag=NORMAL、boot_count=0、backup_status=VALID、image_len=0；片外 STAGING 里还留着 1.0.1（下次升级会被覆盖）、BACKUP 里是 1.0.0、RECOVERY 里是出厂镜像。',
        apply(S) {
          S.ctx.func = 'StartDefaultTask()';
          S.vars.state = 'OTA_ST_IDLE';
          S.vars.md5 = '41e52aea… ✓';
          S.vars.sha = '已清零';
          S.prog.dl = 1; S.prog.bk = 1;
          S.done = true;
          S.ext.staging.mode = 'valid';
          S.ext.backup.mode = 'valid';
          S.ext.recovery.mode = 'valid';
          S.ext.recovery.frac = 1;
          L(S, '[OTA] ===== OTA finished OK =====', 'ok');
          L(S, '平台：任务 1529128 成功；设备版本 1.0.1；业务功能正常', 'ok');
        }
      }
    ];
  };

  /* ==================================================================
   * 异常分支段
   * ================================================================== */

  /* ① 平台没有任务 */
  OTA_SEG.failNoTask = function () {
    return [
      {
        id: 'x-notask', scene: 'fail', label: 'check 返回无任务', dur: 2600,
        code: 'api_check', hl: [296, 303],
        call: ['ota_api_check_task()', '→ has_task = 0', 'ota_run_once() → 1'],
        mods: ['core', 'esp', 'cloud'], flows: ['uart3-rx'],
        g: 'A',
        note: '两种“无任务”：业务 code != 0（平台报错，按无任务处理避免误报），或 tid == 0。返回 1 属于正常情况，task 层打印 “no task on platform”，然后交还串口、重连 MQTT，不升级。',
        apply(S) {
          S.ctx.func = 'ota_api_check_task()';
          S.vars.state = 'OTA_ST_NONE';
          S.vars.ret = '1';
          S.failKind = 'no-task';
          L(S, '[OTA] check resp: {"code":0,"msg":"succ","data":{}}', 'http');
          L(S, '[OTA] no task on platform  → ota_run_once() = 1', 'warn');
        }
      },
      {
        id: 'x-notask-exit', scene: 'fail', label: '交还通道，保持 MQTT', dur: 2400,
        code: 'ota_task_entry', hl: [86, 98],
        call: ['ota_task_entry()', 'ota_net_exit()', 'ota_task_post_update_zero()'],
        mods: ['core', 'esp', 'cloud', 'usart3'], flows: ['uart3-tx'],
        g: 'A',
        note: '把 Update 属性回写 0，避免下次上电重复触发；返回 1 不视为错误，业务继续跑。',
        apply(S) {
          S.vars.ret = '1';
          S.esp.mode = 'mqtt';
          S.intf.cloud = 'mqtt';
          S.otaMode = 0;
          L(S, '[OTA] ota_run_once() = 1  → ===== no task on platform =====', 'warn');
          L(S, '[OTA] posted Update=0 (idempotent)', 'at');
        }
      }
    ];
  };

  /* ② 拒绝差分包 */
  OTA_SEG.failDiff = function () {
    return [
      {
        id: 'x-diff', scene: 'fail', label: 'type != 1：拒绝差分包', dur: 2400,
        code: 'run_once_reject', hl: [1185, 1191],
        call: ['ota_run_once()', 'OTA_REPORT_FAIL(tid, 206)'],
        mods: ['core'], flows: [],
        g: 'A',
        note: '工程只支持整包升级（type=1）。差分包直接拒绝并上报 206。',
        apply(S) {
          S.ctx.func = 'ota_run_once()';
          S.task = { tid: 1529128, size: 3211, type: 2, target: '1.0.1' };
          S.vars.state = 'OTA_ST_ERROR';
          S.failKind = 'diff';
          L(S, '[OTA] diff package not supported (type=2)', 'err');
          L(S, '[OTA] (skip fail report step=206)', 'warn');
        }
      },
      {
        id: 'x-diff-ret', scene: 'fail', label: '返回 -3', dur: 2200,
        code: 'run_once_reject', hl: [1209, 1213],
        call: ['ota_run_once() → -3'],
        mods: ['core'], flows: [],
        g: 'A',
        note: '返回 -3 的含义是“任务被拒绝（差分包 / 目标版本不高于当前版本）”。',
        apply(S) { S.vars.ret = '-3'; L(S, '[OTA] ===== OTA FAILED (code -3) =====', 'err'); }
      }
    ];
  };

  /* ③ 目标版本不高于当前版本 */
  OTA_SEG.failDowngradeVer = function () {
    return [
      {
        id: 'x-downgrade', scene: 'fail', label: '目标版本 <= 当前版本', dur: 2600,
        code: 'run_once_reject', hl: [1193, 1214],
        call: ['version_parse(target)', 'cur_ver <= p.version ?'],
        mods: ['core', 'param'], flows: [],
        g: 'A',
        note: '相等与更小分两种处理：相等 → 补报 201 后返回 1（“已经是最新”，因为升级其实成功了只是 201 没被平台接受）；更小 → 上报 206 并返回 -3（拒绝降级）。',
        apply(S) {
          S.ctx.func = 'ota_run_once()';
          S.task = { tid: 1529128, size: 94824, type: 1, target: '1.0.0' };
          S.vars.version = 0x010001;
          S.vars.state = 'OTA_ST_ERROR';
          S.vars.ret = '-3';
          S.failKind = 'downgrade';
          L(S, '[OTA] reject: target 1.0.0 <= current 0x010001', 'err');
          L(S, '[OTA] (skip fail report step=206)', 'warn');
        }
      }
    ];
  };

  /* ④ 通道交接失败（真实分支：保持 MQTT，不影响业务） */
  OTA_SEG.failNet = function () {
    return [
      {
        id: 'x-net-init', scene: 'fail', label: 'esp01s_init 失败', dur: 2600,
        code: 'net_enter', hl: [132, 137],
        call: ['ota_net_enter()', 'esp01s_init() → 非 ESP_OK', 'ota_net_restore()'],
        mods: ['core', 'esp', 'usart3'], flows: [],
        g: 'A',
        note: '握手 15×2s 仍失败 → 返回 ESP_TIMEOUT → ota_net_enter 返回 -2 并调用 ota_net_restore() 无条件回到“平时状态”。',
        apply(S) {
          S.ctx.func = 'ota_net_enter()';
          S.vars.state = 'OTA_ST_IDLE';
          S.failKind = 'net';
          L(S, '[OTA] esp01s_init FAILED', 'err');
          L(S, '[OTA] ota_net_enter FAILED(-2), stay in MQTT mode', 'err');
        }
      },
      {
        id: 'x-net-exit', scene: 'fail', label: '恢复 MQTT，不升级', dur: 2400,
        code: 'ota_task_entry', hl: [77, 82],
        call: ['ota_task_entry()', '→ s_busy = 0'],
        mods: ['core', 'esp', 'cloud', 'usart3'], flows: ['uart3-tx'],
        g: 'A',
        note: '注意：这条路径上 ota_run_once() 根本没有被调用，所以不会下载、不会改参数区、更不会复位。OTA 失败但设备业务完全不受影响 —— 这正是“通道交接”设计的价值。',
        apply(S) {
          S.ctx.func = 'ota_task_entry()';
          S.esp.mode = 'mqtt';
          S.intf.cloud = 'mqtt';
          S.intf.dma = 'normal';
          S.intf.usart3 = 'idle-rx';
          S.otaMode = 0;
          S.vars.ret = '（未调用）';
          L(S, '[OTA] ota_net_enter FAILED(-3), join_ap timeout', 'err');
          L(S, '[OTA] 保持 MQTT 常连，未进入 ota_run_once()', 'warn');
        }
      }
    ];
  };

  /* ⑤ W25Q64 写失败 */
  OTA_SEG.failW25q = function () {
    return [
      {
        id: 'x-w25q', scene: 'fail', label: '写暂存区失败', dur: 2600,
        code: 'dl_on_data', hl: [434, 443],
        call: ['dl_on_data()', 'w25q16_write() != HAL_OK', 'c.io_err = 1'],
        mods: ['core', 'spi2', 'w25q'], flows: ['spi-w'],
        g: 'A',
        note: '写失败后立刻置 io_err，后续到达的数据被直接丢弃（if (c->io_err) return;），不再尝试写入 —— 避免忙等放大问题。',
        apply(S) {
          S.ctx.func = 'dl_on_data()';
          S.vars.state = 'OTA_ST_ERROR';
          S.ext.staging.mode = 'error';
          S.failKind = 'w25q';
          L(S, '[OTA] ext flash write FAILED @51200', 'err');
        }
      },
      {
        id: 'x-w25q-ret', scene: 'fail', label: '返回 -4，交还通道', dur: 2400,
        code: 'download_try_c', hl: [677, 685],
        call: ['ota_download_try()', 'ota_download() → -4', 'ota_run_once() → -4'],
        mods: ['core', 'esp', 'cloud'], flows: ['uart3-tx'],
        g: 'A',
        note: 'A 槽没有被碰过，参数区里 boot_flag 仍是 NORMAL。这是安全姿态：下次上电照常跑旧固件。',
        apply(S) {
          S.vars.ret = '-4';
          S.vars.boot_flag = 0;
          S.esp.mode = 'mqtt';
          S.otaMode = 0;
          L(S, '[OTA] ota_run_once() = -4  → ===== OTA FAILED (code -4) =====', 'err');
        }
      }
    ];
  };

  /* ⑥ MD5 两遍都失败 */
  OTA_SEG.failMd5 = function () {
    return [
      {
        id: 'x-md5-1', scene: 'fail', label: '第 1 遍 MD5 失败', dur: 2600,
        code: 'download_try_c', hl: [703, 710],
        call: ['md5_hex_equal() → 0', 'OTA_REPORT_FAIL(205)'],
        mods: ['core'], flows: [],
        g: 'A',
        note: '长度对、MD5 错 —— 说明中间丢字节导致数据整体前移。哈希上下文无法回退，只能整体重下。',
        apply(S) {
          S.ctx.func = 'ota_download_try()';
          S.vars.md5 = '41e52aea… ✗';
          S.vars.state = 'OTA_ST_ERROR';
          S.failKind = 'md5';
          L(S, '[OTA] MD5 mismatch (expect 41e52aea...)', 'err');
        }
      },
      {
        id: 'x-md5-2', scene: 'fail', label: '第 2 遍仍然失败', dur: 2800,
        code: 'download_wrap', hl: [737, 750],
        call: ['ota_download()', 'ota_download_try(force_restart=1) → -5'],
        mods: ['core', 'w25q'], flows: [],
        g: 'A',
        note: '兜底只重下一次。若仍失败就返回 -5，不再无限重试 —— 避免把设备卡在下载循环里。',
        apply(S) {
          S.ctx.func = 'ota_download()';
          S.vars.md5 = '41e52aea… ✗';
          S.failKind = 'md5';
          L(S, '[OTA] verify FAILED, erase staging and re-download from 0 ...', 'warn');
          L(S, '[OTA] MD5 mismatch (2nd pass) → return -5', 'err');
        }
      },
      {
        id: 'x-md5-ret', scene: 'fail', label: '返回 -5，A 槽未动', dur: 2400,
        code: 'run_once_download', hl: [1219, 1224],
        call: ['ota_run_once() → -5'],
        mods: ['core', 'param'], flows: [],
        g: 'A',
        note: '整个失败路径上，片内 A 槽与参数区的 boot_flag 都没有被改动 —— 设备继续跑 1.0.0。',
        apply(S) {
          S.vars.ret = '-5';
          S.vars.boot_flag = 0;
          S.vars.backup_status = 1;
          L(S, '[OTA] ota_run_once() = -5  → ===== OTA FAILED (code -5) =====', 'err');
        }
      }
    ];
  };

  /* ⑦ BL：暂存区 SHA-256 失败 → 转 ROLLBACK → 用备份恢复（真实现） */
  OTA_SEG.failStagingSha = function () {
    return [
      {
        id: 'x-sha-fail', scene: 'fail', label: '暂存区 SHA-256 失败', dur: 3000,
        code: 'boot_run_trynew', hl: [435, 446],
        call: ['boot_verify_ext_image() → -1', '→ boot_flag = ROLLBACK'],
        mods: ['core', 'w25q', 'spi2'], flows: ['spi-r'],
        g: 'A',
        note: '★ 这是“先校验、后擦写”原则的实际价值：SHA-256 不过，BL 一格都不擦 A 槽，直接把 flag 改成 ROLLBACK 并保存，然后走回滚分支。A 槽里的旧固件因此完好无损。',
        apply(S) {
          S.ctx.func = 'boot_verify_ext_image()';
          S.vars.state = 'OTA_ST_ERROR';
          S.vars.boot_flag = 2;
          S.vars.boot_count = 0;
          S.failKind = 'staging-sha';
          S.ext.staging.mode = 'corrupt';
          L(S, '[BL] verify staging SHA-256 (len=94824)...', 'boot');
          L(S, '[BL] staging INVALID -> switch to ROLLBACK', 'err');
          L(S, '[BL] param_area_save() OK  (flag=2)', 'warn');
        }
      },
      {
        id: 'x-rollback-verify', scene: 'fail', label: '校验备份区 SHA-256', dur: 2800,
        code: 'boot_do_rollback', hl: [183, 200],
        call: ['boot_do_rollback()', 'boot_verify_ext_image(BACKUP, backup_len, backup_sha)'],
        mods: ['core', 'w25q', 'spi2'], flows: ['spi-r'],
        g: 'A',
        note: '回滚也不是“直接拷”，同样要先校验备份区的 SHA-256。备份区坏了就往下走 recovery，而不是拿坏数据去擦 A 槽。',
        apply(S) {
          S.ctx.func = 'boot_do_rollback()';
          S.ctx.addr = '0x08004B45';
          S.rollbackProg = 0;
          L(S, '[BL] verify backup SHA-256 (len=94820)...', 'boot');
        },
        live(S, p) { S.rollbackProg = p; }
      },
      {
        id: 'x-rollback-copy', scene: 'fail', label: '备份区覆盖 A 槽', dur: 3000,
        code: 'boot_do_rollback', hl: [202, 210],
        call: ['boot_do_rollback()', 'boot_copy_ext_to_run(BACKUP, backup_len)'],
        mods: ['core', 'w25q', 'int-flash'], flows: ['spi-r', 'flash-int'],
        g: 'A',
        note: '擦 A 槽 → 从备份区 1KB 分块搬回来。这一步执行完，片内又变回 1.0.0。',
        apply(S) {
          S.intf.app.state = 'writing';
          S.intf.app.fill = 0;
          S.intf.app.ver = '1.0.0 (回滚中)';
          S.copyProg = 0;
          L(S, '[BL] backup OK, copy backup -> A', 'warn');
        },
        live(S, p) { S.copyProg = p; S.intf.app.fill = p; }
      },
      {
        id: 'x-rollback-ok', scene: 'fail', label: '回滚完成：版本号回退', dur: 2600,
        code: 'boot_run_rollback', hl: [336, 367],
        call: ['boot_run()', 'param.version = backup_version', 'param_area_save()'],
        mods: ['core', 'param', 'int-flash'], flows: ['flash-int'],
        g: 'A',
        note: '★ 注意这里的隐含前提：只有 backup_version != 0 才会覆盖 param.version。若备份版本号为 0（旧格式写入），版本号会保持新版本值，App 的防降级比较会失真 —— 代码注释里已承认这个风险。',
        apply(S) {
          S.vars.boot_flag = 0;
          S.vars.boot_count = 0;
          S.vars.version = 0x010000;
          S.vars.backup_status = 0;
          S.vars.image_len = 0;
          S.intf.app.state = 'ok';
          S.intf.app.fill = 1;
          S.intf.app.ver = '1.0.0';
          S.ext.staging.mode = 'corrupt';
          S.intf.param.seq = 9;
          L(S, '[BL] rollback done, ver=0x010000', 'ok');
          L(S, '[BL] flag→NORMAL, backup_status→EMPTY', 'boot');
        }
      },
      {
        id: 'x-rollback-jump', scene: 'fail', label: '跳回旧固件，设备可用', dur: 2400,
        code: 'boot_run_final', hl: [484, 491],
        call: ['app_jump_validate()', 'app_jump_execute(0x08010000)'],
        mods: ['core', 'int-flash'], flows: ['flash-int'],
        g: 'A',
        note: '回滚成功后照常跳转 —— 用户看到的是“升级没成，但设备还能用，版本还是 1.0.0”。这是这套机制最重要的可用性保证。',
        apply(S) {
          S.ctx.cpu = 'app';
          S.ctx.image = 'APP1';
          S.ctx.func = 'Reset_Handler (App 1.0.0)';
          S.ctx.vtor = '0x08010000';
          S.intf.bl.state = 'idle';
          S.intf.app.state = 'run';
          L(S, '[BL] jump to app @0x08010000（回滚后的旧固件）', 'ok');
          L(S, '设备恢复为 1.0.0 正常运行', 'ok');
        }
      }
    ];
  };

  /* ⑧ TRY_NEW 连续 3 次未确认 → 自动回滚 */
  OTA_SEG.failBootCount = function () {
    return [
      {
        id: 'x-bc-1', scene: 'fail', label: '第 1 次 TRY_NEW：boot_count=1', dur: 2400,
        code: 'boot_run_trynew', hl: [405, 415],
        call: ['boot_run()', 'param.boot_count++', 'param_area_save()'],
        mods: ['core', 'param'], flows: ['flash-int'],
        g: 'A',
        note: '新固件启动后又崩了/又复位了，没有调用 ota_confirm_boot_success()。下次上电 BL 又走 TRY_NEW，boot_count 继续累加。',
        apply(S) {
          S.ctx.cpu = 'bl';
          S.ctx.func = 'boot_run()';
          S.vars.boot_count = 1;
          S.vars.boot_flag = 1;
          S.failKind = 'boot-count';
          L(S, '[BL] >>> TRY_NEW  boot_count 0 → 1', 'warn');
        }
      },
      {
        id: 'x-bc-2', scene: 'fail', label: '第 2 次：boot_count=2', dur: 2200,
        code: 'boot_run_trynew', hl: [408, 415],
        call: ['boot_run()', 'param.boot_count++'],
        mods: ['core', 'param'], flows: ['flash-int'],
        g: 'A',
        note: '阈值判断是 >= OTA_BOOT_MAX_TRIES(3)，所以第 2 次仍然继续尝试。',
        apply(S) { S.vars.boot_count = 2; L(S, '[BL] boot_count 1 → 2（仍 < 3）', 'warn'); }
      },
      {
        id: 'x-bc-3', scene: 'fail', label: '第 3 次：达到阈值，转 ROLLBACK', dur: 2800,
        code: 'boot_run_trynew', hl: [408, 416],
        call: ['boot_run()', 'boot_count >= OTA_BOOT_MAX_TRIES', '→ boot_flag = ROLLBACK'],
        mods: ['core', 'param'], flows: ['flash-int'],
        g: 'A',
        note: '★ 这就是工程里真实存在的“启动确认超时”实现：不是定时器，而是“连续启动次数”。达到 3 次就把 boot_flag 改成 ROLLBACK 并立即执行回滚拷贝。',
        apply(S) {
          S.vars.boot_count = 0;
          S.vars.boot_flag = 2;
          L(S, '[BL] count=3 >= 3, switch to ROLLBACK', 'err');
        }
      },
      {
        id: 'x-bc-rb', scene: 'fail', label: '自动回滚到备份版本', dur: 2800,
        code: 'boot_do_rollback', hl: [183, 211],
        call: ['boot_do_rollback()', '校验备份 → 覆盖 A 槽'],
        mods: ['core', 'w25q', 'int-flash'], flows: ['spi-r', 'flash-int'],
        g: 'A',
        note: '回滚后 boot_flag 复位为 NORMAL、boot_count 清零、backup_status 清成 EMPTY。设备回到旧固件。',
        apply(S) {
          S.vars.boot_flag = 0;
          S.vars.version = 0x010000;
          S.vars.backup_status = 0;
          S.intf.app.ver = '1.0.0';
          S.intf.app.fill = 1;
          L(S, '[BL] rollback done, ver=0x010000  flag=NORMAL', 'ok');
        }
      }
    ];
  };

  /* ⑨ 备份无效 + 恢复失败 → boot_halt 挂死 */
  OTA_SEG.failHalt = function () {
    return [
      {
        id: 'x-halt-1', scene: 'fail', label: '没有有效备份', dur: 2400,
        code: 'boot_do_rollback', hl: [186, 195],
        call: ['boot_do_rollback()', 'backup_status != VALID → -1'],
        mods: ['core', 'param'], flows: [],
        g: 'A',
        note: 'backup_status 不是 VALID（或 backup_len == 0）时，回滚直接失败，不尝试拷贝。',
        apply(S) {
          S.ctx.cpu = 'bl';
          S.ctx.func = 'boot_do_rollback()';
          S.vars.boot_flag = 2;
          S.vars.backup_status = 0;
          S.branch = 'ROLLBACK';
          S.failKind = 'halt';
          S.frame = { title: '为什么回滚失败', lines: ['if (p->backup_status != OTA_BACKUP_VALID', '    || p->backup_len == 0)', '    return -1;   /* 不尝试拷贝 */'] };
          L(S, '[BL] no valid backup', 'err');
          L(S, '[BL] rollback FAILED, try recovery', 'err');
        }
      },
      {
        id: 'x-halt-2', scene: 'fail', label: '恢复区也失败', dur: 2400,
        code: 'boot_run_rollback', hl: [349, 356],
        call: ['boot_do_recovery() → -1', 'boot_halt()'],
        mods: ['core', 'w25q'], flows: [],
        g: 'A',
        note: 'recovery_len == 0 时连恢复镜像都没有。此时唯一正确的做法是挂死并持续喂狗 —— 而不是继续跳转或反复复位，否则串口日志会一直刷，没法定位问题。',
        apply(S) {
          S.ctx.func = 'boot_do_recovery()';
          S.vars.backup_status = 0;
          S.failKind = 'halt';
          L(S, '[BL] no recovery image', 'err');
        }
      },
      {
        id: 'x-halt-3', scene: 'fail', label: 'boot_halt：喂狗挂死', dur: 3000,
        code: 'boot_halt', hl: [62, 68],
        call: ['boot_halt()', 'for(;;) boot_wdg_feed();'],
        mods: ['core', 'iwdg'], flows: [],
        g: 'A',
        note: '★ 这是设备“变砖”的真实边界：A 槽无效、备份无效、恢复区无效，三者同时不成立。此时 BL 不跳转、不复位，只在原地喂狗，等人用调试器/串口介入。',
        apply(S) {
          S.ctx.cpu = 'halt';
          S.ctx.func = 'boot_halt()';
          S.vars.ret = 'halt';
          S.vars.state = 'OTA_ST_ERROR';
          S.halted = true;
          L(S, '[BL] recovery FAILED, system halted!', 'err');
          L(S, '[BL] 进入 boot_halt()：持续喂狗，不跳转、不复位', 'err');
        }
      }
    ];
  };

  /* ⑩ 建议方案模拟（当前工程未实现，全部标 C） */
  OTA_SEG.suggest = function () {
    return [
      {
        id: 'sg-note', scene: 'suggest', label: '★ 建议方案：本段不是现有工程行为', dur: 3000,
        code: 'partition_internal', hl: [59, 64],
        call: ['（建议）A/B 双槽 + 槽指针'],
        mods: ['core', 'int-flash'], flows: [],
        g: 'C',
        note: '以下全部是“建议方案模拟”，当前源码里没有实现。现有工程是单 A 槽 + 片外备份；这里演示一种把 960KB 拆成 A/B 两槽、用“槽指针”原子切换的改法。',
        apply(S) {
          S.ctx.cpu = 'bl';
          S.ctx.image = 'BL';
          S.ctx.func = '（建议）boot_select_slot()';
          S.ctx.addr = '（建议）0x08000000 + slot_table';
          S.ctx.clk = 'HSI 16MHz → PLL 180MHz';
          S.suggestMode = true;
          S.vars.boot_flag = 0;
          S.vars.version = 0x010000;
          S.frame = { title: '（建议）A/B 双槽布局', lines: [
            'Slot A 0x08010000  480KB  VER 1.0.0',
            'Slot B 0x08088000  480KB  VER —',
            'param.active_slot = A',
            '（当前工程无此布局，源码为单 A 槽 960KB）'
          ] };
          S.slotTable = { A: { ver: '1.0.0', active: true }, B: { ver: '—', active: false } };
          L(S, '[建议] 本段为设计模拟，非现有源码行为', 'warn');
        }
      },
      {
        id: 'sg-write-b', scene: 'suggest', label: '（建议）写入非活动槽 B', dur: 3000,
        code: 'partition_internal', hl: [59, 64],
        call: ['（建议）ota_download → slot B'],
        mods: ['core', 'int-flash', 'w25q'], flows: ['flash-int'],
        g: 'C',
        note: '关键区别：新固件直接写进非活动槽，运行中的 A 槽一个字节都不动。擦写期间掉电也不会让设备失去可启动镜像。',
        apply(S) {
          S.ctx.func = '（建议）ota_download_to_slot(B)';
          S.slotTable = { A: { ver: '1.0.0', active: true }, B: { ver: '1.0.1', active: false } };
          S.prog.dl = 1;
          L(S, '[建议] 新固件写入槽 B，槽 A 保持不动', 'ok');
        }
      },
      {
        id: 'sg-switch', scene: 'suggest', label: '（建议）改槽指针完成切换', dur: 2600,
        code: 'partition_flags', hl: [80, 91],
        call: ['（建议）boot_flag → ACTIVE_SLOT = B'],
        mods: ['core', 'param'], flows: ['flash-int'],
        g: 'C',
        note: '切换只是一次参数区写入（几百字节），不再需要擦 960KB、也不再需要搬 94KB。回滚同样是“把指针改回 A”。',
        apply(S) {
          S.ctx.func = '（建议）param_area_save(ACTIVE_SLOT=B)';
          S.slotTable = { A: { ver: '1.0.0', active: false }, B: { ver: '1.0.1', active: true } };
          S.vars.version = 0x010001;
          L(S, '[建议] ACTIVE_SLOT = B  commit 一次参数区写入即完成', 'ok');
        }
      },
      {
        id: 'sg-rollback', scene: 'suggest', label: '（建议）回滚 = 改回指针', dur: 2600,
        code: 'jump_validate', hl: [36, 41],
        call: ['（建议）ACTIVE_SLOT = A', 'app_jump_validate(slot A)'],
        mods: ['core', 'param'], flows: [],
        g: 'C',
        note: '与现有实现对比：现有回滚要“校验备份区 + 擦 A 槽 + 搬 94KB”，建议方案只需把指针改回 A —— 秒级完成，且不存在“搬到一半掉电”的窗口。',
        apply(S) {
          S.ctx.func = '（建议）boot_select_slot()';
          S.slotTable = { A: { ver: '1.0.0', active: true }, B: { ver: '1.0.1', active: false } };
          S.vars.version = 0x010000;
          L(S, '[建议] 回滚：ACTIVE_SLOT = A（旧镜像从未被改写）', 'ok');
          L(S, '[建议] 代价：镜像上限从 960KB 降到 480KB', 'warn');
        }
      }
    ];
  };

})();
