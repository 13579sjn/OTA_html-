/* =============================================================================
 * segments-a.js —— 场景分段时间轴（上半程：上电 → 查询任务）
 *
 * 每个 segment 返回一个 step 数组。step 的字段含义见 js/core/state.js 顶部注释。
 * 所有 apply() 只改动画状态 S，不改动任何事实常量（facts.js）。
 * ========================================================================== */
'use strict';

window.OTA_SEG = window.OTA_SEG || {};

(function () {

  /* ---------- 小工具 ---------- */
  const V6 = (v) => '0x' + (v >>> 0).toString(16).toUpperCase().padStart(6, '0');

  function L(S, text, cls) {
    OTA_STATE.log(S, text, cls || 'info');
  }
  window.OTA_L = L;
  window.OTA_V6 = V6;

  /* ==================================================================
   * 场景 1：上电与复位
   * ================================================================== */
  OTA_SEG.power = function () {
    return [
      {
        id: 'p-reset', scene: 'power', label: '复位释放 · 取向量表', dur: 2400,
        code: 'startup_vectors', hl: [60, 61],
        call: ['硬件复位', 'Reset_Handler'],
        mods: ['core', 'int-flash'], flows: [],
        g: 'A',
        note: 'NRST 释放后，Cortex-M4 从 0x08000000 取第 0 项作为初始 MSP，从 0x08000004 取第 1 项作为复位入口。片内 Flash 最前面放的就是 BootLoader，所以上电永远先跑 BL。',
        apply(S) {
          S.ctx.cpu = 'reset';
          S.ctx.image = 'BL';
          S.ctx.addr = '0x08000000';
          S.ctx.func = 'Reset_Handler';
          S.ctx.msp = '0x20000E00';
          S.ctx.vtor = '0x08000000';
          S.intf.bl.state = 'run';
          L(S, 'NRST 释放，CPU 从 0x08000000 取向量表', 'boot');
          L(S, '向量表[0] = 0x20000E00  (__initial_sp)', 'boot');
          L(S, '向量表[1] = 0x080002F9  (Reset_Handler)', 'boot');
        }
      },
      {
        id: 'p-startup', scene: 'power', label: 'Reset_Handler → SystemInit', dur: 2200,
        code: 'startup_reset', hl: [177, 186],
        call: ['Reset_Handler', 'SystemInit()', '__main()', 'main()'],
        mods: ['core'], flows: ['flash-int'],
        g: 'A',
        note: '复位入口只做三件事：SystemInit() 初始化时钟与向量表基址、__main() 初始化 .data/.bss 段、跳到 main()。BL 的 main 里第一件事是 HAL_Init()。',
        apply(S) {
          S.ctx.func = 'Reset_Handler';
          L(S, 'Reset_Handler: SystemInit() → __main() → main()', 'boot');
        }
      },
      {
        id: 'p-halinit', scene: 'power', label: 'HAL_Init + 时钟树', dur: 2400,
        code: 'boot_clock', hl: [133, 163],
        call: ['main()', 'HAL_Init()', 'SystemClock_Config()'],
        mods: ['core', 'int-flash'], flows: ['flash-int'],
        g: 'A',
        note: 'BootLoader 的时钟源是 HSI(16MHz) → PLL，PLLM=8 / PLLN=180 / PLLP=2 → 180MHz，Flash 等待周期 5。注意：App 用的是 HSE 25MHz → PLL，主频相同但时钟源不同。',
        apply(S) {
          S.ctx.func = 'SystemClock_Config()';
          S.ctx.addr = '0x0801E14D';
          S.ctx.clk = 'HSI 16MHz → PLL 180MHz';
          L(S, 'SystemClock_Config: HSI-PLL → 180MHz，FLASH_LATENCY_5', 'boot');
        }
      },
      {
        id: 'p-periph', scene: 'power', label: '外设初始化顺序', dur: 2200,
        code: 'boot_ledskip', hl: [93, 96],
        call: ['main()', 'MX_GPIO_Init', 'MX_DMA_Init', 'MX_USART1_UART_Init', 'MX_SPI2_Init'],
        mods: ['core', 'usart1', 'spi2', 'dma'], flows: [],
        g: 'A',
        note: 'BL 只初始化四组外设：GPIO、DMA、USART1（日志，PA9/PA10，115200）、SPI2（W25Q64，CS=PB12）。BL 刻意不带任何网络栈，保持极小极可靠。',
        apply(S) {
          S.ctx.func = 'MX_SPI2_Init()';
          S.intf.usart1 = 'ok'; S.intf.spi2 = 'ok'; S.intf.dma = 'ok';
          L(S, 'MX_GPIO_Init / MX_DMA_Init / MX_USART1_UART_Init(115200) / MX_SPI2_Init', 'boot');
        }
      },
      {
        id: 'p-bootrun', scene: 'power', label: '进入 boot_run()', dur: 2000,
        code: 'boot_main', hl: [99, 101],
        call: ['main()', 'boot_run()'],
        mods: ['core'], flows: [],
        g: 'A',
        note: 'boot_run() 之后 main 的 while(1) 永远到不了：要么跳转成功跑 App，要么 boot_halt() 挂死。这是刻意设计 —— BL 不允许“跑飞”。',
        apply(S) {
          S.ctx.cpu = 'bl';
          S.ctx.func = 'boot_run()';
          S.ctx.addr = '0x08004DBD';
          L(S, 'USER CODE 2: boot_run() —— 不返回', 'boot');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 2：BootLoader 初始化
   * ================================================================== */
  OTA_SEG.blInit = function () {
    return [
      {
        id: 'bl-port', scene: 'bl-init', label: '修正 NVIC 优先级', dur: 2400,
        code: 'boot_run_head', hl: [277, 277],
        call: ['boot_run()', 'boot_port_init()'],
        mods: ['core', 'nvic', 'usart1', 'dma'], flows: [],
        g: 'A',
        note: 'CubeMX 生成的 usart.c / dma.c 把 USART1 与 DMA2 流的中断优先级都设成 0，会抢占 SysTick（优先级 15），导致 HAL_Delay 计时不准。boot_port_init() 统一改成 5，与 App 侧 UART_NVIC_Config() 保持一致。',
        apply(S) {
          S.ctx.func = 'boot_port_init()';
          L(S, '[BL] boot_port_init: USART1/DMA2_S2/DMA2_S7 优先级 0 → 5', 'boot');
        }
      },
      {
        id: 'bl-banner', scene: 'bl-init', label: '打印启动横幅', dur: 2200,
        code: 'boot_run_head', hl: [279, 292],
        call: ['boot_run()', 'boot_log()'],
        mods: ['core', 'usart1'], flows: ['uart1-tx'],
        g: 'A',
        note: '横幅把三个分区地址直接打出来，这是现场定位“到底烧到哪了”的第一手信息。USART1 115200，阻塞发送，最可靠。',
        apply(S) {
          S.ctx.func = 'boot_log()';
          S.frame = { title: 'USART1 115200', lines: [
            '==============================================',
            '  STM32F429IGT6 OTA BootLoader v1.0',
            '  build ...',
            '  BL   : 0x08000000 + 48KB',
            '  PARAM: 0x0800C000 + 16KB',
            '  APP A: 0x08010000 + 960KB'
          ] };
          L(S, '[BL] ===== STM32F429IGT6 OTA BootLoader v1.0 =====', 'boot');
          L(S, '[BL] BL: 0x08000000+48KB  PARAM: 0x0800C000+16KB  APP A: 0x08010000+960KB', 'boot');
        }
      },
      {
        id: 'bl-wdg', scene: 'bl-init', label: '看门狗（默认关闭）', dur: 2400,
        code: 'boot_run_head', hl: [295, 299],
        call: ['boot_run()', 'boot_wdg_init()'],
        mods: ['core', 'iwdg'], flows: [],
        g: 'A',
        note: 'BOOT_WDG_ENABLE = 0，所以 boot_wdg_init() 整个实现体被 #if 跳过，boot_wdg_is_enabled() 返回 0，横幅里不会打印 IWDG。原因写在 boot_config.h：IWDG 一旦启动就无法停止，若 App 侧喂狗没打通，跳转后 8.19s 必然复位。',
        apply(S) {
          S.ctx.func = 'boot_wdg_init()';
          S.intf.iwdg = 'off';
          L(S, '[BL] IWDG disabled (BOOT_WDG_ENABLE=0) —— 空操作', 'warn');
        }
      },
      {
        id: 'bl-ext', scene: 'bl-init', label: 'W25Q64 初始化', dur: 2400,
        code: 'boot_ext_id', hl: [20, 31],
        call: ['boot_run()', 'boot_ext_init()', 'W25Q64_InitConfig()'],
        mods: ['core', 'spi2', 'w25q'], flows: ['spi-r'],
        g: 'A',
        note: 'W25Q64_InitConfig() 把 PB12 配成推挽输出做片选，SPI2 已在 MX_SPI2_Init 里配好。返回状态存放在 w25q64_last_status，由 W25Q64_GetLastStatus() 取回。',
        apply(S) {
          S.ctx.func = 'boot_ext_init()';
          L(S, '[BL] W25Q64_InitConfig(): SPI2 + CS(PB12)', 'boot');
        }
      },
      {
        id: 'bl-jedec', scene: 'bl-init', label: '读 JEDEC ID', dur: 2200,
        code: 'boot_ext_id', hl: [33, 50],
        call: ['boot_run()', 'boot_ext_jedec_id()'],
        mods: ['core', 'spi2', 'w25q'], flows: ['spi-r'],
        g: 'A',
        note: '0x9F 命令读三字节：厂商 0xEF(Winbond) / 类型 0x40 / 容量 0x17(8MB) → 0x00EF4017 = W25Q64。实施文档 8.8 记录过读回 0x000000 / 0xFFFFFF 的临界情况。',
        apply(S) {
          S.ctx.func = 'boot_ext_jedec_id()';
          S.counters.spi += 4;
          S.frame = { title: 'SPI2 · JEDEC', lines: ['CS↓  0x9F', 'MF   ← 0xEF', 'MT   ← 0x40', 'CAP  ← 0x17', 'CS↑  = 0x00EF4017 (W25Q64)'] };
          L(S, '[BL] ext flash JEDEC ID: 0xEF4017 (W25Q64)', 'boot');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 3：读取升级标志
   * ================================================================== */
  OTA_SEG.blParam = function () {
    return [
      {
        id: 'bl-param-load', scene: 'bl-param', label: 'param_area_load()', dur: 2800,
        code: 'param_load', hl: [119, 143],
        call: ['boot_run()', 'param_area_load()'],
        mods: ['core', 'param'], flows: ['flash-int'],
        g: 'A',
        note: '参数区不是“一个结构体”，而是 32 个 512B 槽的环形日志：每槽 magic(4B)+seq(4B)+结构体(含 CRC32)。load 时遍历 32 槽，取 seq 最大且 CRC32 正确的那个。每次 save 只写一个新空槽，不需要擦除，把掉电风险从每次降到 1/32。',
        apply(S) {
          S.ctx.func = 'param_area_load()';
          S.ctx.addr = '0x080057DD';
          S.intf.param.state = 'scan';
          L(S, '[BL] param_area_load: 扫描 S3（0x0800C000）32 个 512B 槽', 'boot');
        }
      },
      {
        id: 'bl-param-crc', scene: 'bl-param', label: '取 seq 最大 + CRC32', dur: 2400,
        code: 'param_load', hl: [125, 134],
        call: ['param_area_load()', 'slot_load()', 'crc32_calc()'],
        mods: ['core', 'param'], flows: ['flash-int'],
        g: 'A',
        note: 'seq 用差值比较 ((int32_t)(seq - best_seq) > 0)，这样 uint32 回绕也能正确处理。CRC32 不包含结构体最后 4 字节的 crc32 字段自身。',
        apply(S) {
          S.intf.param.state = 'ok';
          S.intf.param.seq = 2;
          S.vars.boot_flag = 0;
          S.vars.boot_count = 0;
          S.vars.version = 0x010000;
          S.vars.backup_status = 2;
          S.vars.image_len = 94824;
          L(S, '[BL] slot[2] magic=0xA5A5A5A5 crc32=OK → 采用（seq 最大）', 'ok');
        }
      },
      {
        id: 'bl-param-dump', scene: 'bl-param', label: '打印参数快照', dur: 2200,
        code: 'boot_run_param', hl: [323, 328],
        call: ['boot_run()'],
        mods: ['core', 'usart1', 'param'], flows: ['uart1-tx'],
        g: 'A',
        note: '这一行日志是判断“BL 到底读到了什么”的关键：flag=启动标志、count=失败计数、ver=参数区记录版本、img_len=待装镜像长度、bk_st=备份区状态。',
        apply(S) {
          S.ctx.func = 'boot_run()';
          S.frame = { title: '参数区快照', lines: [
            'flag      = 0   (NORMAL)',
            'count     = 0',
            'ver       = 0x010000  (V1.0.0)',
            'img_len   = 94824',
            'bk_st     = 2   (VALID)'
          ] };
          L(S, '[BL] flag=0 count=0 ver=0x010000 img_len=94824 bk_st=2', 'boot');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 4：启动目标判断
   * ================================================================== */
  OTA_SEG.blDecide = function () {
    return [
      {
        id: 'bl-branch', scene: 'bl-decide', label: 'boot_flag 四态分支', dur: 2600,
        code: 'boot_run_branch', hl: [331, 331],
        call: ['boot_run()', 'if (param.boot_flag == …)'],
        mods: ['core', 'param'], flows: [],
        g: 'A',
        note: '四个分支互斥：ROLLBACK(2)、RECOVERY(3)、TRY_NEW(1)、其余一律按 NORMAL(0) 处理。本次演示走 NORMAL —— 也就是“什么都没发生，直接跑现有 App”。',
        apply(S) {
          S.ctx.func = 'boot_run()';
          S.branch = 'NORMAL';
          L(S, '[BL] boot_flag = 0 → NORMAL 分支', 'boot');
        }
      },
      {
        id: 'bl-normal', scene: 'bl-decide', label: 'NORMAL：清失败计数', dur: 2000,
        code: 'boot_run_normal', hl: [450, 459],
        call: ['boot_run()', 'param_area_save()'],
        mods: ['core', 'param'], flows: ['flash-int'],
        g: 'A',
        note: 'NORMAL 分支只做一件事：如果 boot_count 不是 0 就清零并保存。它并不会去动 A 槽 —— 这是“安全姿态”：参数区再乱，也不会把正在跑的镜像擦掉。',
        apply(S) {
          S.ctx.func = 'boot_run()';
          L(S, '[BL] NORMAL: boot_count 已是 0，无需保存', 'boot');
        }
      },
      {
        id: 'bl-validate', scene: 'bl-decide', label: 'app_jump_validate()', dur: 2800,
        code: 'jump_validate', hl: [36, 58],
        call: ['boot_run()', 'app_jump_validate(0x08010000)'],
        mods: ['core', 'int-flash', 'sram'], flows: ['flash-int'],
        g: 'A',
        note: '三道闸门：① 地址必须严格落在 A 槽区间 [0x08010000, 0x080F0000)；② 向量表第 0 项（初始 MSP）必须落在 192KB SRAM 或 64KB CCM 内；③ 复位向量必须落在片内 Flash 内。任一不过就当作镜像无效。',
        apply(S) {
          S.ctx.func = 'app_jump_validate()';
          S.ctx.addr = '0x080048D5';
          S.check = { addr: true, msp: true, reset: true };
          L(S, '[BL] app_jump_validate: 地址区间 ✓  MSP∈RAM ✓  Reset∈Flash ✓', 'ok');
        }
      },
      {
        id: 'bl-vec', scene: 'bl-decide', label: '读 A 槽向量表', dur: 2200,
        code: 'boot_run_final', hl: [463, 464],
        call: ['boot_run()', 'boot_dump_vectors(0x08010000)'],
        mods: ['core', 'int-flash', 'sram'], flows: ['flash-int'],
        g: 'A',
        note: '实测日志里这两个值就是 0x20014E38 / 0x080103F9 —— 与 App 工程 .map 文件里的 __initial_sp 与 Reset_Handler 完全一致（见 facts 里的 symbols）。',
        apply(S) {
          S.ctx.func = 'boot_dump_vectors()';
          S.frame = { title: 'A 槽向量表 @0x08010000', lines: [
            'vec[0] = 0x20014E38   ← 初始 MSP',
            'vec[1] = 0x080103F9   ← Reset_Handler (Thumb)'
          ] };
          L(S, '[BL] target app @0x08010000', 'boot');
          L(S, '[BL] vec[0]=0x20014E38 vec[1]=0x080103F9', 'boot');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 5：启动环境与跳转
   * ================================================================== */
  OTA_SEG.blJump = function () {
    return [
      {
        id: 'j-shutdown', scene: 'bl-jump', label: 'boot_system_shutdown()', dur: 2800,
        code: 'shutdown', hl: [147, 168],
        call: ['app_jump_execute()', 'boot_system_shutdown()'],
        mods: ['core', 'nvic', 'dma', 'usart1', 'spi2'], flows: [],
        g: 'A',
        note: '跳转前必须把 BL 碰过的一切拆干净：关全局中断 → 停 SysTick → 清 NVIC 使能/挂起/优先级 → 关 DMA1/DMA2 全部 16 个流并清标志 → DeInit USART1/SPI2 → 恢复引脚复位态。少一步就会出现“App 里中断进错函数”。',
        apply(S) {
          S.ctx.func = 'boot_system_shutdown()';
          S.ctx.addr = '0x0800548D';
          S.intf.usart1 = 'off'; S.intf.spi2 = 'off'; S.intf.dma = 'off';
          L(S, '[BL] shutdown: __disable_irq / SysTick / NVIC / DMA1+2 / UART1 / SPI2', 'boot');
        }
      },
      {
        id: 'j-clock', scene: 'bl-jump', label: '时钟树恢复 HSI 16MHz', dur: 2600,
        code: 'clock_hsi', hl: [89, 127],
        call: ['boot_system_shutdown()', 'boot_restore_clock_to_hsi()'],
        mods: ['core'], flows: [],
        g: 'A',
        note: '这是整份移植里最“反直觉”的一步：BL 用 HSI-PLL，App 用 HSE25-PLL，主频都是 180MHz 但时钟源不同。若不先切回 HSI，HAL_RCC_OscConfig() 会因为“当前 SYSCLK 仍来自 PLL”而跳过 PLL 重配置。',
        apply(S) {
          S.ctx.func = 'boot_restore_clock_to_hsi()';
          S.ctx.clk = 'HSI 16MHz（Flash 等待周期 5 → 0）';
          L(S, '[BL] restore clock: SYSCLK→HSI, PLL off, HSE off, LATENCY 0', 'warn');
        }
      },
      {
        id: 'j-msp', scene: 'bl-jump', label: '设置主栈指针 MSP', dur: 2400,
        code: 'jump_execute', hl: [76, 77],
        call: ['app_jump_execute()', '__set_MSP()'],
        mods: ['core', 'sram'], flows: [],
        g: 'A',
        note: '★ 先把目标地址存进文件级静态变量 s_jump_addr，再设 MSP。原因写在注释里：设完 MSP 之后栈已经换成 App 的栈，此时若从局部变量（压在旧栈上）取值会读到脏数据。',
        apply(S) {
          S.ctx.func = 'app_jump_execute()';
          S.ctx.addr = '0x08004861';
          S.ctx.msp = '0x20014E38';
          L(S, '[BL] s_jump_addr = 0x08010000（静态区）', 'boot');
          L(S, '[BL] __set_MSP(0x20014E38)  ← App 的栈顶', 'boot');
        }
      },
      {
        id: 'j-vtor', scene: 'bl-jump', label: '重定位向量表 VTOR', dur: 2400,
        code: 'jump_execute', hl: [80, 90],
        call: ['app_jump_execute()', 'SCB->VTOR', '__DSB()', '__ISB()'],
        mods: ['core', 'nvic'], flows: [],
        g: 'A',
        note: 'SCB->VTOR = 0x08010000，再 DSB/ISB 保证写入真正生效、清空流水线里预取的旧指令。随后清 PendSV/SysTick 挂起位再开总中断 —— 顺序错就会“刚开中断就进一次 FreeRTOS 的 PendSV”。',
        apply(S) {
          S.ctx.vtor = '0x08010000';
          L(S, '[BL] SCB->VTOR = 0x08010000  __DSB() __ISB()', 'boot');
          L(S, '[BL] clear PendSV/PendST, __enable_irq()', 'boot');
        }
      },
      {
        id: 'j-entry', scene: 'bl-jump', label: '跳转 · 控制权转移', dur: 2600,
        code: 'jump_execute', hl: [88, 90],
        call: ['app_jump_execute()', 'entry()', 'App Reset_Handler'],
        mods: ['core', 'int-flash'], flows: ['flash-int'],
        g: 'A',
        note: 'entry = *(uint32_t*)(0x08010004) = 0x080103F9，直接调用，不返回。从这一刻起 CPU 执行的是 App 的代码，BL 已经“消失”了 —— 它仍然躺在 0x08000000，但再也没有被调用。',
        apply(S) {
          S.ctx.cpu = 'app';
          S.ctx.image = 'APP1';
          S.ctx.func = 'Reset_Handler (App)';
          S.ctx.addr = '0x080103F9';
          S.intf.bl.state = 'idle';
          S.intf.app.state = 'run';
          S.jumpFlash = 1;
          L(S, '[BL] jump to app @0x08010000', 'ok');
          L(S, '>>> 控制权转移：BootLoader → App 1.0.0', 'ok');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 6：App 启动与自检
   * ================================================================== */
  OTA_SEG.appInit = function () {
    return [
      {
        id: 'a-vtor', scene: 'app-init', label: 'App 里再设一次 VTOR', dur: 2400,
        code: 'app_main_vtor', hl: [225, 227],
        call: ['main()', 'SCB->VTOR = 0x08010000'],
        mods: ['core', 'nvic'], flows: [],
        g: 'A',
        note: '为什么设两次？启动文件里 SystemInit() 的 VTOR 来自 system_stm32f4xx.c 的 VECT_TAB_OFFSET，默认 0 —— 也就是它会把 VTOR 又设回 0x08000000。main() 里再设一次是兜底，必须早于 HAL_Init()（HAL_Init 会启动 TIM14 时基中断）。',
        apply(S) {
          S.ctx.func = 'main()';
          S.ctx.addr = '0x0801E14D';
          S.ctx.vtor = '0x08010000';
          L(S, 'App main(): SCB->VTOR = 0x08010000  __DSB() __ISB()', 'app');
        }
      },
      {
        id: 'a-clock', scene: 'app-init', label: 'HSE 25MHz → 180MHz', dur: 2200,
        code: 'boot_clock', hl: [133, 163],
        call: ['main()', 'SystemClock_Config()'],
        mods: ['core'], flows: [],
        g: 'B',
        note: 'App 的时钟树由 CubeMX 生成为 HSE(25MHz 晶振) → PLL，而 BL 是 HSI → PLL。两者主频同为 180MHz。这正是 BL 跳转前必须把时钟切回 HSI 的原因。（此步骤展示 BL 的同名函数结构，App 侧参数以 HSE 为准，故标 B）',
        apply(S) {
          S.ctx.func = 'SystemClock_Config()';
          S.ctx.clk = 'HSE 25MHz → PLL 180MHz';
          L(S, 'SystemClock_Config: HSE-PLL → 180MHz', 'app');
        }
      },
      {
        id: 'a-periph', scene: 'app-init', label: '外设初始化', dur: 2200,
        code: 'app_main', hl: [234, 268],
        call: ['main()', 'HAL_Init()', 'MX_GPIO_Init()', 'MX_USART1/3_UART_Init()', 'MX_SPI2_Init()', 'MX_FREERTOS_Init()'],
        mods: ['core', 'usart1', 'usart3', 'spi2', 'dma'], flows: [],
        g: 'A',
        note: 'App 比 BL 多了一整套：USART3（接 ESP-01S，PB10/PB11）、LTDC/SDRAM（7 寸屏）、TIM、以及 FreeRTOS。',
        apply(S) {
          S.ctx.func = 'MX_FREERTOS_Init()';
          S.intf.usart1 = 'ok'; S.intf.usart3 = 'ok'; S.intf.spi2 = 'ok'; S.intf.dma = 'ok';
          L(S, 'HAL_Init / clocks / GPIO / DMA / USART1 / USART3(115200) / SPI2', 'app');
        }
      },
      {
        id: 'a-rtos', scene: 'app-init', label: '板级初始化 + IDLE 接收', dur: 2400,
        code: 'freertos_init', hl: [145, 175],
        call: ['MX_FREERTOS_Init()', 'UART_NVIC_Config()', 'SDRAM_Init()', 'LCD_Init()', 'uart_start_receive()'],
        mods: ['core', 'usart1', 'usart3', 'dma', 'sram'], flows: [],
        g: 'A',
        note: '两个串口都用 HAL_UARTEx_ReceiveToIdle_DMA 启动接收（RX_max-1 字节）。这一步是“平时”的接收通道；OTA 期间 USART3 会被 esp01s 抢走并切成 CIRCULAR，两者的互斥由 ota_net_is_active() 守卫。',
        apply(S) {
          S.ctx.func = 'uart_start_receive()';
          S.intf.usart3 = 'idle-rx';
          L(S, 'uart_start_receive(USART1 / USART3) : IDLE + DMA 模式', 'app');
        }
      },
      {
        id: 'a-flash', scene: 'app-init', label: 'W25Q64 + 参数区自检', dur: 2200,
        code: 'freertos_init', hl: [177, 189],
        call: ['MX_FREERTOS_Init()', 'w25q16_init()', 'w25q16_read_jedec_id()', 'param_area_load()'],
        mods: ['core', 'spi2', 'w25q', 'param'], flows: ['spi-r'],
        g: 'A',
        note: 'App 侧也用同一份 param_area_load()。这里打印的 flag=0 ver=0x010000 就是 BL 刚读过的同一份数据 —— 参数区是两边唯一的通信媒介。',
        apply(S) {
          S.ctx.func = 'w25q16_read_jedec_id()';
          S.frame = { title: 'App 自检', lines: ['W25Q64 JEDEC ID = 0xEF4017  OK', 'param load=0  magic=0xA5A5A5A5', 'flag=0  ver=0x010000'] };
          L(S, 'W25Q64 JEDEC ID = 0xEF4017  OK', 'app');
          L(S, 'param load=0 magic=0xA5A5A5A5 flag=0 ver=0x010000', 'app');
        }
      },
      {
        id: 'a-hash', scene: 'app-init', label: 'SHA-256 / MD5 自检', dur: 2000,
        code: 'freertos_init', hl: [191, 206],
        call: ['MX_FREERTOS_Init()', 'sha256_compute()', 'md5_compute()'],
        mods: ['core'], flows: [],
        g: 'A',
        note: '对字符串 "abc" 跑一遍标准向量。这一步不过就说明哈希实现坏了，OTA 必然失败 —— 提前失败比下完 90KB 再失败划算得多。',
        apply(S) {
          S.ctx.func = 'sha256_compute()';
          L(S, 'SHA256(abc)=OK  MD5(abc)=OK', 'ok');
        }
      },
      {
        id: 'a-espinit', scene: 'app-init', label: 'esp8266_Init()', dur: 2800,
        code: 'esp8266_init', hl: [37, 66],
        call: ['MX_FREERTOS_Init()', 'esp8266_Init()', 'uart_printf(USART3)'],
        mods: ['core', 'usart3', 'esp'], flows: ['uart3-tx', 'wifi-dn'],
        g: 'A',
        note: '六条 AT 指令 + 固定延时：AT+RST=1 → AT+CWMODE=1 → AT+CWJAP → AT+MQTTUSERCFG → AT+MQTTCONN(mqtts.heclouds.com:1883) → AT+MQTTSUB。文档里统计这段约 14~15 秒，是启动耗时的主要部分。',
        apply(S) {
          S.ctx.func = 'esp8266_Init()';
          S.ctx.addr = '0x0801D2D1';
          S.esp.mode = 'mqtt';
          S.frame = { title: 'AT 指令序列（USART3 115200）', lines: [
            'AT+RST=1',
            'AT+CWMODE=1',
            'AT+CWJAP="<ssid>","<pwd>"',
            'AT+MQTTUSERCFG=0,1,"<dev>","<pid>","<token>",0,0,""',
            'AT+MQTTCONN=0,"mqtts.heclouds.com",1883,1',
            'AT+MQTTSUB=0,"$sys/<pid>/<dev>/thing/property/set",0'
          ] };
          L(S, 'AT+RST=1 / AT+CWMODE=1 / AT+CWJAP / AT+MQTTUSERCFG / AT+MQTTCONN / AT+MQTTSUB', 'at');
          S.counters.uart3 += 6;
        }
      },
      {
        id: 'a-task', scene: 'app-init', label: '创建 defaultTask', dur: 2200,
        code: 'freertos_task', hl: [257, 266],
        call: ['osKernelStart()', 'StartDefaultTask()', 'ota_p2_selftest()'],
        mods: ['core', 'rtos'], flows: [],
        g: 'A',
        note: 'StartDefaultTask 里先调 ota_p2_selftest()：它做两件事 —— 回滚自测钩子（默认关闭）和 ota_boot_confirm_if_needed()。此刻 boot_flag=0，不是首启，所以只同步版本号后立即返回，不会等 30 秒。',
        apply(S) {
          S.ctx.func = 'StartDefaultTask()';
          S.ctx.addr = '0x0801AE35';
          S.intf.rtos = 'run';
          L(S, '[RTOS] defaultTask created, stack 1536 words', 'app');
          L(S, 'ota_boot_confirm_if_needed(): flag=0 → 普通启动，返回 0', 'app');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 7：ESP8266 联网 + MQTT（常连态）
   * ================================================================== */
  OTA_SEG.net = function () {
    return [
      {
        id: 'n-mqtt-up', scene: 'net', label: 'MQTT 常连建立', dur: 2400,
        code: 'esp8266_init', hl: [57, 63],
        call: ['esp8266_Init()', 'AT+MQTTCONN', 'AT+MQTTSUB'],
        mods: ['core', 'usart3', 'esp', 'cloud'], flows: ['uart3-tx', 'wifi-dn'],
        g: 'A',
        note: '平时用 AT+MQTT 走 CIPMUX=0 的单连接：模块自己维护 MQTT 会话，MCU 只发 AT 命令。这条连接稍后必须被释放，否则 CIPSTART 会直接报 busy。',
        apply(S) {
          S.esp.mode = 'mqtt';
          S.esp.link = 'mqtts.heclouds.com:1883';
          S.intf.cloud = 'mqtt';
          L(S, '+MQTTCONNECTED  mqtts.heclouds.com:1883', 'at');
          L(S, '+MQTTSUBSCRIBED  $sys/FRfr9m3Ppg/OTA_Test_drive/thing/property/set', 'at');
        }
      },
      {
        id: 'n-uplink', scene: 'net', label: '业务属性上报', dur: 2200,
        code: 'uart_process_hook', hl: [451, 462],
        call: ['StartDefaultTask()', 'uart_process()', 'extract_mqtt_info()'],
        mods: ['core', 'usart3', 'esp', 'cloud'], flows: ['uart3-rx'],
        g: 'A',
        note: 'defaultTask 每 100ms 轮询一次 uart_process()：检查 uart3_key，把 uart3_Recived_buf 里的 +MQTTSUBRECV 文本解析成 msg_id / ident / value。',
        apply(S) {
          S.ctx.func = 'uart_process()';
          S.ctx.addr = '0x08020D49';
          S.frame = { title: '+MQTTSUBRECV（文本）', lines: [
            '+MQTTSUBRECV:0,"$sys/<pid>/<dev>/thing/property/set",60,OK',
            '{"id":"13","version":"1.0","params":{"count":50}}'
          ] };
          L(S, '+MQTTSUBRECV  {"id":"13","params":{"count":50}}', 'at');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 8：OTA 升级任务触发
   * ================================================================== */
  OTA_SEG.trigger = function () {
    return [
      {
        id: 't-update', scene: 'trigger', label: '平台下发 Update=1', dur: 2600,
        code: 'uart_process_hook', hl: [456, 478],
        call: ['uart_process()', 'extract_mqtt_info()', 'ota_task_on_update_ident("Update")'],
        mods: ['core', 'usart3', 'esp', 'cloud'], flows: ['uart3-rx', 'wifi-dn'],
        g: 'A',
        note: '触发点是物模型里一个可写属性 Update。平台下发 1 之后，esp_handle.c 在解析出 ident 后立刻调用 ota_task_on_update_ident(ident) —— 这是整个 OTA 的挂钩点，只传一个字符串，改动最小。',
        apply(S) {
          S.ctx.func = 'ota_task_on_update_ident()';
          S.frame = { title: '属性下发', lines: ['ID=13, IDENT=Update, VALUE=1, NUM=1', '→ ota_task_on_update_ident("Update")'] };
          L(S, 'ID=13, IDENT=Update, VALUE=1, NUM=1', 'at');
          L(S, '[OTA] property "Update" received -> request OTA', 'ota');
        }
      },
      {
        id: 't-request', scene: 'trigger', label: 'ota_task_request(1)', dur: 2200,
        code: 'ota_task_request', hl: [114, 143],
        call: ['ota_task_on_update_ident()', 'ota_task_request(1)', 'xTaskCreate()'],
        mods: ['core', 'rtos'], flows: [],
        g: 'A',
        note: 's_req 只置标志，真正干活在独立任务里。任务在首次触发时才懒创建（避开改 CubeMX 生成的 freertos.c），栈给 1536 字 = 6KB —— 因为这条调用链曾把 512 字的 defaultTask 打爆。',
        apply(S) {
          S.ctx.func = 'ota_task_request()';
          L(S, '[OTA] otaTask created (stack 1536 words)', 'ota');
        }
      },
      {
        id: 't-entry', scene: 'trigger', label: 'ota_task_entry 就绪', dur: 2200,
        code: 'ota_task_entry', hl: [66, 77],
        call: ['ota_task_entry()', 'ota_net_enter()'],
        mods: ['core', 'rtos', 'usart3'], flows: [],
        g: 'A',
        note: '任务循环每 200ms 检查一次 s_req，命中后置 s_busy=1，进入通道交接。从这一刻起 USART3 的归属要换人。',
        apply(S) {
          S.ctx.func = 'ota_task_entry()';
          S.ctx.addr = '0x08020039';
          S.otaActive = true;
          L(S, '[OTA] Update trigger -> start OTA', 'ota');
          L(S, '[OTA] >>> enter OTA net mode', 'ota');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 9：通信通道交接（MQTT → 裸 TCP）
   * ================================================================== */
  OTA_SEG.handover = function () {
    return [
      {
        id: 'h-disc', scene: 'handover', label: 'AT+MQTTDISC 断开 MQTT', dur: 2400,
        code: 'net_enter', hl: [111, 116],
        call: ['ota_net_enter()', 'uart_printf("AT+MQTTDISC=0")', 'HAL_Delay(800)'],
        mods: ['core', 'usart3', 'esp', 'cloud'], flows: ['uart3-tx'],
        g: 'A',
        note: '为什么必须“交接”而不是两套并存：CIPMUX=0 单连接模式下，AT+MQTT 自己占着那条唯一 socket，CIPSTART 会直接失败（busy）。接收通道也不兼容（IDLE-DMA + 512B 文本 vs CIRCULAR + 4096B 二进制）。',
        apply(S) {
          S.ctx.func = 'ota_net_enter()';
          S.ctx.addr = '0x0801F781';
          S.intf.cloud = 'disc';
          L(S, 'AT+MQTTDISC=0  → 释放唯一 socket', 'at');
        }
      },
      {
        id: 'h-abort', scene: 'handover', label: '停止 IDLE-DMA 接收', dur: 2000,
        code: 'net_enter', hl: [117, 119],
        call: ['ota_net_enter()', 'HAL_UART_AbortReceive(&huart3)'],
        mods: ['core', 'usart3', 'dma'], flows: [],
        g: 'A',
        note: '先把旧的接收停掉，再换模式。不 Abort 就改 DMA 配置，会出现两个接收者同时抢同一条流 —— 结果必然是丢字节。',
        apply(S) { S.intf.usart3 = 'abort'; L(S, 'HAL_UART_AbortReceive(USART3)', 'app'); }
      },
      {
        id: 'h-dma', scene: 'handover', label: 'DMA1_Stream1 切 CIRCULAR', dur: 2400,
        code: 'net_enter', hl: [120, 126],
        call: ['ota_net_enter()', 'ota_dma_switch_mode(DMA_CIRCULAR)'],
        mods: ['core', 'dma', 'usart3'], flows: [],
        g: 'A',
        note: '必须 DeInit + Init 才会真正写进寄存器（只改 Init.Mode 无效）。为什么不用单字节中断？注释里写得很直白：flash 编程期间 CPU 取指 stall，单字节接收中断进不去，ORE 会把到达字节覆盖掉，实测丢约 7%。DMA 是硬件搬运，不受影响。',
        apply(S) {
          S.ctx.func = 'ota_dma_switch_mode()';
          S.intf.dma = 'circular';
          L(S, 'DMA1_Stream1: NORMAL → CIRCULAR (DeInit + Init)', 'app');
        }
      },
      {
        id: 'h-init', scene: 'handover', label: 'esp01s_init()', dur: 2600,
        code: 'esp_init', hl: [272, 331],
        call: ['ota_net_enter()', 'esp01s_init()', 'HAL_UART_Receive_DMA(4096)'],
        mods: ['core', 'usart3', 'esp', 'dma'], flows: ['uart3-tx'],
        g: 'A',
        note: '顺序很关键：先 HAL_UART_Receive_DMA(&huart3, s_dma_rx, 4096) 启循环接收，再发 AT。若开关状态异常（HAL_BUSY），先 AbortReceive 再重试一次 —— 注释里记着“重试轮 init 13ms 内秒败”的根因就是这个状态没复位。',
        apply(S) {
          S.ctx.func = 'esp01s_init()';
          S.esp.mode = 'raw-tcp';
          S.intf.usart3 = 'circ-dma';
          S.frame = { title: 'AT 序列（裸 TCP 模式）', lines: ['AT                     → OK', 'ATE0                   → OK（关回显）', 'AT+CIPMUX=0            → OK（单连接）', 'AT+CIPMODE=0           → OK（非透传）', 'HAL_UART_Receive_DMA(4096, CIRCULAR)'] };
          L(S, 'AT → OK；ATE0 → OK；AT+CIPMUX=0 → OK；AT+CIPMODE=0 → OK', 'at');
          S.counters.uart3 += 4;
        }
      },
      {
        id: 'h-join', scene: 'handover', label: 'AT+CWJAP 重新入网', dur: 2400,
        code: 'esp_join_ap', hl: [402, 407],
        call: ['ota_net_enter()', 'esp01s_join_ap(wifi_name, wifi_pass, 15000)'],
        mods: ['core', 'usart3', 'esp', 'cloud'], flows: ['wifi-dn'],
        g: 'A',
        note: 'AT+RST 会把模块重启，MQTT 配置随之丢失，但 CWMODE 存在模块 flash 里不受影响。所以入网之后、以及退出 OTA 模式时都必须重发 MQTT 配置（ota_net_restore → esp8266_Init）。',
        apply(S) {
          S.ctx.func = 'esp01s_join_ap()';
          L(S, 'AT+CWJAP="<ssid>","<pwd>" → OK（15000ms 超时）', 'at');
        }
      },
      {
        id: 'h-ready', scene: 'handover', label: '通道切换完成', dur: 2200,
        code: 'net_enter', hl: [147, 150],
        call: ['ota_net_enter()', 's_ota_mode = 1'],
        mods: ['core', 'usart3', 'esp'], flows: [],
        g: 'A',
        note: 's_ota_mode=1 是唯一裁决依据：uart_handle.c 的两个回调（RxEvent / Error）都会先检查它，OTA 期间绝不碰 USART3。',
        apply(S) {
          S.ctx.func = 'ota_net_enter()';
          S.otaMode = 1;
          S.intf.usart3 = 'circ-dma';
          L(S, '[OTA] OTA net mode READY (USART3 owned by esp01s)', 'ok');
        }
      }
    ];
  };

  /* ==================================================================
   * 场景 10：上报版本 + 查询任务
   * ================================================================== */
  OTA_SEG.check = function () {
    return [
      {
        id: 'c-run', scene: 'check', label: 'ota_run_once() 入口', dur: 2400,
        code: 'run_once_head', hl: [1141, 1151],
        call: ['ota_task_entry()', 'ota_run_once()'],
        mods: ['core', 'param'], flows: [],
        g: 'A',
        note: '进入引擎后先做两件“历史遗留”的事：如果恢复区还没初始化就初始化（纯本地操作），然后补报上一次升级的 201。这两步与本次升级是否成功无关，属于收尾与兜底。',
        apply(S) {
          S.ctx.func = 'ota_run_once()';
          S.ctx.addr = '0x0801FB69';
          S.vars.state = 'OTA_ST_IDLE';
          S.vars.ret = '…';
          L(S, '[OTA] ota_run_once() 进入', 'ota');
        }
      },
      {
        id: 'c-recovery', scene: 'check', label: '首次固化出厂镜像', dur: 2600,
        code: 'recovery_init', hl: [866, 892],
        call: ['ota_run_once()', 'ota_init_recovery_if_empty()'],
        mods: ['core', 'spi2', 'w25q', 'int-flash'], flows: ['spi-w', 'flash-int'],
        g: 'A',
        note: '只在 recovery_len == 0 时执行一次：读恢复区头部 16 字节判断是否为空（保守起见有内容就不覆盖），然后擦 15 个 64KB 块，把当前 A 槽逐 1KB 拷进 RECOVERY 区，边拷边算 SHA-256，最后写参数区。',
        apply(S) {
          S.ctx.func = 'ota_init_recovery_if_empty()';
          S.ext.recovery.mode = 'write';
          S.ext.recovery.frac = 0;
          L(S, '[OTA] init recovery (factory) image: 94820 bytes...', 'ota');
          L(S, '[OTA] recovery init done', 'ok');
        },
        live(S, p) {
          S.ext.recovery.frac = Math.min(1, p * 1.05);
          if (p >= 0.98) S.ext.recovery.mode = 'valid';
        }
      },
      {
        id: 'c-201', scene: 'check', label: '补报上次的 201', dur: 2000,
        code: 'pending201', hl: [1002, 1025],
        call: ['ota_run_once()', 'ota_report_pending_201()', 'ota_api_report_status(tid,201)'],
        mods: ['core', 'usart3', 'esp', 'cloud'], flows: ['uart3-tx', 'wifi-dn'],
        g: 'A',
        note: '只有在 ota_tid != 0 且 param.version == 当前固件版本号时才补报 —— 否则会把“上次的结果”错报到这一次的任务上。这次 ota_tid=0，直接返回 1，不发请求。',
        apply(S) {
          S.ctx.func = 'ota_report_pending_201()';
          S.vars.ota_tid = 0;
          L(S, '[OTA] ota_tid = 0，无需补报 201', 'ota');
        }
      },
      {
        id: 'c-version', scene: 'check', label: 'POST /version 上报版本', dur: 2400,
        code: 'api_version', hl: [238, 263],
        call: ['ota_run_once()', 'ota_api_report_version()', 'http_client_request()'],
        mods: ['core', 'esp', 'cloud', 'usart3'], flows: ['uart3-tx', 'wifi-dn'],
        g: 'A',
        note: 'body 是 {"s_version":"1.0.0","f_version":"1.0.0"}。设备报的版本必须严格小于平台升级包的版本，check 才会返回任务。',
        apply(S) {
          S.ctx.func = 'ota_api_report_version()';
          S.vars.state = 'OTA_ST_CHECKING';
          S.http = { method: 'POST', path: '/fuse-ota/FRfr9m3Ppg/OTA_Test_drive/version', body: '{"s_version":"1.0.0","f_version":"1.0.0"}' };
          L(S, '[HTTP] POST /fuse-ota/FRfr9m3Ppg/OTA_Test_drive/version', 'http');
        }
      },
      {
        id: 'c-http', scene: 'check', label: 'HTTP 建连与逐行解析', dur: 2800,
        code: 'http_req_head', hl: [154, 245],
        call: ['http_client_request()', 'esp01s_tcp_connect()', 'esp01s_send()', 'http_read_line()'],
        mods: ['core', 'esp', 'cloud', 'usart3'], flows: ['uart3-tx', 'uart3-rx', 'wifi-dn'],
        g: 'A',
        note: '每次请求都新建一条 TCP（Connection: close）。CIPSTART 的期望串用 "OK" 而不是 "CONNECT" —— 因为 strstr("CONNECT FAIL","CONNECT") 会命中，把失败误判成成功。状态行最多跳过 8 行杂讯。',
        apply(S) {
          S.ctx.func = 'http_client_request_once()';
          S.ctx.addr = '0x0801D881';
          S.frame = { title: 'HTTP 请求（CIPSEND）', lines: [
            'POST /fuse-ota/…/version HTTP/1.1',
            'Host: iot-api.heclouds.com',
            'Content-Length: 39',
            'Authorization: version=2018-10-31&res=…',
            'Connection: close'
          ] };
          L(S, '[HTTP] CIPSTART iot-api.heclouds.com:80 … OK', 'http');
          L(S, '[HTTP] CIPSEND 351 bytes … SEND OK', 'http');
        }
      },
      {
        id: 'c-check', scene: 'check', label: 'GET /check 查询任务', dur: 2600,
        code: 'api_check', hl: [276, 321],
        call: ['ota_run_once()', 'ota_api_check_task()', 'json_get_num()', 'json_get_str()'],
        mods: ['core', 'esp', 'cloud', 'usart3'], flows: ['uart3-tx', 'wifi-dn', 'uart3-rx'],
        g: 'A',
        note: 'type 参数必须是 1。实测：type=2 → {"code":12010,"msg":"task type error"}，type=3 → 12004，不传 → 12001。这是整份移植里唯一的“平台参数坑”。',
        apply(S) {
          S.ctx.func = 'ota_api_check_task()';
          S.ctx.addr = '0x0801E535';
          S.frame = { title: 'check 响应 JSON', lines: [
            '{"code":0,"msg":"succ","data":{',
            '  "target":"1.0.1",',
            '  "tid":1529128,',
            '  "size":94824,',
            '  "md5":"41e52aea…",',
            '  "status":1, "type":1 }}'
          ] };
          L(S, '[OTA] check resp: code=0 tid=1529128 size=94824 type=1 target=1.0.1', 'http');
        }
      },
      {
        id: 'c-json', scene: 'check', label: '解析字段并填任务结构', dur: 2200,
        code: 'api_check', hl: [296, 318],
        call: ['ota_api_check_task()', 'json_get_num("tid"/"size"/"type")', 'json_get_str("target"/"md5")'],
        mods: ['core'], flows: [],
        g: 'A',
        note: '解析器是“极简 JSON”：strstr 找 "key"，跳过空白与冒号，再按类型取值。够用即可 —— 平台返回的字段顺序固定。业务 code != 0 时按“无任务”处理，避免把平台错误误报成升级失败。',
        apply(S) {
          S.ctx.func = 'ota_api_check_task()';
          S.vars.dl_tid = 1529128;
          S.vars.dl_total = 94824;
          S.vars.md5 = '41e52aea…';
          S.task = { tid: 1529128, size: 94824, type: 1, target: '1.0.1' };
          L(S, '[OTA] task found: tid=1529128 size=94824 type=1 target=1.0.1', 'ok');
        }
      },
      {
        id: 'c-reject', scene: 'check', label: '拒绝差分包 / 降级', dur: 2400,
        code: 'run_once_reject', hl: [1185, 1215],
        call: ['ota_run_once()', 'version_parse()', 'ota_api_report_status(206)'],
        mods: ['core'], flows: [],
        g: 'A',
        note: '两条闸门：type != 1 直接拒绝（上报 206）；target 版本 <= 参数区版本时，相等则补报 201 后返回 1（已是最新），更小则上报 206 并返回 -3（拒绝降级）。本次 1.0.1 > 1.0.0，放行。',
        apply(S) {
          S.ctx.func = 'ota_run_once()';
          S.vars.state = 'OTA_ST_DOWNLOADING';
          L(S, 'type=1 ✓   target 1.0.1 > current 1.0.0 ✓  → 允许升级', 'ok');
        }
      }
    ];
  };

})();
