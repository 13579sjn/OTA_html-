/* 自动生成，请勿手改 —— 由 tools/gen-code.js 从真实工程读取
 * 生成时间：2026-10-28T11:21:43.768Z
 * 内容：源码片段（项目 / 相对路径 / 函数 / 起止行 / 逐行原文）
 */
window.OTA_CODE = {
 "generatedAt": "2026-10-28T11:21:43.769Z",
 "root": "D:\\ESP32_IDF_project_\\html_OTA",
 "snippets": {
  "startup_vectors": {
   "id": "startup_vectors",
   "project": "HAL_F429IGT6_bootloard",
   "file": "MDK-ARM/startup_stm32f429xx.s",
   "path": "HAL_F429IGT6_bootloard/MDK-ARM/startup_stm32f429xx.s",
   "func": "__Vectors",
   "from": 56,
   "to": 62,
   "note": "Reset_Handler 向量表：第 0 项为初始 MSP，第 1 项为复位入口",
   "grade": "A",
   "lines": [
    [
     56,
     "                EXPORT  __Vectors"
    ],
    [
     57,
     "                EXPORT  __Vectors_End"
    ],
    [
     58,
     "                EXPORT  __Vectors_Size"
    ],
    [
     59,
     ""
    ],
    [
     60,
     "__Vectors       DCD     __initial_sp               ; Top of Stack"
    ],
    [
     61,
     "                DCD     Reset_Handler              ; Reset Handler"
    ],
    [
     62,
     "                DCD     NMI_Handler                ; NMI Handler"
    ]
   ]
  },
  "startup_reset": {
   "id": "startup_reset",
   "project": "HAL_F429IGT6_bootloard",
   "file": "MDK-ARM/startup_stm32f429xx.s",
   "path": "HAL_F429IGT6_bootloard/MDK-ARM/startup_stm32f429xx.s",
   "func": "Reset_Handler",
   "from": 177,
   "to": 188,
   "note": "Reset_Handler：调用 SystemInit 后进入 __main",
   "grade": "A",
   "lines": [
    [
     177,
     "Reset_Handler    PROC"
    ],
    [
     178,
     "                 EXPORT  Reset_Handler             [WEAK]"
    ],
    [
     179,
     "        IMPORT  SystemInit"
    ],
    [
     180,
     "        IMPORT  __main"
    ],
    [
     181,
     ""
    ],
    [
     182,
     "                 LDR     R0, =SystemInit"
    ],
    [
     183,
     "                 BLX     R0"
    ],
    [
     184,
     "                 LDR     R0, =__main"
    ],
    [
     185,
     "                 BX      R0"
    ],
    [
     186,
     "                 ENDP"
    ],
    [
     187,
     ""
    ],
    [
     188,
     "; Dummy Exception Handlers (infinite loops which can be modified)"
    ]
   ]
  },
  "boot_main": {
   "id": "boot_main",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Core/Src/main.c",
   "path": "HAL_F429IGT6_bootloard/Core/Src/main.c",
   "func": "main",
   "from": 69,
   "to": 113,
   "note": "BootLoader 的 main()：HAL_Init → SystemClock_Config → 外设初始化 → boot_run()",
   "grade": "A",
   "lines": [
    [
     69,
     "int main(void)"
    ],
    [
     70,
     "{"
    ],
    [
     71,
     ""
    ],
    [
     72,
     "  /* USER CODE BEGIN 1 */"
    ],
    [
     73,
     ""
    ],
    [
     74,
     "  /* USER CODE END 1 */"
    ],
    [
     75,
     ""
    ],
    [
     76,
     "  /* MCU Configuration--------------------------------------------------------*/"
    ],
    [
     77,
     ""
    ],
    [
     78,
     "  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */"
    ],
    [
     79,
     "  HAL_Init();"
    ],
    [
     80,
     ""
    ],
    [
     81,
     "  /* USER CODE BEGIN Init */"
    ],
    [
     82,
     ""
    ],
    [
     83,
     "  /* USER CODE END Init */"
    ],
    [
     84,
     ""
    ],
    [
     85,
     "  /* Configure the system clock */"
    ],
    [
     86,
     "  SystemClock_Config();"
    ],
    [
     87,
     ""
    ],
    [
     88,
     "  /* USER CODE BEGIN SysInit */"
    ],
    [
     89,
     ""
    ],
    [
     90,
     "  /* USER CODE END SysInit */"
    ],
    [
     91,
     ""
    ],
    [
     92,
     "  /* Initialize all configured peripherals */"
    ],
    [
     93,
     "  MX_GPIO_Init();"
    ],
    [
     94,
     "  MX_DMA_Init();"
    ],
    [
     95,
     "  MX_USART1_UART_Init();"
    ],
    [
     96,
     "  MX_SPI2_Init();"
    ],
    [
     97,
     "  /* USER CODE BEGIN 2 */"
    ],
    [
     98,
     ""
    ],
    [
     99,
     "  /* OTA BootLoader：按参数区 boot_flag 决定 升级/回滚/恢复出厂，然后跳转 App。"
    ],
    [
     100,
     "     正常情况不返回（跳转后运行 App）。 */"
    ],
    [
     101,
     "  boot_run();"
    ],
    [
     102,
     ""
    ],
    [
     103,
     "  /* USER CODE END 2 */"
    ],
    [
     104,
     ""
    ],
    [
     105,
     "  /* Infinite loop */"
    ],
    [
     106,
     "  /* USER CODE BEGIN WHILE */"
    ],
    [
     107,
     "  while (1)"
    ],
    [
     108,
     "  {"
    ],
    [
     109,
     "    /* USER CODE END WHILE */"
    ],
    [
     110,
     ""
    ],
    [
     111,
     "    /* USER CODE BEGIN 3 */"
    ],
    [
     112,
     "  }"
    ],
    [
     113,
     "  /* USER CODE END 3 */"
    ]
   ]
  },
  "boot_clock": {
   "id": "boot_clock",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Core/Src/main.c",
   "path": "HAL_F429IGT6_bootloard/Core/Src/main.c",
   "func": "SystemClock_Config",
   "from": 120,
   "to": 167,
   "note": "BL 时钟树：HSI → PLL(180MHz)，与 App 的 HSE 源不同",
   "grade": "A",
   "lines": [
    [
     120,
     "void SystemClock_Config(void)"
    ],
    [
     121,
     "{"
    ],
    [
     122,
     "  RCC_OscInitTypeDef RCC_OscInitStruct = {0};"
    ],
    [
     123,
     "  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};"
    ],
    [
     124,
     ""
    ],
    [
     125,
     "  /** Configure the main internal regulator output voltage"
    ],
    [
     126,
     "  */"
    ],
    [
     127,
     "  __HAL_RCC_PWR_CLK_ENABLE();"
    ],
    [
     128,
     "  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);"
    ],
    [
     129,
     ""
    ],
    [
     130,
     "  /** Initializes the RCC Oscillators according to the specified parameters"
    ],
    [
     131,
     "  * in the RCC_OscInitTypeDef structure."
    ],
    [
     132,
     "  */"
    ],
    [
     133,
     "  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;"
    ],
    [
     134,
     "  RCC_OscInitStruct.HSIState = RCC_HSI_ON;"
    ],
    [
     135,
     "  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;"
    ],
    [
     136,
     "  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;"
    ],
    [
     137,
     "  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;"
    ],
    [
     138,
     "  RCC_OscInitStruct.PLL.PLLM = 8;"
    ],
    [
     139,
     "  RCC_OscInitStruct.PLL.PLLN = 180;"
    ],
    [
     140,
     "  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;"
    ],
    [
     141,
     "  RCC_OscInitStruct.PLL.PLLQ = 4;"
    ],
    [
     142,
     "  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)"
    ],
    [
     143,
     "  {"
    ],
    [
     144,
     "    Error_Handler();"
    ],
    [
     145,
     "  }"
    ],
    [
     146,
     ""
    ],
    [
     147,
     "  /** Activate the Over-Drive mode"
    ],
    [
     148,
     "  */"
    ],
    [
     149,
     "  if (HAL_PWREx_EnableOverDrive() != HAL_OK)"
    ],
    [
     150,
     "  {"
    ],
    [
     151,
     "    Error_Handler();"
    ],
    [
     152,
     "  }"
    ],
    [
     153,
     ""
    ],
    [
     154,
     "  /** Initializes the CPU, AHB and APB buses clocks"
    ],
    [
     155,
     "  */"
    ],
    [
     156,
     "  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK"
    ],
    [
     157,
     "                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;"
    ],
    [
     158,
     "  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;"
    ],
    [
     159,
     "  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;"
    ],
    [
     160,
     "  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;"
    ],
    [
     161,
     "  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;"
    ],
    [
     162,
     ""
    ],
    [
     163,
     "  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)"
    ],
    [
     164,
     "  {"
    ],
    [
     165,
     "    Error_Handler();"
    ],
    [
     166,
     "  }"
    ],
    [
     167,
     "}"
    ]
   ]
  },
  "boot_ledskip": {
   "id": "boot_ledskip",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Core/Src/main.c",
   "path": "HAL_F429IGT6_bootloard/Core/Src/main.c",
   "func": "(非函数体)",
   "from": 92,
   "to": 101,
   "note": "MX_GPIO / MX_DMA / MX_USART1 / MX_SPI2 的顺序，之后才进 boot_run()",
   "grade": "A",
   "lines": [
    [
     92,
     "  /* Initialize all configured peripherals */"
    ],
    [
     93,
     "  MX_GPIO_Init();"
    ],
    [
     94,
     "  MX_DMA_Init();"
    ],
    [
     95,
     "  MX_USART1_UART_Init();"
    ],
    [
     96,
     "  MX_SPI2_Init();"
    ],
    [
     97,
     "  /* USER CODE BEGIN 2 */"
    ],
    [
     98,
     ""
    ],
    [
     99,
     "  /* OTA BootLoader：按参数区 boot_flag 决定 升级/回滚/恢复出厂，然后跳转 App。"
    ],
    [
     100,
     "     正常情况不返回（跳转后运行 App）。 */"
    ],
    [
     101,
     "  boot_run();"
    ]
   ]
  },
  "boot_run_head": {
   "id": "boot_run_head",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "boot_run",
   "from": 272,
   "to": 300,
   "note": "boot_run() 入口：端口优先级修正 + banner + 看门狗",
   "grade": "A",
   "lines": [
    [
     272,
     "void boot_run(void)"
    ],
    [
     273,
     "{"
    ],
    [
     274,
     "    ota_param_t param;"
    ],
    [
     275,
     "    uint32_t flash_id;"
    ],
    [
     276,
     ""
    ],
    [
     277,
     "    boot_port_init();    // USART1/DMA2_Stream2/7 的 NVIC 优先级 0 → 5"
    ],
    [
     278,
     ""
    ],
    [
     279,
     "    boot_log(\"\\r\\n\");"
    ],
    [
     280,
     "    boot_log(\"==============================================\\r\\n\");"
    ],
    [
     281,
     "    boot_log(\"  STM32F429IGT6 OTA BootLoader v1.0\\r\\n\");"
    ],
    [
     282,
     "    boot_log(\"  build %s %s\\r\\n\", __DATE__, __TIME__);"
    ],
    [
     283,
     "    boot_log(\"  BL   : 0x%08lX + %luKB\\r\\n\","
    ],
    [
     284,
     "             (unsigned long)OTA_BOOTLOADER_ADDR,"
    ],
    [
     285,
     "             (unsigned long)(OTA_BOOTLOADER_SIZE / 1024UL));"
    ],
    [
     286,
     "    boot_log(\"  PARAM: 0x%08lX + %luKB\\r\\n\","
    ],
    [
     287,
     "             (unsigned long)OTA_PARAM_AREA_ADDR,"
    ],
    [
     288,
     "             (unsigned long)(OTA_PARAM_AREA_SIZE / 1024UL));"
    ],
    [
     289,
     "    boot_log(\"  APP A: 0x%08lX + %luKB\\r\\n\","
    ],
    [
     290,
     "             (unsigned long)OTA_APP_A_ADDR,"
    ],
    [
     291,
     "             (unsigned long)(OTA_APP_SIZE / 1024UL));"
    ],
    [
     292,
     "    boot_log(\"==============================================\\r\\n\");"
    ],
    [
     293,
     ""
    ],
    [
     294,
     "    /* ---- 1. 看门狗（BOOT_WDG_ENABLE=0 时为空操作） ---------------------- */"
    ],
    [
     295,
     "    boot_wdg_init();// BOOT_WDG_ENABLE=0 时是空操作"
    ],
    [
     296,
     "    if (boot_wdg_is_enabled() != 0) "
    ],
    [
     297,
     "    {"
    ],
    [
     298,
     "        boot_log(\"[BL] IWDG enabled (~8.19s)\\r\\n\");"
    ],
    [
     299,
     "    }"
    ],
    [
     300,
     ""
    ]
   ]
  },
  "boot_run_ext": {
   "id": "boot_run_ext",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "(非函数体)",
   "from": 301,
   "to": 310,
   "note": "片外 Flash 初始化与 JEDEC ID 读取",
   "grade": "A",
   "lines": [
    [
     301,
     "    /* ---- 2. 片外 Flash 初始化 + 读 ID ---------------------------------- */"
    ],
    [
     302,
     "    if (boot_ext_init() != 0)   // W25Q64_InitConfig()"
    ],
    [
     303,
     "    {"
    ],
    [
     304,
     "        boot_log(\"[BL] ext flash init FAILED (SPI2 / CS-PB12)\\r\\n\");"
    ],
    [
     305,
     "    }"
    ],
    [
     306,
     ""
    ],
    [
     307,
     "    flash_id = boot_ext_jedec_id();  // 0xEF4017 = W25Q64"
    ],
    [
     308,
     "    boot_log(\"[BL] ext flash JEDEC ID: 0x%06lX (%s)\\r\\n\","
    ],
    [
     309,
     "             (unsigned long)flash_id, boot_id_name(flash_id));"
    ],
    [
     310,
     ""
    ]
   ]
  },
  "boot_run_param": {
   "id": "boot_run_param",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "(非函数体)",
   "from": 311,
   "to": 329,
   "note": "读参数区；无效则重建默认值并保存",
   "grade": "A",
   "lines": [
    [
     311,
     "    /* ---- 3. 读参数区 ---------------------------------------------------- */"
    ],
    [
     312,
     "    if (param_area_load(&param) != 0)"
    ],
    [
     313,
     "    {// 失败 → param_area_defaults() + param_area_save() 重建"
    ],
    [
     314,
     "        boot_log(\"[BL] param invalid, rebuild default\\r\\n\");"
    ],
    [
     315,
     "        param_area_defaults(&param);"
    ],
    [
     316,
     ""
    ],
    [
     317,
     "        if (param_area_save(&param) != 0)"
    ],
    [
     318,
     "        {"
    ],
    [
     319,
     "            boot_log(\"[BL] param save FAILED!\\r\\n\");"
    ],
    [
     320,
     "        }"
    ],
    [
     321,
     "    }"
    ],
    [
     322,
     ""
    ],
    [
     323,
     "    boot_log(\"[BL] flag=%lu count=%lu ver=0x%06lX img_len=%lu bk_st=%u\\r\\n\","
    ],
    [
     324,
     "             (unsigned long)param.boot_flag,"
    ],
    [
     325,
     "             (unsigned long)param.boot_count,"
    ],
    [
     326,
     "             (unsigned long)param.version,"
    ],
    [
     327,
     "             (unsigned long)param.image_len,"
    ],
    [
     328,
     "             (unsigned int)param.backup_status);"
    ],
    [
     329,
     ""
    ]
   ]
  },
  "boot_run_branch": {
   "id": "boot_run_branch",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "(非函数体)",
   "from": 330,
   "to": 332,
   "note": "按 boot_flag 四态分支（ROLLBACK / RECOVERY / TRY_NEW / NORMAL）",
   "grade": "A",
   "lines": [
    [
     330,
     "    /* ---- 4. 按 boot_flag 分支 ------------------------------------------ */"
    ],
    [
     331,
     "    if (param.boot_flag == OTA_BOOT_FLAG_ROLLBACK)"
    ],
    [
     332,
     "    {"
    ]
   ]
  },
  "boot_run_rollback": {
   "id": "boot_run_rollback",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "(非函数体)",
   "from": 331,
   "to": 368,
   "note": "ROLLBACK 分支：校验备份区 → 覆盖 A 槽 → 清标志",
   "grade": "A",
   "lines": [
    [
     331,
     "    if (param.boot_flag == OTA_BOOT_FLAG_ROLLBACK)"
    ],
    [
     332,
     "    {"
    ],
    [
     333,
     "        boot_log(\"[BL] >>> ROLLBACK\\r\\n\");"
    ],
    [
     334,
     ""
    ],
    [
     335,
     "        if (boot_do_rollback(&param) == 0)"
    ],
    [
     336,
     "        {"
    ],
    [
     337,
     "            boot_log(\"[BL] rollback done, ver=0x%06lX\\r\\n\","
    ],
    [
     338,
     "                     (unsigned long)param.backup_version);"
    ],
    [
     339,
     ""
    ],
    [
     340,
     "            /* 回滚成功后，当前版本号同步为备份版本（备份版本号为 0 时不覆盖，"
    ],
    [
     341,
     "               否则 App 的\"防降级\"比较会退化成\"永远允许\") */"
    ],
    [
     342,
     "            if (param.backup_version != 0UL)"
    ],
    [
     343,
     "            {"
    ],
    [
     344,
     "                param.version = param.backup_version;"
    ],
    [
     345,
     "            }"
    ],
    [
     346,
     "        }"
    ],
    [
     347,
     "        else"
    ],
    [
     348,
     "        {"
    ],
    [
     349,
     "            boot_log(\"[BL] rollback FAILED, try recovery\\r\\n\");"
    ],
    [
     350,
     ""
    ],
    [
     351,
     "            if (boot_do_recovery(&param) != 0)"
    ],
    [
     352,
     "            {"
    ],
    [
     353,
     "                boot_log(\"[BL] recovery FAILED, system halted!\\r\\n\");"
    ],
    [
     354,
     "                boot_halt();"
    ],
    [
     355,
     "            }"
    ],
    [
     356,
     "        }"
    ],
    [
     357,
     ""
    ],
    [
     358,
     "        param.boot_flag      = OTA_BOOT_FLAG_NORMAL;"
    ],
    [
     359,
     "        param.boot_count     = 0UL;"
    ],
    [
     360,
     "        param.backup_status  = OTA_BACKUP_EMPTY;"
    ],
    [
     361,
     "        param.backup_len     = 0UL;"
    ],
    [
     362,
     "        param.backup_version = 0UL;"
    ],
    [
     363,
     ""
    ],
    [
     364,
     "        if (param_area_save(&param) != 0)"
    ],
    [
     365,
     "        {"
    ],
    [
     366,
     "            boot_log(\"[BL] param save FAILED!\\r\\n\");"
    ],
    [
     367,
     "        }"
    ],
    [
     368,
     "    }"
    ]
   ]
  },
  "boot_run_recovery": {
   "id": "boot_run_recovery",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "(非函数体)",
   "from": 369,
   "to": 392,
   "note": "RECOVERY 分支：用出厂镜像覆盖 A 槽",
   "grade": "A",
   "lines": [
    [
     369,
     "    else if (param.boot_flag == OTA_BOOT_FLAG_RECOVERY)"
    ],
    [
     370,
     "    {"
    ],
    [
     371,
     "        boot_log(\"[BL] >>> RECOVERY (factory image)\\r\\n\");"
    ],
    [
     372,
     ""
    ],
    [
     373,
     "        if (boot_do_recovery(&param) == 0)"
    ],
    [
     374,
     "        {"
    ],
    [
     375,
     "            boot_log(\"[BL] recovery done\\r\\n\");"
    ],
    [
     376,
     "        }"
    ],
    [
     377,
     "        else"
    ],
    [
     378,
     "        {"
    ],
    [
     379,
     "            boot_log(\"[BL] recovery FAILED\\r\\n\");"
    ],
    [
     380,
     "        }"
    ],
    [
     381,
     ""
    ],
    [
     382,
     "        param.boot_flag      = OTA_BOOT_FLAG_NORMAL;"
    ],
    [
     383,
     "        param.boot_count     = 0UL;"
    ],
    [
     384,
     "        param.backup_status  = OTA_BACKUP_EMPTY;"
    ],
    [
     385,
     "        param.backup_len     = 0UL;"
    ],
    [
     386,
     "        param.backup_version = 0UL;"
    ],
    [
     387,
     ""
    ],
    [
     388,
     "        if (param_area_save(&param) != 0)"
    ],
    [
     389,
     "        {"
    ],
    [
     390,
     "            boot_log(\"[BL] param save FAILED!\\r\\n\");"
    ],
    [
     391,
     "        }"
    ],
    [
     392,
     "    }"
    ]
   ]
  },
  "boot_run_trynew": {
   "id": "boot_run_trynew",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "(非函数体)",
   "from": 393,
   "to": 447,
   "note": "TRY_NEW 分支：先校验暂存区 SHA-256，通过才擦 A 槽；boot_count 累加与自动转回滚",
   "grade": "A",
   "lines": [
    [
     393,
     "    else if (param.boot_flag == OTA_BOOT_FLAG_TRY_NEW)"
    ],
    [
     394,
     "    {"
    ],
    [
     395,
     "        boot_log(\"[BL] >>> TRY_NEW\\r\\n\");"
    ],
    [
     396,
     "        boot_log(\"[BL] verify staging SHA-256 (len=%lu)...\\r\\n\","
    ],
    [
     397,
     "                 (unsigned long)param.image_len);"
    ],
    [
     398,
     ""
    ],
    [
     399,
     "        if (boot_verify_ext_image(EXT_STAGING_ADDR, param.image_len, param.image_sha) == 0)"
    ],
    [
     400,
     "        {"
    ],
    [
     401,
     "            boot_log(\"[BL] staging OK, copy staging -> A\\r\\n\");"
    ],
    [
     402,
     ""
    ],
    [
     403,
     "            if (boot_copy_ext_to_run(EXT_STAGING_ADDR, param.image_len) == 0)"
    ],
    [
     404,
     "            {"
    ],
    [
     405,
     "                /* 拷贝成功：启动计数 +1，达到阈值则改回滚 */"
    ],
    [
     406,
     "                param.boot_count++;"
    ],
    [
     407,
     ""
    ],
    [
     408,
     "                if (param.boot_count >= OTA_BOOT_MAX_TRIES)"
    ],
    [
     409,
     "                {"
    ],
    [
     410,
     "                    boot_log(\"[BL] count=%lu >= %lu, switch to ROLLBACK\\r\\n\","
    ],
    [
     411,
     "                             (unsigned long)param.boot_count,"
    ],
    [
     412,
     "                             (unsigned long)OTA_BOOT_MAX_TRIES);"
    ],
    [
     413,
     "                    param.boot_flag  = OTA_BOOT_FLAG_ROLLBACK;"
    ],
    [
     414,
     "                    param.boot_count = 0UL;"
    ],
    [
     415,
     "                }"
    ],
    [
     416,
     "            }"
    ],
    [
     417,
     "            else"
    ],
    [
     418,
     "            {"
    ],
    [
     419,
     "                /* 拷贝被打断（掉电等）：下次上电重试 */"
    ],
    [
     420,
     "                boot_log(\"[BL] copy FAILED, retry next boot\\r\\n\");"
    ],
    [
     421,
     "                param.boot_count++;"
    ],
    [
     422,
     ""
    ],
    [
     423,
     "                if (param.boot_count >= OTA_BOOT_MAX_TRIES)"
    ],
    [
     424,
     "                {"
    ],
    [
     425,
     "                    param.boot_flag  = OTA_BOOT_FLAG_ROLLBACK;"
    ],
    [
     426,
     "                    param.boot_count = 0UL;"
    ],
    [
     427,
     "                }"
    ],
    [
     428,
     "            }"
    ],
    [
     429,
     ""
    ],
    [
     430,
     "            if (param_area_save(&param) != 0)"
    ],
    [
     431,
     "            {"
    ],
    [
     432,
     "                boot_log(\"[BL] param save FAILED!\\r\\n\");"
    ],
    [
     433,
     "            }"
    ],
    [
     434,
     "        }"
    ],
    [
     435,
     "        else"
    ],
    [
     436,
     "        {"
    ],
    [
     437,
     "            /* 暂存区镜像不可信：直接回滚，绝不拿它去擦 A 槽 */"
    ],
    [
     438,
     "            boot_log(\"[BL] staging INVALID -> switch to ROLLBACK\\r\\n\");"
    ],
    [
     439,
     "            param.boot_flag  = OTA_BOOT_FLAG_ROLLBACK;"
    ],
    [
     440,
     "            param.boot_count = 0UL;"
    ],
    [
     441,
     ""
    ],
    [
     442,
     "            if (param_area_save(&param) != 0)"
    ],
    [
     443,
     "            {"
    ],
    [
     444,
     "                boot_log(\"[BL] param save FAILED!\\r\\n\");"
    ],
    [
     445,
     "            }"
    ],
    [
     446,
     "        }"
    ],
    [
     447,
     "    }"
    ]
   ]
  },
  "boot_run_normal": {
   "id": "boot_run_normal",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "(非函数体)",
   "from": 448,
   "to": 460,
   "note": "NORMAL 分支：清零失败计数",
   "grade": "A",
   "lines": [
    [
     448,
     "    else"
    ],
    [
     449,
     "    {"
    ],
    [
     450,
     "        /* NORMAL：清零失败计数 */"
    ],
    [
     451,
     "        if (param.boot_count != 0UL)"
    ],
    [
     452,
     "        {"
    ],
    [
     453,
     "            param.boot_count = 0UL;"
    ],
    [
     454,
     ""
    ],
    [
     455,
     "            if (param_area_save(&param) != 0)"
    ],
    [
     456,
     "            {"
    ],
    [
     457,
     "                boot_log(\"[BL] param save FAILED!\\r\\n\");"
    ],
    [
     458,
     "            }"
    ],
    [
     459,
     "        }"
    ],
    [
     460,
     "    }"
    ]
   ]
  },
  "boot_run_final": {
   "id": "boot_run_final",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "(非函数体)",
   "from": 462,
   "to": 491,
   "note": "校验 A 槽有效性 → 无效则恢复 → 最后跳转",
   "grade": "A",
   "lines": [
    [
     462,
     "    /* ---- 5. 校验 A 槽，无效则尝试恢复 ---------------------------------- */"
    ],
    [
     463,
     "    boot_log(\"[BL] target app @0x%08lX\\r\\n\", (unsigned long)OTA_APP_A_ADDR);"
    ],
    [
     464,
     "    boot_dump_vectors(OTA_APP_A_ADDR);"
    ],
    [
     465,
     ""
    ],
    [
     466,
     "    if (app_jump_validate(OTA_APP_A_ADDR) != 0)"
    ],
    [
     467,
     "    {"
    ],
    [
     468,
     "        boot_log(\"[BL] app A INVALID, try recovery\\r\\n\");"
    ],
    [
     469,
     ""
    ],
    [
     470,
     "        if (boot_do_recovery(&param) != 0)"
    ],
    [
     471,
     "        {"
    ],
    [
     472,
     "            boot_log(\"[BL] recovery FAILED, system halted!\\r\\n\");"
    ],
    [
     473,
     "            boot_halt();"
    ],
    [
     474,
     "        }"
    ],
    [
     475,
     ""
    ],
    [
     476,
     "        /* 恢复完成后重新校验一次，仍无效就只能挂死 */"
    ],
    [
     477,
     "        if (app_jump_validate(OTA_APP_A_ADDR) != 0)"
    ],
    [
     478,
     "        {"
    ],
    [
     479,
     "            boot_log(\"[BL] still invalid after recovery, system halted!\\r\\n\");"
    ],
    [
     480,
     "            boot_halt();"
    ],
    [
     481,
     "        }"
    ],
    [
     482,
     "    }"
    ],
    [
     483,
     ""
    ],
    [
     484,
     "    /* ---- 6. 跳转 -------------------------------------------------------- */"
    ],
    [
     485,
     "    boot_log(\"[BL] jump to app @0x%08lX\\r\\n\", (unsigned long)OTA_APP_A_ADDR);"
    ],
    [
     486,
     ""
    ],
    [
     487,
     "    app_jump_execute(OTA_APP_A_ADDR);"
    ],
    [
     488,
     ""
    ],
    [
     489,
     "    /* 不会到这里 */"
    ],
    [
     490,
     "    boot_halt();"
    ],
    [
     491,
     "}"
    ]
   ]
  },
  "boot_halt": {
   "id": "boot_halt",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "boot_halt",
   "from": 62,
   "to": 68,
   "note": "不可恢复错误：挂死并持续喂狗（不无限重启）",
   "grade": "A",
   "lines": [
    [
     62,
     "static void boot_halt(void)"
    ],
    [
     63,
     "{"
    ],
    [
     64,
     "    for (;;)"
    ],
    [
     65,
     "    {"
    ],
    [
     66,
     "        boot_wdg_feed();"
    ],
    [
     67,
     "    }"
    ],
    [
     68,
     "}"
    ]
   ]
  },
  "boot_verify_ext": {
   "id": "boot_verify_ext",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "boot_verify_ext_image",
   "from": 77,
   "to": 114,
   "note": "片外镜像 SHA-256 校验：BOOT_VERIFY_CHUNK=64 字节分块",
   "grade": "A",
   "lines": [
    [
     77,
     "static int boot_verify_ext_image(uint32_t ext_addr, uint32_t len, const uint8_t *expect_sha)"
    ],
    [
     78,
     "{"
    ],
    [
     79,
     "    sha256_ctx_t ctx;"
    ],
    [
     80,
     "    uint8_t  digest[SHA256_DIGEST_SIZE];"
    ],
    [
     81,
     "    uint8_t  chunk[BOOT_VERIFY_CHUNK];"
    ],
    [
     82,
     "    uint32_t done = 0UL;"
    ],
    [
     83,
     ""
    ],
    [
     84,
     "    if ((len == 0UL) || (len > OTA_APP_IMAGE_MAX_SIZE))"
    ],
    [
     85,
     "    {"
    ],
    [
     86,
     "        return -1;"
    ],
    [
     87,
     "    }"
    ],
    [
     88,
     ""
    ],
    [
     89,
     "    sha256_init(&ctx);"
    ],
    [
     90,
     ""
    ],
    [
     91,
     "    while (done < len)"
    ],
    [
     92,
     "    {"
    ],
    [
     93,
     "        uint32_t take = len - done;"
    ],
    [
     94,
     ""
    ],
    [
     95,
     "        if (take > BOOT_VERIFY_CHUNK)"
    ],
    [
     96,
     "        {"
    ],
    [
     97,
     "            take = BOOT_VERIFY_CHUNK;"
    ],
    [
     98,
     "        }"
    ],
    [
     99,
     ""
    ],
    [
     100,
     "        if (boot_ext_read(ext_addr + done, chunk, take) != 0)"
    ],
    [
     101,
     "        {"
    ],
    [
     102,
     "            return -1;"
    ],
    [
     103,
     "        }"
    ],
    [
     104,
     ""
    ],
    [
     105,
     "        sha256_update(&ctx, chunk, take);"
    ],
    [
     106,
     "        done += take;"
    ],
    [
     107,
     ""
    ],
    [
     108,
     "        boot_wdg_feed();"
    ],
    [
     109,
     "    }"
    ],
    [
     110,
     ""
    ],
    [
     111,
     "    sha256_final(&ctx, digest);"
    ],
    [
     112,
     ""
    ],
    [
     113,
     "    return (sha256_equal(digest, expect_sha) == 1) ? 0 : -1;"
    ],
    [
     114,
     "}"
    ]
   ]
  },
  "boot_do_rollback": {
   "id": "boot_do_rollback",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "boot_do_rollback",
   "from": 183,
   "to": 211,
   "note": "回滚：先校验备份区 SHA-256，通过后再用备份覆盖 A 槽",
   "grade": "A",
   "lines": [
    [
     183,
     "/**"
    ],
    [
     184,
     " * @brief  从备份区回滚"
    ],
    [
     185,
     " */"
    ],
    [
     186,
     "static int boot_do_rollback(ota_param_t *p)"
    ],
    [
     187,
     "{"
    ],
    [
     188,
     "    if ((p->backup_status != OTA_BACKUP_VALID) || (p->backup_len == 0UL))"
    ],
    [
     189,
     "    {"
    ],
    [
     190,
     "        boot_log(\"[BL] no valid backup\\r\\n\");"
    ],
    [
     191,
     "        return -1;"
    ],
    [
     192,
     "    }"
    ],
    [
     193,
     ""
    ],
    [
     194,
     "    boot_log(\"[BL] verify backup SHA-256 (len=%lu)...\\r\\n\", (unsigned long)p->backup_len);"
    ],
    [
     195,
     ""
    ],
    [
     196,
     "    if (boot_verify_ext_image(EXT_BACKUP_ADDR, p->backup_len, p->backup_sha) != 0)"
    ],
    [
     197,
     "    {"
    ],
    [
     198,
     "        boot_log(\"[BL] backup SHA-256 FAILED\\r\\n\");"
    ],
    [
     199,
     "        return -1;"
    ],
    [
     200,
     "    }"
    ],
    [
     201,
     ""
    ],
    [
     202,
     "    boot_log(\"[BL] backup OK, copy backup -> A\\r\\n\");"
    ],
    [
     203,
     ""
    ],
    [
     204,
     "    if (boot_copy_ext_to_run(EXT_BACKUP_ADDR, p->backup_len) != 0)"
    ],
    [
     205,
     "    {"
    ],
    [
     206,
     "        boot_log(\"[BL] rollback copy FAILED\\r\\n\");"
    ],
    [
     207,
     "        return -1;"
    ],
    [
     208,
     "    }"
    ],
    [
     209,
     ""
    ],
    [
     210,
     "    return 0;"
    ],
    [
     211,
     "}"
    ]
   ]
  },
  "boot_do_recovery": {
   "id": "boot_do_recovery",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "boot_do_recovery",
   "from": 213,
   "to": 241,
   "note": "恢复出厂：校验恢复区 SHA-256 后覆盖 A 槽",
   "grade": "A",
   "lines": [
    [
     213,
     "/**"
    ],
    [
     214,
     " * @brief  从恢复区（出厂固件）恢复"
    ],
    [
     215,
     " */"
    ],
    [
     216,
     "static int boot_do_recovery(ota_param_t *p)"
    ],
    [
     217,
     "{"
    ],
    [
     218,
     "    if ((p->recovery_len == 0UL) || (p->recovery_len > OTA_APP_IMAGE_MAX_SIZE))"
    ],
    [
     219,
     "    {"
    ],
    [
     220,
     "        boot_log(\"[BL] no recovery image\\r\\n\");"
    ],
    [
     221,
     "        return -1;"
    ],
    [
     222,
     "    }"
    ],
    [
     223,
     ""
    ],
    [
     224,
     "    boot_log(\"[BL] verify recovery SHA-256 (len=%lu)...\\r\\n\", (unsigned long)p->recovery_len);"
    ],
    [
     225,
     ""
    ],
    [
     226,
     "    if (boot_verify_ext_image(EXT_RECOVERY_ADDR, p->recovery_len, p->recovery_sha) != 0)"
    ],
    [
     227,
     "    {"
    ],
    [
     228,
     "        boot_log(\"[BL] recovery SHA-256 FAILED\\r\\n\");"
    ],
    [
     229,
     "        return -1;"
    ],
    [
     230,
     "    }"
    ],
    [
     231,
     ""
    ],
    [
     232,
     "    boot_log(\"[BL] recovery OK, copy recovery -> A\\r\\n\");"
    ],
    [
     233,
     ""
    ],
    [
     234,
     "    if (boot_copy_ext_to_run(EXT_RECOVERY_ADDR, p->recovery_len) != 0)"
    ],
    [
     235,
     "    {"
    ],
    [
     236,
     "        boot_log(\"[BL] recovery copy FAILED\\r\\n\");"
    ],
    [
     237,
     "        return -1;"
    ],
    [
     238,
     "    }"
    ],
    [
     239,
     ""
    ],
    [
     240,
     "    return 0;"
    ],
    [
     241,
     "}"
    ]
   ]
  },
  "boot_copy": {
   "id": "boot_copy",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_start.c",
   "func": "boot_copy_ext_to_run",
   "from": 120,
   "to": 181,
   "note": "暂存区 → A 槽：按扇区擦除 + BOOT_COPY_CHUNK=1024 字节分块拷贝",
   "grade": "A",
   "lines": [
    [
     120,
     "static int boot_copy_ext_to_run(uint32_t ext_addr, uint32_t len)"
    ],
    [
     121,
     "{"
    ],
    [
     122,
     "    uint8_t  buf[BOOT_COPY_CHUNK];"
    ],
    [
     123,
     "    uint32_t cur;"
    ],
    [
     124,
     "    uint32_t end;"
    ],
    [
     125,
     "    uint32_t done = 0UL;"
    ],
    [
     126,
     ""
    ],
    [
     127,
     "    if ((len == 0UL) || (len > OTA_APP_IMAGE_MAX_SIZE))"
    ],
    [
     128,
     "    {"
    ],
    [
     129,
     "        return -1;"
    ],
    [
     130,
     "    }"
    ],
    [
     131,
     ""
    ],
    [
     132,
     "    /* ---- 1. 按扇区擦除目标区间 ---------------------------------------- */"
    ],
    [
     133,
     "    cur = OTA_APP_A_ADDR;"
    ],
    [
     134,
     "    end = OTA_APP_A_ADDR + len;"
    ],
    [
     135,
     ""
    ],
    [
     136,
     "    while (cur < end)"
    ],
    [
     137,
     "    {"
    ],
    [
     138,
     "        uint32_t sector_size = flash_if_sector_size(cur);"
    ],
    [
     139,
     ""
    ],
    [
     140,
     "        if (flash_if_erase_addr(cur) != HAL_OK)"
    ],
    [
     141,
     "        {"
    ],
    [
     142,
     "            boot_log(\"[BL] erase FAILED @0x%08lX\\r\\n\", (unsigned long)cur);"
    ],
    [
     143,
     "            return -1;"
    ],
    [
     144,
     "        }"
    ],
    [
     145,
     ""
    ],
    [
     146,
     "        cur += sector_size;"
    ],
    [
     147,
     ""
    ],
    [
     148,
     "        boot_wdg_feed();"
    ],
    [
     149,
     "    }"
    ],
    [
     150,
     ""
    ],
    [
     151,
     "    /* ---- 2. 分块拷贝 --------------------------------------------------- */"
    ],
    [
     152,
     "    while (done < len)"
    ],
    [
     153,
     "    {"
    ],
    [
     154,
     "        uint32_t take = len - done;"
    ],
    [
     155,
     ""
    ],
    [
     156,
     "        if (take > BOOT_COPY_CHUNK)"
    ],
    [
     157,
     "        {"
    ],
    [
     158,
     "            take = BOOT_COPY_CHUNK;"
    ],
    [
     159,
     "        }"
    ],
    [
     160,
     ""
    ],
    [
     161,
     "        if (boot_ext_read(ext_addr + done, buf, take) != 0)"
    ],
    [
     162,
     "        {"
    ],
    [
     163,
     "            boot_log(\"[BL] ext read FAILED @0x%08lX\\r\\n\","
    ],
    [
     164,
     "                     (unsigned long)(ext_addr + done));"
    ],
    [
     165,
     "            return -1;"
    ],
    [
     166,
     "        }"
    ],
    [
     167,
     ""
    ],
    [
     168,
     "        if (flash_if_write(OTA_APP_A_ADDR + done, buf, take) != HAL_OK)"
    ],
    [
     169,
     "        {"
    ],
    [
     170,
     "            boot_log(\"[BL] program FAILED @0x%08lX\\r\\n\","
    ],
    [
     171,
     "                     (unsigned long)(OTA_APP_A_ADDR + done));"
    ],
    [
     172,
     "            return -1;"
    ],
    [
     173,
     "        }"
    ],
    [
     174,
     ""
    ],
    [
     175,
     "        done += take;"
    ],
    [
     176,
     ""
    ],
    [
     177,
     "        boot_wdg_feed();"
    ],
    [
     178,
     "    }"
    ],
    [
     179,
     ""
    ],
    [
     180,
     "    return 0;"
    ],
    [
     181,
     "}"
    ]
   ]
  },
  "partition_internal": {
   "id": "partition_internal",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/partition.h",
   "path": "HAL_F429IGT6_bootloard/Boot/partition.h",
   "func": "#define 片内分区宏",
   "from": 39,
   "to": 64,
   "note": "片内 Flash 分区：BL 48KB / 参数区 16KB / App A 槽 960KB",
   "grade": "A",
   "lines": [
    [
     39,
     "/* ===================== 片内 Flash ===================== */"
    ],
    [
     40,
     ""
    ],
    [
     41,
     "/* Flash 总容量（F429IGT6 = 1MB） */"
    ],
    [
     42,
     "#define OTA_FLASH_SIZE            (1024UL * 1024UL)"
    ],
    [
     43,
     "#define OTA_FLASH_BASE            0x08000000UL"
    ],
    [
     44,
     "#define OTA_FLASH_END             (OTA_FLASH_BASE + OTA_FLASH_SIZE)   /* 0x08100000 */"
    ],
    [
     45,
     ""
    ],
    [
     46,
     "/* BootLoader 分区（S0-S2，3×16KB = 48KB） */"
    ],
    [
     47,
     "#define OTA_BOOTLOADER_ADDR       0x08000000UL"
    ],
    [
     48,
     "#define OTA_BOOTLOADER_SIZE       0x0000C000UL   /* 48KB */"
    ],
    [
     49,
     ""
    ],
    [
     50,
     "/* 参数区（S3，独占 16KB 扇区） */"
    ],
    [
     51,
     "#define OTA_PARAM_AREA_ADDR       0x0800C000UL"
    ],
    [
     52,
     "#define OTA_PARAM_AREA_SIZE       0x00004000UL   /* 16KB */"
    ],
    [
     53,
     ""
    ],
    [
     54,
     "/* 参数区槽位：16KB / 512B = 32 槽；写满 32 次才整扇区擦一次（掉电安全） */"
    ],
    [
     55,
     "#define OTA_PARAM_SLOT_COUNT      32U"
    ],
    [
     56,
     "#define OTA_PARAM_SLOT_SIZE       512U"
    ],
    [
     57,
     "#define OTA_PARAM_SLOT0_ADDR      OTA_PARAM_AREA_ADDR   /* 0x0800C000 */"
    ],
    [
     58,
     ""
    ],
    [
     59,
     "/* App A 槽（S4 64KB + S5-S11 7×128KB = 960KB） */"
    ],
    [
     60,
     "#define OTA_APP_A_ADDR            0x08010000UL"
    ],
    [
     61,
     "#define OTA_APP_SIZE              0x000F0000UL   /* 960KB */"
    ],
    [
     62,
     ""
    ],
    [
     63,
     "/* 固件镜像上限：等于 A 槽大小 */"
    ],
    [
     64,
     "#define OTA_APP_IMAGE_MAX_SIZE    0x000F0000UL"
    ]
   ]
  },
  "partition_flags": {
   "id": "partition_flags",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/partition.h",
   "path": "HAL_F429IGT6_bootloard/Boot/partition.h",
   "func": "#define 启动标志",
   "from": 78,
   "to": 95,
   "note": "启动标志四态 + 备份区状态 + 自动回滚次数阈值",
   "grade": "A",
   "lines": [
    [
     78,
     "/* ===================== 启动标志 ===================== */"
    ],
    [
     79,
     ""
    ],
    [
     80,
     "#define OTA_BOOT_FLAG_NORMAL      0UL   /* 正常启动 */"
    ],
    [
     81,
     "#define OTA_BOOT_FLAG_TRY_NEW     1UL   /* 尝试启动新固件（升级完成重启后） */"
    ],
    [
     82,
     "#define OTA_BOOT_FLAG_ROLLBACK    2UL   /* 回滚到备份版本 */"
    ],
    [
     83,
     "#define OTA_BOOT_FLAG_RECOVERY    3UL   /* 恢复出厂（从恢复区拷贝） */"
    ],
    [
     84,
     ""
    ],
    [
     85,
     "/* 备份区状态 */"
    ],
    [
     86,
     "#define OTA_BACKUP_EMPTY          0x00U"
    ],
    [
     87,
     "#define OTA_BACKUP_DOWNLOADING    0x01U"
    ],
    [
     88,
     "#define OTA_BACKUP_VALID          0x02U"
    ],
    [
     89,
     ""
    ],
    [
     90,
     "/* 新固件连续启动失败达到该次数即自动回滚 */"
    ],
    [
     91,
     "#define OTA_BOOT_MAX_TRIES        3UL"
    ],
    [
     92,
     ""
    ],
    [
     93,
     "/* 版本号编码：V1.2.3 -> 0x010203 */"
    ],
    [
     94,
     "#define OTA_VERSION(major, minor, patch) \\"
    ],
    [
     95,
     "    ((((uint32_t)(major)) << 16) | (((uint32_t)(minor)) << 8) | ((uint32_t)(patch)))"
    ]
   ]
  },
  "partition_ext": {
   "id": "partition_ext",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/partition.h",
   "path": "HAL_F429IGT6_bootloard/Boot/partition.h",
   "func": "(非函数体)",
   "from": 66,
   "to": 91,
   "note": "W25Q64 分区：Staging / Backup / Recovery / Resource 各 960KB 与启动标志",
   "grade": "A",
   "lines": [
    [
     66,
     "/* ===================== 片外 W25Q64（8MB） ===================== */"
    ],
    [
     67,
     ""
    ],
    [
     68,
     "#define EXT_FLASH_SIZE            (8UL * 1024UL * 1024UL)   /* 0x00800000 */"
    ],
    [
     69,
     ""
    ],
    [
     70,
     "/* 三个区各 960KB（= 15 × 64KB，正好是 64KB 块擦除的整数倍） */"
    ],
    [
     71,
     "#define EXT_REGION_SIZE           0x000F0000UL"
    ],
    [
     72,
     ""
    ],
    [
     73,
     "#define EXT_STAGING_ADDR          0x00000000UL                            /* 新固件暂存 */"
    ],
    [
     74,
     "#define EXT_BACKUP_ADDR           (EXT_STAGING_ADDR  + EXT_REGION_SIZE)   /* 0x000F0000 旧固件备份 */"
    ],
    [
     75,
     "#define EXT_RECOVERY_ADDR         (EXT_BACKUP_ADDR   + EXT_REGION_SIZE)   /* 0x001E0000 出厂固件 */"
    ],
    [
     76,
     "#define EXT_RESOURCE_ADDR         (EXT_RECOVERY_ADDR + EXT_REGION_SIZE)   /* 0x002D0000 预留 */"
    ],
    [
     77,
     ""
    ],
    [
     78,
     "/* ===================== 启动标志 ===================== */"
    ],
    [
     79,
     ""
    ],
    [
     80,
     "#define OTA_BOOT_FLAG_NORMAL      0UL   /* 正常启动 */"
    ],
    [
     81,
     "#define OTA_BOOT_FLAG_TRY_NEW     1UL   /* 尝试启动新固件（升级完成重启后） */"
    ],
    [
     82,
     "#define OTA_BOOT_FLAG_ROLLBACK    2UL   /* 回滚到备份版本 */"
    ],
    [
     83,
     "#define OTA_BOOT_FLAG_RECOVERY    3UL   /* 恢复出厂（从恢复区拷贝） */"
    ],
    [
     84,
     ""
    ],
    [
     85,
     "/* 备份区状态 */"
    ],
    [
     86,
     "#define OTA_BACKUP_EMPTY          0x00U"
    ],
    [
     87,
     "#define OTA_BACKUP_DOWNLOADING    0x01U"
    ],
    [
     88,
     "#define OTA_BACKUP_VALID          0x02U"
    ],
    [
     89,
     ""
    ],
    [
     90,
     "/* 新固件连续启动失败达到该次数即自动回滚 */"
    ],
    [
     91,
     "#define OTA_BOOT_MAX_TRIES        3UL"
    ]
   ]
  },
  "ota_params_t": {
   "id": "ota_params_t",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/ota_params.h",
   "path": "HAL_F429IGT6_bootloard/Boot/ota_params.h",
   "func": "struct ota_param_t",
   "from": 21,
   "to": 43,
   "note": "参数区结构体：BL 与 App 的二进制协议（字段顺序不可改）",
   "grade": "A",
   "lines": [
    [
     21,
     "#define OTA_PARAM_MAGIC           0xA5A5A5A5UL"
    ],
    [
     22,
     ""
    ],
    [
     23,
     "/* 注意：本结构体的字段顺序/长度是 BootLoader 与 App 的\"二进制协议\"，"
    ],
    [
     24,
     "   任何一侧改动都必须同步另一侧，否则 CRC 校验全失败（固件会退化成默认参数）。 */"
    ],
    [
     25,
     "typedef struct {"
    ],
    [
     26,
     "    uint32_t magic;             /* 有效标志 OTA_PARAM_MAGIC */"
    ],
    [
     27,
     "    uint32_t version;           /* 当前运行版本，如 V1.2.3 -> 0x010203 */"
    ],
    [
     28,
     "    uint32_t boot_flag;         /* OTA_BOOT_FLAG_xxx */"
    ],
    [
     29,
     "    uint32_t boot_count;        /* 新固件连续启动失败次数 */"
    ],
    [
     30,
     "    uint32_t min_version;       /* 预留：最低允许版本 */"
    ],
    [
     31,
     "    uint32_t resume_offset;     /* 断点续传偏移（0 表示无未完成任务） */"
    ],
    [
     32,
     "    uint32_t image_len;         /* 待升级镜像长度（暂存区，BL 校验用） */"
    ],
    [
     33,
     "    uint32_t backup_version;    /* 备份区固件版本号（0 表示无备份） */"
    ],
    [
     34,
     "    uint32_t backup_len;        /* 备份区固件长度 */"
    ],
    [
     35,
     "    uint32_t recovery_len;      /* 恢复区（出厂）固件长度，0 表示未初始化 */"
    ],
    [
     36,
     "    uint8_t  backup_status;     /* OTA_BACKUP_EMPTY / DOWNLOADING / VALID */"
    ],
    [
     37,
     "    uint8_t  image_sha[32];     /* 暂存区镜像 SHA-256 */"
    ],
    [
     38,
     "    uint8_t  backup_sha[32];    /* 备份区镜像 SHA-256 */"
    ],
    [
     39,
     "    uint8_t  recovery_sha[32];  /* 恢复区镜像 SHA-256 */"
    ],
    [
     40,
     "    uint32_t dl_tid;            /* 当前下载任务号（OneNET tid） */"
    ],
    [
     41,
     "    uint32_t ota_tid;           /* 待上报 201 的任务号 */"
    ],
    [
     42,
     "    uint32_t crc32;             /* 结构体 CRC32（不含本字段） */"
    ],
    [
     43,
     "} ota_param_t;"
    ]
   ]
  },
  "param_load": {
   "id": "param_load",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/param_area.c",
   "path": "HAL_F429IGT6_bootloard/Boot/param_area.c",
   "func": "param_area_load",
   "from": 105,
   "to": 144,
   "note": "param_area_load：遍历 32 槽，取 seq 最大且 CRC32 正确的槽",
   "grade": "A",
   "lines": [
    [
     105,
     "int param_area_load(ota_param_t *param)"
    ],
    [
     106,
     "{"
    ],
    [
     107,
     "    uint32_t i;"
    ],
    [
     108,
     "    int found = 0;"
    ],
    [
     109,
     "    uint32_t best_seq = 0U;"
    ],
    [
     110,
     "    ota_param_t best;"
    ],
    [
     111,
     ""
    ],
    [
     112,
     "    if (param == 0)"
    ],
    [
     113,
     "    {"
    ],
    [
     114,
     "        return -1;"
    ],
    [
     115,
     "    }"
    ],
    [
     116,
     ""
    ],
    [
     117,
     "    (void)memset(&best, 0, sizeof(best));"
    ],
    [
     118,
     ""
    ],
    [
     119,
     "    for (i = 0U; i < OTA_PARAM_SLOT_COUNT; i++)"
    ],
    [
     120,
     "    {"
    ],
    [
     121,
     "        uint32_t seq;"
    ],
    [
     122,
     "        ota_param_t tmp;"
    ],
    [
     123,
     "        uint32_t addr = OTA_PARAM_SLOT0_ADDR + (i * OTA_PARAM_SLOT_SIZE);"
    ],
    [
     124,
     ""
    ],
    [
     125,
     "        if (slot_load(addr, &tmp, &seq) == 0)"
    ],
    [
     126,
     "        {"
    ],
    [
     127,
     "            /* 取 seq 最大（用差值比较，正确处理 uint32 回绕） */"
    ],
    [
     128,
     "            if ((found == 0) || ((int32_t)(seq - best_seq) > 0))"
    ],
    [
     129,
     "            {"
    ],
    [
     130,
     "                best_seq = seq;"
    ],
    [
     131,
     "                best     = tmp;"
    ],
    [
     132,
     "                found    = 1;"
    ],
    [
     133,
     "            }"
    ],
    [
     134,
     "        }"
    ],
    [
     135,
     "    }"
    ],
    [
     136,
     ""
    ],
    [
     137,
     "    if (found == 0)"
    ],
    [
     138,
     "    {"
    ],
    [
     139,
     "        return -1;"
    ],
    [
     140,
     "    }"
    ],
    [
     141,
     ""
    ],
    [
     142,
     "    (void)memcpy(param, &best, sizeof(ota_param_t));"
    ],
    [
     143,
     "    return 0;"
    ],
    [
     144,
     "}"
    ]
   ]
  },
  "param_save": {
   "id": "param_save",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/param_area.c",
   "path": "HAL_F429IGT6_bootloard/Boot/param_area.c",
   "func": "param_area_save",
   "from": 146,
   "to": 215,
   "note": "param_area_save：找空槽写入；写满 32 次才整扇区擦一次（掉电安全）",
   "grade": "A",
   "lines": [
    [
     146,
     "int param_area_save(const ota_param_t *param)"
    ],
    [
     147,
     "{"
    ],
    [
     148,
     "    param_slot_t slot;"
    ],
    [
     149,
     "    ota_param_t tmp;"
    ],
    [
     150,
     "    uint32_t i;"
    ],
    [
     151,
     "    uint32_t cur_seq = 0U;"
    ],
    [
     152,
     "    uint32_t target = 0U;"
    ],
    [
     153,
     "    int has_empty = 0;"
    ],
    [
     154,
     ""
    ],
    [
     155,
     "    if (param == 0)"
    ],
    [
     156,
     "    {"
    ],
    [
     157,
     "        return -1;"
    ],
    [
     158,
     "    }"
    ],
    [
     159,
     ""
    ],
    [
     160,
     "    /* 1. 找当前最大有效 seq */"
    ],
    [
     161,
     "    for (i = 0U; i < OTA_PARAM_SLOT_COUNT; i++)"
    ],
    [
     162,
     "    {"
    ],
    [
     163,
     "        uint32_t seq = 0U;"
    ],
    [
     164,
     "        uint32_t addr = OTA_PARAM_SLOT0_ADDR + (i * OTA_PARAM_SLOT_SIZE);"
    ],
    [
     165,
     ""
    ],
    [
     166,
     "        if (slot_load(addr, 0, &seq) == 0)"
    ],
    [
     167,
     "        {"
    ],
    [
     168,
     "            if ((int32_t)(seq - cur_seq) > 0)"
    ],
    [
     169,
     "            {"
    ],
    [
     170,
     "                cur_seq = seq;"
    ],
    [
     171,
     "            }"
    ],
    [
     172,
     "        }"
    ],
    [
     173,
     "    }"
    ],
    [
     174,
     ""
    ],
    [
     175,
     "    (void)memcpy(&tmp, param, sizeof(ota_param_t));"
    ],
    [
     176,
     "    tmp.crc32 = param_area_crc(&tmp);"
    ],
    [
     177,
     ""
    ],
    [
     178,
     "    /* 2. 找下一个空槽 */"
    ],
    [
     179,
     "    for (i = 0U; i < OTA_PARAM_SLOT_COUNT; i++)"
    ],
    [
     180,
     "    {"
    ],
    [
     181,
     "        uint32_t addr = OTA_PARAM_SLOT0_ADDR + (i * OTA_PARAM_SLOT_SIZE);"
    ],
    [
     182,
     ""
    ],
    [
     183,
     "        if (slot_is_empty(addr) != 0)"
    ],
    [
     184,
     "        {"
    ],
    [
     185,
     "            target = i;"
    ],
    [
     186,
     "            has_empty = 1;"
    ],
    [
     187,
     "            break;"
    ],
    [
     188,
     "        }"
    ],
    [
     189,
     "    }"
    ],
    [
     190,
     ""
    ],
    [
     191,
     "    /* 3. 一个空槽都没有：整扇区擦除后从槽 0 重来 */"
    ],
    [
     192,
     "    if (has_empty == 0)"
    ],
    [
     193,
     "    {"
    ],
    [
     194,
     "        if (flash_if_erase_addr(OTA_PARAM_AREA_ADDR) != HAL_OK)"
    ],
    [
     195,
     "        {"
    ],
    [
     196,
     "            return -1;"
    ],
    [
     197,
     "        }"
    ],
    [
     198,
     "        target = 0U;"
    ],
    [
     199,
     "        cur_seq = 0U;   /* 擦完后旧 seq 已不存在，从 1 重新编号 */"
    ],
    [
     200,
     "    }"
    ],
    [
     201,
     ""
    ],
    [
     202,
     "    /* 4. 写槽 */"
    ],
    [
     203,
     "    slot.magic = OTA_PARAM_MAGIC;"
    ],
    [
     204,
     "    slot.seq   = cur_seq + 1U;"
    ],
    [
     205,
     "    (void)memcpy(&slot.param, &tmp, sizeof(ota_param_t));"
    ],
    [
     206,
     ""
    ],
    [
     207,
     "    if (flash_if_write(OTA_PARAM_SLOT0_ADDR + (target * OTA_PARAM_SLOT_SIZE),"
    ],
    [
     208,
     "                       (const uint8_t *)&slot,"
    ],
    [
     209,
     "                       (uint32_t)(PARAM_SLOT_HEADER_SIZE + sizeof(ota_param_t))) != HAL_OK)"
    ],
    [
     210,
     "    {"
    ],
    [
     211,
     "        return -1;"
    ],
    [
     212,
     "    }"
    ],
    [
     213,
     ""
    ],
    [
     214,
     "    return 0;"
    ],
    [
     215,
     "}"
    ]
   ]
  },
  "param_defaults": {
   "id": "param_defaults",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/param_area.c",
   "path": "HAL_F429IGT6_bootloard/Boot/param_area.c",
   "func": "param_area_defaults",
   "from": 34,
   "to": 54,
   "note": "参数区默认值 = NORMAL + V1.0.0",
   "grade": "A",
   "lines": [
    [
     34,
     "void param_area_defaults(ota_param_t *param)"
    ],
    [
     35,
     "{"
    ],
    [
     36,
     "    if (param == 0)"
    ],
    [
     37,
     "    {"
    ],
    [
     38,
     "        return;"
    ],
    [
     39,
     "    }"
    ],
    [
     40,
     ""
    ],
    [
     41,
     "    (void)memset(param, 0, sizeof(ota_param_t));"
    ],
    [
     42,
     ""
    ],
    [
     43,
     "    param->magic          = OTA_PARAM_MAGIC;"
    ],
    [
     44,
     "    param->version        = OTA_VERSION(1, 0, 0);"
    ],
    [
     45,
     "    param->boot_flag      = OTA_BOOT_FLAG_NORMAL;"
    ],
    [
     46,
     "    param->boot_count     = 0U;"
    ],
    [
     47,
     "    param->min_version    = OTA_VERSION(1, 0, 0);"
    ],
    [
     48,
     "    param->resume_offset  = 0U;"
    ],
    [
     49,
     "    param->backup_status  = OTA_BACKUP_EMPTY;"
    ],
    [
     50,
     "    param->backup_version = 0U;"
    ],
    [
     51,
     "    param->backup_len     = 0U;"
    ],
    [
     52,
     "    param->recovery_len   = 0U;"
    ],
    [
     53,
     "    param->crc32          = param_area_crc(param);"
    ],
    [
     54,
     "}"
    ]
   ]
  },
  "flash_if_sectors": {
   "id": "flash_if_sectors",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/flash_if.c",
   "path": "HAL_F429IGT6_bootloard/Boot/flash_if.c",
   "func": "s_sector_start[] / s_sector_size[]",
   "from": 14,
   "to": 36,
   "note": "F429IGT6 扇区表：S0~S3=16KB，S4=64KB，S5~S11=128KB",
   "grade": "A",
   "lines": [
    [
     14,
     "/* 扇区起始地址表（F429IGT6 共 12 个扇区，覆盖 0x08000000~0x080FFFFF） */"
    ],
    [
     15,
     "static const uint32_t s_sector_start[FLASH_IF_SECTOR_COUNT] = {"
    ],
    [
     16,
     "    0x08000000UL,   /* S0  16KB */"
    ],
    [
     17,
     "    0x08004000UL,   /* S1  16KB */"
    ],
    [
     18,
     "    0x08008000UL,   /* S2  16KB */"
    ],
    [
     19,
     "    0x0800C000UL,   /* S3  16KB */"
    ],
    [
     20,
     "    0x08010000UL,   /* S4  64KB */"
    ],
    [
     21,
     "    0x08020000UL,   /* S5 128KB */"
    ],
    [
     22,
     "    0x08040000UL,   /* S6 128KB */"
    ],
    [
     23,
     "    0x08060000UL,   /* S7 128KB */"
    ],
    [
     24,
     "    0x08080000UL,   /* S8 128KB */"
    ],
    [
     25,
     "    0x080A0000UL,   /* S9 128KB */"
    ],
    [
     26,
     "    0x080C0000UL,   /* S10 128KB */"
    ],
    [
     27,
     "    0x080E0000UL    /* S11 128KB */"
    ],
    [
     28,
     "};"
    ],
    [
     29,
     ""
    ],
    [
     30,
     "/* 扇区大小表 */"
    ],
    [
     31,
     "static const uint32_t s_sector_size[FLASH_IF_SECTOR_COUNT] = {"
    ],
    [
     32,
     "    16UL * 1024UL, 16UL * 1024UL, 16UL * 1024UL, 16UL * 1024UL,"
    ],
    [
     33,
     "    64UL * 1024UL,"
    ],
    [
     34,
     "    128UL * 1024UL, 128UL * 1024UL, 128UL * 1024UL,"
    ],
    [
     35,
     "    128UL * 1024UL, 128UL * 1024UL, 128UL * 1024UL, 128UL * 1024UL"
    ],
    [
     36,
     "};"
    ]
   ]
  },
  "flash_if_erase": {
   "id": "flash_if_erase",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/flash_if.c",
   "path": "HAL_F429IGT6_bootloard/Boot/flash_if.c",
   "func": "flash_if_erase_addr",
   "from": 64,
   "to": 104,
   "note": "按地址擦除所在扇区（HAL_FLASHEx_Erase）",
   "grade": "A",
   "lines": [
    [
     64,
     "HAL_StatusTypeDef flash_if_erase_addr(uint32_t addr)"
    ],
    [
     65,
     "{"
    ],
    [
     66,
     "    return flash_if_erase_region(addr, s_sector_size[flash_if_sector_number(addr)]);"
    ],
    [
     67,
     "}"
    ],
    [
     68,
     ""
    ],
    [
     69,
     "HAL_StatusTypeDef flash_if_erase_region(uint32_t base, uint32_t size)"
    ],
    [
     70,
     "{"
    ],
    [
     71,
     "    FLASH_EraseInitTypeDef erase;"
    ],
    [
     72,
     "    uint32_t first;"
    ],
    [
     73,
     "    uint32_t last;"
    ],
    [
     74,
     "    uint32_t sector_error = 0U;"
    ],
    [
     75,
     "    HAL_StatusTypeDef status;"
    ],
    [
     76,
     ""
    ],
    [
     77,
     "    if (size == 0U)"
    ],
    [
     78,
     "    {"
    ],
    [
     79,
     "        return HAL_OK;"
    ],
    [
     80,
     "    }"
    ],
    [
     81,
     ""
    ],
    [
     82,
     "    first = flash_if_sector_number(base);"
    ],
    [
     83,
     "    last  = flash_if_sector_number(base + size - 1U);"
    ],
    [
     84,
     ""
    ],
    [
     85,
     "    (void)memset(&erase, 0, sizeof(erase));"
    ],
    [
     86,
     "    erase.TypeErase     = FLASH_TYPEERASE_SECTORS;"
    ],
    [
     87,
     "    erase.Sector        = first;"
    ],
    [
     88,
     "    erase.NbSectors     = (last - first) + 1U;"
    ],
    [
     89,
     "    erase.VoltageRange  = FLASH_VOLTAGE_RANGE_3;   /* 2.7V ~ 3.6V（本板 3.3V） */"
    ],
    [
     90,
     "    /* 注意：Banks 字段只在 FLASH_TYPEERASE_MASSERASE 时被 HAL 使用，"
    ],
    [
     91,
     "       扇区擦除走的是 Sector/NbSectors 分支，因此这里无需赋值（已核对 HAL 源码）。 */"
    ],
    [
     92,
     ""
    ],
    [
     93,
     "    status = HAL_FLASH_Unlock();"
    ],
    [
     94,
     "    if (status != HAL_OK)"
    ],
    [
     95,
     "    {"
    ],
    [
     96,
     "        return status;"
    ],
    [
     97,
     "    }"
    ],
    [
     98,
     ""
    ],
    [
     99,
     "    status = HAL_FLASHEx_Erase(&erase, &sector_error);"
    ],
    [
     100,
     ""
    ],
    [
     101,
     "    (void)HAL_FLASH_Lock();"
    ],
    [
     102,
     ""
    ],
    [
     103,
     "    return status;"
    ],
    [
     104,
     "}"
    ]
   ]
  },
  "flash_if_write": {
   "id": "flash_if_write",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/flash_if.c",
   "path": "HAL_F429IGT6_bootloard/Boot/flash_if.c",
   "func": "flash_if_write",
   "from": 106,
   "to": 168,
   "note": "片内 Flash 写：32 位字编程 + 回读校验",
   "grade": "A",
   "lines": [
    [
     106,
     "HAL_StatusTypeDef flash_if_write(uint32_t addr, const uint8_t *data, uint32_t len)"
    ],
    [
     107,
     "{"
    ],
    [
     108,
     "    HAL_StatusTypeDef status;"
    ],
    [
     109,
     "    uint32_t i = 0U;"
    ],
    [
     110,
     ""
    ],
    [
     111,
     "    if ((data == 0) || (len == 0U))"
    ],
    [
     112,
     "    {"
    ],
    [
     113,
     "        return HAL_OK;"
    ],
    [
     114,
     "    }"
    ],
    [
     115,
     ""
    ],
    [
     116,
     "    /* 32 位字编程必须 4 字节对齐 */"
    ],
    [
     117,
     "    if ((addr & 3U) != 0U)"
    ],
    [
     118,
     "    {"
    ],
    [
     119,
     "        return HAL_ERROR;"
    ],
    [
     120,
     "    }"
    ],
    [
     121,
     ""
    ],
    [
     122,
     "    status = HAL_FLASH_Unlock();"
    ],
    [
     123,
     "    if (status != HAL_OK)"
    ],
    [
     124,
     "    {"
    ],
    [
     125,
     "        return status;"
    ],
    [
     126,
     "    }"
    ],
    [
     127,
     ""
    ],
    [
     128,
     "    /* 主体：按 32 位字写 */"
    ],
    [
     129,
     "    for (; (i + 4U) <= len; i += 4U)"
    ],
    [
     130,
     "    {"
    ],
    [
     131,
     "        uint32_t word;"
    ],
    [
     132,
     ""
    ],
    [
     133,
     "        (void)memcpy(&word, &data[i], 4U);"
    ],
    [
     134,
     ""
    ],
    [
     135,
     "        if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr + i, word) != HAL_OK)"
    ],
    [
     136,
     "        {"
    ],
    [
     137,
     "            (void)HAL_FLASH_Lock();"
    ],
    [
     138,
     "            return HAL_ERROR;"
    ],
    [
     139,
     "        }"
    ],
    [
     140,
     "    }"
    ],
    [
     141,
     ""
    ],
    [
     142,
     "    /* 尾部不足 4 字节：补 0xFF 后整字写入 */"
    ],
    [
     143,
     "    if (i < len)"
    ],
    [
     144,
     "    {"
    ],
    [
     145,
     "        uint32_t word = 0xFFFFFFFFUL;"
    ],
    [
     146,
     ""
    ],
    [
     147,
     "        (void)memcpy(&word, &data[i], len - i);"
    ],
    [
     148,
     ""
    ],
    [
     149,
     "        if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, addr + i, word) != HAL_OK)"
    ],
    [
     150,
     "        {"
    ],
    [
     151,
     "            (void)HAL_FLASH_Lock();"
    ],
    [
     152,
     "            return HAL_ERROR;"
    ],
    [
     153,
     "        }"
    ],
    [
     154,
     "    }"
    ],
    [
     155,
     ""
    ],
    [
     156,
     "    (void)HAL_FLASH_Lock();"
    ],
    [
     157,
     ""
    ],
    [
     158,
     "    /* 回读校验（隐式自检，能提前发现擦除不干净/电压异常） */"
    ],
    [
     159,
     "    for (i = 0U; i < len; i++)"
    ],
    [
     160,
     "    {"
    ],
    [
     161,
     "        if (*((const volatile uint8_t *)(addr + i)) != data[i])"
    ],
    [
     162,
     "        {"
    ],
    [
     163,
     "            return HAL_ERROR;"
    ],
    [
     164,
     "        }"
    ],
    [
     165,
     "    }"
    ],
    [
     166,
     ""
    ],
    [
     167,
     "    return HAL_OK;"
    ],
    [
     168,
     "}"
    ]
   ]
  },
  "boot_ext_id": {
   "id": "boot_ext_id",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_ext.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_ext.c",
   "func": "boot_ext_init",
   "from": 20,
   "to": 50,
   "note": "boot_ext_init / boot_ext_jedec_id（0x9F 读 JEDEC）",
   "grade": "A",
   "lines": [
    [
     20,
     "int boot_ext_init(void)"
    ],
    [
     21,
     "{"
    ],
    [
     22,
     "    /* 配置 CS 为推挽输出，并在需要时重新初始化 SPI2 */"
    ],
    [
     23,
     "    W25Q64_InitConfig();"
    ],
    [
     24,
     ""
    ],
    [
     25,
     "    if (W25Q64_GetLastStatus() != HAL_OK)"
    ],
    [
     26,
     "    {"
    ],
    [
     27,
     "        return -1;"
    ],
    [
     28,
     "    }"
    ],
    [
     29,
     ""
    ],
    [
     30,
     "    return 0;"
    ],
    [
     31,
     "}"
    ],
    [
     32,
     ""
    ],
    [
     33,
     "uint32_t boot_ext_jedec_id(void)"
    ],
    [
     34,
     "{"
    ],
    [
     35,
     "    uint32_t id;"
    ],
    [
     36,
     "    uint8_t  mf;"
    ],
    [
     37,
     "    uint8_t  mt;"
    ],
    [
     38,
     "    uint8_t  cap;"
    ],
    [
     39,
     ""
    ],
    [
     40,
     "    W25Q64_CS_L();"
    ],
    [
     41,
     "    (void)W25Q64_ReadWriteByte(BOOT_EXT_CMD_JEDEC_ID);"
    ],
    [
     42,
     "    mf  = W25Q64_ReadWriteByte(0xFFU);   /* Manufacturer */"
    ],
    [
     43,
     "    mt  = W25Q64_ReadWriteByte(0xFFU);   /* Memory Type  */"
    ],
    [
     44,
     "    cap = W25Q64_ReadWriteByte(0xFFU);   /* Capacity     */"
    ],
    [
     45,
     "    W25Q64_CS_H();"
    ],
    [
     46,
     ""
    ],
    [
     47,
     "    id = ((uint32_t)mf << 16) | ((uint32_t)mt << 8) | (uint32_t)cap;"
    ],
    [
     48,
     ""
    ],
    [
     49,
     "    return id;"
    ],
    [
     50,
     "}"
    ]
   ]
  },
  "jump_validate": {
   "id": "jump_validate",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/app_jump.c",
   "path": "HAL_F429IGT6_bootloard/Boot/app_jump.c",
   "func": "app_jump_validate",
   "from": 31,
   "to": 61,
   "note": "app_jump_validate：地址区间 + MSP 落在 RAM + 复位向量落在 Flash",
   "grade": "A",
   "lines": [
    [
     31,
     "int app_jump_validate(uint32_t app_addr)"
    ],
    [
     32,
     "{"
    ],
    [
     33,
     "    uint32_t msp;"
    ],
    [
     34,
     "    uint32_t reset_vec;"
    ],
    [
     35,
     ""
    ],
    [
     36,
     "    /* 1. 地址必须落在 App A 槽内（严格区间，不放松） */"
    ],
    [
     37,
     "    if ((app_addr < OTA_APP_A_ADDR) ||"
    ],
    [
     38,
     "        (app_addr >= (OTA_APP_A_ADDR + OTA_APP_SIZE)))"
    ],
    [
     39,
     "    {"
    ],
    [
     40,
     "        return -1;"
    ],
    [
     41,
     "    }"
    ],
    [
     42,
     ""
    ],
    [
     43,
     "    /* 2. 读向量表前两个字 */"
    ],
    [
     44,
     "    msp       = *(volatile uint32_t *)(app_addr);"
    ],
    [
     45,
     "    reset_vec = *(volatile uint32_t *)(app_addr + 4U);"
    ],
    [
     46,
     ""
    ],
    [
     47,
     "    /* 3. 初始栈指针必须落在 RAM 内 */"
    ],
    [
     48,
     "    if (!(((msp >= APP_STACK_SRAM_BASE) && (msp <= APP_STACK_SRAM_END)) ||"
    ],
    [
     49,
     "          ((msp >= APP_STACK_CCM_BASE)  && (msp <= APP_STACK_CCM_END))))"
    ],
    [
     50,
     "    {"
    ],
    [
     51,
     "        return -1;"
    ],
    [
     52,
     "    }"
    ],
    [
     53,
     ""
    ],
    [
     54,
     "    /* 4. 复位向量必须落在片内 Flash 内 */"
    ],
    [
     55,
     "    if ((reset_vec < APP_FLASH_BASE) || (reset_vec >= APP_FLASH_END))"
    ],
    [
     56,
     "    {"
    ],
    [
     57,
     "        return -1;"
    ],
    [
     58,
     "    }"
    ],
    [
     59,
     ""
    ],
    [
     60,
     "    return 0;"
    ],
    [
     61,
     "}"
    ]
   ]
  },
  "jump_execute": {
   "id": "jump_execute",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/app_jump.c",
   "path": "HAL_F429IGT6_bootloard/Boot/app_jump.c",
   "func": "app_jump_execute",
   "from": 63,
   "to": 96,
   "note": "app_jump_execute：关外设 → 设 MSP → 设 VTOR → DSB/ISB → 开中断 → 跳转",
   "grade": "A",
   "lines": [
    [
     63,
     "void app_jump_execute(uint32_t app_addr)"
    ],
    [
     64,
     "{"
    ],
    [
     65,
     "    void (*entry)(void);"
    ],
    [
     66,
     ""
    ],
    [
     67,
     "    /* 地址先存到静态区：设完 MSP 之后，栈已经换成 App 的栈，"
    ],
    [
     68,
     "       如果从局部变量/参数（可能压在旧栈上）取值会读到脏数据。 */"
    ],
    [
     69,
     "    s_jump_addr = app_addr;"
    ],
    [
     70,
     ""
    ],
    [
     71,
     "    boot_log(\"[BL] shutdown peripherals, restore RCC to HSI...\\r\\n\");"
    ],
    [
     72,
     ""
    ],
    [
     73,
     "    /* 关外设 + 清 NVIC/DMA + 时钟树复位（内部已 __disable_irq） */"
    ],
    [
     74,
     "    boot_system_shutdown();"
    ],
    [
     75,
     ""
    ],
    [
     76,
     "    /* 设置 App 的初始栈指针 */"
    ],
    [
     77,
     "    __set_MSP(*(volatile uint32_t *)s_jump_addr);"
    ],
    [
     78,
     ""
    ],
    [
     79,
     "    /* 重定位向量表 */"
    ],
    [
     80,
     "    SCB->VTOR = s_jump_addr;"
    ],
    [
     81,
     "    __DSB();"
    ],
    [
     82,
     "    __ISB();"
    ],
    [
     83,
     ""
    ],
    [
     84,
     "    /* 清掉可能挂起的异常，再开总中断 */"
    ],
    [
     85,
     "    SCB->ICSR = SCB_ICSR_PENDSVCLR_Msk | SCB_ICSR_PENDSTCLR_Msk;"
    ],
    [
     86,
     "    __enable_irq();"
    ],
    [
     87,
     ""
    ],
    [
     88,
     "    /* 从 App 向量表取 Reset_Handler 并跳转（此调用不返回） */"
    ],
    [
     89,
     "    entry = (void (*)(void))(*(volatile uint32_t *)(s_jump_addr + 4U));"
    ],
    [
     90,
     "    entry();"
    ],
    [
     91,
     ""
    ],
    [
     92,
     "    /* 正常情况不会到这里 */"
    ],
    [
     93,
     "    for (;;)"
    ],
    [
     94,
     "    {"
    ],
    [
     95,
     "    }"
    ],
    [
     96,
     "}"
    ]
   ]
  },
  "shutdown": {
   "id": "shutdown",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_shutdown.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_shutdown.c",
   "func": "boot_system_shutdown",
   "from": 140,
   "to": 200,
   "note": "boot_system_shutdown 的 9 步清理（关中断/SysTick/NVIC/DMA/外设/时钟/使能/PendSV）",
   "grade": "A",
   "lines": [
    [
     140,
     "void boot_system_shutdown(void)"
    ],
    [
     141,
     "{"
    ],
    [
     142,
     "    uint32_t i;"
    ],
    [
     143,
     ""
    ],
    [
     144,
     "    /* 关中断前先喂一次狗，保证后面的清理动作不会被看门狗打断 */"
    ],
    [
     145,
     "    boot_wdg_feed();"
    ],
    [
     146,
     ""
    ],
    [
     147,
     "    /* ---- 1. 关全局中断 -------------------------------------------------- */"
    ],
    [
     148,
     "    __disable_irq();"
    ],
    [
     149,
     ""
    ],
    [
     150,
     "    /* ---- 2. 停 SysTick（BL 用 SysTick 做 HAL 时基） ---------------------- */"
    ],
    [
     151,
     "    SysTick->CTRL = 0UL;"
    ],
    [
     152,
     "    SysTick->LOAD = 0UL;"
    ],
    [
     153,
     "    SysTick->VAL  = 0UL;"
    ],
    [
     154,
     ""
    ],
    [
     155,
     "    /* ---- 3. 清 NVIC：使能位、挂起位、优先级 ----------------------------- */"
    ],
    [
     156,
     "    for (i = 0U; i < 8U; i++)"
    ],
    [
     157,
     "    {"
    ],
    [
     158,
     "        NVIC->ICER[i] = 0xFFFFFFFFUL;"
    ],
    [
     159,
     "        NVIC->ICPR[i] = 0xFFFFFFFFUL;"
    ],
    [
     160,
     "    }"
    ],
    [
     161,
     ""
    ],
    [
     162,
     "    for (i = 0U; i < BOOT_NVIC_IRQ_NUM; i++)"
    ],
    [
     163,
     "    {"
    ],
    [
     164,
     "        NVIC->IP[i] = 0U;"
    ],
    [
     165,
     "    }"
    ],
    [
     166,
     ""
    ],
    [
     167,
     "    /* ---- 4. 关掉全部 DMA 流（BL 用 USART1 TX/RX；App 还会用 USART1/3） -- */"
    ],
    [
     168,
     "    boot_dma_all_off();"
    ],
    [
     169,
     ""
    ],
    [
     170,
     "    /* ---- 5. 反初始化 BL 打开过的外设 ------------------------------------"
    ],
    [
     171,
     "       HAL_UART_DeInit / HAL_SPI_DeInit 会连带："
    ],
    [
     172,
     "         - 关闭外设时钟（USART1/SPI2）"
    ],
    [
     173,
     "         - 把对应引脚 deinit 成浮空输入"
    ],
    [
     174,
     "         - 反初始化关联的 DMA 流"
    ],
    [
     175,
     "         - 关闭对应 NVIC 通道"
    ],
    [
     176,
     "       必须在关闭总时钟前做（这些函数要写外设寄存器）。 */"
    ],
    [
     177,
     "    (void)HAL_UART_DeInit(&huart1);"
    ],
    [
     178,
     "    (void)HAL_SPI_DeInit(&hspi2);"
    ],
    [
     179,
     ""
    ],
    [
     180,
     "    /* ---- 6. 把 BL 碰过的引脚一律恢复成复位态 ----------------------------"
    ],
    [
     181,
     "       USART1: PA9/PA10；SPI2: PB13/PB14/PB15；片外 Flash CS: PB12 */"
    ],
    [
     182,
     "    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_9 | GPIO_PIN_10);"
    ],
    [
     183,
     "    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15);"
    ],
    [
     184,
     ""
    ],
    [
     185,
     "    /* ---- 7. 时钟树恢复为复位状态（HSI 16MHz） --------------------------- */"
    ],
    [
     186,
     "#if (BOOT_RESTORE_CLOCK_ON_JUMP == 1)"
    ],
    [
     187,
     "    boot_restore_clock_to_hsi();"
    ],
    [
     188,
     "#endif"
    ],
    [
     189,
     ""
    ],
    [
     190,
     "    /* ---- 8. 关闭所有外设时钟，给 App 一个\"干净的开机状态\" --------------"
    ],
    [
     191,
     "       这一句必须在最后：前面所有 deinit 都要用到外设时钟。 */"
    ],
    [
     192,
     "    RCC->AHB1ENR = 0UL;"
    ],
    [
     193,
     "    RCC->AHB2ENR = 0UL;"
    ],
    [
     194,
     "    RCC->AHB3ENR = 0UL;"
    ],
    [
     195,
     "    RCC->APB1ENR = 0UL;"
    ],
    [
     196,
     "    RCC->APB2ENR = 0UL;"
    ],
    [
     197,
     ""
    ],
    [
     198,
     "    /* ---- 9. 清掉可能挂起的 PendSV/SysTick（FreeRTOS 相关残留） ---------- */"
    ],
    [
     199,
     "    SCB->ICSR = SCB_ICSR_PENDSVCLR_Msk | SCB_ICSR_PENDSTCLR_Msk;"
    ],
    [
     200,
     "}"
    ]
   ]
  },
  "clock_hsi": {
   "id": "clock_hsi",
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_shutdown.c",
   "path": "HAL_F429IGT6_bootloard/Boot/boot_shutdown.c",
   "func": "boot_restore_clock_to_hsi",
   "from": 82,
   "to": 138,
   "note": "把时钟树恢复为 HSI 16MHz（BL 用 HSI-PLL，App 用 HSE-PLL）",
   "grade": "A",
   "lines": [
    [
     82,
     "void boot_restore_clock_to_hsi(void)"
    ],
    [
     83,
     "{"
    ],
    [
     84,
     "    uint32_t guard;"
    ],
    [
     85,
     ""
    ],
    [
     86,
     "    /* ---- 1. SYSCLK 切回 HSI（16MHz） -------------------------------------"
    ],
    [
     87,
     "       注意：切换前 Flash 等待周期仍是 5（180MHz 的值），"
    ],
    [
     88,
     "       频率降低时\"等待周期偏大\"永远安全，切完再调小。 */"
    ],
    [
     89,
     "    CLEAR_BIT(RCC->CFGR, RCC_CFGR_SW);"
    ],
    [
     90,
     ""
    ],
    [
     91,
     "    guard = 0x000FFFFFUL;"
    ],
    [
     92,
     "    while (((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) && (guard != 0U))"
    ],
    [
     93,
     "    {"
    ],
    [
     94,
     "        guard--;"
    ],
    [
     95,
     "    }"
    ],
    [
     96,
     ""
    ],
    [
     97,
     "    /* ---- 2. AHB / APB1 / APB2 分频全部恢复为 1，MCO/RTC 分频清掉 -------- */"
    ],
    [
     98,
     "    CLEAR_BIT(RCC->CFGR, RCC_CFGR_HPRE   | RCC_CFGR_PPRE1  | RCC_CFGR_PPRE2 |"
    ],
    [
     99,
     "                         RCC_CFGR_MCO1   | RCC_CFGR_MCO1PRE | RCC_CFGR_MCO2PRE |"
    ],
    [
     100,
     "                         RCC_CFGR_MCO2   | RCC_CFGR_RTCPRE   | RCC_CFGR_I2SSRC);"
    ],
    [
     101,
     ""
    ],
    [
     102,
     "    /* ---- 3. 关 PLL ------------------------------------------------------- */"
    ],
    [
     103,
     "    CLEAR_BIT(RCC->CR, RCC_CR_PLLON);"
    ],
    [
     104,
     ""
    ],
    [
     105,
     "    guard = 0x000FFFFFUL;"
    ],
    [
     106,
     "    while (((RCC->CR & RCC_CR_PLLRDY) != 0U) && (guard != 0U))"
    ],
    [
     107,
     "    {"
    ],
    [
     108,
     "        guard--;"
    ],
    [
     109,
     "    }"
    ],
    [
     110,
     ""
    ],
    [
     111,
     "    /* ---- 4. 关 HSE / CSS / BYPASS --------------------------------------- */"
    ],
    [
     112,
     "    CLEAR_BIT(RCC->CR, RCC_CR_CSSON | RCC_CR_HSEON | RCC_CR_HSEBYP);"
    ],
    [
     113,
     ""
    ],
    [
     114,
     "    guard = 0x000FFFFFUL;"
    ],
    [
     115,
     "    while (((RCC->CR & RCC_CR_HSERDY) != 0U) && (guard != 0U))"
    ],
    [
     116,
     "    {"
    ],
    [
     117,
     "        guard--;"
    ],
    [
     118,
     "    }"
    ],
    [
     119,
     ""
    ],
    [
     120,
     "    /* ---- 5. PLL 配置寄存器恢复复位值（0x24003010 是 F4 的复位值） ------- */"
    ],
    [
     121,
     "    RCC->PLLCFGR = 0x24003010UL;"
    ],
    [
     122,
     ""
    ],
    [
     123,
     "    /* ---- 6. 关掉所有 RCC 中断（CSS/LSE/RTC 等） -------------------------- */"
    ],
    [
     124,
     "    RCC->CIR = 0UL;"
    ],
    [
     125,
     ""
    ],
    [
     126,
     "    /* ---- 7. 主频只有 16MHz，Flash 等待周期降到 0 ------------------------- */"
    ],
    [
     127,
     "    __HAL_FLASH_SET_LATENCY(FLASH_LATENCY_0);"
    ],
    [
     128,
     ""
    ],
    [
     129,
     "    guard = 0x000FFFFFUL;"
    ],
    [
     130,
     "    while ((__HAL_FLASH_GET_LATENCY() != FLASH_LATENCY_0) && (guard != 0U))"
    ],
    [
     131,
     "    {"
    ],
    [
     132,
     "        guard--;"
    ],
    [
     133,
     "    }"
    ],
    [
     134,
     ""
    ],
    [
     135,
     "    /* 说明：LSI 故意不动 —— 看门狗（若已启动）靠它运行，且 App 侧也可能用。"
    ],
    [
     136,
     "       OverDrive 也故意不关：HAL_PWREx_EnableOverDrive() 是幂等的，"
    ],
    [
     137,
     "       保持开启反而少一个\"关不掉/等超时\"的风险点。 */"
    ],
    [
     138,
     "}"
    ]
   ]
  },
  "app_partition": {
   "id": "app_partition",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/partition.h",
   "path": "HAL_F429IGT6_App/OTA/partition.h",
   "func": "(非函数体)",
   "from": 60,
   "to": 95,
   "note": "App 侧同一份分区表（与 BL 必须逐字节一致）与启动标志定义",
   "grade": "A",
   "lines": [
    [
     60,
     "#define OTA_APP_A_ADDR            0x08010000UL"
    ],
    [
     61,
     "#define OTA_APP_SIZE              0x000F0000UL   /* 960KB */"
    ],
    [
     62,
     ""
    ],
    [
     63,
     "/* 固件镜像上限：等于 A 槽大小 */"
    ],
    [
     64,
     "#define OTA_APP_IMAGE_MAX_SIZE    0x000F0000UL"
    ],
    [
     65,
     ""
    ],
    [
     66,
     "/* ===================== 片外 W25Q64（8MB） ===================== */"
    ],
    [
     67,
     ""
    ],
    [
     68,
     "#define EXT_FLASH_SIZE            (8UL * 1024UL * 1024UL)   /* 0x00800000 */"
    ],
    [
     69,
     ""
    ],
    [
     70,
     "/* 三个区各 960KB（= 15 × 64KB，正好是 64KB 块擦除的整数倍） */"
    ],
    [
     71,
     "#define EXT_REGION_SIZE           0x000F0000UL"
    ],
    [
     72,
     ""
    ],
    [
     73,
     "#define EXT_STAGING_ADDR          0x00000000UL                            /* 新固件暂存 */"
    ],
    [
     74,
     "#define EXT_BACKUP_ADDR           (EXT_STAGING_ADDR  + EXT_REGION_SIZE)   /* 0x000F0000 旧固件备份 */"
    ],
    [
     75,
     "#define EXT_RECOVERY_ADDR         (EXT_BACKUP_ADDR   + EXT_REGION_SIZE)   /* 0x001E0000 出厂固件 */"
    ],
    [
     76,
     "#define EXT_RESOURCE_ADDR         (EXT_RECOVERY_ADDR + EXT_REGION_SIZE)   /* 0x002D0000 预留 */"
    ],
    [
     77,
     ""
    ],
    [
     78,
     "/* ===================== 启动标志 ===================== */"
    ],
    [
     79,
     ""
    ],
    [
     80,
     "#define OTA_BOOT_FLAG_NORMAL      0UL   /* 正常启动 */"
    ],
    [
     81,
     "#define OTA_BOOT_FLAG_TRY_NEW     1UL   /* 尝试启动新固件（升级完成重启后） */"
    ],
    [
     82,
     "#define OTA_BOOT_FLAG_ROLLBACK    2UL   /* 回滚到备份版本 */"
    ],
    [
     83,
     "#define OTA_BOOT_FLAG_RECOVERY    3UL   /* 恢复出厂（从恢复区拷贝） */"
    ],
    [
     84,
     ""
    ],
    [
     85,
     "/* 备份区状态 */"
    ],
    [
     86,
     "#define OTA_BACKUP_EMPTY          0x00U"
    ],
    [
     87,
     "#define OTA_BACKUP_DOWNLOADING    0x01U"
    ],
    [
     88,
     "#define OTA_BACKUP_VALID          0x02U"
    ],
    [
     89,
     ""
    ],
    [
     90,
     "/* 新固件连续启动失败达到该次数即自动回滚 */"
    ],
    [
     91,
     "#define OTA_BOOT_MAX_TRIES        3UL"
    ],
    [
     92,
     ""
    ],
    [
     93,
     "/* 版本号编码：V1.2.3 -> 0x010203 */"
    ],
    [
     94,
     "#define OTA_VERSION(major, minor, patch) \\"
    ],
    [
     95,
     "    ((((uint32_t)(major)) << 16) | (((uint32_t)(minor)) << 8) | ((uint32_t)(patch)))"
    ]
   ]
  },
  "app_cfg_version": {
   "id": "app_cfg_version",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_config.h",
   "path": "HAL_F429IGT6_App/OTA/ota_config.h",
   "func": "(非函数体)",
   "from": 44,
   "to": 50,
   "note": "版本号两行必须同步修改：NUM 用于防降级，STR 用于上报",
   "grade": "A",
   "lines": [
    [
     44,
     "/* ===================== 固件版本 ===================== */"
    ],
    [
     45,
     ""
    ],
    [
     46,
     "/* 内部比较编码（防降级），发布新固件时与下一行同步修改 */"
    ],
    [
     47,
     "#define OTA_APP_VERSION_NUM     OTA_VERSION(1, 0, 0)"
    ],
    [
     48,
     ""
    ],
    [
     49,
     "/* 上报平台的版本字符串：必须与平台升级包的版本号\"不同且更小\"才匹配得到任务 */"
    ],
    [
     50,
     "#define OTA_APP_VERSION_STR     \"1.0.0\""
    ]
   ]
  },
  "app_cfg_dl": {
   "id": "app_cfg_dl",
   "project": "HAL_F429IGT6_App_2",
   "file": "OTA/ota_config.h",
   "path": "HAL_F429IGT6_App_2/OTA/ota_config.h",
   "func": "(非函数体)",
   "from": 52,
   "to": 99,
   "note": "OTA_DL_CHUNK=256 / 检查点 16384 / 启动确认窗口 30000ms",
   "grade": "A",
   "lines": [
    [
     52,
     "/* ===================== 下载参数 ===================== */"
    ],
    [
     53,
     ""
    ],
    [
     54,
     "/*"
    ],
    [
     55,
     " * 攒块大小：攒够这么多字节才写一次外部 Flash。"
    ],
    [
     56,
     " *"
    ],
    [
     57,
     " * ⚠ 这个值同时影响两件事：写 Flash 的总次数（吞吐）和单次阻塞时长（丢字节概率）。"
    ],
    [
     58,
     " *"
    ],
    [
     59,
     " *   1) 吞吐：本工程 bsp/W25q64 的 WriteDataInternal() 每当 0xFF 预检通过就会做一次"
    ],
    [
     60,
     " *      page program（典型 0.4ms 忙等）。若按 4 字节一写："
    ],
    [
     61,
     " *        72KB  -> 18432 次 -> 约 7.4 秒；960KB -> 245760 次 -> 约 98 秒"
    ],
    [
     62,
     " *      1024 字节攒块：72KB -> 288 次 -> 约 0.12 秒（吞吐早就够了，不是瓶颈）"
    ],
    [
     63,
     " *"
    ],
    [
     64,
     " *   2) 丢字节：实测 1024 攒块时，每次写 Flash 阻塞约 2ms，期间 UART 进来约 23 字节，"
    ],
    [
     65,
     " *      但在 ESP8266 突发推送 1460 字节 TCP 段的瞬间，生产者会短时超过消费者，"
    ],
    [
     66,
     " *      导致 +IPD 帧头错位、后续数据停住（表现为 TRUNCATED，然后必须整套重下）。"
    ],
    [
     67,
     " *      三次升级实测 100% 命中了这个问题，每次都要\"下载两遍\"。"
    ],
    [
     68,
     " *"
    ],
    [
     69,
     " *   -> 改成 256 后，单次阻塞降到约 0.5ms，消费节奏更密，明显降低错位概率；"
    ],
    [
     70,
     " *      代价是写 Flash 次数增加 4 倍（72KB -> 373 次），总耗时仍只增加约 0.1 秒。"
    ],
    [
     71,
     " *      （W25Q64 的 page program 按 256 字节页对齐，256 攒块正好是整页，没有额外开销）"
    ],
    [
     72,
     " */"
    ],
    [
     73,
     "#define OTA_DL_CHUNK            256U"
    ],
    [
     74,
     ""
    ],
    [
     75,
     "/* 断点续传检查点：每写这么多字节保存一次参数区 */"
    ],
    [
     76,
     "#define OTA_CHECKPOINT_INTERVAL 16384U"
    ],
    [
     77,
     ""
    ],
    [
     78,
     "/*"
    ],
    [
     79,
     " * 下载进度上报粒度（百分比）。"
    ],
    [
     80,
     " * 100 = 不中途上报（只在下载完成时报一次 step=100）。"
    ],
    [
     81,
     " * 原因：ESP8266 单连接下\"中途上报\"必须\"断开连接->发 HTTP->再 Range 续传\"，"
    ],
    [
     82,
     " *       轮次多、失败面大。72KB 只要约 7 秒，86400 字节/960KB 约 90 秒，"
    ],
    [
     83,
     " *       一次性下载完全可接受，因此默认关闭中途上报。"
    ],
    [
     84,
     " */"
    ],
    [
     85,
     "#define OTA_PROGRESS_STEP       100U"
    ],
    [
     86,
     ""
    ],
    [
     87,
     "/* ===================== 行为开关 ===================== */"
    ],
    [
     88,
     ""
    ],
    [
     89,
     "/*"
    ],
    [
     90,
     " * 1 = 只\"下载 + 备份 + 写参数\"，不置 TRY_NEW、不复位（P3a 用）"
    ],
    [
     91,
     " * 0 = 走完整流程：置 TRY_NEW + NVIC_SystemReset()，由 BootLoader 拷贝并试运行（P3b 用）"
    ],
    [
     92,
     " *"
    ],
    [
     93,
     " * P3a 阶段设 1 的目的：先把\"能不能把 72KB 完整写进 W25Q64 并通过 SHA-256\"验证掉，"
    ],
    [
     94,
     " * 避免第一次就把板子刷成未知状态（万一固件有问题，A 槽被擦一半会很难查）。"
    ],
    [
     95,
     " */"
    ],
    [
     96,
     "#define OTA_TEST_NO_REBOOT      0"
    ],
    [
     97,
     ""
    ],
    [
     98,
     "/* 启动成功后保持运行的静默窗口：满这么久才固化为 NORMAL 并上报 201 */"
    ],
    [
     99,
     "#define OTA_STARTUP_CONFIRM_MS  30000U"
    ]
   ]
  },
  "app_main": {
   "id": "app_main",
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/main.c",
   "path": "HAL_F429IGT6_App/Core/Src/main.c",
   "func": "main",
   "from": 207,
   "to": 270,
   "note": "App 的 main()：VTOR 重定位必须早于 HAL_Init()",
   "grade": "A",
   "lines": [
    [
     207,
     "int main(void)"
    ],
    [
     208,
     "{"
    ],
    [
     209,
     ""
    ],
    [
     210,
     "  /* USER CODE BEGIN 1 */"
    ],
    [
     211,
     ""
    ],
    [
     212,
     "  /* 【OTA 向量表重定位】把中断向量表指向 App 自己的基址。"
    ],
    [
     213,
     "   *"
    ],
    [
     214,
     "   * 为什么必须放在这里（HAL_Init 之前）："
    ],
    [
     215,
     "   *   上电时 CPU 从 0x08000000 取向量表（那是 BootLoader 的），VTOR 也指向那里。"
    ],
    [
     216,
     "   *   如果不重定位，App 里所有中断（SysTick/TIM14/USART/DMA…）都会跳进"
    ],
    [
     217,
     "   *   BootLoader 的向量表，进到错误的函数里 → 表现为\"能跑但中断全乱\"/HardFault。"
    ],
    [
     218,
     "   *   HAL_Init() 会启动 TIM14 时基中断，所以必须抢在它之前设置好。"
    ],
    [
     219,
     "   *"
    ],
    [
     220,
     "   * 这个值必须与两处完全一致（三处同源）："
    ],
    [
     221,
     "   *   1) 本工程 Keil 魔术棒 IROM1 的 Start = 0x08010000"
    ],
    [
     222,
     "   *   2) BootLoader 的 Boot/partition.h 里 OTA_APP_A_ADDR = 0x08010000"
    ],
    [
     223,
     "   * 现在是\"先验证能否跳转\"的临时硬编码，等 OTA 整体移植时改成引用 partition.h 的宏。"
    ],
    [
     224,
     "   */"
    ],
    [
     225,
     "  SCB->VTOR = 0x08010000UL;/* ① 写向量表基址（可能还在写缓冲里） */"
    ],
    [
     226,
     "  __DSB();                     /* ② 等 ① 真正写完 */"
    ],
    [
     227,
     "  __ISB();                     /* ③ 清掉流水线里已预取的旧指令，后续取指/异常入口都按新表走 */"
    ],
    [
     228,
     ""
    ],
    [
     229,
     "  /* USER CODE END 1 */"
    ],
    [
     230,
     ""
    ],
    [
     231,
     "  /* MCU Configuration--------------------------------------------------------*/"
    ],
    [
     232,
     ""
    ],
    [
     233,
     "  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */"
    ],
    [
     234,
     "  HAL_Init();"
    ],
    [
     235,
     ""
    ],
    [
     236,
     "  /* USER CODE BEGIN Init */"
    ],
    [
     237,
     "  led_boot_blink(3);"
    ],
    [
     238,
     "  /* USER CODE END Init */"
    ],
    [
     239,
     ""
    ],
    [
     240,
     "  /* Configure the system clock */"
    ],
    [
     241,
     "  SystemClock_Config();"
    ],
    [
     242,
     ""
    ],
    [
     243,
     "  /* USER CODE BEGIN SysInit */"
    ],
    [
     244,
     ""
    ],
    [
     245,
     "  /* USER CODE END SysInit */"
    ],
    [
     246,
     ""
    ],
    [
     247,
     "  /* Initialize all configured peripherals */"
    ],
    [
     248,
     "  MX_GPIO_Init();"
    ],
    [
     249,
     "  MX_DMA_Init();"
    ],
    [
     250,
     "  MX_USART1_UART_Init();"
    ],
    [
     251,
     "  MX_TIM1_Init();"
    ],
    [
     252,
     "  MX_TIM3_Init();"
    ],
    [
     253,
     "  MX_SPI2_Init();"
    ],
    [
     254,
     "  MX_USART3_UART_Init();"
    ],
    [
     255,
     "  /* USER CODE BEGIN 2 */"
    ],
    [
     256,
     ""
    ],
    [
     257,
     "//  W25Q64_RunSelfTest();"
    ],
    [
     258,
     "  "
    ],
    [
     259,
     "  //Load_Drow_Dialog();"
    ],
    [
     260,
     "  //ctp_test();"
    ],
    [
     261,
     ""
    ],
    [
     262,
     "  /* USER CODE END 2 */"
    ],
    [
     263,
     ""
    ],
    [
     264,
     "  /* Call init function for freertos objects (in cmsis_os2.c) */"
    ],
    [
     265,
     "  MX_FREERTOS_Init();"
    ],
    [
     266,
     ""
    ],
    [
     267,
     "  /* Start scheduler */"
    ],
    [
     268,
     "  osKernelStart();"
    ],
    [
     269,
     ""
    ],
    [
     270,
     "  /* We should never get here as control is now taken by the scheduler */"
    ]
   ]
  },
  "app_main_vtor": {
   "id": "app_main_vtor",
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/main.c",
   "path": "HAL_F429IGT6_App/Core/Src/main.c",
   "func": "main() 开头",
   "from": 210,
   "to": 232,
   "note": "★ SCB->VTOR = 0x08010000，否则所有中断都跳进 BL 的向量表",
   "grade": "A",
   "lines": [
    [
     210,
     "  /* USER CODE BEGIN 1 */"
    ],
    [
     211,
     ""
    ],
    [
     212,
     "  /* 【OTA 向量表重定位】把中断向量表指向 App 自己的基址。"
    ],
    [
     213,
     "   *"
    ],
    [
     214,
     "   * 为什么必须放在这里（HAL_Init 之前）："
    ],
    [
     215,
     "   *   上电时 CPU 从 0x08000000 取向量表（那是 BootLoader 的），VTOR 也指向那里。"
    ],
    [
     216,
     "   *   如果不重定位，App 里所有中断（SysTick/TIM14/USART/DMA…）都会跳进"
    ],
    [
     217,
     "   *   BootLoader 的向量表，进到错误的函数里 → 表现为\"能跑但中断全乱\"/HardFault。"
    ],
    [
     218,
     "   *   HAL_Init() 会启动 TIM14 时基中断，所以必须抢在它之前设置好。"
    ],
    [
     219,
     "   *"
    ],
    [
     220,
     "   * 这个值必须与两处完全一致（三处同源）："
    ],
    [
     221,
     "   *   1) 本工程 Keil 魔术棒 IROM1 的 Start = 0x08010000"
    ],
    [
     222,
     "   *   2) BootLoader 的 Boot/partition.h 里 OTA_APP_A_ADDR = 0x08010000"
    ],
    [
     223,
     "   * 现在是\"先验证能否跳转\"的临时硬编码，等 OTA 整体移植时改成引用 partition.h 的宏。"
    ],
    [
     224,
     "   */"
    ],
    [
     225,
     "  SCB->VTOR = 0x08010000UL;/* ① 写向量表基址（可能还在写缓冲里） */"
    ],
    [
     226,
     "  __DSB();                     /* ② 等 ① 真正写完 */"
    ],
    [
     227,
     "  __ISB();                     /* ③ 清掉流水线里已预取的旧指令，后续取指/异常入口都按新表走 */"
    ],
    [
     228,
     ""
    ],
    [
     229,
     "  /* USER CODE END 1 */"
    ],
    [
     230,
     ""
    ],
    [
     231,
     "  /* MCU Configuration--------------------------------------------------------*/"
    ],
    [
     232,
     ""
    ]
   ]
  },
  "freertos_init": {
   "id": "freertos_init",
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/freertos.c",
   "path": "HAL_F429IGT6_App/Core/Src/freertos.c",
   "func": "MX_FREERTOS_Init",
   "from": 142,
   "to": 215,
   "note": "MX_FREERTOS_Init：外设/屏幕/Flash/参数区/算法自检 + esp8266_Init",
   "grade": "A",
   "lines": [
    [
     142,
     "void MX_FREERTOS_Init(void) {"
    ],
    [
     143,
     "  /* USER CODE BEGIN Init */"
    ],
    [
     144,
     ""
    ],
    [
     145,
     "  UART_NVIC_Config();"
    ],
    [
     146,
     ""
    ],
    [
     147,
     "  delay_init(SystemCoreClock / 1000000U);"
    ],
    [
     148,
     "  LED_Init();"
    ],
    [
     149,
     "  KEY_Init();"
    ],
    [
     150,
     ""
    ],
    [
     151,
     "  SDRAM_Init();"
    ],
    [
     152,
     ""
    ],
    [
     153,
     "  LCD_Init();"
    ],
    [
     154,
     "  printf(\"LCD OK id=0x%04X %ux%u\\r\\n\", lcddev.id, lcddev.width, lcddev.height);"
    ],
    [
     155,
     ""
    ],
    [
     156,
     "  tp_dev.init();"
    ],
    [
     157,
     "  printf(\"TP OK type=0x%02X\\r\\n\", tp_dev.touchtype);"
    ],
    [
     158,
     ""
    ],
    [
     159,
     "  POINT_COLOR = RED;"
    ],
    [
     160,
     "  LCD_ShowString(30, 50, 200, 16, 16, \"Apollo STM32F4\");"
    ],
    [
     161,
     "  LCD_ShowString(30, 70, 200, 16, 16, \"TOUCH TEST\");"
    ],
    [
     162,
     "  LCD_ShowString(30, 90, 200, 16, 16, \"7 inch RGB CTP\");"
    ],
    [
     163,
     "  if (tp_dev.touchtype != 0XFF)"
    ],
    [
     164,
     "  {"
    ],
    [
     165,
     "    LCD_ShowString(30, 110, 200, 16, 16, \"Press KEY0 to Adjust\");"
    ],
    [
     166,
     "  }"
    ],
    [
     167,
     ""
    ],
    [
     168,
     "  if (uart_start_receive(&huart1, (uint8_t *)uart1_Recived_buf) != HAL_OK)"
    ],
    [
     169,
     "  {"
    ],
    [
     170,
     "    printf(\"USART1 RX start failed\\r\\n\");"
    ],
    [
     171,
     "  }"
    ],
    [
     172,
     "  if (uart_start_receive(&huart3, (uint8_t *)uart3_Recived_buf) != HAL_OK)"
    ],
    [
     173,
     "  {"
    ],
    [
     174,
     "    printf(\"USART3 RX start failed\\r\\n\");"
    ],
    [
     175,
     "  }"
    ],
    [
     176,
     "  "
    ],
    [
     177,
     "\tw25q16_init();"
    ],
    [
     178,
     "\tuint32_t id = w25q16_read_jedec_id();"
    ],
    [
     179,
     "\tprintf(\"W25Q64 JEDEC ID = 0x%06lX  %s\\r\\n\", (unsigned long)id,"
    ],
    [
     180,
     "\t\t   (id == W25Q_EXT_JEDEC_W25Q64) ? \"OK\" : \"FAIL\"); "
    ],
    [
     181,
     "  /* ---- P1 �Լ� �ڣ�������ֻ�� ---- */"
    ],
    [
     182,
     "  {"
    ],
    [
     183,
     "    extern int param_area_load(ota_param_t *param);   /* ���� param_area.h */"
    ],
    [
     184,
     "    ota_param_t p;"
    ],
    [
     185,
     "    int r = param_area_load(&p);"
    ],
    [
     186,
     "    printf(\"param load=%d magic=0x%08lX flag=%lu ver=0x%06lX\\r\\n\","
    ],
    [
     187,
     "           r, (unsigned long)p.magic,"
    ],
    [
     188,
     "           (unsigned long)p.boot_flag, (unsigned long)p.version);"
    ],
    [
     189,
     "  }"
    ],
    [
     190,
     ""
    ],
    [
     191,
     "  /* ---- P1 �Լ� �ۣ�SHA256 / MD5 �㷨 ---- */"
    ],
    [
     192,
     "  {"
    ],
    [
     193,
     "    static const uint8_t sha_abc[32] = {"
    ],
    [
     194,
     "      0xba,0x78,0x16,0xbf,0x8f,0x01,0xcf,0xea,0x41,0x41,0x40,0xde,"
    ],
    [
     195,
     "      0x5d,0xae,0x22,0x23,0xb0,0x03,0x61,0xa3,0x96,0x17,0x7a,0x9c,"
    ],
    [
     196,
     "      0xb4,0x10,0xff,0x61,0xf2,0x00,0x15,0xad };"
    ],
    [
     197,
     "    static const uint8_t md5_abc[16] = {"
    ],
    [
     198,
     "      0x90,0x01,0x50,0x98,0x3c,0xd2,0x4f,0xb0,"
    ],
    [
     199,
     "      0xd6,0x96,0x3f,0x7d,0x28,0xe1,0x7f,0x72 };"
    ],
    [
     200,
     "    uint8_t d32[32], d16[16];"
    ],
    [
     201,
     "    sha256_compute((const uint8_t *)\"abc\", 3, d32);"
    ],
    [
     202,
     "    md5_compute((const uint8_t *)\"abc\", 3, d16);"
    ],
    [
     203,
     "    printf(\"SHA256(abc)=%s  MD5(abc)=%s\\r\\n\","
    ],
    [
     204,
     "           sha256_equal(d32, sha_abc) ? \"OK\" : \"FAIL\","
    ],
    [
     205,
     "           md5_equal(d16, md5_abc)    ? \"OK\" : \"FAIL\");"
    ],
    [
     206,
     "  }"
    ],
    [
     207,
     ""
    ],
    [
     208,
     "  "
    ],
    [
     209,
     "  printf(\"FreeRTOS Start\\r\\n\");"
    ],
    [
     210,
     "\t"
    ],
    [
     211,
     "  esp8266_Init();"
    ],
    [
     212,
     "  /* USER CODE END Init */"
    ],
    [
     213,
     ""
    ],
    [
     214,
     "  /* USER CODE BEGIN RTOS_MUTEX */"
    ],
    [
     215,
     "  /* add mutexes, ... */"
    ]
   ]
  },
  "freertos_task": {
   "id": "freertos_task",
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/freertos.c",
   "path": "HAL_F429IGT6_App/Core/Src/freertos.c",
   "func": "StartDefaultTask",
   "from": 257,
   "to": 291,
   "note": "StartDefaultTask：ota_p2_selftest() 后进入 100ms 轮询业务循环",
   "grade": "A",
   "lines": [
    [
     257,
     "void StartDefaultTask(void const * argument)"
    ],
    [
     258,
     "{"
    ],
    [
     259,
     "  /* USER CODE BEGIN StartDefaultTask */"
    ],
    [
     260,
     "  /* If this line is missing, the scheduler never reached this task. */"
    ],
    [
     261,
     "  printf(\"[RTOS] StartDefaultTask running, free heap=%u\\r\\n\","
    ],
    [
     262,
     "         (unsigned int)xPortGetFreeHeapSize());"
    ],
    [
     263,
     ""
    ],
    [
     264,
     "  /* ---- P2 selftest: OTA network handover (comment out after pass) ---- */"
    ],
    [
     265,
     "  ota_p2_selftest();"
    ],
    [
     266,
     "  /* --------------------------------------------------------------------- */"
    ],
    [
     267,
     ""
    ],
    [
     268,
     "  /* Infinite loop */"
    ],
    [
     269,
     "  for(;;)"
    ],
    [
     270,
     "  {"
    ],
    [
     271,
     "    /* uart_printf uses DMA. If the DMA TX complete callback never runs, gState"
    ],
    [
     272,
     "       stays BUSY_TX and the message is dropped after the 100 ms guard. */"
    ],
    [
     273,
     "//    if (huart1.gState != HAL_UART_STATE_READY)"
    ],
    [
     274,
     "//    {"
    ],
    [
     275,
     "//      printf(\"[UART] huart1.gState=%u not ready\\r\\n\", (unsigned int)huart1.gState);"
    ],
    [
     276,
     "//    }"
    ],
    [
     277,
     ""
    ],
    [
     278,
     "//    uart_printf(&huart1, \"OK while, min free heap=%u\\r\\n\","
    ],
    [
     279,
     "//                (unsigned int)xPortGetMinimumEverFreeHeapSize());"
    ],
    [
     280,
     "\tstatic uint8_t count;"
    ],
    [
     281,
     "\tuart_process();"
    ],
    [
     282,
     "\t  if(onenet_count != count)"
    ],
    [
     283,
     "\t  {"
    ],
    [
     284,
     "\t\tuart_printf(&huart1, \"onenet_count=%d\\r\\n\",onenet_count);"
    ],
    [
     285,
     "\t\tcount = onenet_count;  "
    ],
    [
     286,
     "\t  }"
    ],
    [
     287,
     "    key_scan();"
    ],
    [
     288,
     ""
    ],
    [
     289,
     "    osDelay(100);"
    ],
    [
     290,
     "  }"
    ],
    [
     291,
     "  /* USER CODE END StartDefaultTask */"
    ]
   ]
  },
  "esp8266_init": {
   "id": "esp8266_init",
   "project": "HAL_F429IGT6_App",
   "file": "App/esp_handle.c",
   "path": "HAL_F429IGT6_App/App/esp_handle.c",
   "func": "esp8266_Init",
   "from": 37,
   "to": 66,
   "note": "esp8266_Init：AT+RST/CWMODE/CWJAP/MQTTUSERCFG/MQTTCONN/MQTTSUB（GBK 源文件）",
   "grade": "A",
   "lines": [
    [
     37,
     "void esp8266_Init(void)"
    ],
    [
     38,
     "{"
    ],
    [
     39,
     "    HAL_Delay(300);"
    ],
    [
     40,
     ""
    ],
    [
     41,
     "\tuart_printf(&huart3, \"AT+RST=1\\r\\n\");"
    ],
    [
     42,
     "\tuart_printf(&huart1, \"AT+RST=1\\r\\n\");"
    ],
    [
     43,
     "\tHAL_Delay(3000);"
    ],
    [
     44,
     "\t"
    ],
    [
     45,
     "    uart_printf(&huart3,\"AT+CWMODE=1\\r\\n\");"
    ],
    [
     46,
     "\tuart_printf(&huart1,\"AT+CWMODE=1\\r\\n\");\t"
    ],
    [
     47,
     "    HAL_Delay(1000);"
    ],
    [
     48,
     ""
    ],
    [
     49,
     "\tuart_printf(&huart3,\"AT+CWJAP=\\\"%s\\\",\\\"%s\\\"\\r\\n\", wifi_name, wifi_pass);"
    ],
    [
     50,
     "\tuart_printf(&huart1,\"AT+CWJAP=\\\"%s\\\",\\\"%s\\\"\\r\\n\", wifi_name, wifi_pass);"
    ],
    [
     51,
     "    HAL_Delay(3500);"
    ],
    [
     52,
     "\t"
    ],
    [
     53,
     "\tuart_printf(&huart3,\"AT+MQTTUSERCFG=0,1,\\\"%s\\\",\\\"%s\\\",\\\"%s\\\",0,0,\\\"\\\"\\r\\n\", device_name, produce_ID, token);\t\t"
    ],
    [
     54,
     "\tuart_printf(&huart1,\"AT+MQTTUSERCFG=0,1,\\\"%s\\\",\\\"%s\\\",\\\"%s\\\",0,0,\\\"\\\"\\r\\n\", device_name, produce_ID, token);\t"
    ],
    [
     55,
     "    HAL_Delay(4000);"
    ],
    [
     56,
     "\t"
    ],
    [
     57,
     "    uart_printf(&huart3,\"AT+MQTTCONN=0,\\\"mqtts.heclouds.com\\\",1883,1\\r\\n\");"
    ],
    [
     58,
     "\tuart_printf(&huart1,\"AT+MQTTCONN=0,\\\"mqtts.heclouds.com\\\",1883,1\\r\\n\");"
    ],
    [
     59,
     "    HAL_Delay(2500);"
    ],
    [
     60,
     "\t"
    ],
    [
     61,
     "    uart_printf(&huart3, \"AT+MQTTSUB=0,\\\"%s\\\",0\\r\\n\", subscribe_topic);"
    ],
    [
     62,
     "\tuart_printf(&huart1, \"AT+MQTTSUB=0,\\\"%s\\\",0\\r\\n\", subscribe_topic);"
    ],
    [
     63,
     "    HAL_Delay(500);"
    ],
    [
     64,
     "\t"
    ],
    [
     65,
     "    HAL_UARTEx_ReceiveToIdle_DMA(&huart3, (uint8_t *)uart3_Recived_buf, 512);\t"
    ],
    [
     66,
     "}"
    ]
   ]
  },
  "uart_process_hook": {
   "id": "uart_process_hook",
   "project": "HAL_F429IGT6_App",
   "file": "App/esp_handle.c",
   "path": "HAL_F429IGT6_App/App/esp_handle.c",
   "func": "uart_process",
   "from": 433,
   "to": 482,
   "note": "uart_process：解析 +MQTTSUBRECV 后把 ident 交给 ota_task_on_update_ident",
   "grade": "A",
   "lines": [
    [
     433,
     "void uart_process(void)"
    ],
    [
     434,
     "{"
    ],
    [
     435,
     "    char msg_id[64] = {0};"
    ],
    [
     436,
     "    char ident[32] = {0};"
    ],
    [
     437,
     "    char value[32] = {0};"
    ],
    [
     438,
     ""
    ],
    [
     439,
     "    int32_t parsed_value = 0;"
    ],
    [
     440,
     "    OnenetValueType parsed_type = ONENET_VALUE_INVALID;"
    ],
    [
     441,
     ""
    ],
    [
     442,
     "    /* 1. 没有新数据就直接返回 */"
    ],
    [
     443,
     "    if (uart3_key == 0)"
    ],
    [
     444,
     "        return;"
    ],
    [
     445,
     ""
    ],
    [
     446,
     "    uart3_key = 0;"
    ],
    [
     447,
     ""
    ],
    [
     448,
     "    /* 2. 确保接收缓冲区以 '\\0' 结尾 */"
    ],
    [
     449,
     "    uart3_Recived_buf[255] = '\\0';"
    ],
    [
     450,
     ""
    ],
    [
     451,
     "    /* 3. 判断是否为 OneNET MQTT 下发消息 */"
    ],
    [
     452,
     "    if (strstr((char *)uart3_Recived_buf,"
    ],
    [
     453,
     "               \"+MQTTSUBRECV\") != NULL)"
    ],
    [
     454,
     "    {"
    ],
    [
     455,
     "        /* 4. 解析消息 ID、标识符和数值 */"
    ],
    [
     456,
     "        if (extract_mqtt_info("
    ],
    [
     457,
     "\t\t\t\t\t\t\t(char *)uart3_Recived_buf,"
    ],
    [
     458,
     "\t\t\t\t\t\t\tmsg_id, sizeof(msg_id),"
    ],
    [
     459,
     "\t\t\t\t\t\t\tident, sizeof(ident),"
    ],
    [
     460,
     "\t\t\t\t\t\t\tvalue, sizeof(value),"
    ],
    [
     461,
     "\t\t\t\t\t\t\t&parsed_value,"
    ],
    [
     462,
     "\t\t\t\t\t\t\t&parsed_type))"
    ],
    [
     463,
     "        {"
    ],
    [
     464,
     "            /*"
    ],
    [
     465,
     "             * 5. 保存解析结果"
    ],
    [
     466,
     "             *    onenet_numeric_value //  onenet_value_type"
    ],
    [
     467,
     "             * true  -> 1"
    ],
    [
     468,
     "             * false -> 0"
    ],
    [
     469,
     "             * 3     -> 3"
    ],
    [
     470,
     "             * 4     -> 4"
    ],
    [
     471,
     "             * 5     -> 5"
    ],
    [
     472,
     "             */"
    ],
    [
     473,
     "            onenet_numeric_value = parsed_value;"
    ],
    [
     474,
     "            onenet_value_type    = parsed_type;"
    ],
    [
     475,
     ""
    ],
    [
     476,
     "\t\t\t"
    ],
    [
     477,
     "\t\t\t/* 判断 LED 布尔属性 */"
    ],
    [
     478,
     "\t\t\tota_task_on_update_ident(ident);"
    ],
    [
     479,
     "\t\t\tif (strcmp(ident, \"LED\") == 0 && parsed_type == ONENET_VALUE_BOOL)"
    ],
    [
     480,
     "\t\t\t{"
    ],
    [
     481,
     "\t\t\t\tonenet_led_state = (uint8_t)parsed_value;"
    ],
    [
     482,
     ""
    ]
   ]
  },
  "ota_task_entry": {
   "id": "ota_task_entry",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_task.c",
   "path": "HAL_F429IGT6_App/OTA/ota_task.c",
   "func": "ota_task_entry",
   "from": 60,
   "to": 110,
   "note": "ota_task_entry：s_req 触发 → ota_net_enter → ota_run_once → ota_net_exit",
   "grade": "A",
   "lines": [
    [
     60,
     "static void ota_task_entry(void *arg)"
    ],
    [
     61,
     "{"
    ],
    [
     62,
     "    (void)arg;"
    ],
    [
     63,
     ""
    ],
    [
     64,
     "    for (;;)"
    ],
    [
     65,
     "    {"
    ],
    [
     66,
     "        if ((s_req != 0U) && (s_busy == 0))"
    ],
    [
     67,
     "        {"
    ],
    [
     68,
     "            int r;"
    ],
    [
     69,
     ""
    ],
    [
     70,
     "            s_req  = 0U;"
    ],
    [
     71,
     "            s_busy = 1;"
    ],
    [
     72,
     ""
    ],
    [
     73,
     "            printf(\"\\r\\n[OTA] ================================\\r\\n\");"
    ],
    [
     74,
     "            printf(\"[OTA] Update trigger -> start OTA\\r\\n\");"
    ],
    [
     75,
     "            printf(\"[OTA] ================================\\r\\n\");"
    ],
    [
     76,
     ""
    ],
    [
     77,
     "            r = ota_net_enter();"
    ],
    [
     78,
     "            if (r != 0)"
    ],
    [
     79,
     "            {"
    ],
    [
     80,
     "                printf(\"[OTA] ota_net_enter FAILED(%d), stay in MQTT mode\\r\\n\", r);"
    ],
    [
     81,
     "            }"
    ],
    [
     82,
     "            else"
    ],
    [
     83,
     "            {"
    ],
    [
     84,
     "                r = ota_run_once();     /* 若真升级：内部复位，不返回 */"
    ],
    [
     85,
     ""
    ],
    [
     86,
     "                printf(\"[OTA] ota_run_once() = %d\\r\\n\", r);"
    ],
    [
     87,
     ""
    ],
    [
     88,
     "                (void)ota_net_exit();   /* 交还 USART3、重连 MQTT */"
    ],
    [
     89,
     "                ota_task_post_update_zero();"
    ],
    [
     90,
     ""
    ],
    [
     91,
     "                if (r == 0)"
    ],
    [
     92,
     "                {"
    ],
    [
     93,
     "                    printf(\"[OTA] ===== OTA finished OK =====\\r\\n\");"
    ],
    [
     94,
     "                }"
    ],
    [
     95,
     "                else if (r == 1)"
    ],
    [
     96,
     "                {"
    ],
    [
     97,
     "                    printf(\"[OTA] ===== no task on platform =====\\r\\n\");"
    ],
    [
     98,
     "                }"
    ],
    [
     99,
     "                else"
    ],
    [
     100,
     "                {"
    ],
    [
     101,
     "                    printf(\"[OTA] ===== OTA FAILED (code %d) =====\\r\\n\", r);"
    ],
    [
     102,
     "                }"
    ],
    [
     103,
     "            }"
    ],
    [
     104,
     ""
    ],
    [
     105,
     "            s_busy = 0;"
    ],
    [
     106,
     "        }"
    ],
    [
     107,
     ""
    ],
    [
     108,
     "        vTaskDelay(pdMS_TO_TICKS(200));"
    ],
    [
     109,
     "    }"
    ],
    [
     110,
     "}"
    ]
   ]
  },
  "ota_task_request": {
   "id": "ota_task_request",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_task.c",
   "path": "HAL_F429IGT6_App/OTA/ota_task.c",
   "func": "ota_task_request",
   "from": 114,
   "to": 143,
   "note": "ota_task_request：首次触发时懒创建 1536 字栈的 otaTask",
   "grade": "A",
   "lines": [
    [
     114,
     "void ota_task_request(uint32_t value)"
    ],
    [
     115,
     "{"
    ],
    [
     116,
     "    if (value == 0U)"
    ],
    [
     117,
     "    {"
    ],
    [
     118,
     "        return;                 /* 0 = 空闲值，不触发 */"
    ],
    [
     119,
     "    }"
    ],
    [
     120,
     "    if (s_busy != 0)"
    ],
    [
     121,
     "    {"
    ],
    [
     122,
     "        printf(\"[OTA] busy, trigger ignored\\r\\n\");"
    ],
    [
     123,
     "        return;"
    ],
    [
     124,
     "    }"
    ],
    [
     125,
     ""
    ],
    [
     126,
     "    s_req = value;"
    ],
    [
     127,
     ""
    ],
    [
     128,
     "    if (s_h == NULL)"
    ],
    [
     129,
     "    {"
    ],
    [
     130,
     "        /* 首次触发时懒创建（避开改 CubeMX 生成的 freertos.c） */"
    ],
    [
     131,
     "        if (xTaskCreate(ota_task_entry, \"otaTask\", 1536, NULL,"
    ],
    [
     132,
     "                        tskIDLE_PRIORITY + 2U, &s_h) != pdPASS)"
    ],
    [
     133,
     "        {"
    ],
    [
     134,
     "            s_h   = NULL;"
    ],
    [
     135,
     "            s_req = 0U;"
    ],
    [
     136,
     "            printf(\"[OTA] xTaskCreate FAILED (heap low?)\\r\\n\");"
    ],
    [
     137,
     "        }"
    ],
    [
     138,
     "        else"
    ],
    [
     139,
     "        {"
    ],
    [
     140,
     "            printf(\"[OTA] otaTask created (stack 1536 words)\\r\\n\");"
    ],
    [
     141,
     "        }"
    ],
    [
     142,
     "    }"
    ],
    [
     143,
     "}"
    ]
   ]
  },
  "net_enter": {
   "id": "net_enter",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_net_switch.c",
   "path": "HAL_F429IGT6_App/OTA/ota_net_switch.c",
   "func": "ota_net_enter",
   "from": 104,
   "to": 151,
   "note": "ota_net_enter：断 MQTT → 停 IDLE-DMA → DMA 切 CIRCULAR → esp01s 接管 → 入网",
   "grade": "A",
   "lines": [
    [
     104,
     "int ota_net_enter(void)"
    ],
    [
     105,
     "{"
    ],
    [
     106,
     "    if (s_ota_mode != 0)"
    ],
    [
     107,
     "    {"
    ],
    [
     108,
     "        return 0;   /* 已经在 OTA 模式，幂等返回 */"
    ],
    [
     109,
     "    }"
    ],
    [
     110,
     ""
    ],
    [
     111,
     "    printf(\"\\r\\n[OTA] >>> enter OTA net mode\\r\\n\");"
    ],
    [
     112,
     ""
    ],
    [
     113,
     "    /* ---- 1. 让模块断开 MQTT，释放那条唯一的 socket ---------------------- */"
    ],
    [
     114,
     "    uart_printf(&huart3, \"AT+MQTTDISC=0\\r\\n\");"
    ],
    [
     115,
     "    HAL_Delay(800);          /* 等模块处理 + 等 DMA 把这一行发完 */"
    ],
    [
     116,
     ""
    ],
    [
     117,
     "    /* ---- 2. 停掉当前的 IDLE-DMA 接收 ------------------------------------ */"
    ],
    [
     118,
     "    (void)HAL_UART_AbortReceive(&huart3);"
    ],
    [
     119,
     ""
    ],
    [
     120,
     "    /* ---- 3. USART3_RX 的 DMA 切到 CIRCULAR ------------------------------ */"
    ],
    [
     121,
     "    if (ota_dma_switch_mode(DMA_CIRCULAR) != 0)"
    ],
    [
     122,
     "    {"
    ],
    [
     123,
     "        printf(\"[OTA] dma -> CIRCULAR FAILED\\r\\n\");"
    ],
    [
     124,
     "        ota_net_restore();"
    ],
    [
     125,
     "        return -1;"
    ],
    [
     126,
     "    }"
    ],
    [
     127,
     ""
    ],
    [
     128,
     "    /* ---- 4. esp01s 接管 ------------------------------------------------"
    ],
    [
     129,
     "       内部顺序：AT / AT+RST(等 ready 4s) / ATE0 / CIPMUX=0 / CIPMODE=0，"
    ],
    [
     130,
     "       并调用 HAL_UART_Receive_DMA(&huart3, s_dma_rx, 4096) 启动循环接收。"
    ],
    [
     131,
     "       注意 AT+RST 会让模块重启，CWMODE(保存在 flash) 不受影响，MQTT 配置会丢。 */"
    ],
    [
     132,
     "    if (esp01s_init() != ESP_OK)"
    ],
    [
     133,
     "    {"
    ],
    [
     134,
     "        printf(\"[OTA] esp01s_init FAILED\\r\\n\");"
    ],
    [
     135,
     "        ota_net_restore();"
    ],
    [
     136,
     "        return -2;"
    ],
    [
     137,
     "    }"
    ],
    [
     138,
     ""
    ],
    [
     139,
     "    /* ---- 5. 重新入网（AT+CWJAP） ---------------------------------------- */"
    ],
    [
     140,
     "    if (esp01s_join_ap(wifi_name, wifi_pass, 15000) != ESP_OK)"
    ],
    [
     141,
     "    {"
    ],
    [
     142,
     "        printf(\"[OTA] esp01s_join_ap FAILED\\r\\n\");"
    ],
    [
     143,
     "        ota_net_restore();"
    ],
    [
     144,
     "        return -3;"
    ],
    [
     145,
     "    }"
    ],
    [
     146,
     ""
    ],
    [
     147,
     "    s_ota_mode = 1;"
    ],
    [
     148,
     "    printf(\"[OTA] OTA net mode READY (USART3 owned by esp01s)\\r\\n\");"
    ],
    [
     149,
     ""
    ],
    [
     150,
     "    return 0;"
    ],
    [
     151,
     "}"
    ]
   ]
  },
  "net_restore": {
   "id": "net_restore",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_net_switch.c",
   "path": "HAL_F429IGT6_App/OTA/ota_net_switch.c",
   "func": "ota_net_restore",
   "from": 84,
   "to": 102,
   "note": "ota_net_restore：DMA 回 NORMAL、恢复 IDLE 接收、重连 MQTT",
   "grade": "A",
   "lines": [
    [
     84,
     "static void ota_net_restore(void)"
    ],
    [
     85,
     "{"
    ],
    [
     86,
     "    /* 1. 停掉当前接收（可能是 esp01s 的循环 DMA，也可能是中断） */"
    ],
    [
     87,
     "    (void)HAL_UART_AbortReceive(&huart3);"
    ],
    [
     88,
     ""
    ],
    [
     89,
     "    /* 2. DMA 切回 NORMAL */"
    ],
    [
     90,
     "    (void)ota_dma_switch_mode(DMA_NORMAL);"
    ],
    [
     91,
     ""
    ],
    [
     92,
     "    /* 3. 先清标志，再恢复接收：否则 uart_handle.c 里的守卫会把 USART3 让路掉 */"
    ],
    [
     93,
     "    s_ota_mode = 0;"
    ],
    [
     94,
     ""
    ],
    [
     95,
     "    /* 4. 恢复原来的 IDLE-DMA 接收 */"
    ],
    [
     96,
     "    (void)uart_start_receive(&huart3, (uint8_t *)uart3_Recived_buf);"
    ],
    [
     97,
     ""
    ],
    [
     98,
     "    /* 5. 重配并重连 MQTT"
    ],
    [
     99,
     "          必须做 —— esp01s_init() 里的 AT+RST 把模块的 MQTT 配置清空了。"
    ],
    [
     100,
     "          esp8266_Init() 内部会再启动一次 IDLE 接收，重复调用返回 HAL_BUSY 无副作用。 */"
    ],
    [
     101,
     "    esp8266_Init();"
    ],
    [
     102,
     "}"
    ]
   ]
  },
  "run_once_head": {
   "id": "run_once_head",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "ota_run_once",
   "from": 1130,
   "to": 1178,
   "note": "ota_run_once 前半：恢复区初始化 → 补报 201 → 上报版本 → check 任务",
   "grade": "A",
   "lines": [
    [
     1130,
     "int ota_run_once(void)"
    ],
    [
     1131,
     "{"
    ],
    [
     1132,
     "    static ota_param_t p;"
    ],
    [
     1133,
     "    static ota_task_t  t;"
    ],
    [
     1134,
     "    static uint8_t     new_sha[SHA256_DIGEST_SIZE];"
    ],
    [
     1135,
     "    static uint8_t     bk_sha[SHA256_DIGEST_SIZE];"
    ],
    [
     1136,
     "    uint32_t    cur_ver;"
    ],
    [
     1137,
     "    uint32_t    new_len = 0U;"
    ],
    [
     1138,
     "    uint32_t    bk_len = 0U;"
    ],
    [
     1139,
     "    int         r;"
    ],
    [
     1140,
     ""
    ],
    [
     1141,
     "    (void)memset(&s_st, 0, sizeof(s_st));"
    ],
    [
     1142,
     "    ota_set_state(OTA_ST_IDLE, \"start\");"
    ],
    [
     1143,
     ""
    ],
    [
     1144,
     "    /* ---- 0. 恢复区出厂镜像（只做一次，纯本地操作） ---------------------- */"
    ],
    [
     1145,
     "    if ((param_area_load(&p) == 0) && (p.recovery_len == 0U))"
    ],
    [
     1146,
     "    {"
    ],
    [
     1147,
     "        (void)ota_init_recovery_if_empty();"
    ],
    [
     1148,
     "    }"
    ],
    [
     1149,
     ""
    ],
    [
     1150,
     "    /* ---- 1. 补报上次升级的 201 ----------------------------------------- */"
    ],
    [
     1151,
     "    (void)ota_report_pending_201();"
    ],
    [
     1152,
     ""
    ],
    [
     1153,
     "    /* ---- 2. 上报当前版本 ----------------------------------------------- */"
    ],
    [
     1154,
     "    ota_set_state(OTA_ST_CHECKING, \"report version\");"
    ],
    [
     1155,
     "    ota_feed_watchdog();"
    ],
    [
     1156,
     "    if (ota_api_report_version() != 0)"
    ],
    [
     1157,
     "    {"
    ],
    [
     1158,
     "        ota_set_state(OTA_ST_ERROR, \"report version FAILED\");"
    ],
    [
     1159,
     "        OTA_ERR(\"[OTA] report version FAILED\\r\\n\");"
    ],
    [
     1160,
     "        return -1;"
    ],
    [
     1161,
     "    }"
    ],
    [
     1162,
     "    OTA_LOG(\"[OTA] version %s reported\\r\\n\", OTA_APP_VERSION_STR);"
    ],
    [
     1163,
     ""
    ],
    [
     1164,
     "    /* ---- 3. 查任务 ------------------------------------------------------ */"
    ],
    [
     1165,
     "    ota_set_state(OTA_ST_CHECKING, \"checking...\");"
    ],
    [
     1166,
     "    ota_feed_watchdog();"
    ],
    [
     1167,
     "    if (ota_api_check_task(&t) != 0)"
    ],
    [
     1168,
     "    {"
    ],
    [
     1169,
     "        ota_set_state(OTA_ST_ERROR, \"check FAILED\");"
    ],
    [
     1170,
     "        OTA_ERR(\"[OTA] check FAILED\\r\\n\");"
    ],
    [
     1171,
     "        return -2;"
    ],
    [
     1172,
     "    }"
    ],
    [
     1173,
     "    if (t.has_task == 0)"
    ],
    [
     1174,
     "    {"
    ],
    [
     1175,
     "        ota_set_state(OTA_ST_NONE, \"no task\");"
    ],
    [
     1176,
     "        OTA_LOG(\"[OTA] no task on platform\\r\\n\");"
    ],
    [
     1177,
     "        return 1;"
    ],
    [
     1178,
     "    }"
    ]
   ]
  },
  "run_once_reject": {
   "id": "run_once_reject",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "(非函数体)",
   "from": 1180,
   "to": 1215,
   "note": "拒绝差分包（type!=1）与降级（target<=current）",
   "grade": "A",
   "lines": [
    [
     1180,
     "    OTA_LOG(\"[OTA] task found: tid=%lu size=%lu type=%lu target=%s\\r\\n\","
    ],
    [
     1181,
     "            (unsigned long)t.tid, (unsigned long)t.size,"
    ],
    [
     1182,
     "            (unsigned long)t.type, t.target);"
    ],
    [
     1183,
     ""
    ],
    [
     1184,
     "    /* ---- 4. 拒绝差分包 / 降级 ------------------------------------------ */"
    ],
    [
     1185,
     "    if (t.type != 1U)"
    ],
    [
     1186,
     "    {"
    ],
    [
     1187,
     "        ota_set_state(OTA_ST_ERROR, \"diff pkg unsupported\");"
    ],
    [
     1188,
     "        OTA_ERR(\"[OTA] diff package not supported (type=%lu)\\r\\n\", (unsigned long)t.type);"
    ],
    [
     1189,
     "        OTA_REPORT_FAIL(t.tid, 206U);"
    ],
    [
     1190,
     "        return -3;"
    ],
    [
     1191,
     "    }"
    ],
    [
     1192,
     ""
    ],
    [
     1193,
     "    if ((t.target[0] != '\\0') && (version_parse(t.target, &cur_ver) == 0))"
    ],
    [
     1194,
     "    {"
    ],
    [
     1195,
     "        if (param_area_load(&p) != 0)"
    ],
    [
     1196,
     "        {"
    ],
    [
     1197,
     "            param_area_defaults(&p);"
    ],
    [
     1198,
     "        }"
    ],
    [
     1199,
     "        if (cur_ver <= p.version)"
    ],
    [
     1200,
     "        {"
    ],
    [
     1201,
     "            if (cur_ver == p.version)"
    ],
    [
     1202,
     "            {"
    ],
    [
     1203,
     "                /* 目标版本等于当前版本：说明升级已完成但 201 没被平台接受，补报一次 */"
    ],
    [
     1204,
     "                (void)ota_api_report_status(t.tid, 201U);"
    ],
    [
     1205,
     "                ota_set_state(OTA_ST_NONE, \"already updated\");"
    ],
    [
     1206,
     "                return 1;"
    ],
    [
     1207,
     "            }"
    ],
    [
     1208,
     ""
    ],
    [
     1209,
     "            ota_set_state(OTA_ST_ERROR, \"rejected: ver too low\");"
    ],
    [
     1210,
     "            OTA_ERR(\"[OTA] reject: target %s <= current 0x%06lX\\r\\n\","
    ],
    [
     1211,
     "                    t.target, (unsigned long)p.version);"
    ],
    [
     1212,
     "            OTA_REPORT_FAIL(t.tid, 206U);"
    ],
    [
     1213,
     "            return -3;"
    ],
    [
     1214,
     "        }"
    ],
    [
     1215,
     "    }"
    ]
   ]
  },
  "run_once_download": {
   "id": "run_once_download",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "(非函数体)",
   "from": 1217,
   "to": 1233,
   "note": "下载 + 备份两步",
   "grade": "A",
   "lines": [
    [
     1217,
     "    /* ---- 5. 下载 -------------------------------------------------------- */"
    ],
    [
     1218,
     "    ota_set_state(OTA_ST_DOWNLOADING, \"downloading...\");"
    ],
    [
     1219,
     "    r = ota_download(&t, &new_len, new_sha);"
    ],
    [
     1220,
     "    if (r != 0)"
    ],
    [
     1221,
     "    {"
    ],
    [
     1222,
     "        ota_set_state(OTA_ST_ERROR, \"download/verify FAILED\");"
    ],
    [
     1223,
     "        return r;   /* -4 / -5 */"
    ],
    [
     1224,
     "    }"
    ],
    [
     1225,
     "    s_new_len = new_len;"
    ],
    [
     1226,
     "    (void)memcpy(s_new_sha, new_sha, sizeof(new_sha));"
    ],
    [
     1227,
     ""
    ],
    [
     1228,
     "    /* ---- 6. 备份旧固件 -------------------------------------------------- */"
    ],
    [
     1229,
     "    if (ota_backup_current_app(&bk_len, bk_sha) != 0)"
    ],
    [
     1230,
     "    {"
    ],
    [
     1231,
     "        ota_set_state(OTA_ST_ERROR, \"backup FAILED\");"
    ],
    [
     1232,
     "        return -6;"
    ],
    [
     1233,
     "    }"
    ]
   ]
  },
  "run_once_commit": {
   "id": "run_once_commit",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "(非函数体)",
   "from": 1235,
   "to": 1264,
   "note": "把镜像长度/SHA-256/备份信息固化进参数区，并上报 step=100",
   "grade": "A",
   "lines": [
    [
     1235,
     "    /* ---- 7. 固化到参数区 ------------------------------------------------ */"
    ],
    [
     1236,
     "    if (param_area_load(&p) != 0)"
    ],
    [
     1237,
     "    {"
    ],
    [
     1238,
     "        param_area_defaults(&p);"
    ],
    [
     1239,
     "    }"
    ],
    [
     1240,
     ""
    ],
    [
     1241,
     "    p.image_len = s_new_len;"
    ],
    [
     1242,
     "    (void)memcpy(p.image_sha, s_new_sha, sizeof(s_new_sha));"
    ],
    [
     1243,
     ""
    ],
    [
     1244,
     "    p.backup_version = p.version;"
    ],
    [
     1245,
     "    p.backup_len     = bk_len;"
    ],
    [
     1246,
     "    (void)memcpy(p.backup_sha, bk_sha, sizeof(bk_sha));"
    ],
    [
     1247,
     "    p.backup_status  = OTA_BACKUP_VALID;"
    ],
    [
     1248,
     ""
    ],
    [
     1249,
     "    p.resume_offset  = 0U;"
    ],
    [
     1250,
     "    p.dl_tid         = t.tid;"
    ],
    [
     1251,
     ""
    ],
    [
     1252,
     "    if (param_area_save(&p) != 0)"
    ],
    [
     1253,
     "    {"
    ],
    [
     1254,
     "        ota_set_state(OTA_ST_ERROR, \"param save FAILED\");"
    ],
    [
     1255,
     "        OTA_ERR(\"[OTA] param save FAILED\\r\\n\");"
    ],
    [
     1256,
     "        return -7;"
    ],
    [
     1257,
     "    }"
    ],
    [
     1258,
     ""
    ],
    [
     1259,
     "    OTA_LOG(\"[OTA] param saved: image_len=%lu backup_len=%lu\\r\\n\","
    ],
    [
     1260,
     "            (unsigned long)p.image_len, (unsigned long)p.backup_len);"
    ],
    [
     1261,
     ""
    ],
    [
     1262,
     "    /* ---- 8. 上报 100 ---------------------------------------------------- */"
    ],
    [
     1263,
     "    (void)ota_api_report_status(t.tid, 100U);"
    ],
    [
     1264,
     ""
    ]
   ]
  },
  "run_once_apply": {
   "id": "run_once_apply",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "(非函数体)",
   "from": 1266,
   "to": 1288,
   "note": "应用：OTA_TEST_NO_REBOOT=0 时直接 ota_apply_and_reboot()（不返回）",
   "grade": "A",
   "lines": [
    [
     1266,
     "    ota_set_state(OTA_ST_READY_REBOOT, \"ready\");"
    ],
    [
     1267,
     ""
    ],
    [
     1268,
     "#if (OTA_TEST_NO_REBOOT == 1)"
    ],
    [
     1269,
     ""
    ],
    [
     1270,
     "    /* P3a：只下载不升级。留在 READY_REBOOT 状态，由调用方决定后续动作。 */"
    ],
    [
     1271,
     "    (void)snprintf(s_st.msg, sizeof(s_st.msg), \"downloaded, NOT applied\");"
    ],
    [
     1272,
     "    OTA_LOG(\"\\r\\n[OTA] ===== P3a DONE (OTA_TEST_NO_REBOOT=1) =====\\r\\n\");"
    ],
    [
     1273,
     "    OTA_LOG(\"[OTA]   new image : %lu bytes in W25Q64 staging\\r\\n\","
    ],
    [
     1274,
     "            (unsigned long)s_new_len);"
    ],
    [
     1275,
     "    OTA_LOG(\"[OTA]   backup    : %lu bytes in W25Q64 backup\\r\\n\","
    ],
    [
     1276,
     "            (unsigned long)bk_len);"
    ],
    [
     1277,
     "    OTA_LOG(\"[OTA]   tid       : %lu\\r\\n\", (unsigned long)t.tid);"
    ],
    [
     1278,
     "    OTA_LOG(\"[OTA]   A slot NOT touched, flag stays NORMAL: not upgrading yet\\r\\n\");"
    ],
    [
     1279,
     "    OTA_LOG(\"[OTA]   set OTA_TEST_NO_REBOOT=0 to actually apply\\r\\n\\r\\n\");"
    ],
    [
     1280,
     "    return 0;"
    ],
    [
     1281,
     ""
    ],
    [
     1282,
     "#else"
    ],
    [
     1283,
     ""
    ],
    [
     1284,
     "    ota_apply_and_reboot(t.tid);   /* 不返回 */"
    ],
    [
     1285,
     "    return 0;"
    ],
    [
     1286,
     ""
    ],
    [
     1287,
     "#endif"
    ],
    [
     1288,
     "}"
    ]
   ]
  },
  "api_version": {
   "id": "api_version",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "ota_api_report_version",
   "from": 227,
   "to": 264,
   "note": "POST /fuse-ota/{pid}/{dev}/version",
   "grade": "A",
   "lines": [
    [
     227,
     "static int ota_api_report_version(void)"
    ],
    [
     228,
     "{"
    ],
    [
     229,
     "    /* ★ 这些缓冲/结构体放静态区（约 700B），避免压在 FreeRTOS 任务栈上。"
    ],
    [
     230,
     "       本工程同一时刻只有一个任务跑 OTA，静态化不影响正确性。 */"
    ],
    [
     231,
     "    static char     path[160];"
    ],
    [
     232,
     "    static char     body[80];"
    ],
    [
     233,
     "    static char     extra[220];"
    ],
    [
     234,
     "    static uint8_t  rbuf[192];"
    ],
    [
     235,
     "    static http_resp_t resp;"
    ],
    [
     236,
     "    uint32_t code;"
    ],
    [
     237,
     ""
    ],
    [
     238,
     "    (void)snprintf(path, sizeof(path), \"/fuse-ota/%s/%s/version\", OTA_PID, OTA_DEV);"
    ],
    [
     239,
     "    (void)snprintf(body, sizeof(body), \"{\\\"s_version\\\":\\\"%s\\\",\\\"f_version\\\":\\\"%s\\\"}\","
    ],
    [
     240,
     "                   OTA_APP_VERSION_STR, OTA_FW_VERSION_STR);"
    ],
    [
     241,
     "    (void)snprintf(extra, sizeof(extra),"
    ],
    [
     242,
     "                   \"Content-Type: application/json\\r\\nAuthorization: %s\\r\\n\", OTA_TOKEN);"
    ],
    [
     243,
     ""
    ],
    [
     244,
     "    (void)memset(&resp, 0, sizeof(resp));"
    ],
    [
     245,
     "    resp.body = rbuf;"
    ],
    [
     246,
     "    resp.body_cap = (uint32_t)sizeof(rbuf);"
    ],
    [
     247,
     ""
    ],
    [
     248,
     "    if (http_client_request(OTA_API_HOST, OTA_API_PORT, \"POST\", path, extra, body,"
    ],
    [
     249,
     "                            &resp, 0, 0, 8000) != ESP_OK)"
    ],
    [
     250,
     "    {"
    ],
    [
     251,
     "        return -1;"
    ],
    [
     252,
     "    }"
    ],
    [
     253,
     ""
    ],
    [
     254,
     "    if (rbuf != 0)"
    ],
    [
     255,
     "    {"
    ],
    [
     256,
     "        rbuf[(resp.body_len < sizeof(rbuf)) ? resp.body_len : (sizeof(rbuf) - 1U)] = (uint8_t)'\\0';"
    ],
    [
     257,
     "    }"
    ],
    [
     258,
     ""
    ],
    [
     259,
     "    if (json_get_num((const char *)rbuf, \"code\", &code) != 0)"
    ],
    [
     260,
     "    {"
    ],
    [
     261,
     "        return -1;"
    ],
    [
     262,
     "    }"
    ],
    [
     263,
     "    return (code == 0U) ? 0 : -1;"
    ],
    [
     264,
     "}"
    ]
   ]
  },
  "api_check": {
   "id": "api_check",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "ota_api_check_task",
   "from": 266,
   "to": 321,
   "note": "GET /fuse-ota/{pid}/{dev}/check?type=1&version=… —— type 必须是 1",
   "grade": "A",
   "lines": [
    [
     266,
     "static int ota_api_check_task(ota_task_t *t)"
    ],
    [
     267,
     "{"
    ],
    [
     268,
     "    static char     path[200];"
    ],
    [
     269,
     "    static char     extra[220];"
    ],
    [
     270,
     "    static uint8_t  rbuf[512];"
    ],
    [
     271,
     "    static http_resp_t resp;"
    ],
    [
     272,
     "    uint32_t v;"
    ],
    [
     273,
     ""
    ],
    [
     274,
     "    (void)memset(t, 0, sizeof(*t));"
    ],
    [
     275,
     ""
    ],
    [
     276,
     "    /* ★ type 必须是 1（实测 2 -> 12010，3 -> 12004，不传 -> 12001） */"
    ],
    [
     277,
     "    (void)snprintf(path, sizeof(path), \"/fuse-ota/%s/%s/check?type=%d&version=%s\","
    ],
    [
     278,
     "                   OTA_PID, OTA_DEV, OTA_TASK_TYPE, OTA_APP_VERSION_STR);"
    ],
    [
     279,
     "    (void)snprintf(extra, sizeof(extra), \"Authorization: %s\\r\\n\", OTA_TOKEN);"
    ],
    [
     280,
     ""
    ],
    [
     281,
     "    (void)memset(&resp, 0, sizeof(resp));"
    ],
    [
     282,
     "    resp.body = rbuf;"
    ],
    [
     283,
     "    resp.body_cap = (uint32_t)sizeof(rbuf);"
    ],
    [
     284,
     ""
    ],
    [
     285,
     "    if (http_client_request(OTA_API_HOST, OTA_API_PORT, \"GET\", path, extra, 0,"
    ],
    [
     286,
     "                            &resp, 0, 0, 8000) != ESP_OK)"
    ],
    [
     287,
     "    {"
    ],
    [
     288,
     "        return -1;"
    ],
    [
     289,
     "    }"
    ],
    [
     290,
     ""
    ],
    [
     291,
     "    rbuf[(resp.body_len < sizeof(rbuf)) ? resp.body_len : (sizeof(rbuf) - 1U)] = (uint8_t)'\\0';"
    ],
    [
     292,
     ""
    ],
    [
     293,
     "    OTA_LOG(\"[OTA] check resp: %s\\r\\n\", (char *)rbuf);"
    ],
    [
     294,
     ""
    ],
    [
     295,
     "    /* 平台返回业务错误时按\"无任务\"处理（与源工程一致，避免误报） */"
    ],
    [
     296,
     "    if ((json_get_num((const char *)rbuf, \"code\", &v) != 0) || (v != 0U))"
    ],
    [
     297,
     "    {"
    ],
    [
     298,
     "        return 0;"
    ],
    [
     299,
     "    }"
    ],
    [
     300,
     "    if ((json_get_num((const char *)rbuf, \"tid\", &v) != 0) || (v == 0U))"
    ],
    [
     301,
     "    {"
    ],
    [
     302,
     "        return 0;   /* 没有任务 */"
    ],
    [
     303,
     "    }"
    ],
    [
     304,
     ""
    ],
    [
     305,
     "    t->tid = v;"
    ],
    [
     306,
     "    t->has_task = 1;"
    ],
    [
     307,
     ""
    ],
    [
     308,
     "    if (json_get_num((const char *)rbuf, \"size\", &v) == 0)   { t->size = v; }"
    ],
    [
     309,
     "    if (json_get_num((const char *)rbuf, \"type\", &v) == 0)   { t->type = v; }"
    ],
    [
     310,
     "    if (json_get_num((const char *)rbuf, \"status\", &v) == 0) { t->status = v; }"
    ],
    [
     311,
     "    if (json_get_str((const char *)rbuf, \"target\", t->target, sizeof(t->target)) != 0)"
    ],
    [
     312,
     "    {"
    ],
    [
     313,
     "        t->target[0] = '\\0';"
    ],
    [
     314,
     "    }"
    ],
    [
     315,
     "    if (json_get_str((const char *)rbuf, \"md5\", t->md5, sizeof(t->md5)) != 0)"
    ],
    [
     316,
     "    {"
    ],
    [
     317,
     "        t->md5[0] = '\\0';"
    ],
    [
     318,
     "    }"
    ],
    [
     319,
     ""
    ],
    [
     320,
     "    return 0;"
    ],
    [
     321,
     "}"
    ]
   ]
  },
  "api_status": {
   "id": "api_status",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "ota_api_report_status",
   "from": 323,
   "to": 355,
   "note": "POST /fuse-ota/{pid}/{dev}/{tid}/status  {\"step\":N}",
   "grade": "A",
   "lines": [
    [
     323,
     "static int ota_api_report_status(uint32_t tid, uint32_t step)"
    ],
    [
     324,
     "{"
    ],
    [
     325,
     "    static char     path[200];"
    ],
    [
     326,
     "    static char     body[32];"
    ],
    [
     327,
     "    static char     extra[220];"
    ],
    [
     328,
     "    static uint8_t  rbuf[192];"
    ],
    [
     329,
     "    static http_resp_t resp;"
    ],
    [
     330,
     "    uint32_t code;"
    ],
    [
     331,
     ""
    ],
    [
     332,
     "    (void)snprintf(path, sizeof(path), \"/fuse-ota/%s/%s/%lu/status\","
    ],
    [
     333,
     "                   OTA_PID, OTA_DEV, (unsigned long)tid);"
    ],
    [
     334,
     "    (void)snprintf(body, sizeof(body), \"{\\\"step\\\":%lu}\", (unsigned long)step);"
    ],
    [
     335,
     "    (void)snprintf(extra, sizeof(extra),"
    ],
    [
     336,
     "                   \"Content-Type: application/json\\r\\nAuthorization: %s\\r\\n\", OTA_TOKEN);"
    ],
    [
     337,
     ""
    ],
    [
     338,
     "    (void)memset(&resp, 0, sizeof(resp));"
    ],
    [
     339,
     "    resp.body = rbuf;"
    ],
    [
     340,
     "    resp.body_cap = (uint32_t)sizeof(rbuf);"
    ],
    [
     341,
     ""
    ],
    [
     342,
     "    if (http_client_request(OTA_API_HOST, OTA_API_PORT, \"POST\", path, extra, body,"
    ],
    [
     343,
     "                            &resp, 0, 0, 8000) != ESP_OK)"
    ],
    [
     344,
     "    {"
    ],
    [
     345,
     "        return -1;"
    ],
    [
     346,
     "    }"
    ],
    [
     347,
     ""
    ],
    [
     348,
     "    rbuf[(resp.body_len < sizeof(rbuf)) ? resp.body_len : (sizeof(rbuf) - 1U)] = (uint8_t)'\\0';"
    ],
    [
     349,
     ""
    ],
    [
     350,
     "    if ((json_get_num((const char *)rbuf, \"code\", &code) != 0) || (code != 0U))"
    ],
    [
     351,
     "    {"
    ],
    [
     352,
     "        return -1;"
    ],
    [
     353,
     "    }"
    ],
    [
     354,
     "    return 0;"
    ],
    [
     355,
     "}"
    ]
   ]
  },
  "dl_on_data": {
   "id": "dl_on_data",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "dl_on_data",
   "from": 407,
   "to": 476,
   "note": "★ 下载回调：SHA-256 + MD5 同流更新，攒够 256 字节写一次 W25Q64，每 16KB 存检查点",
   "grade": "A",
   "lines": [
    [
     407,
     "static void dl_on_data(const uint8_t *data, uint32_t len, void *arg)"
    ],
    [
     408,
     "{"
    ],
    [
     409,
     "    ota_dl_t *c = (ota_dl_t *)arg;"
    ],
    [
     410,
     ""
    ],
    [
     411,
     "    if (c == 0)"
    ],
    [
     412,
     "    {"
    ],
    [
     413,
     "        return;"
    ],
    [
     414,
     "    }"
    ],
    [
     415,
     "    if (c->io_err != 0U)"
    ],
    [
     416,
     "    {"
    ],
    [
     417,
     "        return;   /* 已经写失败，丢弃后续数据 */"
    ],
    [
     418,
     "    }"
    ],
    [
     419,
     ""
    ],
    [
     420,
     "    /* 哈希基于原始字节流（与平台 MD5 一致，不含任何补齐） */"
    ],
    [
     421,
     "    sha256_update(&c->sha, data, len);"
    ],
    [
     422,
     "    md5_update(&c->md5, data, len);"
    ],
    [
     423,
     ""
    ],
    [
     424,
     "    while (len > 0U)"
    ],
    [
     425,
     "    {"
    ],
    [
     426,
     "        uint32_t room = OTA_DL_CHUNK - c->blen;"
    ],
    [
     427,
     "        uint32_t take = (len < room) ? len : room;"
    ],
    [
     428,
     ""
    ],
    [
     429,
     "        (void)memcpy(&c->buf[c->blen], data, take);"
    ],
    [
     430,
     "        c->blen += take;"
    ],
    [
     431,
     "        data    += take;"
    ],
    [
     432,
     "        len     -= take;"
    ],
    [
     433,
     ""
    ],
    [
     434,
     "        if (c->blen == OTA_DL_CHUNK)"
    ],
    [
     435,
     "        {"
    ],
    [
     436,
     "            /* ★ 1KB 攒块写：把 4 字节粒度带来的 64 倍 page program 开销消掉 */"
    ],
    [
     437,
     "            if (w25q16_write(EXT_STAGING_ADDR + c->offset, c->buf, c->blen) != HAL_OK)"
    ],
    [
     438,
     "            {"
    ],
    [
     439,
     "                c->io_err = 1U;"
    ],
    [
     440,
     "                ota_set_state(OTA_ST_ERROR, \"ext flash write err\");"
    ],
    [
     441,
     "                OTA_ERR(\"[OTA] ext flash write FAILED @%lu\\r\\n\", (unsigned long)c->offset);"
    ],
    [
     442,
     "                return;"
    ],
    [
     443,
     "            }"
    ],
    [
     444,
     "            c->offset += c->blen;"
    ],
    [
     445,
     "            c->blen = 0U;"
    ],
    [
     446,
     ""
    ],
    [
     447,
     "            /* 每 16KB 存一次断点 */"
    ],
    [
     448,
     "            if ((c->offset - c->last_save) >= OTA_CHECKPOINT_INTERVAL)"
    ],
    [
     449,
     "            {"
    ],
    [
     450,
     "                ota_param_t p;"
    ],
    [
     451,
     "                if (param_area_load(&p) == 0)"
    ],
    [
     452,
     "                {"
    ],
    [
     453,
     "                    p.resume_offset = c->offset;"
    ],
    [
     454,
     "                    p.backup_status = OTA_BACKUP_DOWNLOADING;"
    ],
    [
     455,
     "                    p.dl_tid        = c->tid;"
    ],
    [
     456,
     "                    (void)param_area_save(&p);"
    ],
    [
     457,
     "                }"
    ],
    [
     458,
     "                c->last_save = c->offset;"
    ],
    [
     459,
     "            }"
    ],
    [
     460,
     ""
    ],
    [
     461,
     "            ota_feed_watchdog();"
    ],
    [
     462,
     "        }"
    ],
    [
     463,
     "    }"
    ],
    [
     464,
     ""
    ],
    [
     465,
     "    /* 进度（含尚未落盘的 buf 部分） */"
    ],
    [
     466,
     "    if (c->total > 0U)"
    ],
    [
     467,
     "    {"
    ],
    [
     468,
     "        uint32_t done = c->offset + c->blen;"
    ],
    [
     469,
     "        s_st.downloaded = done;"
    ],
    [
     470,
     "        s_st.progress   = (uint32_t)(((uint64_t)done * 100U) / c->total);"
    ],
    [
     471,
     "        if (s_st.progress > 100U)"
    ],
    [
     472,
     "        {"
    ],
    [
     473,
     "            s_st.progress = 100U;"
    ],
    [
     474,
     "        }"
    ],
    [
     475,
     "    }"
    ],
    [
     476,
     "}"
    ]
   ]
  },
  "download_try_a": {
   "id": "download_try_a",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "ota_download_try",
   "from": 486,
   "to": 581,
   "note": "ota_download_try 前半：断点判定（重扫 0~offset 补哈希）或整块擦除暂存区",
   "grade": "A",
   "lines": [
    [
     486,
     "static int ota_download_try(const ota_task_t *t, uint32_t *len_out, uint8_t *sha_out,"
    ],
    [
     487,
     "                            int force_restart)"
    ],
    [
     488,
     "{"
    ],
    [
     489,
     "    static ota_dl_t c;              /* 1KB 缓冲 + 上下文，放静态区避免吃任务栈 */"
    ],
    [
     490,
     "    static http_resp_t resp;"
    ],
    [
     491,
     "    static ota_param_t p;"
    ],
    [
     492,
     "    static char path[200];"
    ],
    [
     493,
     "    static char extra[240];"
    ],
    [
     494,
     "    static uint8_t md5_digest[MD5_DIGEST_SIZE];"
    ],
    [
     495,
     "    uint32_t off;"
    ],
    [
     496,
     "    int r;"
    ],
    [
     497,
     "    int resume = 0;"
    ],
    [
     498,
     ""
    ],
    [
     499,
     "    (void)memset(&c, 0, sizeof(c));"
    ],
    [
     500,
     "    c.tid   = t->tid;"
    ],
    [
     501,
     "    c.total = t->size;"
    ],
    [
     502,
     "    sha256_init(&c.sha);"
    ],
    [
     503,
     "    md5_init(&c.md5);"
    ],
    [
     504,
     ""
    ],
    [
     505,
     "    s_st.tid   = t->tid;"
    ],
    [
     506,
     "    s_st.total = t->size;"
    ],
    [
     507,
     "    s_st.progress = 0U;"
    ],
    [
     508,
     "    s_st.downloaded = 0U;"
    ],
    [
     509,
     "    if (t->target[0] != '\\0')"
    ],
    [
     510,
     "    {"
    ],
    [
     511,
     "        (void)strncpy(s_st.target, t->target, sizeof(s_st.target) - 1U);"
    ],
    [
     512,
     "        s_st.target[sizeof(s_st.target) - 1U] = '\\0';"
    ],
    [
     513,
     "    }"
    ],
    [
     514,
     ""
    ],
    [
     515,
     "    /* ---- 1. 断点续传判定 ------------------------------------------------ */"
    ],
    [
     516,
     "    if ((force_restart == 0) &&"
    ],
    [
     517,
     "        (param_area_load(&p) == 0) &&"
    ],
    [
     518,
     "        (p.dl_tid == t->tid) &&"
    ],
    [
     519,
     "        (p.backup_status == OTA_BACKUP_DOWNLOADING) &&"
    ],
    [
     520,
     "        ((p.resume_offset & 3U) == 0U) &&"
    ],
    [
     521,
     "        (p.resume_offset < OTA_APP_IMAGE_MAX_SIZE))"
    ],
    [
     522,
     "    {"
    ],
    [
     523,
     "        resume = 1;"
    ],
    [
     524,
     "        c.offset    = p.resume_offset;"
    ],
    [
     525,
     "        c.last_save = c.offset;"
    ],
    [
     526,
     ""
    ],
    [
     527,
     "        OTA_LOG(\"[OTA] resume from %lu / %lu\\r\\n\","
    ],
    [
     528,
     "                (unsigned long)c.offset, (unsigned long)t->size);"
    ],
    [
     529,
     ""
    ],
    [
     530,
     "        /* ★ 断点续传必须重扫 0~offset 补哈希（哈希上下文无法跨断电保存） */"
    ],
    [
     531,
     "        {"
    ],
    [
     532,
     "            uint32_t done = 0U;"
    ],
    [
     533,
     "            uint8_t  hb[256];"
    ],
    [
     534,
     ""
    ],
    [
     535,
     "            while (done < c.offset)"
    ],
    [
     536,
     "            {"
    ],
    [
     537,
     "                uint32_t take = c.offset - done;"
    ],
    [
     538,
     "                if (take > (uint32_t)sizeof(hb))"
    ],
    [
     539,
     "                {"
    ],
    [
     540,
     "                    take = (uint32_t)sizeof(hb);"
    ],
    [
     541,
     "                }"
    ],
    [
     542,
     "                if (w25q16_read(EXT_STAGING_ADDR + done, hb, take) != HAL_OK)"
    ],
    [
     543,
     "                {"
    ],
    [
     544,
     "                    return -4;"
    ],
    [
     545,
     "                }"
    ],
    [
     546,
     "                sha256_update(&c.sha, hb, take);"
    ],
    [
     547,
     "                md5_update(&c.md5, hb, take);"
    ],
    [
     548,
     "                done += take;"
    ],
    [
     549,
     "                ota_feed_watchdog();"
    ],
    [
     550,
     "            }"
    ],
    [
     551,
     "        }"
    ],
    [
     552,
     "    }"
    ],
    [
     553,
     "    else"
    ],
    [
     554,
     "    {"
    ],
    [
     555,
     "        /* ---- 2. 全新下载：必须先擦干净暂存区 ---------------------------- */"
    ],
    [
     556,
     "        c.offset    = 0U;"
    ],
    [
     557,
     "        c.last_save = 0U;"
    ],
    [
     558,
     ""
    ],
    [
     559,
     "        OTA_LOG(\"[OTA] erase staging area (%lu KB)...\\r\\n\","
    ],
    [
     560,
     "                (unsigned long)(OTA_APP_IMAGE_MAX_SIZE / 1024UL));"
    ],
    [
     561,
     ""
    ],
    [
     562,
     "        for (off = 0U; off < OTA_APP_IMAGE_MAX_SIZE; off += 65536U)"
    ],
    [
     563,
     "        {"
    ],
    [
     564,
     "            if (w25q16_erase_block(EXT_STAGING_ADDR + off) != HAL_OK)"
    ],
    [
     565,
     "            {"
    ],
    [
     566,
     "                OTA_ERR(\"[OTA] erase staging FAILED @%lu\\r\\n\", (unsigned long)off);"
    ],
    [
     567,
     "                return -4;"
    ],
    [
     568,
     "            }"
    ],
    [
     569,
     "            ota_feed_watchdog();"
    ],
    [
     570,
     "        }"
    ],
    [
     571,
     ""
    ],
    [
     572,
     "        if (param_area_load(&p) == 0)"
    ],
    [
     573,
     "        {"
    ],
    [
     574,
     "            p.resume_offset = 0U;"
    ],
    [
     575,
     "            p.backup_status = OTA_BACKUP_DOWNLOADING;"
    ],
    [
     576,
     "            p.dl_tid        = t->tid;"
    ],
    [
     577,
     "            p.image_len     = 0U;"
    ],
    [
     578,
     "            (void)memset(p.image_sha, 0, sizeof(p.image_sha));"
    ],
    [
     579,
     "            (void)param_area_save(&p);"
    ],
    [
     580,
     "        }"
    ],
    [
     581,
     "    }"
    ]
   ]
  },
  "download_try_b": {
   "id": "download_try_b",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "(非函数体)",
   "from": 583,
   "to": 675,
   "note": "下载循环：最多 8 轮 Range 续传 + 截断检测（实收 < Content-Length 即 TRUNCATED）",
   "grade": "A",
   "lines": [
    [
     583,
     "    /* ---- 3. 发 GET（Range 续传，最多 8 轮） ------------------------------ */"
    ],
    [
     584,
     "    /* 为什么必须重试："
    ],
    [
     585,
     "       实测 6628 字节的尾巴只收到 6468 字节就停住 —— ESP8266 在 115200 批量接收时，"
    ],
    [
     586,
     "       偶发一次 UART overrun 就会让 \"+IPD,<len>:\" 帧头错位，之后不再输出数据，"
    ],
    [
     587,
     "       http_client 一直等到超时（r=-2）。"
    ],
    [
     588,
     "       每轮以当前 c.offset 作为新的 Range 起点续传，只要本轮还有进展就能把尾巴补齐，"
    ],
    [
     589,
     "       最终由 MD5 把关（f407 原版就是这么做的，我第一版简化掉了）。"
    ],
    [
     590,
     ""
    ],
    [
     591,
     "       注：total 用平台返回的 t->size（权威值），不依赖 Content-Range 解析"
    ],
    [
     592,
     "           （实测 total_size 解析出来是 0，不能作判据）。 */"
    ],
    [
     593,
     "    if (t->size == 0U)"
    ],
    [
     594,
     "    {"
    ],
    [
     595,
     "        OTA_ERR(\"[OTA] task size unknown, abort\\r\\n\");"
    ],
    [
     596,
     "        return -4;"
    ],
    [
     597,
     "    }"
    ],
    [
     598,
     ""
    ],
    [
     599,
     "    {"
    ],
    [
     600,
     "        int      attempt;"
    ],
    [
     601,
     "        uint32_t before;"
    ],
    [
     602,
     ""
    ],
    [
     603,
     "        for (attempt = 0; (attempt < 8) && (c.offset < t->size) && (c.io_err == 0U); attempt++)"
    ],
    [
     604,
     "        {"
    ],
    [
     605,
     "            before = c.offset;"
    ],
    [
     606,
     ""
    ],
    [
     607,
     "            (void)snprintf(path, sizeof(path), \"/fuse-ota/%s/%s/%lu/download\","
    ],
    [
     608,
     "                           OTA_PID, OTA_DEV, (unsigned long)t->tid);"
    ],
    [
     609,
     "            (void)snprintf(extra, sizeof(extra),"
    ],
    [
     610,
     "                           \"Authorization: %s\\r\\nRange: bytes=%lu-\\r\\n\","
    ],
    [
     611,
     "                           OTA_TOKEN, (unsigned long)c.offset);"
    ],
    [
     612,
     ""
    ],
    [
     613,
     "            OTA_LOG(\"[OTA] GET (try %d) Range: bytes=%lu- / %lu\\r\\n\","
    ],
    [
     614,
     "                    attempt, (unsigned long)c.offset, (unsigned long)t->size);"
    ],
    [
     615,
     ""
    ],
    [
     616,
     "            (void)memset(&resp, 0, sizeof(resp));"
    ],
    [
     617,
     "            resp.ota_errno = -1;"
    ],
    [
     618,
     ""
    ],
    [
     619,
     "            r = http_client_request(OTA_API_HOST, OTA_API_PORT, \"GET\", path, extra, 0,"
    ],
    [
     620,
     "                                    &resp, dl_on_data, &c, 8000);"
    ],
    [
     621,
     ""
    ],
    [
     622,
     "            /* 本轮零头先落盘，保证 c.offset 与实际写入一致（下一轮 Range 才对得上） */"
    ],
    [
     623,
     "            if ((c.io_err == 0U) && (c.blen > 0U))"
    ],
    [
     624,
     "            {"
    ],
    [
     625,
     "                if (w25q16_write(EXT_STAGING_ADDR + c.offset, c.buf, c.blen) != HAL_OK)"
    ],
    [
     626,
     "                {"
    ],
    [
     627,
     "                    c.io_err = 1U;"
    ],
    [
     628,
     "                }"
    ],
    [
     629,
     "                else"
    ],
    [
     630,
     "                {"
    ],
    [
     631,
     "                    c.offset += c.blen;"
    ],
    [
     632,
     "                }"
    ],
    [
     633,
     "                c.blen = 0U;"
    ],
    [
     634,
     "            }"
    ],
    [
     635,
     ""
    ],
    [
     636,
     "            OTA_LOG(\"[OTA] try %d: ret=%d status=%d len=%lu errno=%d got=%lu/%lu\\r\\n\","
    ],
    [
     637,
     "                    attempt, r, resp.status_code, (unsigned long)resp.content_len,"
    ],
    [
     638,
     "                    resp.ota_errno, (unsigned long)c.offset, (unsigned long)t->size);"
    ],
    [
     639,
     ""
    ],
    [
     640,
     "            /* 中途截断检测：本轮实际收到的字节数少于服务器声明的 Content-Length，"
    ],
    [
     641,
     "               说明中间丢了字节（数据会整体前移），续传无法修复，需要整体重下。 */"
    ],
    [
     642,
     "            if ((resp.content_len > 0U) && ((c.offset - before) < resp.content_len))"
    ],
    [
     643,
     "            {"
    ],
    [
     644,
     "                OTA_ERR(\"[OTA] try %d TRUNCATED: %lu of %lu bytes (data shifted!)\\r\\n\","
    ],
    [
     645,
     "                        attempt, (unsigned long)(c.offset - before),"
    ],
    [
     646,
     "                        (unsigned long)resp.content_len);"
    ],
    [
     647,
     "            }"
    ],
    [
     648,
     ""
    ],
    [
     649,
     "            if (c.io_err != 0U)"
    ],
    [
     650,
     "            {"
    ],
    [
     651,
     "                break;"
    ],
    [
     652,
     "            }"
    ],
    [
     653,
     "            if (resp.ota_errno > 0)"
    ],
    [
     654,
     "            {"
    ],
    [
     655,
     "                OTA_ERR(\"[OTA] platform Ota-Errno=%d\\r\\n\", resp.ota_errno);"
    ],
    [
     656,
     "                OTA_REPORT_FAIL(t->tid, 207U);"
    ],
    [
     657,
     "                return -4;"
    ],
    [
     658,
     "            }"
    ],
    [
     659,
     "            if ((resp.status_code != 200) && (resp.status_code != 206) && (resp.status_code != 416))"
    ],
    [
     660,
     "            {"
    ],
    [
     661,
     "                OTA_ERR(\"[OTA] http status=%d\\r\\n\", resp.status_code);"
    ],
    [
     662,
     "                return -4;"
    ],
    [
     663,
     "            }"
    ],
    [
     664,
     "            if (c.offset >= t->size)"
    ],
    [
     665,
     "            {"
    ],
    [
     666,
     "                break;      /* 收齐了 */"
    ],
    [
     667,
     "            }"
    ],
    [
     668,
     "            if (c.offset <= before)"
    ],
    [
     669,
     "            {"
    ],
    [
     670,
     "                OTA_ERR(\"[OTA] no progress in try %d, abort\\r\\n\", attempt);"
    ],
    [
     671,
     "                return -4;"
    ],
    [
     672,
     "            }"
    ],
    [
     673,
     "            /* 本轮有进展但还没齐 -> 继续下一轮补尾巴 */"
    ],
    [
     674,
     "        }"
    ],
    [
     675,
     "    }"
    ]
   ]
  },
  "download_try_c": {
   "id": "download_try_c",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "(非函数体)",
   "from": 677,
   "to": 721,
   "note": "收齐判定 + 长度校验 + 平台 MD5 校验 + SHA-256 收尾",
   "grade": "A",
   "lines": [
    [
     677,
     "    if (c.io_err != 0U)"
    ],
    [
     678,
     "    {"
    ],
    [
     679,
     "        return -4;"
    ],
    [
     680,
     "    }"
    ],
    [
     681,
     "    if (c.offset < t->size)"
    ],
    [
     682,
     "    {"
    ],
    [
     683,
     "        OTA_ERR(\"[OTA] incomplete: %lu / %lu after retries\\r\\n\","
    ],
    [
     684,
     "                (unsigned long)c.offset, (unsigned long)t->size);"
    ],
    [
     685,
     "        return -4;"
    ],
    [
     686,
     "    }"
    ],
    [
     687,
     ""
    ],
    [
     688,
     "    s_st.downloaded = c.offset;"
    ],
    [
     689,
     "    s_st.progress   = 100U;"
    ],
    [
     690,
     ""
    ],
    [
     691,
     "    /* ---- 5. 校验 -------------------------------------------------------- */"
    ],
    [
     692,
     "    ota_set_state(OTA_ST_VERIFYING, \"verify md5/size/sha\");"
    ],
    [
     693,
     ""
    ],
    [
     694,
     "    /* 长度 */"
    ],
    [
     695,
     "    if ((t->size > 0U) && (c.offset != t->size))"
    ],
    [
     696,
     "    {"
    ],
    [
     697,
     "        OTA_ERR(\"[OTA] size mismatch: got %lu, expect %lu\\r\\n\","
    ],
    [
     698,
     "                (unsigned long)c.offset, (unsigned long)t->size);"
    ],
    [
     699,
     "        OTA_REPORT_FAIL(t->tid, 206U);"
    ],
    [
     700,
     "        return -5;"
    ],
    [
     701,
     "    }"
    ],
    [
     702,
     ""
    ],
    [
     703,
     "    /* 平台 MD5 */"
    ],
    [
     704,
     "    md5_final(&c.md5, md5_digest);"
    ],
    [
     705,
     "    if ((t->md5[0] != '\\0') && (md5_hex_equal(t->md5, md5_digest) == 0))"
    ],
    [
     706,
     "    {"
    ],
    [
     707,
     "        OTA_ERR(\"[OTA] MD5 mismatch (expect %s)\\r\\n\", t->md5);"
    ],
    [
     708,
     "        OTA_REPORT_FAIL(t->tid, 205U);"
    ],
    [
     709,
     "        return -5;"
    ],
    [
     710,
     "    }"
    ],
    [
     711,
     ""
    ],
    [
     712,
     "    /* SHA-256（留给 BL 二次校验） */"
    ],
    [
     713,
     "    sha256_final(&c.sha, sha_out);"
    ],
    [
     714,
     ""
    ],
    [
     715,
     "    *len_out = c.offset;"
    ],
    [
     716,
     ""
    ],
    [
     717,
     "    OTA_LOG(\"[OTA] download OK: %lu bytes, md5=%s\\r\\n\","
    ],
    [
     718,
     "            (unsigned long)c.offset, t->md5);"
    ],
    [
     719,
     ""
    ],
    [
     720,
     "    return 0;"
    ],
    [
     721,
     "}"
    ]
   ]
  },
  "download_wrap": {
   "id": "download_wrap",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "ota_download",
   "from": 733,
   "to": 751,
   "note": "校验失败兜底：擦除暂存区、从头完整重下一次",
   "grade": "A",
   "lines": [
    [
     733,
     "static int ota_download(const ota_task_t *t, uint32_t *len_out, uint8_t *sha_out)"
    ],
    [
     734,
     "{"
    ],
    [
     735,
     "    int r;"
    ],
    [
     736,
     ""
    ],
    [
     737,
     "    r = ota_download_try(t, len_out, sha_out, 0);"
    ],
    [
     738,
     ""
    ],
    [
     739,
     "    if (r == -5)"
    ],
    [
     740,
     "    {"
    ],
    [
     741,
     "        OTA_ERR(\"[OTA] verify FAILED, erase staging and re-download from 0 ...\\r\\n\");"
    ],
    [
     742,
     "        r = ota_download_try(t, len_out, sha_out, 1);"
    ],
    [
     743,
     ""
    ],
    [
     744,
     "        if (r == 0)"
    ],
    [
     745,
     "        {"
    ],
    [
     746,
     "            OTA_LOG(\"[OTA] re-download OK on 2nd pass\\r\\n\");"
    ],
    [
     747,
     "        }"
    ],
    [
     748,
     "    }"
    ],
    [
     749,
     ""
    ],
    [
     750,
     "    return r;"
    ],
    [
     751,
     "}"
    ]
   ]
  },
  "backup_app": {
   "id": "backup_app",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "ota_backup_current_app",
   "from": 759,
   "to": 814,
   "note": "ota_backup_current_app：探测 A 槽实际长度 → 擦备份区 → 1KB 分块复制并算 SHA-256",
   "grade": "A",
   "lines": [
    [
     759,
     "static int ota_backup_current_app(uint32_t *len_out, uint8_t *sha_out)"
    ],
    [
     760,
     "{"
    ],
    [
     761,
     "    static uint8_t buf[1024];"
    ],
    [
     762,
     "    sha256_ctx_t ctx;"
    ],
    [
     763,
     "    uint32_t app_len;"
    ],
    [
     764,
     "    uint32_t copied = 0U;"
    ],
    [
     765,
     "    uint32_t off;"
    ],
    [
     766,
     ""
    ],
    [
     767,
     "    ota_set_state(OTA_ST_BACKUPING, \"backup old fw\");"
    ],
    [
     768,
     ""
    ],
    [
     769,
     "    app_len = ota_probe_run_len();"
    ],
    [
     770,
     "    OTA_LOG(\"[OTA] current app length = %lu bytes\\r\\n\", (unsigned long)app_len);"
    ],
    [
     771,
     ""
    ],
    [
     772,
     "    /* 擦除备份区（15 个 64KB 块） */"
    ],
    [
     773,
     "    for (off = 0U; off < OTA_APP_IMAGE_MAX_SIZE; off += 65536U)"
    ],
    [
     774,
     "    {"
    ],
    [
     775,
     "        if (w25q16_erase_block(EXT_BACKUP_ADDR + off) != HAL_OK)"
    ],
    [
     776,
     "        {"
    ],
    [
     777,
     "            OTA_ERR(\"[OTA] erase backup FAILED @%lu\\r\\n\", (unsigned long)off);"
    ],
    [
     778,
     "            return -1;"
    ],
    [
     779,
     "        }"
    ],
    [
     780,
     "        ota_feed_watchdog();"
    ],
    [
     781,
     "    }"
    ],
    [
     782,
     ""
    ],
    [
     783,
     "    /* 拷贝 + 边拷边算 SHA-256 */"
    ],
    [
     784,
     "    sha256_init(&ctx);"
    ],
    [
     785,
     "    while (copied < app_len)"
    ],
    [
     786,
     "    {"
    ],
    [
     787,
     "        uint32_t take = app_len - copied;"
    ],
    [
     788,
     ""
    ],
    [
     789,
     "        if (take > (uint32_t)sizeof(buf))"
    ],
    [
     790,
     "        {"
    ],
    [
     791,
     "            take = (uint32_t)sizeof(buf);"
    ],
    [
     792,
     "        }"
    ],
    [
     793,
     ""
    ],
    [
     794,
     "        flash_if_read(OTA_APP_A_ADDR + copied, buf, take);"
    ],
    [
     795,
     ""
    ],
    [
     796,
     "        if (w25q16_write(EXT_BACKUP_ADDR + copied, buf, take) != HAL_OK)"
    ],
    [
     797,
     "        {"
    ],
    [
     798,
     "            OTA_ERR(\"[OTA] write backup FAILED @%lu\\r\\n\", (unsigned long)copied);"
    ],
    [
     799,
     "            return -1;"
    ],
    [
     800,
     "        }"
    ],
    [
     801,
     ""
    ],
    [
     802,
     "        sha256_update(&ctx, buf, take);"
    ],
    [
     803,
     "        copied += take;"
    ],
    [
     804,
     ""
    ],
    [
     805,
     "        ota_feed_watchdog();"
    ],
    [
     806,
     "    }"
    ],
    [
     807,
     "    sha256_final(&ctx, sha_out);"
    ],
    [
     808,
     ""
    ],
    [
     809,
     "    *len_out = app_len;"
    ],
    [
     810,
     ""
    ],
    [
     811,
     "    OTA_LOG(\"[OTA] backup done: %lu bytes\\r\\n\", (unsigned long)app_len);"
    ],
    [
     812,
     ""
    ],
    [
     813,
     "    return 0;"
    ],
    [
     814,
     "}"
    ]
   ]
  },
  "probe_len": {
   "id": "probe_len",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "ota_probe_run_len",
   "from": 363,
   "to": 391,
   "note": "ota_probe_run_len：从 A 槽末尾反扫第一个非 0xFF 并 4KB 对齐",
   "grade": "A",
   "lines": [
    [
     363,
     "static uint32_t ota_probe_run_len(void)"
    ],
    [
     364,
     "{"
    ],
    [
     365,
     "    static uint8_t buf[256];        /* 静态，省 256B 栈 */"
    ],
    [
     366,
     "    int32_t off;"
    ],
    [
     367,
     ""
    ],
    [
     368,
     "    for (off = (int32_t)OTA_APP_IMAGE_MAX_SIZE - (int32_t)sizeof(buf);"
    ],
    [
     369,
     "         off >= 0;"
    ],
    [
     370,
     "         off -= (int32_t)sizeof(buf))"
    ],
    [
     371,
     "    {"
    ],
    [
     372,
     "        uint32_t i;"
    ],
    [
     373,
     ""
    ],
    [
     374,
     "        flash_if_read(OTA_APP_A_ADDR + (uint32_t)off, buf, (uint32_t)sizeof(buf));"
    ],
    [
     375,
     ""
    ],
    [
     376,
     "        for (i = (uint32_t)sizeof(buf); i > 0U; i--)"
    ],
    [
     377,
     "        {"
    ],
    [
     378,
     "            if (buf[i - 1U] != 0xFFU)"
    ],
    [
     379,
     "            {"
    ],
    [
     380,
     "                uint32_t len = ((uint32_t)off + i + 0xFFFU) & ~0xFFFUL;"
    ],
    [
     381,
     "                if (len > OTA_APP_IMAGE_MAX_SIZE)"
    ],
    [
     382,
     "                {"
    ],
    [
     383,
     "                    len = OTA_APP_IMAGE_MAX_SIZE;"
    ],
    [
     384,
     "                }"
    ],
    [
     385,
     "                return len;"
    ],
    [
     386,
     "            }"
    ],
    [
     387,
     "        }"
    ],
    [
     388,
     "    }"
    ],
    [
     389,
     ""
    ],
    [
     390,
     "    return OTA_APP_IMAGE_MAX_SIZE;"
    ],
    [
     391,
     "}"
    ]
   ]
  },
  "apply_reboot": {
   "id": "apply_reboot",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "ota_apply_and_reboot",
   "from": 818,
   "to": 848,
   "note": "ota_apply_and_reboot：置 TRY_NEW / boot_count=0 / ota_tid，3 秒倒计时后 NVIC_SystemReset",
   "grade": "A",
   "lines": [
    [
     818,
     "static void ota_apply_and_reboot(uint32_t tid)"
    ],
    [
     819,
     "{"
    ],
    [
     820,
     "    ota_param_t p;"
    ],
    [
     821,
     "    int i;"
    ],
    [
     822,
     ""
    ],
    [
     823,
     "    if (param_area_load(&p) != 0)"
    ],
    [
     824,
     "    {"
    ],
    [
     825,
     "        param_area_defaults(&p);"
    ],
    [
     826,
     "    }"
    ],
    [
     827,
     ""
    ],
    [
     828,
     "    p.boot_flag  = OTA_BOOT_FLAG_TRY_NEW;"
    ],
    [
     829,
     "    p.boot_count = 0U;"
    ],
    [
     830,
     "    p.ota_tid    = tid;"
    ],
    [
     831,
     "    p.dl_tid     = 0U;"
    ],
    [
     832,
     ""
    ],
    [
     833,
     "    if (param_area_save(&p) != 0)"
    ],
    [
     834,
     "    {"
    ],
    [
     835,
     "        OTA_ERR(\"[OTA] param save FAILED (TRY_NEW)\\r\\n\");"
    ],
    [
     836,
     "    }"
    ],
    [
     837,
     ""
    ],
    [
     838,
     "    ota_set_state(OTA_ST_READY_REBOOT, \"update ok, reboot in 3s\");"
    ],
    [
     839,
     "    OTA_LOG(\"[OTA] set TRY_NEW, reboot in 3s...\\r\\n\");"
    ],
    [
     840,
     ""
    ],
    [
     841,
     "    for (i = 3; i > 0; i--)"
    ],
    [
     842,
     "    {"
    ],
    [
     843,
     "        ota_feed_watchdog();"
    ],
    [
     844,
     "        HAL_Delay(1000);"
    ],
    [
     845,
     "    }"
    ],
    [
     846,
     ""
    ],
    [
     847,
     "    NVIC_SystemReset();"
    ],
    [
     848,
     "}"
    ]
   ]
  },
  "confirm_success": {
   "id": "confirm_success",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "ota_confirm_boot_success",
   "from": 949,
   "to": 994,
   "note": "ota_confirm_boot_success：固化为 NORMAL、清计数与暂存信息",
   "grade": "A",
   "lines": [
    [
     949,
     "int ota_confirm_boot_success(void)"
    ],
    [
     950,
     "{"
    ],
    [
     951,
     "    ota_param_t p;"
    ],
    [
     952,
     "    int need_save = 0;"
    ],
    [
     953,
     ""
    ],
    [
     954,
     "    if (param_area_load(&p) != 0)"
    ],
    [
     955,
     "    {"
    ],
    [
     956,
     "        return -1;"
    ],
    [
     957,
     "    }"
    ],
    [
     958,
     ""
    ],
    [
     959,
     "    /* 版本号不匹配就更新（回滚/恢复出厂后版本会变） */"
    ],
    [
     960,
     "    if (p.version != OTA_APP_VERSION_NUM)"
    ],
    [
     961,
     "    {"
    ],
    [
     962,
     "        p.version = OTA_APP_VERSION_NUM;"
    ],
    [
     963,
     "        need_save = 1;"
    ],
    [
     964,
     "    }"
    ],
    [
     965,
     ""
    ],
    [
     966,
     "    if (p.boot_flag != OTA_BOOT_FLAG_TRY_NEW)"
    ],
    [
     967,
     "    {"
    ],
    [
     968,
     "        if (need_save != 0)"
    ],
    [
     969,
     "        {"
    ],
    [
     970,
     "            (void)param_area_save(&p);"
    ],
    [
     971,
     "        }"
    ],
    [
     972,
     "        return 0;"
    ],
    [
     973,
     "    }"
    ],
    [
     974,
     ""
    ],
    [
     975,
     "    /* 新固件已稳定运行满窗口：固化为 NORMAL */"
    ],
    [
     976,
     "    p.boot_flag      = OTA_BOOT_FLAG_NORMAL;"
    ],
    [
     977,
     "    p.boot_count     = 0U;"
    ],
    [
     978,
     "    p.version        = OTA_APP_VERSION_NUM;"
    ],
    [
     979,
     "    p.resume_offset  = 0U;"
    ],
    [
     980,
     "    p.backup_status  = OTA_BACKUP_VALID;"
    ],
    [
     981,
     "    p.image_len      = 0U;"
    ],
    [
     982,
     "    (void)memset(p.image_sha, 0, sizeof(p.image_sha));"
    ],
    [
     983,
     "    p.dl_tid         = 0U;"
    ],
    [
     984,
     ""
    ],
    [
     985,
     "    if (param_area_save(&p) != 0)"
    ],
    [
     986,
     "    {"
    ],
    [
     987,
     "        return -2;"
    ],
    [
     988,
     "    }"
    ],
    [
     989,
     ""
    ],
    [
     990,
     "    OTA_LOG(\"[OTA] boot confirmed, flag=NORMAL, ver=0x%06lX\\r\\n\","
    ],
    [
     991,
     "            (unsigned long)p.version);"
    ],
    [
     992,
     ""
    ],
    [
     993,
     "    return 0;"
    ],
    [
     994,
     "}"
    ]
   ]
  },
  "boot_confirm": {
   "id": "boot_confirm",
   "project": "HAL_F429IGT6_App_2",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App_2/OTA/ota_engine.c",
   "func": "ota_boot_confirm_if_needed",
   "from": 1035,
   "to": 1086,
   "note": "ota_boot_confirm_if_needed：TRY_NEW 首启横幅 + 30s 静默窗口 + 确认",
   "grade": "A",
   "lines": [
    [
     1035,
     "int ota_boot_confirm_if_needed(void)"
    ],
    [
     1036,
     "{"
    ],
    [
     1037,
     "    static ota_param_t p;"
    ],
    [
     1038,
     "    uint32_t waited = 0U;"
    ],
    [
     1039,
     ""
    ],
    [
     1040,
     "    if (param_area_load(&p) != 0)"
    ],
    [
     1041,
     "    {"
    ],
    [
     1042,
     "        return 0;"
    ],
    [
     1043,
     "    }"
    ],
    [
     1044,
     "    if (p.boot_flag != OTA_BOOT_FLAG_TRY_NEW)"
    ],
    [
     1045,
     "    {"
    ],
    [
     1046,
     "        /*"
    ],
    [
     1047,
     "         * 普通启动也要同步 param.version = 当前固件版本！"
    ],
    [
     1048,
     "         *"
    ],
    [
     1049,
     "         * 为什么必须有这一步："
    ],
    [
     1050,
     "         *   板子从 1.0.1 手动烧回 1.0.0 时，参数区里残留的 version 仍是 0x010001。"
    ],
    [
     1051,
     "         *   于是 ota_run_once() 里 \"target(1.0.1) <= param.version(0x010001)\" 成立，"
    ],
    [
     1052,
     "         *   被判定为\"已经是最新版本\"，直接补报 201 并返回 1 ——"
    ],
    [
     1053,
     "         *   一个字节都不下载，但平台会收到\"升级成功\"，造成假成功。"
    ],
    [
     1054,
     "         *   ota_confirm_boot_success() 内部只同步版本号、不改 flag，所以这里安全。"
    ],
    [
     1055,
     "         */"
    ],
    [
     1056,
     "        (void)ota_confirm_boot_success();"
    ],
    [
     1057,
     "        return 0;   /* 普通启动，不需要 30s 静默窗口 */"
    ],
    [
     1058,
     "    }"
    ],
    [
     1059,
     ""
    ],
    [
     1060,
     "    OTA_ERR(\"\\r\\n\");"
    ],
    [
     1061,
     "    OTA_ERR(\"[OTA] ##################################################\\r\\n\");"
    ],
    [
     1062,
     "    OTA_ERR(\"[OTA] #                                                #\\r\\n\");"
    ],
    [
     1063,
     "    OTA_ERR(\"[OTA] #     NEW FIRMWARE FIRST BOOT  (boot_flag=TRY_NEW)\\r\\n\");"
    ],
    [
     1064,
     "    OTA_ERR(\"[OTA] #                                                #\\r\\n\");"
    ],
    [
     1065,
     "    OTA_ERR(\"[OTA] #     version : %s\\r\\n\", OTA_APP_VERSION_STR);"
    ],
    [
     1066,
     "    OTA_ERR(\"[OTA] #     build   : %s  %s\\r\\n\", __DATE__, __TIME__);"
    ],
    [
     1067,
     "    OTA_ERR(\"[OTA] #     silent  : %lu ms\\r\\n\", (unsigned long)OTA_STARTUP_CONFIRM_MS);"
    ],
    [
     1068,
     "    OTA_ERR(\"[OTA] #                                                #\\r\\n\");"
    ],
    [
     1069,
     "    OTA_ERR(\"[OTA] ##################################################\\r\\n\");"
    ],
    [
     1070,
     ""
    ],
    [
     1071,
     "    /* 静默窗口：这期间任何崩溃/看门狗复位都会让 BL 的 boot_count +1，"
    ],
    [
     1072,
     "       连续 3 次就自动回滚到备份版本。所以这里必须喂狗并稳定运行。 */"
    ],
    [
     1073,
     "    while (waited < OTA_STARTUP_CONFIRM_MS)"
    ],
    [
     1074,
     "    {"
    ],
    [
     1075,
     "        ota_feed_watchdog();"
    ],
    [
     1076,
     "        HAL_Delay(100);"
    ],
    [
     1077,
     "        waited += 100U;"
    ],
    [
     1078,
     "    }"
    ],
    [
     1079,
     ""
    ],
    [
     1080,
     "    (void)ota_confirm_boot_success();"
    ],
    [
     1081,
     ""
    ],
    [
     1082,
     "    OTA_ERR(\"[OTA] >>> BOOT CONFIRMED: flag=NORMAL, version=%s\\r\\n\\r\\n\","
    ],
    [
     1083,
     "            OTA_APP_VERSION_STR);"
    ],
    [
     1084,
     ""
    ],
    [
     1085,
     "    return 1;"
    ],
    [
     1086,
     "}"
    ]
   ]
  },
  "pending201": {
   "id": "pending201",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "ota_report_pending_201",
   "from": 998,
   "to": 1026,
   "note": "ota_report_pending_201：补报上次升级成功",
   "grade": "A",
   "lines": [
    [
     998,
     "int ota_report_pending_201(void)"
    ],
    [
     999,
     "{"
    ],
    [
     1000,
     "    ota_param_t p;"
    ],
    [
     1001,
     ""
    ],
    [
     1002,
     "    if (param_area_load(&p) != 0)"
    ],
    [
     1003,
     "    {"
    ],
    [
     1004,
     "        return 1;"
    ],
    [
     1005,
     "    }"
    ],
    [
     1006,
     "    if (p.ota_tid == 0U)"
    ],
    [
     1007,
     "    {"
    ],
    [
     1008,
     "        return 1;"
    ],
    [
     1009,
     "    }"
    ],
    [
     1010,
     "    if (p.version != OTA_APP_VERSION_NUM)"
    ],
    [
     1011,
     "    {"
    ],
    [
     1012,
     "        return 1;   /* 版本不符：不是本次升级的结果 */"
    ],
    [
     1013,
     "    }"
    ],
    [
     1014,
     ""
    ],
    [
     1015,
     "    if (ota_api_report_status(p.ota_tid, 201U) != 0)"
    ],
    [
     1016,
     "    {"
    ],
    [
     1017,
     "        return -1;"
    ],
    [
     1018,
     "    }"
    ],
    [
     1019,
     ""
    ],
    [
     1020,
     "    p.ota_tid = 0U;"
    ],
    [
     1021,
     "    (void)param_area_save(&p);"
    ],
    [
     1022,
     ""
    ],
    [
     1023,
     "    OTA_LOG(\"[OTA] reported 201 to platform\\r\\n\");"
    ],
    [
     1024,
     ""
    ],
    [
     1025,
     "    return 0;"
    ],
    [
     1026,
     "}"
    ]
   ]
  },
  "recovery_init": {
   "id": "recovery_init",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "path": "HAL_F429IGT6_App/OTA/ota_engine.c",
   "func": "ota_init_recovery_if_empty",
   "from": 852,
   "to": 945,
   "note": "ota_init_recovery_if_empty：首次运行时把当前 A 槽固件固化到恢复区",
   "grade": "A",
   "lines": [
    [
     852,
     "int ota_init_recovery_if_empty(void)"
    ],
    [
     853,
     "{"
    ],
    [
     854,
     "    static uint8_t buf[1024];       /* 静态缓冲：本工程 startup 里的 Heap_Size 很小，"
    ],
    [
     855,
     "                                        malloc(1024) 会失败，所以不能用 malloc */"
    ],
    [
     856,
     "    ota_param_t p;"
    ],
    [
     857,
     "    uint8_t head[16];"
    ],
    [
     858,
     "    sha256_ctx_t ctx;"
    ],
    [
     859,
     "    uint8_t sha[SHA256_DIGEST_SIZE];"
    ],
    [
     860,
     "    uint32_t fw_len;"
    ],
    [
     861,
     "    uint32_t copied = 0U;"
    ],
    [
     862,
     "    uint32_t off;"
    ],
    [
     863,
     "    uint32_t i;"
    ],
    [
     864,
     "    int empty = 1;"
    ],
    [
     865,
     ""
    ],
    [
     866,
     "    if (param_area_load(&p) != 0)"
    ],
    [
     867,
     "    {"
    ],
    [
     868,
     "        param_area_defaults(&p);"
    ],
    [
     869,
     "    }"
    ],
    [
     870,
     "    if (p.recovery_len != 0U)"
    ],
    [
     871,
     "    {"
    ],
    [
     872,
     "        return 0;   /* 已经初始化过 */"
    ],
    [
     873,
     "    }"
    ],
    [
     874,
     ""
    ],
    [
     875,
     "    if (w25q16_read(EXT_RECOVERY_ADDR, head, (uint32_t)sizeof(head)) != HAL_OK)"
    ],
    [
     876,
     "    {"
    ],
    [
     877,
     "        return -1;"
    ],
    [
     878,
     "    }"
    ],
    [
     879,
     "    for (i = 0U; i < (uint32_t)sizeof(head); i++)"
    ],
    [
     880,
     "    {"
    ],
    [
     881,
     "        if (head[i] != 0xFFU)"
    ],
    [
     882,
     "        {"
    ],
    [
     883,
     "            empty = 0;"
    ],
    [
     884,
     "            break;"
    ],
    [
     885,
     "        }"
    ],
    [
     886,
     "    }"
    ],
    [
     887,
     "    if (empty == 0)"
    ],
    [
     888,
     "    {"
    ],
    [
     889,
     "        /* 有内容但参数区没记录：保守起见不覆盖 */"
    ],
    [
     890,
     "        OTA_LOG(\"[OTA] recovery not empty but no record, skip init\\r\\n\");"
    ],
    [
     891,
     "        return 0;"
    ],
    [
     892,
     "    }"
    ],
    [
     893,
     ""
    ],
    [
     894,
     "    fw_len = ota_probe_run_len();"
    ],
    [
     895,
     ""
    ],
    [
     896,
     "    OTA_LOG(\"[OTA] init recovery (factory) image: %lu bytes...\\r\\n\","
    ],
    [
     897,
     "            (unsigned long)fw_len);"
    ],
    [
     898,
     ""
    ],
    [
     899,
     "    for (off = 0U; off < OTA_APP_IMAGE_MAX_SIZE; off += 65536U)"
    ],
    [
     900,
     "    {"
    ],
    [
     901,
     "        if (w25q16_erase_block(EXT_RECOVERY_ADDR + off) != HAL_OK)"
    ],
    [
     902,
     "        {"
    ],
    [
     903,
     "            OTA_ERR(\"[OTA] erase recovery FAILED @%lu\\r\\n\", (unsigned long)off);"
    ],
    [
     904,
     "            return -2;"
    ],
    [
     905,
     "        }"
    ],
    [
     906,
     "        ota_feed_watchdog();"
    ],
    [
     907,
     "    }"
    ],
    [
     908,
     ""
    ],
    [
     909,
     "    sha256_init(&ctx);"
    ],
    [
     910,
     "    while (copied < fw_len)"
    ],
    [
     911,
     "    {"
    ],
    [
     912,
     "        uint32_t take = fw_len - copied;"
    ],
    [
     913,
     ""
    ],
    [
     914,
     "        if (take > 1024U)"
    ],
    [
     915,
     "        {"
    ],
    [
     916,
     "            take = 1024U;"
    ],
    [
     917,
     "        }"
    ],
    [
     918,
     ""
    ],
    [
     919,
     "        flash_if_read(OTA_APP_A_ADDR + copied, buf, take);"
    ],
    [
     920,
     ""
    ],
    [
     921,
     "        if (w25q16_write(EXT_RECOVERY_ADDR + copied, buf, take) != HAL_OK)"
    ],
    [
     922,
     "        {"
    ],
    [
     923,
     "            return -3;"
    ],
    [
     924,
     "        }"
    ],
    [
     925,
     ""
    ],
    [
     926,
     "        sha256_update(&ctx, buf, take);"
    ],
    [
     927,
     "        copied += take;"
    ],
    [
     928,
     ""
    ],
    [
     929,
     "        ota_feed_watchdog();"
    ],
    [
     930,
     "    }"
    ],
    [
     931,
     "    sha256_final(&ctx, sha);"
    ],
    [
     932,
     ""
    ],
    [
     933,
     "    p.recovery_len = fw_len;"
    ],
    [
     934,
     "    (void)memcpy(p.recovery_sha, sha, sizeof(sha));"
    ],
    [
     935,
     ""
    ],
    [
     936,
     "    if (param_area_save(&p) != 0)"
    ],
    [
     937,
     "    {"
    ],
    [
     938,
     "        OTA_ERR(\"[OTA] param save FAILED (recovery)\\r\\n\");"
    ],
    [
     939,
     "        return -4;"
    ],
    [
     940,
     "    }"
    ],
    [
     941,
     ""
    ],
    [
     942,
     "    OTA_LOG(\"[OTA] recovery init done\\r\\n\");"
    ],
    [
     943,
     ""
    ],
    [
     944,
     "    return 0;"
    ],
    [
     945,
     "}"
    ]
   ]
  },
  "http_req_head": {
   "id": "http_req_head",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/http_client.c",
   "path": "HAL_F429IGT6_App/OTA/http_client.c",
   "func": "(非函数体)",
   "from": 154,
   "to": 245,
   "note": "http_client_request_once：CIPSTART → CIPSEND → 状态行容错跳过 8 行",
   "grade": "A",
   "lines": [
    [
     154,
     "    /* 1. TCP 连接 */"
    ],
    [
     155,
     "    /* ★ 发请求前先丢弃接收缓冲里的残留字节。"
    ],
    [
     156,
     "       上一个请求结束时模块可能异步打印 CLOSED/OK，若不清掉，"
    ],
    [
     157,
     "       后续 esp01s_send()/读状态行时可能匹配到旧文本，表现为\"发不出去/等不到响应\"。 */"
    ],
    [
     158,
     "    esp01s_flush_rx();"
    ],
    [
     159,
     "    printf(\"[HTTP] CIPSTART %s:%u ...\\r\\n\", host, (unsigned)port);"
    ],
    [
     160,
     "    if (esp01s_tcp_connect(host, port, 5000) != ESP_OK)"
    ],
    [
     161,
     "    {"
    ],
    [
     162,
     "        /*  建连失败也收尾一次：避免模块残留 TCP 状态"
    ],
    [
     163,
     "           （AT 引擎忙）导致下次 init/建连卡死 */"
    ],
    [
     164,
     "        printf(\"[HTTP] CIPSTART FAILED\\r\\n\");"
    ],
    [
     165,
     "        esp01s_tcp_close();"
    ],
    [
     166,
     "        return ESP_ERR;"
    ],
    [
     167,
     "    }"
    ],
    [
     168,
     ""
    ],
    [
     169,
     "    /* 2. 构造请求：有 body 时头 + body 合并为一次 CIPSEND，"
    ],
    [
     170,
     "       减少发送阶段的 AT 往返与\"服务器响应抢在 SEND OK 前到达\"的竞态窗口 */"
    ],
    [
     171,
     "    if (body != NULL && body[0] != '\\0')"
    ],
    [
     172,
     "    {"
    ],
    [
     173,
     "        int hl = snprintf(req, sizeof(req),"
    ],
    [
     174,
     "                 \"%s %s HTTP/1.1\\r\\n\""
    ],
    [
     175,
     "                 \"Host: %s\\r\\n\""
    ],
    [
     176,
     "                 \"Content-Length: %u\\r\\n\""
    ],
    [
     177,
     "                 \"%s\""
    ],
    [
     178,
     "                 \"Connection: close\\r\\n\""
    ],
    [
     179,
     "                 \"\\r\\n\","
    ],
    [
     180,
     "                 method, path, host, (unsigned)strlen(body),"
    ],
    [
     181,
     "                 (extra_hdr != NULL) ? extra_hdr : \"\");"
    ],
    [
     182,
     "        if (hl < 0 || (uint32_t)hl + strlen(body) >= sizeof(req))"
    ],
    [
     183,
     "        {"
    ],
    [
     184,
     "            esp01s_tcp_close();"
    ],
    [
     185,
     "            return ESP_ERR;"
    ],
    [
     186,
     "        }"
    ],
    [
     187,
     "        memcpy(req + hl, body, strlen(body) + 1U);   /* 连 '\\0' 一起拷入 */"
    ],
    [
     188,
     "    }"
    ],
    [
     189,
     "    else if (extra_hdr != NULL)"
    ],
    [
     190,
     "    {"
    ],
    [
     191,
     "        snprintf(req, sizeof(req),"
    ],
    [
     192,
     "                 \"%s %s HTTP/1.1\\r\\n\""
    ],
    [
     193,
     "                 \"Host: %s\\r\\n\""
    ],
    [
     194,
     "                 \"%s\""
    ],
    [
     195,
     "                 \"Connection: close\\r\\n\""
    ],
    [
     196,
     "                 \"\\r\\n\","
    ],
    [
     197,
     "                 method, path, host, extra_hdr);"
    ],
    [
     198,
     "    }"
    ],
    [
     199,
     "    else"
    ],
    [
     200,
     "    {"
    ],
    [
     201,
     "        snprintf(req, sizeof(req),"
    ],
    [
     202,
     "                 \"%s %s HTTP/1.1\\r\\n\""
    ],
    [
     203,
     "                 \"Host: %s\\r\\n\""
    ],
    [
     204,
     "                 \"Connection: close\\r\\n\""
    ],
    [
     205,
     "                 \"\\r\\n\","
    ],
    [
     206,
     "                 method, path, host);"
    ],
    [
     207,
     "    }"
    ],
    [
     208,
     "    printf(\"[HTTP] CIPSEND %u bytes ...\\r\\n\", (unsigned)strlen(req));"
    ],
    [
     209,
     "    if (esp01s_send((const uint8_t *)req, (uint32_t)strlen(req), 3000) != ESP_OK)"
    ],
    [
     210,
     "    {"
    ],
    [
     211,
     "        printf(\"[HTTP] CIPSEND FAILED (no SEND OK)\\r\\n\");"
    ],
    [
     212,
     "        esp01s_tcp_close();"
    ],
    [
     213,
     "        return ESP_ERR;"
    ],
    [
     214,
     "    }"
    ],
    [
     215,
     "    printf(\"[HTTP] sent OK, waiting response...\\r\\n\");"
    ],
    [
     216,
     ""
    ],
    [
     217,
     "    /* 3. 状态行：HTTP/1.1 200 OK / 206 Partial Content"
    ],
    [
     218,
     "        容错：AT 固件可能在响应前混入杂讯行"
    ],
    [
     219,
     "       （CLOSED/ERROR/空行等，v7/v8 监听实证），最多跳过 8 行 */"
    ],
    [
     220,
     "    r = http_read_line(line, sizeof(line), 3000);"
    ],
    [
     221,
     "    if (r < 0)"
    ],
    [
     222,
     "    {"
    ],
    [
     223,
     "        printf(\"[HTTP] read status line TIMEOUT\\r\\n\");"
    ],
    [
     224,
     "        esp01s_tcp_close();"
    ],
    [
     225,
     "        return r;"
    ],
    [
     226,
     "    }"
    ],
    [
     227,
     "    for (int skip = 0; skip < 8 &&"
    ],
    [
     228,
     "         strncmp(line, \"HTTP/1.1 \", 9) != 0; skip++)"
    ],
    [
     229,
     "    {"
    ],
    [
     230,
     "        r = http_read_line(line, sizeof(line), 3000);"
    ],
    [
     231,
     "        if (r < 0)"
    ],
    [
     232,
     "        {"
    ],
    [
     233,
     "            esp01s_tcp_close();"
    ],
    [
     234,
     "            return r;"
    ],
    [
     235,
     "        }"
    ],
    [
     236,
     "    }"
    ],
    [
     237,
     "    if (strncmp(line, \"HTTP/1.1 \", 9) == 0)"
    ],
    [
     238,
     "    {"
    ],
    [
     239,
     "        resp->status_code = atoi(line + 9);"
    ],
    [
     240,
     "    }"
    ],
    [
     241,
     "    else"
    ],
    [
     242,
     "    {"
    ],
    [
     243,
     "        esp01s_tcp_close();"
    ],
    [
     244,
     "        return ESP_ERR;"
    ],
    [
     245,
     "    }"
    ]
   ]
  },
  "http_req_hdr": {
   "id": "http_req_hdr",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/http_client.c",
   "path": "HAL_F429IGT6_App/OTA/http_client.c",
   "func": "(非函数体)",
   "from": 247,
   "to": 289,
   "note": "响应头解析：Content-Length / Content-Range / Transfer-Encoding / Ota-Errno",
   "grade": "A",
   "lines": [
    [
     247,
     "    /* 4. 响应头：直到空行 */"
    ],
    [
     248,
     "    while (1)"
    ],
    [
     249,
     "    {"
    ],
    [
     250,
     "        r = http_read_line(line, sizeof(line), 3000);"
    ],
    [
     251,
     "        if (r < 0)"
    ],
    [
     252,
     "        {"
    ],
    [
     253,
     "            esp01s_tcp_close();"
    ],
    [
     254,
     "            return r;"
    ],
    [
     255,
     "        }"
    ],
    [
     256,
     "        if (r == 0)"
    ],
    [
     257,
     "        {"
    ],
    [
     258,
     "            break;   /* 空行：头结束 */"
    ],
    [
     259,
     "        }"
    ],
    [
     260,
     "        if (strncmp(line, \"Content-Length:\", 15) == 0)"
    ],
    [
     261,
     "        {"
    ],
    [
     262,
     "            resp->content_len = (uint32_t)strtoul(line + 15, NULL, 10);"
    ],
    [
     263,
     "        }"
    ],
    [
     264,
     "        else if (strncmp(line, \"Content-Range:\", 14) == 0)"
    ],
    [
     265,
     "        {"
    ],
    [
     266,
     "            /* 形如 bytes 1024-190399/190400 */"
    ],
    [
     267,
     "            char *p = strchr(line + 14, ' ');"
    ],
    [
     268,
     "            if (p != NULL)"
    ],
    [
     269,
     "            {"
    ],
    [
     270,
     "                p++;"
    ],
    [
     271,
     "                resp->start_offset = (uint32_t)strtoul(p, &p, 10);"
    ],
    [
     272,
     "                if (*p == '-') p++;"
    ],
    [
     273,
     "                (void)strtoul(p, &p, 10);   /* end */"
    ],
    [
     274,
     "                if (*p == '/') p++;"
    ],
    [
     275,
     "                resp->total_size = (uint32_t)strtoul(p, NULL, 10);"
    ],
    [
     276,
     "            }"
    ],
    [
     277,
     "        }"
    ],
    [
     278,
     "        else if (strncmp(line, \"Transfer-Encoding:\", 18) == 0)"
    ],
    [
     279,
     "        {"
    ],
    [
     280,
     "            if (strstr(line + 18, \"chunked\") != NULL)"
    ],
    [
     281,
     "            {"
    ],
    [
     282,
     "                chunked = 1;"
    ],
    [
     283,
     "            }"
    ],
    [
     284,
     "        }"
    ],
    [
     285,
     "        else if (strncmp(line, \"Ota-Errno:\", 10) == 0)"
    ],
    [
     286,
     "        {"
    ],
    [
     287,
     "            resp->ota_errno = atoi(line + 10);"
    ],
    [
     288,
     "        }"
    ],
    [
     289,
     "    }"
    ]
   ]
  },
  "http_req_body": {
   "id": "http_req_body",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/http_client.c",
   "path": "HAL_F429IGT6_App/OTA/http_client.c",
   "func": "(非函数体)",
   "from": 291,
   "to": 409,
   "note": "正文读取：chunked 解码 / 定长 / 读到连接关闭",
   "grade": "A",
   "lines": [
    [
     291,
     "    /* 5. 读取正文 */"
    ],
    [
     292,
     "    if (chunked)"
    ],
    [
     293,
     "    {"
    ],
    [
     294,
     "        /* chunked 解码：循环读\"大小行 + 数据 + CRLF\"，直至 0 分块与尾随头 */"
    ],
    [
     295,
     "        for (;;)"
    ],
    [
     296,
     "        {"
    ],
    [
     297,
     "            uint32_t csize;"
    ],
    [
     298,
     ""
    ],
    [
     299,
     "            if (resp->abort_flag != NULL && *resp->abort_flag != 0)"
    ],
    [
     300,
     "            {"
    ],
    [
     301,
     "                break;"
    ],
    [
     302,
     "            }"
    ],
    [
     303,
     "            r = http_read_line(line, sizeof(line), timeout_ms);"
    ],
    [
     304,
     "            if (r < 0)"
    ],
    [
     305,
     "            {"
    ],
    [
     306,
     "                esp01s_tcp_close();"
    ],
    [
     307,
     "                return r;"
    ],
    [
     308,
     "            }"
    ],
    [
     309,
     "            if (http_parse_chunk_size(line, &csize) != 0)"
    ],
    [
     310,
     "            {"
    ],
    [
     311,
     "                esp01s_tcp_close();"
    ],
    [
     312,
     "                return ESP_ERR;"
    ],
    [
     313,
     "            }"
    ],
    [
     314,
     "            if (csize == 0)"
    ],
    [
     315,
     "            {"
    ],
    [
     316,
     "                /* 尾随头直至空行 */"
    ],
    [
     317,
     "                while (1)"
    ],
    [
     318,
     "                {"
    ],
    [
     319,
     "                    r = http_read_line(line, sizeof(line), timeout_ms);"
    ],
    [
     320,
     "                    if (r < 0)"
    ],
    [
     321,
     "                    {"
    ],
    [
     322,
     "                        esp01s_tcp_close();"
    ],
    [
     323,
     "                        return r;"
    ],
    [
     324,
     "                    }"
    ],
    [
     325,
     "                    if (r == 0)"
    ],
    [
     326,
     "                    {"
    ],
    [
     327,
     "                        break;"
    ],
    [
     328,
     "                    }"
    ],
    [
     329,
     "                }"
    ],
    [
     330,
     "                break;"
    ],
    [
     331,
     "            }"
    ],
    [
     332,
     "            remaining = csize;"
    ],
    [
     333,
     "            while (remaining > 0)"
    ],
    [
     334,
     "            {"
    ],
    [
     335,
     "                if (resp->abort_flag != NULL && *resp->abort_flag != 0)"
    ],
    [
     336,
     "                {"
    ],
    [
     337,
     "                    break;"
    ],
    [
     338,
     "                }"
    ],
    [
     339,
     "                want = (remaining > sizeof(chunk)) ? (uint32_t)sizeof(chunk) : remaining;"
    ],
    [
     340,
     "                r = http_read_body(chunk, want, timeout_ms, on_data, arg, resp);"
    ],
    [
     341,
     "                if (r <= 0)"
    ],
    [
     342,
     "                {"
    ],
    [
     343,
     "                    esp01s_tcp_close();"
    ],
    [
     344,
     "                    return (r < 0) ? r : ESP_ERR;"
    ],
    [
     345,
     "                }"
    ],
    [
     346,
     "                remaining -= (uint32_t)r;"
    ],
    [
     347,
     "            }"
    ],
    [
     348,
     "            if (remaining > 0)"
    ],
    [
     349,
     "            {"
    ],
    [
     350,
     "                break;   /* 被中止标志截断 */"
    ],
    [
     351,
     "            }"
    ],
    [
     352,
     "            /* 分块结尾 CRLF */"
    ],
    [
     353,
     "            r = http_read_line(line, sizeof(line), timeout_ms);"
    ],
    [
     354,
     "            if (r < 0)"
    ],
    [
     355,
     "            {"
    ],
    [
     356,
     "                esp01s_tcp_close();"
    ],
    [
     357,
     "                return r;"
    ],
    [
     358,
     "            }"
    ],
    [
     359,
     "        }"
    ],
    [
     360,
     "    }"
    ],
    [
     361,
     "    else if (resp->content_len > 0)"
    ],
    [
     362,
     "    {"
    ],
    [
     363,
     "        remaining = resp->content_len;"
    ],
    [
     364,
     "        while (remaining > 0)"
    ],
    [
     365,
     "        {"
    ],
    [
     366,
     "            if (resp->abort_flag != NULL && *resp->abort_flag != 0)"
    ],
    [
     367,
     "            {"
    ],
    [
     368,
     "                break;"
    ],
    [
     369,
     "            }"
    ],
    [
     370,
     "            want = (remaining > sizeof(chunk)) ? (uint32_t)sizeof(chunk) : remaining;"
    ],
    [
     371,
     "            r = http_read_body(chunk, want, timeout_ms, on_data, arg, resp);"
    ],
    [
     372,
     "            if (r <= 0)"
    ],
    [
     373,
     "            {"
    ],
    [
     374,
     "                esp01s_tcp_close();"
    ],
    [
     375,
     "                return (r < 0) ? r : ESP_ERR;"
    ],
    [
     376,
     "            }"
    ],
    [
     377,
     "            remaining -= (uint32_t)r;"
    ],
    [
     378,
     "        }"
    ],
    [
     379,
     "    }"
    ],
    [
     380,
     "    else if (keep_body)"
    ],
    [
     381,
     "    {"
    ],
    [
     382,
     "        /* 无 Content-Length 亦非 chunked：读至连接关闭（Connection: close） */"
    ],
    [
     383,
     "        for (;;)"
    ],
    [
     384,
     "        {"
    ],
    [
     385,
     "            if (resp->abort_flag != NULL && *resp->abort_flag != 0)"
    ],
    [
     386,
     "            {"
    ],
    [
     387,
     "                break;"
    ],
    [
     388,
     "            }"
    ],
    [
     389,
     "            r = http_read_body(chunk, sizeof(chunk), timeout_ms, on_data, arg, resp);"
    ],
    [
     390,
     "            if (r == ESP_CLOSED)"
    ],
    [
     391,
     "            {"
    ],
    [
     392,
     "                break;"
    ],
    [
     393,
     "            }"
    ],
    [
     394,
     "            if (r == ESP_TIMEOUT)"
    ],
    [
     395,
     "            {"
    ],
    [
     396,
     "                esp01s_tcp_close();"
    ],
    [
     397,
     "                return ESP_TIMEOUT;"
    ],
    [
     398,
     "            }"
    ],
    [
     399,
     "            if (r < 0)"
    ],
    [
     400,
     "            {"
    ],
    [
     401,
     "                esp01s_tcp_close();"
    ],
    [
     402,
     "                return r;"
    ],
    [
     403,
     "            }"
    ],
    [
     404,
     "        }"
    ],
    [
     405,
     "    }"
    ],
    [
     406,
     ""
    ],
    [
     407,
     "    esp01s_tcp_close();"
    ],
    [
     408,
     "    return ESP_OK;"
    ],
    [
     409,
     "}"
    ]
   ]
  },
  "http_wrap": {
   "id": "http_wrap",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/http_client.c",
   "path": "HAL_F429IGT6_App/OTA/http_client.c",
   "func": "http_client_request",
   "from": 419,
   "to": 445,
   "note": "请求包装：下载类请求不重试，其余最多 3 次",
   "grade": "A",
   "lines": [
    [
     419,
     "int http_client_request(const char *host, uint16_t port,"
    ],
    [
     420,
     "                        const char *method, const char *path,"
    ],
    [
     421,
     "                        const char *extra_hdr, const char *body,"
    ],
    [
     422,
     "                        http_resp_t *resp,"
    ],
    [
     423,
     "                        void (*on_data)(const uint8_t *data, uint32_t len, void *arg),"
    ],
    [
     424,
     "                        void *arg, uint32_t timeout_ms)"
    ],
    [
     425,
     "{"
    ],
    [
     426,
     "    int attempt;"
    ],
    [
     427,
     "    int r;"
    ],
    [
     428,
     "    int max_attempt = (on_data != NULL) ? 1 : 3;"
    ],
    [
     429,
     ""
    ],
    [
     430,
     "    for (attempt = 0; attempt < max_attempt; attempt++)"
    ],
    [
     431,
     "    {"
    ],
    [
     432,
     "        r = http_client_request_once(host, port, method, path, extra_hdr, body,"
    ],
    [
     433,
     "                                     resp, on_data, arg, timeout_ms);"
    ],
    [
     434,
     "        if (r == ESP_OK)"
    ],
    [
     435,
     "        {"
    ],
    [
     436,
     "            return ESP_OK;"
    ],
    [
     437,
     "        }"
    ],
    [
     438,
     "        if (attempt + 1 < max_attempt)"
    ],
    [
     439,
     "        {"
    ],
    [
     440,
     "            esp01s_tcp_close();   /* 清残留 TCP 状态，避免模块 AT 引擎忙 */"
    ],
    [
     441,
     "            HAL_Delay(200);       /* 给模块/网络短暂恢复时间 */"
    ],
    [
     442,
     "        }"
    ],
    [
     443,
     "    }"
    ],
    [
     444,
     "    return r;"
    ],
    [
     445,
     "}"
    ]
   ]
  },
  "esp_init": {
   "id": "esp_init",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "path": "HAL_F429IGT6_App/OTA/esp01s.c",
   "func": "esp01s_init",
   "from": 258,
   "to": 331,
   "note": "esp01s_init：先启 DMA 循环接收，再 AT 握手 / ATE0 / CIPMUX=0 / CIPMODE=0",
   "grade": "A",
   "lines": [
    [
     258,
     "int esp01s_init(void)"
    ],
    [
     259,
     "{"
    ],
    [
     260,
     "    int i;"
    ],
    [
     261,
     "    int ok = 0;"
    ],
    [
     262,
     ""
    ],
    [
     263,
     "    s_ring_head = 0;"
    ],
    [
     264,
     "    s_ring_tail = 0;"
    ],
    [
     265,
     "    s_data_len  = 0;"
    ],
    [
     266,
     "    s_data_head = 0;"
    ],
    [
     267,
     "    s_ipd_state = IPD_STATE_HEAD;"
    ],
    [
     268,
     "    s_ipd_len   = 0;"
    ],
    [
     269,
     "    s_ipd_line_n = 0;"
    ],
    [
     270,
     "    s_closed    = 0;"
    ],
    [
     271,
     ""
    ],
    [
     272,
     "    /*  必须先启动 USART3 RX DMA 循环接收，再发 AT 命令："
    ],
    [
     273,
     "       （原先的单字节中断在 flash 编程期间被 CPU stall 阻塞会 ORE"
    ],
    [
     274,
     "       丢字节，已整体改 DMA）DMA 硬件搬运不受 flash 编程影响。 */"
    ],
    [
     275,
     "    if (HAL_UART_Receive_DMA(&huart3, s_dma_rx, ESP_DMA_RX_SIZE) != HAL_OK)"
    ],
    [
     276,
     "    {"
    ],
    [
     277,
     "        /* 接收状态异常（HAL_BUSY，此前日志重试轮 init"
    ],
    [
     278,
     "           13ms 内秒败的根源）：先 Abort 复位接收状态，重试一次再失败 */"
    ],
    [
     279,
     "        (void)HAL_UART_AbortReceive(&huart3);"
    ],
    [
     280,
     "        HAL_Delay(10);"
    ],
    [
     281,
     "        if (HAL_UART_Receive_DMA(&huart3, s_dma_rx, ESP_DMA_RX_SIZE) != HAL_OK)"
    ],
    [
     282,
     "        {"
    ],
    [
     283,
     "            return ESP_ERR;"
    ],
    [
     284,
     "        }"
    ],
    [
     285,
     "    }"
    ],
    [
     286,
     ""
    ],
    [
     287,
     "    /* AT 命令必须带 \"\\r\\n\" 行结束符，ESP-AT 固件按行解析，"
    ],
    [
     288,
     "       无结束符的命令不会执行也不会回复。 */"
    ],
    [
     289,
     "    /* 先快速握手（模块健康时无需等待 RST 复位时间） */"
    ],
    [
     290,
     "    for (i = 0; i < 2; i++)"
    ],
    [
     291,
     "    {"
    ],
    [
     292,
     "        if (esp01s_at_cmd(\"AT\\r\\n\", \"OK\", 1500) == ESP_OK)"
    ],
    [
     293,
     "        {"
    ],
    [
     294,
     "            ok = 1;"
    ],
    [
     295,
     "            break;"
    ],
    [
     296,
     "        }"
    ],
    [
     297,
     "    }"
    ],
    [
     298,
     ""
    ],
    [
     299,
     "    /* 握手失败：模块可能处于卡死/中间态（例如上次"
    ],
    [
     300,
     "       AT+CIPSTART 超时未收尾），先尽力收尾 + 软复位，再长时探测："
    ],
    [
     301,
     "       模块内部 TCP/DNS 重试最长约 15~30s，期间引擎忙不响应任何"
    ],
    [
     302,
     "       命令，必须等它恢复空闲（最长 30s 恢复窗口）。 */"
    ],
    [
     303,
     "    if (!ok)"
    ],
    [
     304,
     "    {"
    ],
    [
     305,
     "        esp01s_at_cmd(\"AT+CIPCLOSE\\r\\n\", \"OK\", 800);   /* 尽力收尾残留连接 */"
    ],
    [
     306,
     "        esp01s_soft_reset();"
    ],
    [
     307,
     "        for (i = 0; i < 15; i++)    /* 15 × 2s = 最长 30s */"
    ],
    [
     308,
     "        {"
    ],
    [
     309,
     "            if (esp01s_at_cmd(\"AT\\r\\n\", \"OK\", 2000) == ESP_OK)"
    ],
    [
     310,
     "            {"
    ],
    [
     311,
     "                ok = 1;"
    ],
    [
     312,
     "                break;"
    ],
    [
     313,
     "            }"
    ],
    [
     314,
     "        }"
    ],
    [
     315,
     "        if (!ok)"
    ],
    [
     316,
     "        {"
    ],
    [
     317,
     "            return ESP_TIMEOUT;"
    ],
    [
     318,
     "        }"
    ],
    [
     319,
     "    }"
    ],
    [
     320,
     ""
    ],
    [
     321,
     "    esp01s_at_cmd(\"ATE0\\r\\n\", \"OK\", 1000);        /* 关闭回显（失败不致命） */"
    ],
    [
     322,
     "    esp01s_at_cmd(\"AT+CIPMUX=0\\r\\n\", \"OK\", 1000); /* 单连接模式 */"
    ],
    [
     323,
     "    esp01s_at_cmd(\"AT+CIPMODE=0\\r\\n\", \"OK\", 1000);/* 非透传模式 */"
    ],
    [
     324,
     "    /* 已删除 AT+CIPDNS_DEF：实测本固件（AT 2.3.0-dev /"
    ],
    [
     325,
     "       Bin 2.2.0）返回 ERROR，且紧接着触发 WIFI DISCONNECT（两次"
    ],
    [
     326,
     "       串口监听均复现），重连后的 TCP 为半死连接（CONNECT OK 但"
    ],
    [
     327,
     "       SEND OK 后服务器零响应即 CLOSED）。IP 直连不依赖模块 DNS，"
    ],
    [
     328,
     "       此命令无意义且有害，直接移除。 */"
    ],
    [
     329,
     ""
    ],
    [
     330,
     "    return ESP_OK;"
    ],
    [
     331,
     "}"
    ]
   ]
  },
  "esp_parse": {
   "id": "esp_parse",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "path": "HAL_F429IGT6_App/OTA/esp01s.c",
   "func": "esp01s_parse",
   "from": 135,
   "to": 240,
   "note": "★ +IPD,<len>: 帧头剥离状态机（HEAD/LEN/DATA），并识别 CLOSED/Unlink",
   "grade": "A",
   "lines": [
    [
     135,
     "static void esp01s_parse(void)"
    ],
    [
     136,
     "{"
    ],
    [
     137,
     "    esp01s_dma_to_ring();   /* 先把 DMA 新字节搬入接收环形缓冲 */"
    ],
    [
     138,
     ""
    ],
    [
     139,
     "    while (ring_available() > 0)"
    ],
    [
     140,
     "    {"
    ],
    [
     141,
     "        int b = ring_pop();"
    ],
    [
     142,
     "        if (b < 0) break;"
    ],
    [
     143,
     ""
    ],
    [
     144,
     "        if (s_ipd_state == IPD_STATE_HEAD)"
    ],
    [
     145,
     "        {"
    ],
    [
     146,
     "            /* 只有一帧开始处的 '+' 才可能是 IPD 帧头 */"
    ],
    [
     147,
     "            if (b == '+' && s_ipd_line_n == 0)"
    ],
    [
     148,
     "            {"
    ],
    [
     149,
     "                s_ipd_line[0] = '+';"
    ],
    [
     150,
     "                s_ipd_line_n  = 1;"
    ],
    [
     151,
     "                s_ipd_state   = IPD_STATE_LEN;"
    ],
    [
     152,
     "            }"
    ],
    [
     153,
     "            else if (b == '\\r' || b == '\\n')"
    ],
    [
     154,
     "            {"
    ],
    [
     155,
     "                /* +IPD 帧间的 \\r\\n 分隔符直接丢弃，不推入 s_data。"
    ],
    [
     156,
     "                   AT 2.3.0-dev 在 +IPD 帧之间会发 \\r\\n\\r\\n（帧尾标记），旧"
    ],
    [
     157,
     "                   逻辑把这些空白字节当成 body 数据推入 s_data，被"
    ],
    [
     158,
     "                   http_client 读走写 flash，导致 MD5 错（实测在 body 偏移"
    ],
    [
     159,
     "                   0x0A07 处插入 4 字节 \\r\\n\\r\\n，末尾 4 字节被挤出）。"
    ],
    [
     160,
     "                   body 数据在 DATA 态搬运，DATA 态不丢弃任何字节，不受影响。 */"
    ],
    [
     161,
     "            }"
    ],
    [
     162,
     "            else if (b == '+' && s_ipd_line_n > 0)"
    ],
    [
     163,
     "            {"
    ],
    [
     164,
     "                /* 上一行数据残留：视为数据 */"
    ],
    [
     165,
     "                if (s_data_len < ESP_DATA_BUF_SIZE)"
    ],
    [
     166,
     "                {"
    ],
    [
     167,
     "                    s_data[(s_data_head + s_data_len) % ESP_DATA_BUF_SIZE] = (uint8_t)b;"
    ],
    [
     168,
     "                    s_data_len++;"
    ],
    [
     169,
     "                }"
    ],
    [
     170,
     "            }"
    ],
    [
     171,
     "            else"
    ],
    [
     172,
     "            {"
    ],
    [
     173,
     "                /* 非 '+' 开头：AT 提示行或直接数据 */"
    ],
    [
     174,
     "                if (s_data_len < ESP_DATA_BUF_SIZE)"
    ],
    [
     175,
     "                {"
    ],
    [
     176,
     "                    s_data[(s_data_head + s_data_len) % ESP_DATA_BUF_SIZE] = (uint8_t)b;"
    ],
    [
     177,
     "                    s_data_len++;"
    ],
    [
     178,
     "                }"
    ],
    [
     179,
     "            }"
    ],
    [
     180,
     "        }"
    ],
    [
     181,
     "        else if (s_ipd_state == IPD_STATE_LEN)"
    ],
    [
     182,
     "        {"
    ],
    [
     183,
     "            /* 累积行，直到 ':' 或 '\\n' */"
    ],
    [
     184,
     "            if (s_ipd_line_n < (uint8_t)sizeof(s_ipd_line) - 1U)"
    ],
    [
     185,
     "            {"
    ],
    [
     186,
     "                s_ipd_line[s_ipd_line_n++] = (uint8_t)b;"
    ],
    [
     187,
     "            }"
    ],
    [
     188,
     "            if (b == '\\n')"
    ],
    [
     189,
     "            {"
    ],
    [
     190,
     "                /* 一整行结束，但没等到 ':'——可能是 \"CLOSED\"/\"Unlink\"/\"OK\" 等提示 */"
    ],
    [
     191,
     "                if (strstr((const char *)s_ipd_line, \"CLOSED\") != NULL ||"
    ],
    [
     192,
     "                    strstr((const char *)s_ipd_line, \"Unlink\") != NULL)"
    ],
    [
     193,
     "                {"
    ],
    [
     194,
     "                    s_closed = 1;"
    ],
    [
     195,
     "                }"
    ],
    [
     196,
     "                s_ipd_line_n = 0;"
    ],
    [
     197,
     "                s_ipd_state  = IPD_STATE_HEAD;"
    ],
    [
     198,
     "            }"
    ],
    [
     199,
     "            else if (b == ':')"
    ],
    [
     200,
     "            {"
    ],
    [
     201,
     "                /* 提取 +IPD,<len>: 中的长度 */"
    ],
    [
     202,
     "                const char *p = strchr((const char *)s_ipd_line, ',');"
    ],
    [
     203,
     "                uint32_t len = 0;"
    ],
    [
     204,
     "                if (p != NULL)"
    ],
    [
     205,
     "                {"
    ],
    [
     206,
     "                    p++;"
    ],
    [
     207,
     "                    while (*p >= '0' && *p <= '9')"
    ],
    [
     208,
     "                    {"
    ],
    [
     209,
     "                        len = len * 10U + (uint32_t)(*p - '0');"
    ],
    [
     210,
     "                        p++;"
    ],
    [
     211,
     "                    }"
    ],
    [
     212,
     "                }"
    ],
    [
     213,
     "                s_ipd_len   = len;"
    ],
    [
     214,
     "                s_ipd_state = IPD_STATE_DATA;"
    ],
    [
     215,
     "                s_ipd_line_n = 0;"
    ],
    [
     216,
     "            }"
    ],
    [
     217,
     "        }"
    ],
    [
     218,
     "        else /* IPD_STATE_DATA */"
    ],
    [
     219,
     "        {"
    ],
    [
     220,
     "            /* 搬运数据字节 */"
    ],
    [
     221,
     "            if (s_ipd_len > 0)"
    ],
    [
     222,
     "            {"
    ],
    [
     223,
     "                if (s_data_len < ESP_DATA_BUF_SIZE)"
    ],
    [
     224,
     "                {"
    ],
    [
     225,
     "                    s_data[(s_data_head + s_data_len) % ESP_DATA_BUF_SIZE] = (uint8_t)b;"
    ],
    [
     226,
     "                    s_data_len++;"
    ],
    [
     227,
     "                }"
    ],
    [
     228,
     "                s_ipd_len--;"
    ],
    [
     229,
     "                if (s_ipd_len == 0)"
    ],
    [
     230,
     "                {"
    ],
    [
     231,
     "                    s_ipd_state = IPD_STATE_HEAD;"
    ],
    [
     232,
     "                }"
    ],
    [
     233,
     "            }"
    ],
    [
     234,
     "            else"
    ],
    [
     235,
     "            {"
    ],
    [
     236,
     "                s_ipd_state = IPD_STATE_HEAD;"
    ],
    [
     237,
     "            }"
    ],
    [
     238,
     "        }"
    ],
    [
     239,
     "    }"
    ],
    [
     240,
     "}"
    ]
   ]
  },
  "esp_join_ap": {
   "id": "esp_join_ap",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "path": "HAL_F429IGT6_App/OTA/esp01s.c",
   "func": "esp01s_join_ap",
   "from": 402,
   "to": 407,
   "note": "esp01s_join_ap：AT+CWJAP 入网（超时 15000ms）",
   "grade": "A",
   "lines": [
    [
     402,
     "int esp01s_join_ap(const char *ssid, const char *pass, uint32_t timeout_ms)"
    ],
    [
     403,
     "{"
    ],
    [
     404,
     "    char cmd[128];"
    ],
    [
     405,
     "    snprintf(cmd, sizeof(cmd), \"AT+CWJAP=\\\"%s\\\",\\\"%s\\\"\\r\\n\", ssid, pass);"
    ],
    [
     406,
     "    return esp01s_at_cmd(cmd, \"OK\", timeout_ms);"
    ],
    [
     407,
     "}"
    ]
   ]
  },
  "esp_dma": {
   "id": "esp_dma",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "path": "HAL_F429IGT6_App/OTA/esp01s.c",
   "func": "esp01s_dma_to_ring",
   "from": 37,
   "to": 55,
   "note": "DMA 循环缓冲 → 环形缓冲：靠 NDTR 轮询搬运，不依赖中断",
   "grade": "A",
   "lines": [
    [
     37,
     "/* 从 DMA 循环缓冲搬运新字节到接收环形缓冲（在 esp01s_parse 开头调用） */"
    ],
    [
     38,
     "static void esp01s_dma_to_ring(void)"
    ],
    [
     39,
     "{"
    ],
    [
     40,
     "    uint16_t cnt, cur;"
    ],
    [
     41,
     ""
    ],
    [
     42,
     "    /* ORE 置位会停止 USART 接收，DMA 模式极少发生但必须清（读 SR 后写 0） */"
    ],
    [
     43,
     "    if (__HAL_UART_GET_FLAG(&huart3, UART_FLAG_ORE))"
    ],
    [
     44,
     "    {"
    ],
    [
     45,
     "        __HAL_UART_CLEAR_OREFLAG(&huart3);"
    ],
    [
     46,
     "    }"
    ],
    [
     47,
     ""
    ],
    [
     48,
     "    cnt = (uint16_t)__HAL_DMA_GET_COUNTER(&hdma_usart3_rx);"
    ],
    [
     49,
     "    cur = (uint16_t)((ESP_DMA_RX_SIZE - cnt) % ESP_DMA_RX_SIZE);"
    ],
    [
     50,
     "    while (s_dma_last != cur)"
    ],
    [
     51,
     "    {"
    ],
    [
     52,
     "        esp01s_feed_byte(s_dma_rx[s_dma_last]);"
    ],
    [
     53,
     "        s_dma_last = (uint16_t)((s_dma_last + 1U) % ESP_DMA_RX_SIZE);"
    ],
    [
     54,
     "    }"
    ],
    [
     55,
     "}"
    ]
   ]
  },
  "esp_read": {
   "id": "esp_read",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "path": "HAL_F429IGT6_App/OTA/esp01s.c",
   "func": "esp01s_read",
   "from": 785,
   "to": 825,
   "note": "esp01s_read：从 s_data 流缓冲搬字节，超时/断开分别返回 ESP_TIMEOUT / ESP_CLOSED",
   "grade": "A",
   "lines": [
    [
     785,
     "int esp01s_read(uint8_t *buf, uint32_t len, uint32_t timeout_ms)"
    ],
    [
     786,
     "{"
    ],
    [
     787,
     "    uint32_t start = HAL_GetTick();"
    ],
    [
     788,
     "    uint32_t got = 0;"
    ],
    [
     789,
     ""
    ],
    [
     790,
     "    while (got < len)"
    ],
    [
     791,
     "    {"
    ],
    [
     792,
     "        esp01s_parse();"
    ],
    [
     793,
     ""
    ],
    [
     794,
     "        /* 从数据流缓冲搬取 */"
    ],
    [
     795,
     "        if (s_data_len > 0)"
    ],
    [
     796,
     "        {"
    ],
    [
     797,
     "            uint32_t take = s_data_len;"
    ],
    [
     798,
     "            if (take > (len - got))"
    ],
    [
     799,
     "            {"
    ],
    [
     800,
     "                take = len - got;"
    ],
    [
     801,
     "            }"
    ],
    [
     802,
     "            for (uint32_t i = 0; i < take; i++)"
    ],
    [
     803,
     "            {"
    ],
    [
     804,
     "                buf[got + i] = s_data[(s_data_head + i) % ESP_DATA_BUF_SIZE];"
    ],
    [
     805,
     "            }"
    ],
    [
     806,
     "            s_data_head = (s_data_head + take) % ESP_DATA_BUF_SIZE;"
    ],
    [
     807,
     "            s_data_len -= take;"
    ],
    [
     808,
     "            got += take;"
    ],
    [
     809,
     "            continue;"
    ],
    [
     810,
     "        }"
    ],
    [
     811,
     ""
    ],
    [
     812,
     "        if (s_closed)"
    ],
    [
     813,
     "        {"
    ],
    [
     814,
     "            return (got > 0) ? (int)got : ESP_CLOSED;"
    ],
    [
     815,
     "        }"
    ],
    [
     816,
     ""
    ],
    [
     817,
     "        if ((HAL_GetTick() - start) >= timeout_ms)"
    ],
    [
     818,
     "        {"
    ],
    [
     819,
     "            return (got > 0) ? (int)got : ESP_TIMEOUT;"
    ],
    [
     820,
     "        }"
    ],
    [
     821,
     "        esp01s_wait_hook();"
    ],
    [
     822,
     "        HAL_Delay(1);"
    ],
    [
     823,
     "    }"
    ],
    [
     824,
     "    return (int)got;"
    ],
    [
     825,
     "}"
    ]
   ]
  },
  "esp_send": {
   "id": "esp_send",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "path": "HAL_F429IGT6_App/OTA/esp01s.c",
   "func": "esp01s_send",
   "from": 652,
   "to": 700,
   "note": "esp01s_send：AT+CIPSEND 等 \">\" 后发数据",
   "grade": "A",
   "lines": [
    [
     652,
     "int esp01s_send(const uint8_t *data, uint32_t len, uint32_t timeout_ms)"
    ],
    [
     653,
     "{"
    ],
    [
     654,
     "    char cmd[32];"
    ],
    [
     655,
     "    uint32_t start = HAL_GetTick();"
    ],
    [
     656,
     "    char collect[64];"
    ],
    [
     657,
     "    uint32_t n = 0;"
    ],
    [
     658,
     "    uint8_t  error_seen = 0;   /* 已收到 ERROR 标记 */"
    ],
    [
     659,
     "    uint32_t err_start  = 0;   /* ERROR 到达时刻 */"
    ],
    [
     660,
     ""
    ],
    [
     661,
     "    /* 丢弃上次残留应答字节；\">\" 提示与 \"SEND OK\" 同样从 s_data 匹配 */"
    ],
    [
     662,
     "    esp01s_flush_rx();"
    ],
    [
     663,
     ""
    ],
    [
     664,
     "    snprintf(cmd, sizeof(cmd), \"AT+CIPSEND=%lu\\r\\n\", (unsigned long)len);"
    ],
    [
     665,
     "    if (HAL_UART_Transmit(&huart3, (uint8_t *)cmd, (uint16_t)strlen(cmd), 500) != HAL_OK)"
    ],
    [
     666,
     "    {"
    ],
    [
     667,
     "        return ESP_ERR;"
    ],
    [
     668,
     "    }"
    ],
    [
     669,
     ""
    ],
    [
     670,
     "    /* 等待 \">\" 提示符 */"
    ],
    [
     671,
     "    while ((HAL_GetTick() - start) < timeout_ms)"
    ],
    [
     672,
     "    {"
    ],
    [
     673,
     "        esp01s_parse();"
    ],
    [
     674,
     "        esp01s_wait_hook();"
    ],
    [
     675,
     "        while (s_data_len > 0)"
    ],
    [
     676,
     "        {"
    ],
    [
     677,
     "            uint8_t b = s_data[s_data_head];"
    ],
    [
     678,
     "            s_data_head = (s_data_head + 1U) % ESP_DATA_BUF_SIZE;"
    ],
    [
     679,
     "            s_data_len--;"
    ],
    [
     680,
     "            if (n < sizeof(collect) - 1U)"
    ],
    [
     681,
     "            {"
    ],
    [
     682,
     "                collect[n++] = (char)b;"
    ],
    [
     683,
     "                collect[n] = '\\0';"
    ],
    [
     684,
     "            }"
    ],
    [
     685,
     "            if (strstr(collect, \">\") != NULL)"
    ],
    [
     686,
     "            {"
    ],
    [
     687,
     "                goto prompt_ok;"
    ],
    [
     688,
     "            }"
    ],
    [
     689,
     "            if (strstr(collect, \"ERROR\") != NULL)"
    ],
    [
     690,
     "            {"
    ],
    [
     691,
     "                return ESP_ERR;"
    ],
    [
     692,
     "            }"
    ],
    [
     693,
     "        }"
    ],
    [
     694,
     "        HAL_Delay(2);"
    ],
    [
     695,
     "    }"
    ],
    [
     696,
     "    return ESP_TIMEOUT;"
    ],
    [
     697,
     ""
    ],
    [
     698,
     "prompt_ok:"
    ],
    [
     699,
     "    /* 发送数据 */"
    ],
    [
     700,
     "    if (HAL_UART_Transmit(&huart3, (uint8_t *)data, (uint16_t)len, 2000) != HAL_OK)"
    ]
   ]
  },
  "esp_at_cmd": {
   "id": "esp_at_cmd",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "path": "HAL_F429IGT6_App/OTA/esp01s.c",
   "func": "esp01s_at_cmd",
   "from": 352,
   "to": 400,
   "note": "esp01s_at_cmd：滚动匹配期望串，同时识别 ERROR/FAIL",
   "grade": "A",
   "lines": [
    [
     352,
     "int esp01s_at_cmd(const char *cmd, const char *expect, uint32_t timeout_ms)"
    ],
    [
     353,
     "{"
    ],
    [
     354,
     "    uint32_t start = HAL_GetTick();"
    ],
    [
     355,
     "    char collect[128];"
    ],
    [
     356,
     "    uint32_t n = 0;"
    ],
    [
     357,
     ""
    ],
    [
     358,
     "    /* 丢弃上次命令残留的应答字节（含环形缓冲），避免误匹配 */"
    ],
    [
     359,
     "    esp01s_flush_rx();"
    ],
    [
     360,
     ""
    ],
    [
     361,
     "    /* 发送命令 */"
    ],
    [
     362,
     "    if (HAL_UART_Transmit(&huart3, (uint8_t *)cmd, (uint16_t)strlen(cmd), 500) != HAL_OK)"
    ],
    [
     363,
     "    {"
    ],
    [
     364,
     "        return ESP_ERR;"
    ],
    [
     365,
     "    }"
    ],
    [
     366,
     ""
    ],
    [
     367,
     "    /* 等待期望串 / 失败提示 / 超时 */"
    ],
    [
     368,
     "    while ((HAL_GetTick() - start) < timeout_ms)"
    ],
    [
     369,
     "    {"
    ],
    [
     370,
     "        esp01s_parse();"
    ],
    [
     371,
     "        esp01s_wait_hook();"
    ],
    [
     372,
     "        while (s_data_len > 0)"
    ],
    [
     373,
     "        {"
    ],
    [
     374,
     "            uint8_t b = s_data[s_data_head];"
    ],
    [
     375,
     "            s_data_head = (s_data_head + 1U) % ESP_DATA_BUF_SIZE;"
    ],
    [
     376,
     "            s_data_len--;"
    ],
    [
     377,
     "            if (n < sizeof(collect) - 1U)"
    ],
    [
     378,
     "            {"
    ],
    [
     379,
     "                collect[n++] = (char)b;"
    ],
    [
     380,
     "                collect[n] = '\\0';"
    ],
    [
     381,
     "            }"
    ],
    [
     382,
     "            /* 滚动匹配 */"
    ],
    [
     383,
     "            if (strstr(collect, expect) != NULL)"
    ],
    [
     384,
     "            {"
    ],
    [
     385,
     "                return ESP_OK;"
    ],
    [
     386,
     "            }"
    ],
    [
     387,
     "            /* 补充识别常见失败/非预期提示，避免干等超时："
    ],
    [
     388,
     "               \"DNS Fail\" / \"CONNECT FAIL\" / \"ALREADY CONNECTED\" */"
    ],
    [
     389,
     "            if (strstr(collect, \"ERROR\")    != NULL ||"
    ],
    [
     390,
     "                strstr(collect, \"FAIL\")     != NULL ||"
    ],
    [
     391,
     "                strstr(collect, \"DNS Fail\") != NULL ||"
    ],
    [
     392,
     "                strstr(collect, \"ALREADY CONNECTED\") != NULL)"
    ],
    [
     393,
     "            {"
    ],
    [
     394,
     "                return ESP_ERR;"
    ],
    [
     395,
     "            }"
    ],
    [
     396,
     "        }"
    ],
    [
     397,
     "        HAL_Delay(2);"
    ],
    [
     398,
     "    }"
    ],
    [
     399,
     "    return ESP_TIMEOUT;"
    ],
    [
     400,
     "}"
    ]
   ]
  },
  "esp_tcp_connect": {
   "id": "esp_tcp_connect",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "path": "HAL_F429IGT6_App/OTA/esp01s.c",
   "func": "esp01s_tcp_connect",
   "from": 507,
   "to": 555,
   "note": "esp01s_tcp_connect：已知主机 IP 直连优先（规避模块 DNS 挂起）",
   "grade": "A",
   "lines": [
    [
     507,
     "int esp01s_tcp_connect(const char *host, uint16_t port, uint32_t timeout_ms)"
    ],
    [
     508,
     "{"
    ],
    [
     509,
     "    char cmd[128];"
    ],
    [
     510,
     "    uint32_t i;"
    ],
    [
     511,
     "    int k;"
    ],
    [
     512,
     "    int r;"
    ],
    [
     513,
     ""
    ],
    [
     514,
     "    /* 已知主机：IP 直连优先，表内 IP 全失败后再退回域名（模块 DNS） */"
    ],
    [
     515,
     "    for (i = 0; i < sizeof(s_host_ip) / sizeof(s_host_ip[0]); i++)"
    ],
    [
     516,
     "    {"
    ],
    [
     517,
     "        if (strcmp(host, s_host_ip[i].host) == 0)"
    ],
    [
     518,
     "        {"
    ],
    [
     519,
     "            const char *ips[2];"
    ],
    [
     520,
     "            int n = 0;"
    ],
    [
     521,
     ""
    ],
    [
     522,
     "            ips[n++] = s_host_ip[i].ip1;"
    ],
    [
     523,
     "            if (s_host_ip[i].ip2 != NULL)"
    ],
    [
     524,
     "            {"
    ],
    [
     525,
     "                ips[n++] = s_host_ip[i].ip2;"
    ],
    [
     526,
     "            }"
    ],
    [
     527,
     "            for (k = 0; k < n; k++)"
    ],
    [
     528,
     "            {"
    ],
    [
     529,
     "                snprintf(cmd, sizeof(cmd), \"AT+CIPSTART=\\\"TCP\\\",\\\"%s\\\",%u\\r\\n\","
    ],
    [
     530,
     "                         ips[k], (unsigned)port);"
    ],
    [
     531,
     "                r = esp01s_at_cmd(cmd, \"OK\", timeout_ms);"
    ],
    [
     532,
     "                if (r == ESP_OK)"
    ],
    [
     533,
     "                {"
    ],
    [
     534,
     "                    return ESP_OK;"
    ],
    [
     535,
     "                }"
    ],
    [
     536,
     "                esp01s_drain_pending(4000);   /* 排干挂起响应，引擎复位 */"
    ],
    [
     537,
     "            }"
    ],
    [
     538,
     "            /* 最后用域名试一次（模块 DNS 正常时仍可成功） */"
    ],
    [
     539,
     "            snprintf(cmd, sizeof(cmd), \"AT+CIPSTART=\\\"TCP\\\",\\\"%s\\\",%u\\r\\n\","
    ],
    [
     540,
     "                     host, (unsigned)port);"
    ],
    [
     541,
     "            r = esp01s_at_cmd(cmd, \"OK\", timeout_ms);"
    ],
    [
     542,
     "            esp01s_drain_pending(4000);"
    ],
    [
     543,
     "            return r;"
    ],
    [
     544,
     "        }"
    ],
    [
     545,
     "    }"
    ],
    [
     546,
     ""
    ],
    [
     547,
     "    /* 未知主机：域名优先（维持原逻辑） */"
    ],
    [
     548,
     "    snprintf(cmd, sizeof(cmd), \"AT+CIPSTART=\\\"TCP\\\",\\\"%s\\\",%u\\r\\n\", host, (unsigned)port);"
    ],
    [
     549,
     "    r = esp01s_at_cmd(cmd, \"OK\", timeout_ms);"
    ],
    [
     550,
     "    if (r != ESP_OK)"
    ],
    [
     551,
     "    {"
    ],
    [
     552,
     "        esp01s_drain_pending(4000);"
    ],
    [
     553,
     "    }"
    ],
    [
     554,
     "    return r;"
    ],
    [
     555,
     "}"
    ]
   ]
  },
  "esp01s_h": {
   "id": "esp01s_h",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.h",
   "path": "HAL_F429IGT6_App/OTA/esp01s.h",
   "func": "#define 接收缓冲规格",
   "from": 33,
   "to": 41,
   "note": "接收缓冲规格：环形缓冲 4096B + 数据流缓冲 8192B",
   "grade": "A",
   "lines": [
    [
     33,
     "/* 串口接收环形缓冲区大小"
    ],
    [
     34,
     "   [FIX] 1024 -> 2048 -> 4096："
    ],
    [
     35,
     "   115200 波特率约 11.5KB/s。下载时 OTA 任务会周期性写 W25Q64（每 1KB 约 2ms），"
    ],
    [
     36,
     "   生产者可能短暂超过消费者。4096 字节可容忍约 350ms 的消费停顿，"
    ],
    [
     37,
     "   显著降低 \"+IPD 帧头错位 -> 后续数据停住\" 的概率"
    ],
    [
     38,
     "   （实测 6628 字节的尾巴曾只收到 6468 就卡死，最终超时 r=-2）。 */"
    ],
    [
     39,
     "#define ESP_RX_RING_SIZE   4096U"
    ],
    [
     40,
     "/* 数据缓冲区（剥离 IPD 头后的字节流）：同步加大到 8KB */"
    ],
    [
     41,
     "#define ESP_DATA_BUF_SIZE  8192U"
    ]
   ]
  },
  "uart_rx_cb": {
   "id": "uart_rx_cb",
   "project": "HAL_F429IGT6_App",
   "file": "bsp/UART/uart_handle.c",
   "path": "HAL_F429IGT6_App/bsp/UART/uart_handle.c",
   "func": "HAL_UARTEx_RxEventCallback",
   "from": 124,
   "to": 157,
   "note": "HAL_UARTEx_RxEventCallback：OTA 模式下 USART3 必须让路给 esp01s",
   "grade": "A",
   "lines": [
    [
     124,
     "void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)"
    ],
    [
     125,
     "{"
    ],
    [
     126,
     "  /* OTA 模式期间 USART3 归 esp01s 独占（CIRCULAR DMA + NDTR 轮询）。"
    ],
    [
     127,
     "     这里若再调 uart_start_receive()，会把 esp01s 正在用的循环 DMA 抢掉，"
    ],
    [
     128,
     "     表现为\"下载中途丢字节、MD5 必错\"，所以必须让路。 */"
    ],
    [
     129,
     "  if ((huart->Instance == USART3) && (ota_net_is_active() != 0))"
    ],
    [
     130,
     "  {"
    ],
    [
     131,
     "    return;"
    ],
    [
     132,
     "  }"
    ],
    [
     133,
     ""
    ],
    [
     134,
     "  if (huart->Instance == USART1)"
    ],
    [
     135,
     "  {"
    ],
    [
     136,
     "    if (Size < RX_max)"
    ],
    [
     137,
     "    {"
    ],
    [
     138,
     "      uart1_Recived_buf[Size] = '\\0';"
    ],
    [
     139,
     "    }"
    ],
    [
     140,
     "    uart1_recv_len = Size;"
    ],
    [
     141,
     "    uart1_key = 1;"
    ],
    [
     142,
     ""
    ],
    [
     143,
     "    uart_start_receive(&huart1, (uint8_t *)uart1_Recived_buf);"
    ],
    [
     144,
     "  }"
    ],
    [
     145,
     ""
    ],
    [
     146,
     "  if (huart->Instance == USART3)"
    ],
    [
     147,
     "  {"
    ],
    [
     148,
     "    if (Size < RX_max)"
    ],
    [
     149,
     "    {"
    ],
    [
     150,
     "      uart3_Recived_buf[Size] = '\\0';"
    ],
    [
     151,
     "    }"
    ],
    [
     152,
     "    uart3_recv_len = Size;"
    ],
    [
     153,
     "    uart3_key = 1;"
    ],
    [
     154,
     ""
    ],
    [
     155,
     "    uart_start_receive(&huart3, (uint8_t *)uart3_Recived_buf);"
    ],
    [
     156,
     "  }"
    ],
    [
     157,
     "}"
    ]
   ]
  },
  "w25q_ext_write": {
   "id": "w25q_ext_write",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "path": "HAL_F429IGT6_App/OTA/w25q_ext.c",
   "func": "w25q16_write",
   "from": 146,
   "to": 182,
   "note": "w25q16_write：4KB 分块调用 W25Q64_WriteData（内部按 256B 页跨页写）",
   "grade": "A",
   "lines": [
    [
     146,
     "HAL_StatusTypeDef w25q16_write(uint32_t addr, const uint8_t *data, uint32_t len)"
    ],
    [
     147,
     "{"
    ],
    [
     148,
     "    uint32_t done = 0U;"
    ],
    [
     149,
     ""
    ],
    [
     150,
     "    if ((data == 0) || (len == 0U))"
    ],
    [
     151,
     "    {"
    ],
    [
     152,
     "        return HAL_OK;"
    ],
    [
     153,
     "    }"
    ],
    [
     154,
     ""
    ],
    [
     155,
     "    if ((addr >= W25Q_EXT_FLASH_SIZE) || (len > (W25Q_EXT_FLASH_SIZE - addr)))"
    ],
    [
     156,
     "    {"
    ],
    [
     157,
     "        return HAL_ERROR;"
    ],
    [
     158,
     "    }"
    ],
    [
     159,
     ""
    ],
    [
     160,
     "    while (done < len)"
    ],
    [
     161,
     "    {"
    ],
    [
     162,
     "        uint32_t take = len - done;"
    ],
    [
     163,
     ""
    ],
    [
     164,
     "        if (take > W25Q_XFER_CHUNK)"
    ],
    [
     165,
     "        {"
    ],
    [
     166,
     "            take = W25Q_XFER_CHUNK;"
    ],
    [
     167,
     "        }"
    ],
    [
     168,
     ""
    ],
    [
     169,
     "        /* 驱动内部按 256B 页自动拆分并跨页续写，这里只需给首地址 + 长度。"
    ],
    [
     170,
     "           注意驱动签名是 uint8_t *，本函数保证不修改内容，故做一次去 const。 */"
    ],
    [
     171,
     "        W25Q64_WriteData(addr + done, (uint8_t *)&data[done], take);"
    ],
    [
     172,
     ""
    ],
    [
     173,
     "        if (W25Q64_GetLastStatus() != HAL_OK)"
    ],
    [
     174,
     "        {"
    ],
    [
     175,
     "            return HAL_ERROR;"
    ],
    [
     176,
     "        }"
    ],
    [
     177,
     ""
    ],
    [
     178,
     "        done += take;"
    ],
    [
     179,
     "    }"
    ],
    [
     180,
     ""
    ],
    [
     181,
     "    return HAL_OK;"
    ],
    [
     182,
     "}"
    ]
   ]
  },
  "w25q_ext_erase": {
   "id": "w25q_ext_erase",
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "path": "HAL_F429IGT6_App/OTA/w25q_ext.c",
   "func": "w25q16_erase_sector",
   "from": 186,
   "to": 210,
   "note": "w25q16_erase_sector / erase_block（块擦除强制 64KB 对齐检查）",
   "grade": "A",
   "lines": [
    [
     186,
     "HAL_StatusTypeDef w25q16_erase_sector(uint32_t addr)"
    ],
    [
     187,
     "{"
    ],
    [
     188,
     "    if (addr >= W25Q_EXT_FLASH_SIZE)"
    ],
    [
     189,
     "    {"
    ],
    [
     190,
     "        return HAL_ERROR;"
    ],
    [
     191,
     "    }"
    ],
    [
     192,
     ""
    ],
    [
     193,
     "    W25Q64_SectorErase(addr);"
    ],
    [
     194,
     ""
    ],
    [
     195,
     "    return (W25Q64_GetLastStatus() == HAL_OK) ? HAL_OK : HAL_ERROR;"
    ],
    [
     196,
     "}"
    ],
    [
     197,
     ""
    ],
    [
     198,
     "HAL_StatusTypeDef w25q16_erase_block(uint32_t addr)"
    ],
    [
     199,
     "{"
    ],
    [
     200,
     "    /* 地址必须 64KB 对齐，否则芯片实际擦除的是\"包含该地址的块\"，"
    ],
    [
     201,
     "       OTA 分区会错位——这里做硬检查，早失败早发现。 */"
    ],
    [
     202,
     "    if ((addr >= W25Q_EXT_FLASH_SIZE) || ((addr % W25Q_EXT_BLOCK_SIZE) != 0U))"
    ],
    [
     203,
     "    {"
    ],
    [
     204,
     "        return HAL_ERROR;"
    ],
    [
     205,
     "    }"
    ],
    [
     206,
     ""
    ],
    [
     207,
     "    W25Q64_BlockErase(addr);"
    ],
    [
     208,
     ""
    ],
    [
     209,
     "    return (W25Q64_GetLastStatus() == HAL_OK) ? HAL_OK : HAL_ERROR;"
    ],
    [
     210,
     "}"
    ]
   ]
  }
 }
};
