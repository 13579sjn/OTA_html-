/* 自动生成，请勿手改 —— 由 tools/gen-code.js 从真实工程读取
 * 生成时间：2026-10-28T11:21:43.770Z
 * 内容：函数索引与工程统计
 */
window.OTA_INDEX = {
 "generatedAt": "2026-10-28T11:21:43.770Z",
 "functions": [
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "func": "boot_port_init",
   "line": 48,
   "static": true,
   "fileLine": "static void boot_port_init(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "func": "boot_halt",
   "line": 62,
   "static": true,
   "fileLine": "static void boot_halt(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "func": "boot_verify_ext_image",
   "line": 77,
   "static": true,
   "fileLine": "static int boot_verify_ext_image(uint32_t ext_addr, uint32_t len, const uint8_t *expect_sha)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "func": "boot_copy_ext_to_run",
   "line": 120,
   "static": true,
   "fileLine": "static int boot_copy_ext_to_run(uint32_t ext_addr, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "func": "boot_do_rollback",
   "line": 186,
   "static": true,
   "fileLine": "static int boot_do_rollback(ota_param_t *p)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "func": "boot_do_recovery",
   "line": 216,
   "static": true,
   "fileLine": "static int boot_do_recovery(ota_param_t *p)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "func": "boot_dump_vectors",
   "line": 261,
   "static": true,
   "fileLine": "static void boot_dump_vectors(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_start.c",
   "func": "boot_run",
   "line": 272,
   "static": false,
   "fileLine": "void boot_run(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/app_jump.c",
   "func": "app_jump_validate",
   "line": 31,
   "static": false,
   "fileLine": "int app_jump_validate(uint32_t app_addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/app_jump.c",
   "func": "app_jump_execute",
   "line": 63,
   "static": false,
   "fileLine": "void app_jump_execute(uint32_t app_addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/param_area.c",
   "func": "param_area_crc",
   "line": 28,
   "static": false,
   "fileLine": "uint32_t param_area_crc(const ota_param_t *param)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/param_area.c",
   "func": "param_area_defaults",
   "line": 34,
   "static": false,
   "fileLine": "void param_area_defaults(ota_param_t *param)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/param_area.c",
   "func": "slot_is_empty",
   "line": 57,
   "static": true,
   "fileLine": "static int slot_is_empty(uint32_t slot_addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/param_area.c",
   "func": "slot_load",
   "line": 76,
   "static": true,
   "fileLine": "static int slot_load(uint32_t slot_addr, ota_param_t *out, uint32_t *out_seq)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/param_area.c",
   "func": "param_area_load",
   "line": 105,
   "static": false,
   "fileLine": "int param_area_load(ota_param_t *param)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/param_area.c",
   "func": "param_area_save",
   "line": 146,
   "static": false,
   "fileLine": "int param_area_save(const ota_param_t *param)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/flash_if.c",
   "func": "flash_if_sector_number",
   "line": 38,
   "static": false,
   "fileLine": "uint32_t flash_if_sector_number(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/flash_if.c",
   "func": "flash_if_sector_start",
   "line": 54,
   "static": false,
   "fileLine": "uint32_t flash_if_sector_start(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/flash_if.c",
   "func": "flash_if_sector_size",
   "line": 59,
   "static": false,
   "fileLine": "uint32_t flash_if_sector_size(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/flash_if.c",
   "func": "flash_if_erase_addr",
   "line": 64,
   "static": false,
   "fileLine": "HAL_StatusTypeDef flash_if_erase_addr(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/flash_if.c",
   "func": "flash_if_erase_region",
   "line": 69,
   "static": false,
   "fileLine": "HAL_StatusTypeDef flash_if_erase_region(uint32_t base, uint32_t size)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/flash_if.c",
   "func": "flash_if_write",
   "line": 106,
   "static": false,
   "fileLine": "HAL_StatusTypeDef flash_if_write(uint32_t addr, const uint8_t *data, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/flash_if.c",
   "func": "flash_if_read",
   "line": 170,
   "static": false,
   "fileLine": "void flash_if_read(uint32_t addr, uint8_t *buf, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_ext.c",
   "func": "boot_ext_init",
   "line": 20,
   "static": false,
   "fileLine": "int boot_ext_init(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_ext.c",
   "func": "boot_ext_jedec_id",
   "line": 33,
   "static": false,
   "fileLine": "uint32_t boot_ext_jedec_id(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_ext.c",
   "func": "boot_ext_read",
   "line": 52,
   "static": false,
   "fileLine": "int boot_ext_read(uint32_t addr, uint8_t *buf, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_ext.c",
   "func": "boot_ext_write",
   "line": 90,
   "static": false,
   "fileLine": "int boot_ext_write(uint32_t addr, const uint8_t *buf, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_ext.c",
   "func": "boot_ext_erase_block",
   "line": 130,
   "static": false,
   "fileLine": "int boot_ext_erase_block(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_ext.c",
   "func": "boot_ext_erase_sector",
   "line": 140,
   "static": false,
   "fileLine": "int boot_ext_erase_sector(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_shutdown.c",
   "func": "boot_dma_stream_off",
   "line": 34,
   "static": true,
   "fileLine": "static void boot_dma_stream_off(DMA_Stream_TypeDef *p)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_shutdown.c",
   "func": "boot_dma_all_off",
   "line": 62,
   "static": true,
   "fileLine": "static void boot_dma_all_off(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_shutdown.c",
   "func": "boot_restore_clock_to_hsi",
   "line": 82,
   "static": false,
   "fileLine": "void boot_restore_clock_to_hsi(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_shutdown.c",
   "func": "boot_system_shutdown",
   "line": 140,
   "static": false,
   "fileLine": "void boot_system_shutdown(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_wdg.c",
   "func": "boot_wdg_init",
   "line": 21,
   "static": false,
   "fileLine": "void boot_wdg_init(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_wdg.c",
   "func": "boot_wdg_feed",
   "line": 62,
   "static": false,
   "fileLine": "void boot_wdg_feed(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_wdg.c",
   "func": "boot_wdg_is_enabled",
   "line": 67,
   "static": false,
   "fileLine": "int boot_wdg_is_enabled(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_log.c",
   "func": "_sys_exit",
   "line": 28,
   "static": false,
   "fileLine": "void _sys_exit(int x)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_log.c",
   "func": "_ttywrch",
   "line": 36,
   "static": false,
   "fileLine": "void _ttywrch(int ch)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Boot/boot_log.c",
   "func": "boot_log",
   "line": 42,
   "static": false,
   "fileLine": "void boot_log(const char *fmt, ...)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Core/Src/main.c",
   "func": "main",
   "line": 69,
   "static": false,
   "fileLine": "int main(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Core/Src/main.c",
   "func": "SystemClock_Config",
   "line": 120,
   "static": false,
   "fileLine": "void SystemClock_Config(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Core/Src/main.c",
   "func": "Error_Handler",
   "line": 177,
   "static": false,
   "fileLine": "void Error_Handler(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Core/Src/main.c",
   "func": "assert_failed",
   "line": 195,
   "static": false,
   "fileLine": "void assert_failed(uint8_t *file, uint32_t line)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_SPIIsCompatible",
   "line": 21,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_SPIIsCompatible(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_Transmit",
   "line": 54,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_Transmit(const uint8_t *data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_Receive",
   "line": 69,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_Receive(uint8_t *data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_Transfer",
   "line": 84,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_Transfer(const uint8_t *tx_data, uint8_t *rx_data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_IsRangeValid",
   "line": 103,
   "static": true,
   "fileLine": "static uint8_t W25Q64_IsRangeValid(uint32_t addr, uint32_t size)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_SendCommandAddress",
   "line": 118,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_SendCommandAddress(uint8_t command, uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_ReadStatusInternal",
   "line": 130,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_ReadStatusInternal(uint8_t register_number, uint8_t *value)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_WriteEnableInternal",
   "line": 167,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_WriteEnableInternal(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_WaitWhileBusy",
   "line": 190,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_WaitWhileBusy(uint32_t timeout_ms)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_ReadDataInternal",
   "line": 213,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_ReadDataInternal(uint32_t addr, uint8_t *data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_PageWriteInternal",
   "line": 244,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_PageWriteInternal(uint32_t addr, const uint8_t *data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_StepOverPageWriteInternal",
   "line": 290,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_StepOverPageWriteInternal(uint32_t addr,"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_EraseInternal",
   "line": 329,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_EraseInternal(uint8_t command, uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_WriteDataInternal",
   "line": 362,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_WriteDataInternal(uint32_t addr,"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_InitConfig",
   "line": 449,
   "static": false,
   "fileLine": "void W25Q64_InitConfig(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_ReadWriteByte",
   "line": 474,
   "static": false,
   "fileLine": "uint8_t W25Q64_ReadWriteByte(uint8_t data)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_GetID",
   "line": 482,
   "static": false,
   "fileLine": "uint16_t W25Q64_GetID(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_ReadState",
   "line": 509,
   "static": false,
   "fileLine": "uint8_t W25Q64_ReadState(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_WriteENABLE",
   "line": 517,
   "static": false,
   "fileLine": "void W25Q64_WriteENABLE(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_SectorErase",
   "line": 522,
   "static": false,
   "fileLine": "void W25Q64_SectorErase(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_BlockErase",
   "line": 527,
   "static": false,
   "fileLine": "void W25Q64_BlockErase(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_ReadData",
   "line": 532,
   "static": false,
   "fileLine": "void W25Q64_ReadData(uint32_t addr, uint8_t *data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_PageWrite",
   "line": 537,
   "static": false,
   "fileLine": "void W25Q64_PageWrite(uint32_t addr, uint8_t *data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_StepOverPageWrite",
   "line": 542,
   "static": false,
   "fileLine": "void W25Q64_StepOverPageWrite(uint32_t addr, uint8_t *data, uint32_t size)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_WriteData",
   "line": 547,
   "static": false,
   "fileLine": "void W25Q64_WriteData(uint32_t addr, uint8_t *data, uint32_t size)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_ReadStatusRegister",
   "line": 552,
   "static": false,
   "fileLine": "HAL_StatusTypeDef W25Q64_ReadStatusRegister(uint8_t register_number, uint8_t *value)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_WriteStatusRegister",
   "line": 558,
   "static": false,
   "fileLine": "HAL_StatusTypeDef W25Q64_WriteStatusRegister(uint8_t register_number, uint8_t value)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "W25q64/w25q64.c",
   "func": "W25Q64_GetLastStatus",
   "line": 602,
   "static": false,
   "fileLine": "HAL_StatusTypeDef W25Q64_GetLastStatus(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "UART/uart_handle.c",
   "func": "uart_start_receive",
   "line": 23,
   "static": false,
   "fileLine": "HAL_StatusTypeDef uart_start_receive(UART_HandleTypeDef *huart, uint8_t *buf)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "UART/uart_handle.c",
   "func": "uart_printf",
   "line": 56,
   "static": false,
   "fileLine": "void uart_printf(UART_HandleTypeDef *huart, const char *format, ...)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "UART/uart_handle.c",
   "func": "HAL_UARTEx_RxEventCallback",
   "line": 94,
   "static": false,
   "fileLine": "void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "UART/uart_handle.c",
   "func": "HAL_UART_ErrorCallback",
   "line": 109,
   "static": false,
   "fileLine": "void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Core/Src/usart.c",
   "func": "MX_USART1_UART_Init",
   "line": 33,
   "static": false,
   "fileLine": "void MX_USART1_UART_Init(void)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Core/Src/usart.c",
   "func": "HAL_UART_MspInit",
   "line": 61,
   "static": false,
   "fileLine": "void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle)"
  },
  {
   "project": "HAL_F429IGT6_bootloard",
   "file": "Core/Src/usart.c",
   "func": "HAL_UART_MspDeInit",
   "line": 131,
   "static": false,
   "fileLine": "void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_set_state",
   "line": 75,
   "static": true,
   "fileLine": "static void ota_set_state(ota_state_t st, const char *msg)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_get_status",
   "line": 85,
   "static": false,
   "fileLine": "void ota_get_status(ota_status_t *st)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_feed_watchdog",
   "line": 94,
   "static": false,
   "fileLine": "void ota_feed_watchdog(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "json_get_str",
   "line": 101,
   "static": true,
   "fileLine": "static int json_get_str(const char *json, const char *key, char *out, uint32_t outlen)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "json_get_num",
   "line": 143,
   "static": true,
   "fileLine": "static int json_get_num(const char *json, const char *key, uint32_t *val)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "version_parse",
   "line": 185,
   "static": true,
   "fileLine": "static int version_parse(const char *s, uint32_t *ver)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "md5_hex_equal",
   "line": 200,
   "static": true,
   "fileLine": "static int md5_hex_equal(const char *hex, const uint8_t *digest)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_api_report_version",
   "line": 227,
   "static": true,
   "fileLine": "static int ota_api_report_version(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_api_check_task",
   "line": 266,
   "static": true,
   "fileLine": "static int ota_api_check_task(ota_task_t *t)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_api_report_status",
   "line": 323,
   "static": true,
   "fileLine": "static int ota_api_report_status(uint32_t tid, uint32_t step)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_probe_run_len",
   "line": 363,
   "static": true,
   "fileLine": "static uint32_t ota_probe_run_len(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "dl_on_data",
   "line": 407,
   "static": true,
   "fileLine": "static void dl_on_data(const uint8_t *data, uint32_t len, void *arg)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_download_try",
   "line": 486,
   "static": true,
   "fileLine": "static int ota_download_try(const ota_task_t *t, uint32_t *len_out, uint8_t *sha_out,"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_download",
   "line": 733,
   "static": true,
   "fileLine": "static int ota_download(const ota_task_t *t, uint32_t *len_out, uint8_t *sha_out)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_backup_current_app",
   "line": 759,
   "static": true,
   "fileLine": "static int ota_backup_current_app(uint32_t *len_out, uint8_t *sha_out)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_apply_and_reboot",
   "line": 818,
   "static": true,
   "fileLine": "static void ota_apply_and_reboot(uint32_t tid)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_init_recovery_if_empty",
   "line": 852,
   "static": false,
   "fileLine": "int ota_init_recovery_if_empty(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_confirm_boot_success",
   "line": 949,
   "static": false,
   "fileLine": "int ota_confirm_boot_success(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_report_pending_201",
   "line": 998,
   "static": false,
   "fileLine": "int ota_report_pending_201(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_report_version",
   "line": 1030,
   "static": false,
   "fileLine": "int ota_report_version(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_boot_confirm_if_needed",
   "line": 1035,
   "static": false,
   "fileLine": "int ota_boot_confirm_if_needed(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_manual_rollback",
   "line": 1090,
   "static": false,
   "fileLine": "void ota_manual_rollback(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_manual_recovery",
   "line": 1113,
   "static": false,
   "fileLine": "void ota_manual_recovery(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_engine.c",
   "func": "ota_run_once",
   "line": 1130,
   "static": false,
   "fileLine": "int ota_run_once(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_task.c",
   "func": "ota_task_post_update_zero",
   "line": 43,
   "static": true,
   "fileLine": "static void ota_task_post_update_zero(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_task.c",
   "func": "ota_task_post_update_zero",
   "line": 55,
   "static": true,
   "fileLine": "static void ota_task_post_update_zero(void) { }"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_task.c",
   "func": "ota_task_entry",
   "line": 60,
   "static": true,
   "fileLine": "static void ota_task_entry(void *arg)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_task.c",
   "func": "ota_task_request",
   "line": 114,
   "static": false,
   "fileLine": "void ota_task_request(uint32_t value)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_task.c",
   "func": "ota_task_on_update_ident",
   "line": 145,
   "static": false,
   "fileLine": "void ota_task_on_update_ident(const char *ident)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_task.c",
   "func": "ota_task_is_busy",
   "line": 160,
   "static": false,
   "fileLine": "int ota_task_is_busy(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_net_switch.c",
   "func": "ota_net_is_active",
   "line": 46,
   "static": false,
   "fileLine": "int ota_net_is_active(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_net_switch.c",
   "func": "ota_dma_switch_mode",
   "line": 58,
   "static": true,
   "fileLine": "static int ota_dma_switch_mode(uint32_t mode)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_net_switch.c",
   "func": "ota_net_restore",
   "line": 84,
   "static": true,
   "fileLine": "static void ota_net_restore(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_net_switch.c",
   "func": "ota_net_enter",
   "line": 104,
   "static": false,
   "fileLine": "int ota_net_enter(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_net_switch.c",
   "func": "ota_net_exit",
   "line": 153,
   "static": false,
   "fileLine": "int ota_net_exit(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_net_switch.c",
   "func": "ota_p2_selftest",
   "line": 182,
   "static": false,
   "fileLine": "void ota_p2_selftest(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_dma_to_ring",
   "line": 38,
   "static": true,
   "fileLine": "static void esp01s_dma_to_ring(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_feed_byte",
   "line": 85,
   "static": false,
   "fileLine": "void esp01s_feed_byte(uint8_t byte)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "ring_available",
   "line": 96,
   "static": true,
   "fileLine": "static uint32_t ring_available(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "ring_pop",
   "line": 101,
   "static": true,
   "fileLine": "static int ring_pop(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_flush_rx",
   "line": 114,
   "static": false,
   "fileLine": "void esp01s_flush_rx(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_parse",
   "line": 135,
   "static": true,
   "fileLine": "static void esp01s_parse(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_soft_reset",
   "line": 248,
   "static": true,
   "fileLine": "static int esp01s_soft_reset(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_init",
   "line": 258,
   "static": false,
   "fileLine": "int esp01s_init(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "HAL_UART_RxCpltCallback",
   "line": 339,
   "static": false,
   "fileLine": "void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_at_cmd",
   "line": 352,
   "static": false,
   "fileLine": "int esp01s_at_cmd(const char *cmd, const char *expect, uint32_t timeout_ms)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_join_ap",
   "line": 402,
   "static": false,
   "fileLine": "int esp01s_join_ap(const char *ssid, const char *pass, uint32_t timeout_ms)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_wifi_status",
   "line": 413,
   "static": false,
   "fileLine": "int esp01s_wifi_status(uint32_t timeout_ms)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_drain_pending",
   "line": 473,
   "static": true,
   "fileLine": "static void esp01s_drain_pending(uint32_t max_ms)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_tcp_connect",
   "line": 507,
   "static": false,
   "fileLine": "int esp01s_tcp_connect(const char *host, uint16_t port, uint32_t timeout_ms)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_tcp_close",
   "line": 557,
   "static": false,
   "fileLine": "void esp01s_tcp_close(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp_data_find",
   "line": 572,
   "static": true,
   "fileLine": "static int32_t esp_data_find(const char *pat, uint32_t pat_len)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp_data_drop",
   "line": 599,
   "static": true,
   "fileLine": "static void esp_data_drop(uint32_t nbytes)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp_data_drop_upto",
   "line": 610,
   "static": true,
   "fileLine": "static void esp_data_drop_upto(int32_t end_off)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp_data_remove",
   "line": 632,
   "static": true,
   "fileLine": "static void esp_data_remove(uint32_t off, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_send",
   "line": 652,
   "static": false,
   "fileLine": "int esp01s_send(const uint8_t *data, uint32_t len, uint32_t timeout_ms)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/esp01s.c",
   "func": "esp01s_read",
   "line": 785,
   "static": false,
   "fileLine": "int esp01s_read(uint8_t *buf, uint32_t len, uint32_t timeout_ms)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/http_client.c",
   "func": "http_read_line",
   "line": 15,
   "static": true,
   "fileLine": "static int http_read_line(char *buf, uint32_t maxlen, uint32_t timeout_ms)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/http_client.c",
   "func": "http_read_body",
   "line": 52,
   "static": true,
   "fileLine": "static int http_read_body(uint8_t *buf, uint32_t want, uint32_t timeout_ms,"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/http_client.c",
   "func": "http_parse_chunk_size",
   "line": 78,
   "static": true,
   "fileLine": "static int http_parse_chunk_size(const char *line, uint32_t *size)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/http_client.c",
   "func": "http_client_request_once",
   "line": 117,
   "static": true,
   "fileLine": "static int http_client_request_once(const char *host, uint16_t port,"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/http_client.c",
   "func": "http_client_request",
   "line": 419,
   "static": false,
   "fileLine": "int http_client_request(const char *host, uint16_t port,"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/param_area.c",
   "func": "param_area_crc",
   "line": 29,
   "static": false,
   "fileLine": "uint32_t param_area_crc(const ota_param_t *param)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/param_area.c",
   "func": "param_area_defaults",
   "line": 35,
   "static": false,
   "fileLine": "void param_area_defaults(ota_param_t *param)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/param_area.c",
   "func": "slot_is_empty",
   "line": 58,
   "static": true,
   "fileLine": "static int slot_is_empty(uint32_t slot_addr)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/param_area.c",
   "func": "slot_load",
   "line": 77,
   "static": true,
   "fileLine": "static int slot_load(uint32_t slot_addr, ota_param_t *out, uint32_t *out_seq)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/param_area.c",
   "func": "param_area_load",
   "line": 106,
   "static": false,
   "fileLine": "int param_area_load(ota_param_t *param)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/param_area.c",
   "func": "param_area_save",
   "line": 147,
   "static": false,
   "fileLine": "int param_area_save(const ota_param_t *param)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/flash_if.c",
   "func": "flash_if_sector_number",
   "line": 40,
   "static": false,
   "fileLine": "uint32_t flash_if_sector_number(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/flash_if.c",
   "func": "flash_if_sector_start",
   "line": 56,
   "static": false,
   "fileLine": "uint32_t flash_if_sector_start(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/flash_if.c",
   "func": "flash_if_sector_size",
   "line": 61,
   "static": false,
   "fileLine": "uint32_t flash_if_sector_size(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/flash_if.c",
   "func": "flash_if_erase_addr",
   "line": 66,
   "static": false,
   "fileLine": "HAL_StatusTypeDef flash_if_erase_addr(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/flash_if.c",
   "func": "flash_if_erase_region",
   "line": 71,
   "static": false,
   "fileLine": "HAL_StatusTypeDef flash_if_erase_region(uint32_t base, uint32_t size)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/flash_if.c",
   "func": "flash_if_write",
   "line": 108,
   "static": false,
   "fileLine": "HAL_StatusTypeDef flash_if_write(uint32_t addr, const uint8_t *data, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/flash_if.c",
   "func": "flash_if_read",
   "line": 172,
   "static": false,
   "fileLine": "void flash_if_read(uint32_t addr, uint8_t *buf, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "func": "w25q16_init",
   "line": 46,
   "static": false,
   "fileLine": "void w25q16_init(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "func": "w25q16_read_jedec_id",
   "line": 52,
   "static": false,
   "fileLine": "uint32_t w25q16_read_jedec_id(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "func": "w25q16_read_status1",
   "line": 70,
   "static": false,
   "fileLine": "uint8_t w25q16_read_status1(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "func": "w25q16_read_status2",
   "line": 75,
   "static": false,
   "fileLine": "uint8_t w25q16_read_status2(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "func": "w25q16_wait_busy",
   "line": 84,
   "static": false,
   "fileLine": "void w25q16_wait_busy(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "func": "w25q16_write_enable",
   "line": 94,
   "static": false,
   "fileLine": "void w25q16_write_enable(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "func": "w25q16_write_disable",
   "line": 99,
   "static": false,
   "fileLine": "void w25q16_write_disable(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "func": "w25q16_read",
   "line": 108,
   "static": false,
   "fileLine": "HAL_StatusTypeDef w25q16_read(uint32_t addr, uint8_t *data, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "func": "w25q16_write",
   "line": 146,
   "static": false,
   "fileLine": "HAL_StatusTypeDef w25q16_write(uint32_t addr, const uint8_t *data, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "func": "w25q16_erase_sector",
   "line": 186,
   "static": false,
   "fileLine": "HAL_StatusTypeDef w25q16_erase_sector(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "func": "w25q16_erase_block",
   "line": 198,
   "static": false,
   "fileLine": "HAL_StatusTypeDef w25q16_erase_block(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "func": "w25q16_erase_chip",
   "line": 212,
   "static": false,
   "fileLine": "HAL_StatusTypeDef w25q16_erase_chip(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/w25q_ext.c",
   "func": "w25q16_is_erased",
   "line": 231,
   "static": false,
   "fileLine": "int w25q16_is_erased(uint32_t addr, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_rollback_test.c",
   "func": "rb_wait_ms",
   "line": 31,
   "static": true,
   "fileLine": "static void rb_wait_ms(uint32_t ms)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_rollback_test.c",
   "func": "ota_rollback_test_arm",
   "line": 45,
   "static": false,
   "fileLine": "int ota_rollback_test_arm(uint32_t delay_ms)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_rollback_test.c",
   "func": "ota_rollback_test_hook",
   "line": 73,
   "static": false,
   "fileLine": "int ota_rollback_test_hook(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_rollback_test.c",
   "func": "ota_rollback_test_hook",
   "line": 116,
   "static": false,
   "fileLine": "int ota_rollback_test_hook(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/ota_rollback_test.c",
   "func": "ota_rollback_test_arm",
   "line": 121,
   "static": false,
   "fileLine": "int ota_rollback_test_arm(uint32_t delay_ms)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/crc32.c",
   "func": "crc32_calc",
   "line": 12,
   "static": false,
   "fileLine": "uint32_t crc32_calc(const uint8_t *data, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/sha256.c",
   "func": "sha256_transform",
   "line": 46,
   "static": true,
   "fileLine": "static void sha256_transform(sha256_ctx_t *ctx, const uint8_t block[SHA256_BLOCK_SIZE])"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/sha256.c",
   "func": "sha256_init",
   "line": 108,
   "static": false,
   "fileLine": "void sha256_init(sha256_ctx_t *ctx)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/sha256.c",
   "func": "sha256_update",
   "line": 127,
   "static": false,
   "fileLine": "void sha256_update(sha256_ctx_t *ctx, const uint8_t *data, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/sha256.c",
   "func": "sha256_final",
   "line": 172,
   "static": false,
   "fileLine": "void sha256_final(sha256_ctx_t *ctx, uint8_t digest[SHA256_DIGEST_SIZE])"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/sha256.c",
   "func": "sha256_compute",
   "line": 224,
   "static": false,
   "fileLine": "void sha256_compute(const uint8_t *data, uint32_t len, uint8_t digest[SHA256_DIGEST_SIZE])"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/sha256.c",
   "func": "sha256_equal",
   "line": 233,
   "static": false,
   "fileLine": "int sha256_equal(const uint8_t *a, const uint8_t *b)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/md5.c",
   "func": "rotl32",
   "line": 41,
   "static": true,
   "fileLine": "static uint32_t rotl32(uint32_t x, uint32_t n)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/md5.c",
   "func": "md5_block",
   "line": 46,
   "static": true,
   "fileLine": "static void md5_block(md5_ctx_t *ctx, const uint8_t *block)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/md5.c",
   "func": "md5_init",
   "line": 100,
   "static": false,
   "fileLine": "void md5_init(md5_ctx_t *ctx)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/md5.c",
   "func": "md5_update",
   "line": 110,
   "static": false,
   "fileLine": "void md5_update(md5_ctx_t *ctx, const uint8_t *data, uint32_t len)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/md5.c",
   "func": "md5_final",
   "line": 146,
   "static": false,
   "fileLine": "void md5_final(md5_ctx_t *ctx, uint8_t digest[MD5_DIGEST_SIZE])"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/md5.c",
   "func": "md5_compute",
   "line": 179,
   "static": false,
   "fileLine": "void md5_compute(const uint8_t *data, uint32_t len, uint8_t digest[MD5_DIGEST_SIZE])"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/md5.c",
   "func": "md5_equal",
   "line": 187,
   "static": false,
   "fileLine": "int md5_equal(const uint8_t *a, const uint8_t *b)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "OTA/md5.c",
   "func": "md5_digest_to_hex",
   "line": 198,
   "static": false,
   "fileLine": "void md5_digest_to_hex(const uint8_t digest[MD5_DIGEST_SIZE], char *out)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "App/esp_handle.c",
   "func": "esp8266_Init",
   "line": 37,
   "static": false,
   "fileLine": "void esp8266_Init(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "App/esp_handle.c",
   "func": "json_read_string",
   "line": 85,
   "static": true,
   "fileLine": "static int json_read_string(const char **cursor,"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "App/esp_handle.c",
   "func": "json_read_scalar",
   "line": 165,
   "static": true,
   "fileLine": "static int json_read_scalar(const char **cursor,"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "App/esp_handle.c",
   "func": "onenet_send_set_reply",
   "line": 388,
   "static": false,
   "fileLine": "void onenet_send_set_reply(const char *msg_id)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "App/esp_handle.c",
   "func": "uart_process",
   "line": 433,
   "static": false,
   "fileLine": "void uart_process(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/main.c",
   "func": "W25Q64_ShowResult",
   "line": 86,
   "static": true,
   "fileLine": "static void W25Q64_ShowResult(uint16_t y, const char *label, uint8_t ok, uint16_t value)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/main.c",
   "func": "W25Q64_RunSelfTest",
   "line": 96,
   "static": true,
   "fileLine": "static void W25Q64_RunSelfTest(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/main.c",
   "func": "UART_NVIC_Config",
   "line": 192,
   "static": false,
   "fileLine": "void UART_NVIC_Config(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/main.c",
   "func": "main",
   "line": 207,
   "static": false,
   "fileLine": "int main(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/main.c",
   "func": "SystemClock_Config",
   "line": 287,
   "static": false,
   "fileLine": "void SystemClock_Config(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/main.c",
   "func": "HAL_TIM_PeriodElapsedCallback",
   "line": 347,
   "static": false,
   "fileLine": "void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/main.c",
   "func": "Error_Handler",
   "line": 365,
   "static": false,
   "fileLine": "void Error_Handler(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/main.c",
   "func": "assert_failed",
   "line": 383,
   "static": false,
   "fileLine": "void assert_failed(uint8_t *file, uint32_t line)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/freertos.c",
   "func": "vApplicationGetIdleTaskMemory",
   "line": 128,
   "static": false,
   "fileLine": "void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t "
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/freertos.c",
   "func": "MX_FREERTOS_Init",
   "line": 142,
   "static": false,
   "fileLine": "void MX_FREERTOS_Init(void) {"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "Core/Src/freertos.c",
   "func": "StartDefaultTask",
   "line": 257,
   "static": false,
   "fileLine": "void StartDefaultTask(void const * argument)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/UART/uart_handle.c",
   "func": "uart_start_receive",
   "line": 24,
   "static": false,
   "fileLine": "HAL_StatusTypeDef uart_start_receive(UART_HandleTypeDef *huart, uint8_t *buf)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/UART/uart_handle.c",
   "func": "uart_printf",
   "line": 57,
   "static": false,
   "fileLine": "void uart_printf(UART_HandleTypeDef *huart, const char *format, ...)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/UART/uart_handle.c",
   "func": "uart_handle",
   "line": 95,
   "static": false,
   "fileLine": "void uart_handle(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/UART/uart_handle.c",
   "func": "HAL_UARTEx_RxEventCallback",
   "line": 124,
   "static": false,
   "fileLine": "void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/UART/uart_handle.c",
   "func": "HAL_UART_ErrorCallback",
   "line": 159,
   "static": false,
   "fileLine": "void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_SPIIsCompatible",
   "line": 21,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_SPIIsCompatible(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_Transmit",
   "line": 54,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_Transmit(const uint8_t *data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_Receive",
   "line": 69,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_Receive(uint8_t *data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_Transfer",
   "line": 84,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_Transfer(const uint8_t *tx_data, uint8_t *rx_data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_IsRangeValid",
   "line": 103,
   "static": true,
   "fileLine": "static uint8_t W25Q64_IsRangeValid(uint32_t addr, uint32_t size)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_SendCommandAddress",
   "line": 118,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_SendCommandAddress(uint8_t command, uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_ReadStatusInternal",
   "line": 130,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_ReadStatusInternal(uint8_t register_number, uint8_t *value)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_WriteEnableInternal",
   "line": 167,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_WriteEnableInternal(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_WaitWhileBusy",
   "line": 190,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_WaitWhileBusy(uint32_t timeout_ms)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_ReadDataInternal",
   "line": 213,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_ReadDataInternal(uint32_t addr, uint8_t *data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_PageWriteInternal",
   "line": 244,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_PageWriteInternal(uint32_t addr, const uint8_t *data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_StepOverPageWriteInternal",
   "line": 290,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_StepOverPageWriteInternal(uint32_t addr,"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_EraseInternal",
   "line": 329,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_EraseInternal(uint8_t command, uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_WriteDataInternal",
   "line": 362,
   "static": true,
   "fileLine": "static HAL_StatusTypeDef W25Q64_WriteDataInternal(uint32_t addr,"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_InitConfig",
   "line": 449,
   "static": false,
   "fileLine": "void W25Q64_InitConfig(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_ReadWriteByte",
   "line": 474,
   "static": false,
   "fileLine": "uint8_t W25Q64_ReadWriteByte(uint8_t data)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_GetID",
   "line": 482,
   "static": false,
   "fileLine": "uint16_t W25Q64_GetID(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_ReadState",
   "line": 509,
   "static": false,
   "fileLine": "uint8_t W25Q64_ReadState(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_WriteENABLE",
   "line": 517,
   "static": false,
   "fileLine": "void W25Q64_WriteENABLE(void)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_SectorErase",
   "line": 522,
   "static": false,
   "fileLine": "void W25Q64_SectorErase(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_BlockErase",
   "line": 527,
   "static": false,
   "fileLine": "void W25Q64_BlockErase(uint32_t addr)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_ReadData",
   "line": 532,
   "static": false,
   "fileLine": "void W25Q64_ReadData(uint32_t addr, uint8_t *data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_PageWrite",
   "line": 537,
   "static": false,
   "fileLine": "void W25Q64_PageWrite(uint32_t addr, uint8_t *data, uint16_t size)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_StepOverPageWrite",
   "line": 542,
   "static": false,
   "fileLine": "void W25Q64_StepOverPageWrite(uint32_t addr, uint8_t *data, uint32_t size)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_WriteData",
   "line": 547,
   "static": false,
   "fileLine": "void W25Q64_WriteData(uint32_t addr, uint8_t *data, uint32_t size)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_ReadStatusRegister",
   "line": 552,
   "static": false,
   "fileLine": "HAL_StatusTypeDef W25Q64_ReadStatusRegister(uint8_t register_number, uint8_t *value)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_WriteStatusRegister",
   "line": 558,
   "static": false,
   "fileLine": "HAL_StatusTypeDef W25Q64_WriteStatusRegister(uint8_t register_number, uint8_t value)"
  },
  {
   "project": "HAL_F429IGT6_App",
   "file": "bsp/W25q64/w25q64.c",
   "func": "W25Q64_GetLastStatus",
   "line": 602,
   "static": false,
   "fileLine": "HAL_StatusTypeDef W25Q64_GetLastStatus(void)"
  }
 ],
 "stats": [
  {
   "project": "HAL_F429IGT6_bootloard",
   "files": 42,
   "lines": 5745
  },
  {
   "project": "HAL_F429IGT6_App",
   "files": 86,
   "lines": 18355
  },
  {
   "project": "HAL_F429IGT6_App_2",
   "files": 86,
   "lines": 18357
  }
 ]
};
