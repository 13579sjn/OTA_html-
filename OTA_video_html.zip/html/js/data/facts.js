/* =============================================================================
 * facts.js —— 工程事实层（全部来自源码，逐项标注出处）
 *
 * 证据等级约定（与网页 UI 上的徽标一一对应）：
 *   A = 源码已证实      代码中确实存在，能定位到文件与行号
 *   B = 根据源码推导    由多个函数/变量/标志推出，源码没有一句话写全
 *   C = 建议方案/模拟   当前工程未实现，仅用于解释一种可能的改进设计
 *
 * 本文件不包含任何动画逻辑，只提供"事实"。动画层不允许改写这里的数值。
 * ========================================================================== */
'use strict';

window.OTA_FACTS = (function () {

  /* ------------------------------------------------------------------ */
  /* 1. 芯片与工程                                                       */
  /* ------------------------------------------------------------------ */

  const mcu = {
    part: 'STM32F429IGT6',
    core: 'ARM Cortex-M4F（带 FPU）',
    flashKB: 1024,
    sramKB: 192,          /* SRAM1 112K + SRAM2 16K + SRAM3 64K */
    ccmKB: 64,
    sysclkMHz: 180,
    blClock: 'HSI 16MHz → PLL 180MHz',
    appClock: 'HSE 25MHz → PLL 180MHz',
    note: 'BL 与 App 主频相同但时钟源不同，这是跳转前必须把时钟树恢复为 HSI 的原因。'
  };

  const projects = [
    {
      id: 'HAL_F429IGT6_bootloard',
      name: 'HAL_F429IGT6_bootloard',
      short: 'BootLoader',
      role: '决定跑哪个 App 并跳过去；负责校验、搬运、回滚、恢复出厂',
      irom: '0x08000000 / 0x0000C000',
      bin: 'bin 24,880 B（本机 MDK-ARM/Bin 实测）',
      keyDir: 'Boot/',
      color: '#7ad7ff'
    },
    {
      id: 'HAL_F429IGT6_App',
      name: 'HAL_F429IGT6_App',
      short: 'App 1.0.0',
      role: '当前运行固件；负责上网、从 OneNET 拉固件、写片外 Flash、校验、置标志复位',
      irom: '0x08010000 / 0x000F0000',
      bin: 'bin 94,820 B（V1.0.0）',
      keyDir: 'OTA/ App/',
      color: '#57e389'
    },
    {
      id: 'HAL_F429IGT6_App_2',
      name: 'HAL_F429IGT6_App_2',
      short: 'App 1.0.1',
      role: '升级包固件（同源同地址，仅版本号不同）；编译出的 bin 上传 OneNET 作为“新固件”',
      irom: '0x08010000 / 0x000F0000',
      bin: 'bin 94,824 B（V1.0.1）',
      keyDir: 'OTA/ App/',
      color: '#ffb454'
    }
  ];

  /* ------------------------------------------------------------------ */
  /* 2. 片内 Flash 分区（partition.h 逐字）                              */
  /* ------------------------------------------------------------------ */

  const intFlash = {
    base: 0x08000000,
    size: 0x00100000,
    regions: [
      {
        id: 'bl', name: 'BootLoader', short: 'BL',
        addr: 0x08000000, size: 0x0000C000, sectors: 'S0–S2',
        write: 'Keil IROM1（0x08000000 / 0xC000）',
        erase: '按 16KB 扇区（flash_if_erase_addr）',
        color: '#7ad7ff',
        desc: '上电复位向量所在；OTA 期间只读不写。'
      },
      {
        id: 'param', name: '参数区 PARAM', short: 'PARAM',
        addr: 0x0800C000, size: 0x00004000, sectors: 'S3',
        write: 'param_area_save()：32 槽 × 512B 轮转',
        erase: '写满 32 次才整扇区擦一次',
        color: '#c792ea',
        desc: 'BL 与 App 之间唯一的持久化通信媒介（boot_flag / version / 各类 SHA-256）。'
      },
      {
        id: 'app', name: 'App A 槽', short: 'APP A',
        addr: 0x08010000, size: 0x000F0000, sectors: 'S4–S11',
        write: '仅 BootLoader 在 TRY_NEW / ROLLBACK / RECOVERY 时写入',
        erase: 'S4=64KB + S5~S11 各 128KB，必须按扇区分别擦',
        color: '#57e389',
        desc: '唯一的可执行 App 槽。App 自己不能替换自己，所以必须由 BL 完成擦写。'
      }
    ]
  };

  /* F429IGT6 真实扇区表（flash_if.c 的 s_sector_start / s_sector_size 逐字） */
  const sectors = [
    { i: 0, addr: 0x08000000, size: 0x004000, kb: 16 },
    { i: 1, addr: 0x08004000, size: 0x004000, kb: 16 },
    { i: 2, addr: 0x08008000, size: 0x004000, kb: 16 },
    { i: 3, addr: 0x0800C000, size: 0x004000, kb: 16 },
    { i: 4, addr: 0x08010000, size: 0x010000, kb: 64 },
    { i: 5, addr: 0x08020000, size: 0x020000, kb: 128 },
    { i: 6, addr: 0x08040000, size: 0x020000, kb: 128 },
    { i: 7, addr: 0x08060000, size: 0x020000, kb: 128 },
    { i: 8, addr: 0x08080000, size: 0x020000, kb: 128 },
    { i: 9, addr: 0x080A0000, size: 0x020000, kb: 128 },
    { i: 10, addr: 0x080C0000, size: 0x020000, kb: 128 },
    { i: 11, addr: 0x080E0000, size: 0x020000, kb: 128 }
  ];

  /* ------------------------------------------------------------------ */
  /* 3. 片外 W25Q64 分区（partition.h 逐字）                              */
  /* ------------------------------------------------------------------ */

  const extFlash = {
    part: 'W25Q64',
    bus: 'SPI2，片选 PB12',
    jedec: '0x00EF4017',
    size: 0x00800000,
    sectorSize: 0x1000,
    blockSize: 0x10000,
    pageSize: 0x100,
    regions: [
      {
        id: 'staging', name: 'STAGING 暂存', short: '暂存',
        addr: 0x000000, size: 0x000F0000,
        color: '#35e0d0',
        desc: '新固件先落这里（App 下载写入，边下边写）。BL 校验 SHA-256 通过后才搬运到片内 A 槽。'
      },
      {
        id: 'backup', name: 'BACKUP 备份', short: '备份',
        addr: 0x000F0000, size: 0x000F0000,
        color: '#ffb454',
        desc: '升级前把当前 A 槽固件拷到这里；回滚时 BL 用它覆盖 A 槽。'
      },
      {
        id: 'recovery', name: 'RECOVERY 恢复', short: '恢复',
        addr: 0x001E0000, size: 0x000F0000,
        color: '#8ab4f8',
        desc: '出厂镜像。首次运行时 ota_init_recovery_if_empty() 把当时的 A 槽固件固化一份。'
      },
      {
        id: 'resource', name: 'RESOURCE 资源', short: '资源',
        addr: 0x002D0000, size: 0x000F0000,
        color: '#5d7285',
        desc: '预留给字库/图片等 LVGL 资源，OTA 流程不触碰。'
      }
    ],
    free: '0x003C0000 之后约 4.25MB 空闲'
  };

  /* ------------------------------------------------------------------ */
  /* 4. 启动标志四态（partition.h + boot_start.c 的实际分支）             */
  /* ------------------------------------------------------------------ */

  const bootFlags = [
    {
      v: 0, name: 'OTA_BOOT_FLAG_NORMAL', short: 'NORMAL',
      writtenBy: '出厂默认 / BL 升级完成后 / 新固件确认后',
      blAction: '直接校验并跳转 A 槽（boot_count 非 0 时清零）',
      clearedBy: '—',
      color: '#57e389',
      codeRef: 'boot_start.c:448-460'
    },
    {
      v: 1, name: 'OTA_BOOT_FLAG_TRY_NEW', short: 'TRY_NEW',
      writtenBy: 'App 的 ota_apply_and_reboot()',
      blAction: '校验暂存区 SHA-256 → 拷贝到 A 槽 → boot_count+1 → 跳转；达到 OTA_BOOT_MAX_TRIES(3) 自动转 ROLLBACK',
      clearedBy: '新固件调 ota_confirm_boot_success() 置回 NORMAL',
      color: '#ffb454',
      codeRef: 'boot_start.c:393-447'
    },
    {
      v: 2, name: 'OTA_BOOT_FLAG_ROLLBACK', short: 'ROLLBACK',
      writtenBy: '新固件自证失败 / 手动 ota_manual_rollback() / BL 试运行超次数',
      blAction: '校验备份区 SHA-256 → 拷贝到 A 槽 → 版本号改回 backup_version → 清标志 → 跳转',
      clearedBy: 'BL 自己（写回 NORMAL）',
      color: '#ff8a5b',
      codeRef: 'boot_start.c:331-368'
    },
    {
      v: 3, name: 'OTA_BOOT_FLAG_RECOVERY', short: 'RECOVERY',
      writtenBy: '手动 ota_manual_recovery() / 回滚不可用时的兜底',
      blAction: '校验恢复区 SHA-256 → 拷贝到 A 槽 → 清标志 → 跳转',
      clearedBy: 'BL 自己（写回 NORMAL）',
      color: '#8ab4f8',
      codeRef: 'boot_start.c:369-392'
    }
  ];

  const backupStatus = [
    { v: 0, name: 'OTA_BACKUP_EMPTY', short: 'EMPTY' },
    { v: 1, name: 'OTA_BACKUP_DOWNLOADING', short: 'DOWNLOADING' },
    { v: 2, name: 'OTA_BACKUP_VALID', short: 'VALID' }
  ];

  /* ------------------------------------------------------------------ */
  /* 4b. 真实符号地址（取自两个工程的 .map 文件，逐字）                   */
  /* ------------------------------------------------------------------ */

  const symbols = {
    boot: [
      { name: '__Vectors', addr: '0x08000000', note: 'BL 向量表起始（复位后取指）', src: 'HAL_F429IGT6_bootloard.map' },
      { name: '__initial_sp', addr: '0x20000E00', note: 'BL 初始 MSP', src: 'HAL_F429IGT6_bootloard.map' },
      { name: 'Reset_Handler', addr: '0x080002F9', note: 'BL 复位入口（Thumb）', src: 'HAL_F429IGT6_bootloard.map' },
      { name: 'boot_run', addr: '0x08004DBD', note: 'BL 主流程', src: 'HAL_F429IGT6_bootloard.map' },
      { name: 'boot_verify_ext_image', addr: '0x08005571', note: '暂存区 SHA-256 校验', src: 'HAL_F429IGT6_bootloard.map' },
      { name: 'boot_copy_ext_to_run', addr: '0x08004911', note: '片外 → A 槽搬运', src: 'HAL_F429IGT6_bootloard.map' },
      { name: 'app_jump_validate', addr: '0x080048D5', note: '三道闸门', src: 'HAL_F429IGT6_bootloard.map' },
      { name: 'app_jump_execute', addr: '0x08004861', note: '跳转执行', src: 'HAL_F429IGT6_bootloard.map' },
      { name: 'boot_system_shutdown', addr: '0x0800548D', note: '九步清理', src: 'HAL_F429IGT6_bootloard.map' },
      { name: 'param_area_load', addr: '0x080057DD', note: '参数区读取', src: 'HAL_F429IGT6_bootloard.map' }
    ],
    app: [
      { name: '__Vectors', addr: '0x08010000', note: 'App 向量表（IROM1 起点）', src: 'HAL_F429IGT6.map' },
      { name: '__initial_sp', addr: '0x20014E38', note: 'App 初始 MSP（与 BL 日志一致）', src: 'HAL_F429IGT6.map' },
      { name: 'Reset_Handler', addr: '0x080103F9', note: 'App 复位入口（与 BL 日志一致）', src: 'HAL_F429IGT6.map' },
      { name: 'ota_run_once', addr: '0x0801FB69', note: 'OTA 引擎主流程', src: 'HAL_F429IGT6.map' },
      { name: 'ota_download_try', addr: '0x0801EF59', note: '单次下载尝试', src: 'HAL_F429IGT6.map' },
      { name: 'dl_on_data', addr: '0x0801C8E5', note: '下载回调（双哈希 + 写 Flash）', src: 'HAL_F429IGT6.map' },
      { name: 'esp01s_parse', addr: '0x0801CE21', note: '+IPD 解析', src: 'HAL_F429IGT6.map' },
      { name: 'http_client_request_once', addr: '0x0801D881', note: 'HTTP 请求', src: 'HAL_F429IGT6.map' },
      { name: 'ota_backup_current_app', addr: '0x0801EA85', note: '备份旧固件', src: 'HAL_F429IGT6.map' },
      { name: 'ota_apply_and_reboot', addr: '0x0801E9C5', note: '置 TRY_NEW + 复位', src: 'HAL_F429IGT6.map' },
      { name: 'ota_confirm_boot_success', addr: '0x0801EDF5', note: '固化 NORMAL', src: 'HAL_F429IGT6.map' },
      { name: 'ota_net_enter', addr: '0x0801F781', note: '通道交接', src: 'HAL_F429IGT6.map' },
      { name: 'w25q16_write', addr: '0x08021319', note: '写片外 Flash', src: 'HAL_F429IGT6.map' },
      { name: 'esp8266_Init', addr: '0x0801D2D1', note: 'MQTT 初始化', src: 'HAL_F429IGT6.map' }
    ]
  };

  /* ------------------------------------------------------------------ */
  /* 5. 关键常量（值 + 出处）                                            */
  /* ------------------------------------------------------------------ */

  const constants = [
    { k: 'OTA_BOOTLOADER_ADDR', v: '0x08000000', src: 'Boot/partition.h:47', g: 'A' },
    { k: 'OTA_BOOTLOADER_SIZE', v: '0xC000 (48KB)', src: 'Boot/partition.h:48', g: 'A' },
    { k: 'OTA_PARAM_AREA_ADDR', v: '0x0800C000', src: 'Boot/partition.h:51', g: 'A' },
    { k: 'OTA_PARAM_AREA_SIZE', v: '0x4000 (16KB)', src: 'Boot/partition.h:52', g: 'A' },
    { k: 'OTA_PARAM_SLOT_COUNT', v: '32', src: 'Boot/partition.h:55', g: 'A' },
    { k: 'OTA_PARAM_SLOT_SIZE', v: '512 B', src: 'Boot/partition.h:56', g: 'A' },
    { k: 'OTA_APP_A_ADDR', v: '0x08010000', src: 'Boot/partition.h:60', g: 'A' },
    { k: 'OTA_APP_SIZE', v: '0xF0000 (960KB)', src: 'Boot/partition.h:61', g: 'A' },
    { k: 'OTA_APP_IMAGE_MAX_SIZE', v: '0xF0000 (960KB)', src: 'Boot/partition.h:64', g: 'A' },
    { k: 'EXT_STAGING_ADDR', v: '0x000000', src: 'Boot/partition.h:73', g: 'A' },
    { k: 'EXT_BACKUP_ADDR', v: '0x000F0000', src: 'Boot/partition.h:74', g: 'A' },
    { k: 'EXT_RECOVERY_ADDR', v: '0x001E0000', src: 'Boot/partition.h:75', g: 'A' },
    { k: 'EXT_RESOURCE_ADDR', v: '0x002D0000', src: 'Boot/partition.h:76', g: 'A' },
    { k: 'EXT_REGION_SIZE', v: '0xF0000 (960KB)', src: 'Boot/partition.h:71', g: 'A' },
    { k: 'OTA_BOOT_MAX_TRIES', v: '3', src: 'Boot/partition.h:91', g: 'A' },
    { k: 'OTA_PARAM_MAGIC', v: '0xA5A5A5A5', src: 'Boot/ota_params.h:21', g: 'A' },
    { k: 'BOOT_VERIFY_CHUNK', v: '64 B', src: 'Boot/boot_config.h:50', g: 'A' },
    { k: 'BOOT_COPY_CHUNK', v: '1024 B', src: 'Boot/boot_config.h:53', g: 'A' },
    { k: 'BOOT_WDG_ENABLE', v: '0（关闭）', src: 'Boot/boot_config.h:25', g: 'A' },
    { k: 'BOOT_RESTORE_CLOCK_ON_JUMP', v: '1', src: 'Boot/boot_config.h:41', g: 'A' },
    { k: 'OTA_APP_VERSION_STR (App)', v: '"1.0.0"', src: 'App/OTA/ota_config.h:50', g: 'A' },
    { k: 'OTA_APP_VERSION_STR (App_2)', v: '"1.0.1"', src: 'App_2/OTA/ota_config.h:50', g: 'A' },
    { k: 'OTA_DL_CHUNK', v: '256 B', src: 'App/OTA/ota_config.h:73', g: 'A' },
    { k: 'OTA_CHECKPOINT_INTERVAL', v: '16384 B', src: 'App/OTA/ota_config.h:76', g: 'A' },
    { k: 'OTA_PROGRESS_STEP', v: '100（不中途上报）', src: 'App/OTA/ota_config.h:85', g: 'A' },
    { k: 'OTA_TEST_NO_REBOOT', v: '0（走完整升级）', src: 'App/OTA/ota_config.h:96', g: 'A' },
    { k: 'OTA_STARTUP_CONFIRM_MS', v: '30000 ms', src: 'App/OTA/ota_config.h:99', g: 'A' },
    { k: 'OTA_SELFTEST_STAGE', v: '0（关闭自测）', src: 'App/OTA/ota_config.h:107', g: 'A' },
    { k: 'OTA_REPORT_FAIL_TO_PLATFORM', v: '0（调试期不上报失败）', src: 'App/OTA/ota_config.h:122', g: 'A' },
    { k: 'ESP_RX_RING_SIZE', v: '4096 B', src: 'App/OTA/esp01s.h:39', g: 'A' },
    { k: 'ESP_DATA_BUF_SIZE', v: '8192 B', src: 'App/OTA/esp01s.h:41', g: 'A' },
    { k: 'USART1 波特率', v: '115200 8-N-1', src: 'App/Core/Src/usart.c:47', g: 'A' },
    { k: 'USART3 波特率', v: '115200 8-N-1', src: 'App/Core/Src/usart.c:76', g: 'A' },
    { k: 'W25Q64 页 / 扇区 / 块', v: '256 / 4096 / 65536 B', src: 'Boot/W25q64/w25q64.h:18-20', g: 'A' },
    { k: 'App 镜像实际大小 (1.0.0)', v: '94,820 B', src: 'MDK-ARM/Bin/HAL_F429IGT6.bin', g: 'A' },
    { k: 'App 镜像实际大小 (1.0.1)', v: '94,824 B', src: 'App_2/MDK-ARM/Bin/HAL_F429IGT6.bin', g: 'A' },
    { k: 'BL 镜像实际大小', v: '24,880 B', src: 'MDK-ARM/Bin/HAL_F429IGT6_bootloard.bin', g: 'A' }
  ];

  /* ------------------------------------------------------------------ */
  /* 6. OneNET 平台与接口（ota_config.h + http_client 逐字）             */
  /* ------------------------------------------------------------------ */

  const platform = {
    host: 'iot-api.heclouds.com',
    port: 80,
    pid: 'FRfr9m3Ppg',
    dev: 'OTA_Test_drive',
    taskType: 1,
    tokenTail: '…&method=sha1&sign=kLYbgpjIMWGT9klNJKWXX15G3GI%3D',
    tokenEt: 'et=1809960178（≈2027-05-10 到期）',
    apis: [
      { step: '① 上报版本', m: 'POST', path: '/fuse-ota/{pid}/{dev}/version', body: '{"s_version":"1.0.0","f_version":"1.0.0"}', ref: 'ota_engine.c:227' },
      { step: '② 查询任务', m: 'GET', path: '/fuse-ota/{pid}/{dev}/check?type=1&version=1.0.0', body: '—', ref: 'ota_engine.c:266' },
      { step: '③ 下载固件', m: 'GET', path: '/fuse-ota/{pid}/{dev}/{tid}/download', body: 'Range: bytes=<offset>-', ref: 'ota_engine.c:607' },
      { step: '④ 上报状态', m: 'POST', path: '/fuse-ota/{pid}/{dev}/{tid}/status', body: '{"step":N}', ref: 'ota_engine.c:323' }
    ],
    statusCodes: [
      { step: 100, mean: '下载完成', ref: 'ota_engine.c:1263', g: 'A' },
      { step: 201, mean: '升级成功', ref: 'ota_engine.c:1015', g: 'A' },
      { step: 205, mean: 'MD5 校验失败（默认被开关屏蔽）', ref: 'ota_engine.c:708', g: 'A' },
      { step: 206, mean: '升级失败：差分包 / 降级 / 长度不符', ref: 'ota_engine.c:699,1189,1212', g: 'A' },
      { step: 207, mean: '下载失败（Ota-Errno > 0）', ref: 'ota_engine.c:656', g: 'A' }
    ]
  };

  /* ------------------------------------------------------------------ */
  /* 7. 变量定义（变量面板用；key 与动画状态里的字段对应）                */
  /* ------------------------------------------------------------------ */

  const varDefs = [
    { k: 'boot_flag', label: 'boot_flag', src: 'ota_param_t', kind: 'flag', g: 'A', tip: '启动目标选择标志，BL 全流程的唯一裁决依据' },
    { k: 'boot_count', label: 'boot_count', src: 'ota_param_t', kind: 'num', g: 'A', tip: '新固件连续启动次数，≥3 自动回滚' },
    { k: 'version', label: 'version', src: 'ota_param_t', kind: 'ver', g: 'A', tip: '参数区记录的当前版本，App 用它做防降级比较' },
    { k: 'image_len', label: 'image_len', src: 'ota_param_t', kind: 'num', g: 'A', tip: '暂存区待装镜像长度，BL 校验用' },
    { k: 'resume_offset', label: 'resume_offset', src: 'ota_param_t', kind: 'num', g: 'A', tip: '断点续传偏移，0 表示无未完成任务' },
    { k: 'backup_status', label: 'backup_status', src: 'ota_param_t', kind: 'bk', g: 'A', tip: '备份区状态 EMPTY / DOWNLOADING / VALID' },
    { k: 'ota_tid', label: 'ota_tid', src: 'ota_param_t', kind: 'num', g: 'A', tip: '待补报 201 的任务号' },
    { k: 'dl_tid', label: 'dl_tid', src: 'ota_param_t', kind: 'num', g: 'A', tip: '当前下载任务号，续传判定用' },
    { k: 'dl_offset', label: 'c.offset', src: 'ota_dl_t.c', kind: 'bytes', g: 'A', tip: '已写入暂存区的字节数（256 的整数倍）' },
    { k: 'dl_total', label: 'c.total', src: 'ota_dl_t.c', kind: 'bytes', g: 'A', tip: '平台任务声明的镜像总字节数' },
    { k: 'blen', label: 'c.blen', src: 'ota_dl_t.c', kind: 'num', g: 'A', tip: '攒块缓冲当前字节数，满 256 才写一次 Flash' },
    { k: 'md5', label: 'MD5(t.md5)', src: 'ota_task_t.md5', kind: 'hash', g: 'A', tip: '平台下发的镜像 MD5，与本地流水线计算的 MD5 比对' },
    { k: 'sha', label: 'SHA-256(新)', src: 'ota_param_t.image_sha', kind: 'hash', g: 'A', tip: '本地计算的 SHA-256，写进参数区供 BL 二次校验' },
    { k: 'state', label: 's_st.state', src: 'ota_state_t', kind: 'state', g: 'A', tip: 'OTA 引擎状态（供 UI 显示）' },
    { k: 'ret', label: '返回值 r', src: 'ota_run_once()', kind: 'ret', g: 'A', tip: '0=成功 1=无任务 -4=下载失败 -5=校验失败 …' }
  ];

  /* ------------------------------------------------------------------ */
  /* 8. 场景（时间轴上的大段；顺序按真实执行次序）                        */
  /* ------------------------------------------------------------------ */

  const scenes = [
    { id: 'power', idx: 1, title: '上电与复位', sub: '取向量表 → Reset_Handler', color: '#7ad7ff' },
    { id: 'bl-init', idx: 2, title: 'BootLoader 初始化', sub: '时钟 / 外设 / 片外 Flash', color: '#7ad7ff' },
    { id: 'bl-param', idx: 3, title: '读取升级标志', sub: '参数区 32 槽轮转', color: '#c792ea' },
    { id: 'bl-decide', idx: 4, title: '启动目标判断', sub: 'boot_flag 四态', color: '#c792ea' },
    { id: 'bl-jump', idx: 5, title: '启动环境与跳转', sub: '拆外设 / MSP / VTOR', color: '#7ad7ff' },
    { id: 'app-init', idx: 6, title: 'App 启动与自检', sub: 'VTOR / FreeRTOS / 自检', color: '#57e389' },
    { id: 'net', idx: 7, title: 'ESP8266 联网 + MQTT', sub: 'AT 指令序列', color: '#35e0d0' },
    { id: 'trigger', idx: 8, title: 'OTA 升级任务触发', sub: 'Update 属性 → 任务创建', color: '#35e0d0' },
    { id: 'handover', idx: 9, title: '通信通道交接', sub: 'MQTT → 裸 TCP', color: '#35e0d0' },
    { id: 'check', idx: 10, title: '上报版本与查询任务', sub: 'HTTP + JSON 解析', color: '#35e0d0' },
    { id: 'download', idx: 11, title: '固件下载', sub: '+IPD → DMA → W25Q64', color: '#35e0d0' },
    { id: 'verify', idx: 12, title: '完整性校验', sub: '长度 / MD5 / SHA-256', color: '#57e389' },
    { id: 'backup', idx: 13, title: '备份旧固件', sub: 'A 槽 → BACKUP', color: '#ffb454' },
    { id: 'commit', idx: 14, title: '写参数并复位', sub: 'TRY_NEW + NVIC_SystemReset', color: '#ffb454' },
    { id: 'bl-trynew', idx: 15, title: 'BL 执行 TRY_NEW', sub: '校验 → 擦 A 槽 → 搬运', color: '#7ad7ff' },
    { id: 'bl-jump2', idx: 16, title: '跳转到新固件', sub: 'MSP / VTOR / 控制权转移', color: '#7ad7ff' },
    { id: 'confirm', idx: 17, title: '新固件首启确认', sub: '30s 静默 → 固化 NORMAL', color: '#57e389' },
    { id: 'done', idx: 18, title: '升级成功', sub: '补报 201 + 版本同步', color: '#57e389' },
    { id: 'fail', idx: 19, title: '异常分支', sub: '失败 / 回滚 / 挂死', color: '#ff5d5d' },
    { id: 'suggest', idx: 20, title: '建议方案模拟', sub: '当前工程未实现', color: '#8ab4f8' }
  ];

  /* ------------------------------------------------------------------ */
  /* 9. 已发现的问题与未实现项（每条都带源码证据）                        */
  /* ------------------------------------------------------------------ */

  const findings = [
    {
      id: 'f-wdg', level: 'risk', title: 'BootLoader 的 IWDG 默认是关闭的',
      detail: 'BOOT_WDG_ENABLE = 0，boot_wdg_init() 整体不执行。BL 里所有 boot_wdg_feed() 调用都是空转。若 App 侧喂狗没打通就置 1，跳转后 8.19s 必然复位。',
      ev: 'boot_config.h:25，boot_wdg.c:23', g: 'A'
    },
    {
      id: 'f-nosign', level: 'risk', title: '只有 MD5 + SHA-256，没有数字签名',
      detail: '平台 MD5 校验传输完整性，本地 SHA-256 校验落地完整性，但两者都不是签名。能修改升级包并同时改平台 MD5 的攻击者仍可通过。',
      ev: 'ota_engine.c:704-713；boot_start.c:77-114', g: 'A'
    },
    {
      id: 'f-single-slot', level: 'fact', title: '不是 A/B 双槽，而是“单 A 槽 + 片外备份”',
      detail: '片内只有 0x08010000 一个 App 槽；App 与 App_2 的 IROM1 完全相同（0x08010000/0xF0000），二者是同一镜像的两个版本，不是两个可并存的运行槽。所谓“双镜像”实际由 W25Q64 的 STAGING / BACKUP / RECOVERY 三个区承担。',
      ev: 'partition.h:60-64；两份 .sct 均为 LR_IROM1 0x08010000', g: 'A'
    },
    {
      id: 'f-copy-risk', level: 'risk', title: 'TRY_NEW 拷贝期间掉电会留下半个 A 槽',
      detail: 'boot_copy_ext_to_run() 先擦后写，拷贝中途掉电后 A 槽处于半写状态。此时 boot_flag 仍是 TRY_NEW，下次上电会按 boot_count 累加，第 3 次自动转 ROLLBACK —— 也就是说“连续 3 次上电失败”才触发回滚，期间设备无法正常运行。',
      ev: 'boot_start.c:120-181、408-428', g: 'B'
    },
    {
      id: 'f-trunc', level: 'fact', title: '下载会被截断，工程用“续传 + 整体重下”兜底',
      detail: '实测每次升级都命中 +IPD 帧头错位导致的数据前移；代码用最多 8 轮 Range 续传补尾，再用 MD5 判定，失败则擦除暂存区整体重下。代价是每次升级可能下两遍。',
      ev: 'ota_engine.c:583-751；实测日志见实施文档 5.4', g: 'A'
    },
    {
      id: 'f-no-progress', level: 'todo', title: '下载中途进度上报是关闭的',
      detail: 'OTA_PROGRESS_STEP = 100 表示不中途上报。原因写在注释里：单连接下中途上报必须断连→发 HTTP→再 Range 续传，轮次多失败面大。',
      ev: 'ota_config.h:78-85', g: 'A'
    },
    {
      id: 'f-no-lcd', level: 'todo', title: 'LCD 升级进度页未接回',
      detail: '屏幕驱动在 App 里可用（LCD_Init），但 OTA 过程没有绘制进度页；ota_status_t 快照接口已经准备好，只差 UI 消费。',
      ev: 'ota_engine.h:50-62（接口已存在）；freertos.c:153 只做静态显示', g: 'B'
    },
    {
      id: 'f-nofunc-test', level: 'todo', title: '启动确认只做“时间”判断，不做功能自检',
      detail: '新固件首启的确认条件是“静默跑满 30s 且没复位”。如果新固件能启动但业务功能全坏（例如网络不通），它仍会在 30s 后把 flag 固化为 NORMAL，不会再回滚。',
      ev: 'ota_engine.c:1073-1080', g: 'A'
    },
    {
      id: 'f-backup-ver', level: 'risk', title: '回滚后的版本号同步有一个隐含前提',
      detail: 'ROLLBACK 分支里只有 backup_version != 0 才覆盖 param.version。若备份版本号为 0（例如备份是旧格式写入的），版本号会保持新版本值，导致 App 的防降级比较失真。代码注释已自认此风险。',
      ev: 'boot_start.c:342-345', g: 'A'
    },
    {
      id: 'f-doc-name', level: 'note', title: '文档与源码的宏名不一致（不影响功能）',
      detail: '实施文档第 2.1 节的表格写 OTA_BL_ADDR / OTA_PARAM_ADDR，实际 partition.h 里的名字是 OTA_BOOTLOADER_ADDR / OTA_PARAM_AREA_ADDR。以源码为准。',
      ev: 'partition.h:47,51 vs 实施文档 2.1 表格', g: 'A'
    },
    {
      id: 'f-gbk', level: 'note', title: 'App/esp_handle.c 是 GBK 编码',
      detail: '该文件是历史遗留的 GBK 文本，与其他 UTF-8 源文件混编。Keil 能正常编译，但跨编辑器/CI 处理时容易出现乱码（实施文档 8.9 记录过一次乱码故障）。本次网页展示该文件时做了转码，行号与原文件一致。',
      ev: 'App/esp_handle.c（GBK）', g: 'A'
    },
    {
      id: 'f-uart1-baud', level: 'note', title: 'USART1 与 USART3 都跑 115200',
      detail: 'BL 日志与 App 日志走 USART1(PA9/PA10)；ESP-01S 走 USART3(PB10/PB11)。两条链路都是 115200 8-N-1，所以“115200 下的约 11.5KB/s”同时是日志与固件下行速率的量级。',
      ev: 'Boot/Core/Src/usart.c:44；App/Core/Src/usart.c:47,76', g: 'A'
    }
  ];

  /* ------------------------------------------------------------------ */
  /* 10. 建议方案（当前工程未实现，标记 C）                              */
  /* ------------------------------------------------------------------ */

  const suggestions = [
    {
      id: 's-ab', title: '片内 A/B 双槽 + 原子指针切换',
      now: '单 A 槽，升级必须擦写运行中镜像，靠片外备份回滚',
      idea: '把 960KB 拆成 480KB+B 槽，boot_flag 改为“当前槽指针”，新固件写入非活动槽后只改指针即可切换，擦写期间旧镜像完整保留，回滚变成“改指针”而不是“再拷一次”。',
      cost: '镜像上限降到 480KB；需要在 BL 里维护槽指针与两个 SHA。'
    },
    {
      id: 's-sign', title: '升级包 Ed25519 签名',
      now: 'MD5（传输）+ SHA-256（落地），无签名',
      idea: 'OTA 包里带 64B Ed25519 签名，BL 用内置公钥验签；验签失败直接拒绝搬运。密钥与验证代码留在 BL，App 无法绕过。',
      cost: 'BL 体积增加约 4~6KB，需一次可信的密钥注入流程。'
    },
    {
      id: 's-window', title: '窗口化下载（根治“每次下载两遍”）',
      now: '整包一次性下完，串口消费跟不上就截断、重下',
      idea: '每下 64KB 主动断开一次连接，把 +IPD 帧头错位的影响限制在单个窗口内；配合 Range 续传，坏窗口只重下 64KB。',
      cost: 'HTTP 轮次从 1 次变 15 次，每轮有 TCP 建连开销。'
    },
    {
      id: 's-health', title: '带功能自检的启动确认',
      now: '只等 30s 且没复位就确认',
      idea: '新固件启动后先跑一组自检（网络可连、W25Q64 ID 正确、屏幕可用），全部通过才调 ota_confirm_boot_success()；任一项失败立即置 ROLLBACK 并复位。',
      cost: '首启确认时间变长；自检项要避免依赖 OTA 自身。'
    }
  ];

  return {
    version: '1.0',
    mcu, projects, intFlash, sectors, extFlash, bootFlags, backupStatus,
    constants, platform, varDefs, scenes, findings, suggestions, symbols,
    /* 变量面板里会被动画改写的字段初始值 */
    initialState: {
      boot_flag: 0, boot_count: 0, version: 0x010000, image_len: 0,
      resume_offset: 0, backup_status: 0, ota_tid: 0, dl_tid: 0,
      dl_offset: 0, dl_total: 0, blen: 0,
      md5: '—', sha: '—', state: 'OTA_ST_IDLE', ret: '—'
    }
  };
})();
