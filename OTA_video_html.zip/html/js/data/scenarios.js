/* =============================================================================
 * scenarios.js —— 把分段时间轴组装成可播放的完整演示
 *
 * 一个 scenario = 一组 step（含绝对时间 t0/t1）+ 场景边界 + 关键事件标记。
 * 正常路径与异常路径共享同一批 segment，保证“同一段流程只有一份描述”。
 * ========================================================================== */
'use strict';

window.OTA_SCENARIOS = (function () {

  const SG = window.OTA_SEG;

  /* 常用组合 */
  const prologueBoot = () => [].concat(
    SG.power(), SG.blInit(), SG.blParam(), SG.blDecide()
  );

  const toAppReady = () => [].concat(
    SG.blJump(), SG.appInit(), SG.net()
  );

  const toOtaReady = () => [].concat(
    SG.trigger(), SG.handover()
  );

  const fullPrefix = () => [].concat(prologueBoot(), toAppReady(), toOtaReady());

  const definitions = [
    {
      id: 'normal',
      title: '正常升级（1.0.0 → 1.0.1）',
      short: '正常升级',
      mode: 'real',
      tone: 'ok',
      desc: '从复位开始，完整走完：BL 判断启动目标 → App 联网 → Update 触发 → 通道交接 → 上报版本与 check → 下载并写 W25Q64 → MD5/SHA-256 → 备份 → 置 TRY_NEW 复位 → BL 校验并搬运 → 跳转 → 新固件 30s 首启确认 → 补报 201。',
      build: () => [].concat(
        fullPrefix(),
        SG.check(), SG.download(), SG.verify(), SG.backup(), SG.commit(),
        SG.blTryNew(), SG.blJump2(), SG.confirm(), SG.done()
      )
    },
    {
      id: 'truncate',
      title: '真机实测：截断自愈 + 重下',
      short: '截断自愈',
      mode: 'real',
      tone: 'warn',
      desc: '复现实施文档 5.4 记录的那次真实升级：第 1 轮收 93,511/94,824 超时 → TRUNCATED → Range 续传补到 94,824 → 字节数对了但 MD5 错（丢的字节在中间）→ 擦除整体重下 → 第 2 遍一次收全 → 成功。',
      build: () => [].concat(
        fullPrefix(),
        SG.check(), SG.download({ truncate: true }), SG.verify(), SG.backup(), SG.commit(),
        SG.blTryNew(), SG.blJump2(), SG.confirm(), SG.done()
      )
    },
    {
      id: 'fail-md5',
      title: '异常：MD5 两遍都失败',
      short: 'MD5 失败',
      mode: 'real',
      tone: 'err',
      desc: '兜底只重下一次；第二遍仍不匹配就返回 -5。整条失败路径上片内 A 槽与 boot_flag 都没有被改动，设备继续跑 1.0.0。',
      build: () => [].concat(
        fullPrefix(), SG.check(), SG.download().slice(0, 8), SG.failMd5()
      )
    },
    {
      id: 'fail-w25q',
      title: '异常：W25Q64 写入失败',
      short: 'Flash 写失败',
      mode: 'real',
      tone: 'err',
      desc: 'dl_on_data() 里 w25q16_write() 返回非 HAL_OK → c.io_err=1 → 后续数据直接丢弃 → 返回 -4。A 槽未被触碰。',
      build: () => [].concat(
        fullPrefix(), SG.check(), SG.download().slice(0, 6), SG.failW25q()
      )
    },
    {
      id: 'fail-net',
      title: '异常：ESP8266 通道交接失败',
      short: '联网失败',
      mode: 'real',
      tone: 'warn',
      desc: 'AT 握手 / 入网失败时 ota_net_enter() 返回负值，ota_net_restore() 无条件回到 MQTT 模式。注意此路径上 ota_run_once() 根本没被调用 —— 不下载、不改参数、不复位。',
      build: () => [].concat(
        prologueBoot(), toAppReady(), SG.trigger(), SG.failNet()
      )
    },
    {
      id: 'fail-notask',
      title: '异常：平台没有升级任务',
      short: '无任务',
      mode: 'real',
      tone: 'warn',
      desc: 'check 返回 code!=0 或 tid==0 → 按“无任务”处理 → 返回 1。属于正常情况，交还串口后业务继续。',
      build: () => [].concat(
        fullPrefix(), SG.check().slice(0, 6), SG.failNoTask()
      )
    },
    {
      id: 'fail-downgrade',
      title: '异常：目标版本不高于当前版本',
      short: '拒绝降级',
      mode: 'real',
      tone: 'warn',
      desc: 'target <= param.version：相等则补报 201 后返回 1（已是最新）；更小则上报 206 并返回 -3（拒绝降级）。',
      build: () => [].concat(
        fullPrefix(), SG.check().slice(0, 7), SG.failDowngradeVer()
      )
    },
    {
      id: 'fail-staging-sha',
      title: '异常：暂存区 SHA-256 失败 → 自动回滚',
      short: 'BL 校验失败→回滚',
      mode: 'real',
      tone: 'err',
      desc: 'BL 在擦 A 槽之前先校验暂存区 SHA-256；不过就一格都不擦，直接把 flag 改成 ROLLBACK 并保存，随后校验备份区、用备份覆盖 A 槽、版本号回退，设备回到 1.0.0 继续可用。',
      build: () => [].concat(
        fullPrefix(), SG.check(), SG.download(), SG.verify(), SG.backup(), SG.commit(),
        SG.blTryNew().slice(0, 1), SG.failStagingSha()
      )
    },
    {
      id: 'fail-bootcount',
      title: '异常：新固件连续 3 次未确认 → 自动回滚',
      short: '启动确认超时',
      mode: 'real',
      tone: 'err',
      desc: '新固件每次都启动、但都没调用 ota_confirm_boot_success()。BL 每次以 TRY_NEW 启动都会 boot_count+1，达到 OTA_BOOT_MAX_TRIES(3) 时自动把 flag 改成 ROLLBACK 并执行回滚。',
      build: () => [].concat(
        fullPrefix(), SG.check(), SG.download(), SG.verify(), SG.backup(), SG.commit(),
        SG.failBootCount()
      )
    },
    {
      id: 'fail-halt',
      title: '异常：回滚与恢复都失败 → 挂死',
      short: '无可用镜像',
      mode: 'real',
      tone: 'err',
      desc: 'A 槽无效、备份无效、恢复区也没有镜像 —— 三条路全断。此时 BL 调 boot_halt() 原地喂狗，不跳转也不复位，等人用调试器介入。这是设备真正会“变砖”的唯一情形。',
      build: () => [].concat(
        SG.power(), SG.blInit(), SG.blParam(), SG.failHalt()
      )
    },
    {
      id: 'suggest-ab',
      title: '建议方案模拟：A/B 双槽切换',
      short: '建议·A/B 双槽',
      mode: 'suggest',
      tone: 'suggest',
      desc: '★ 本场景不是现有工程的行为，而是“建议方案模拟”：把 960KB 拆成 A/B 两槽，新固件写入非活动槽，切换只改一次参数区指针。用来对比现有“单 A 槽 + 覆盖式升级”的代价。',
      build: () => [].concat(SG.suggest())
    }
  ];

  /* 关键事件标记（时间轴上画三角） */
  const MARKERS = {
    'p-reset': '复位',
    'bl-jedec': 'W25Q64 OK',
    'bl-branch': '启动判断',
    'j-entry': '跳转 App',
    'a-espinit': 'MQTT 连接',
    't-update': 'Update=1',
    'h-ready': '通道就绪',
    'c-json': '拿到任务',
    'd-erase': '擦暂存区',
    'd-ipd': '+IPD 收数',
    'd-trunc': '截断!',
    'd-md5fail': 'MD5 失败',
    'd-redownload': '整体重下',
    'v-md5': 'MD5 通过',
    'b-done': '备份完成',
    'm-trynew': 'TRY_NEW',
    'm-reboot': '系统复位',
    'n-verify': 'BL 校验',
    'n-copy': '搬运到 A 槽',
    'f-confirm': '确认 NORMAL',
    'f-201': '补报 201',
    'g-summary': '升级成功',
    'x-notask': '无任务',
    'x-md5-ret': '失败 -5',
    'x-w25q-ret': '失败 -4',
    'x-net-exit': '未升级',
    'x-sha-fail': '拦截!',
    'x-rollback-ok': '已回滚',
    'x-halt-3': '挂死',
    'sg-switch': '指针切换'
  };

  const cache = {};

  function compile(def) {
    const raw = def.build();
    let t = 0;
    const steps = raw.map((s, i) => {
      const dur = s.dur || 2400;
      const step = Object.assign({}, s, {
        idx: i,
        t0: t,
        t1: t + dur,
        dur: dur,
        marker: MARKERS[s.id] || null
      });
      t += dur;
      return step;
    });

    /* 场景边界 */
    const scenes = [];
    steps.forEach((s) => {
      let sc = scenes[scenes.length - 1];
      if (!sc || sc.id !== s.scene) {
        sc = { id: s.scene, t0: s.t0, t1: s.t1, steps: [], names: [] };
        scenes.push(sc);
      }
      sc.t1 = s.t1;
      sc.steps.push(s.idx);
      sc.names.push(s.label);
    });

    /* 场景中文名从 facts 里补 */
    const meta = {};
    (window.OTA_FACTS ? OTA_FACTS.scenes : []).forEach((m) => { meta[m.id] = m; });
    scenes.forEach((sc, i) => {
      const m = meta[sc.id] || { title: sc.id, sub: '', color: '#35e0d0', idx: i + 1 };
      sc.title = m.title;
      sc.sub = m.sub;
      sc.color = m.color;
      sc.no = m.idx;
    });

    const markers = steps.filter((s) => s.marker).map((s) => ({
      t: s.t0, t0: s.t0, t1: s.t1, label: s.marker, stepId: s.id, scene: s.scene
    }));

    return {
      id: def.id, title: def.title, short: def.short, mode: def.mode,
      tone: def.tone, desc: def.desc,
      steps: steps,
      scenes: scenes,
      markers: markers,
      total: t,
      suggest: def.mode === 'suggest'
    };
  }

  function get(id) {
    if (cache[id]) return cache[id];
    const def = definitions.find((d) => d.id === id);
    if (!def) return null;
    cache[id] = compile(def);
    return cache[id];
  }

  function list() {
    return definitions.map((d) => ({
      id: d.id, title: d.title, short: d.short, mode: d.mode, tone: d.tone, desc: d.desc
    }));
  }

  return { get, list, definitions };
})();
