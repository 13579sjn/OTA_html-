/* =============================================================================
 * stage.js —— 主画面（SVG）
 *
 * 结构：MCU 芯片外观 + 内部模块（Cortex-M4 / NVIC / SRAM / 内部 Flash / 外设）
 *       + 左侧 PC 串口节点 + 右侧 OneNET 云、ESP-01S、W25Q64
 *       + 底部片内 Flash 分区图与参数区 32 槽
 * 全部更新由 render(S) 单向驱动，不保存任何动画中间量（避免拖动时间轴后状态错位）。
 * ========================================================================== */
'use strict';

window.OTA_STAGE = (function () {

  const NS = 'http://www.w3.org/2000/svg';

  /* ---------- 几何：连线折线与粒子路径 ---------- */
  const PATHS = {
    uart1: [[120, 182], [104, 182]],
    uart3: [[700, 300], [730, 300], [730, 179], [760, 179]],
    spi2: [[700, 344], [730, 344], [730, 452], [760, 452]],
    wifi: [[927, 80], [927, 100]],
    flashInt: [[578, 176], [578, 200]],
    dieToStrip: [[410, 470], [410, 612]]
  };

  const FLOW_DEF = {
    'uart1-tx': { path: 'uart1', color: '#7ad7ff', n: 4, speed: 0.55, dir: 1 },
    'uart3-tx': { path: 'uart3', color: '#ffb454', n: 5, speed: 0.42, dir: -1 },
    'uart3-rx': { path: 'uart3', color: '#35e0d0', n: 9, speed: 0.5, dir: 1 },
    'spi-w': { path: 'spi2', color: '#c792ea', n: 6, speed: 0.6, dir: 1 },
    'spi-r': { path: 'spi2', color: '#8ab4f8', n: 6, speed: 0.6, dir: -1 },
    'wifi-dn': { path: 'wifi', color: '#35e0d0', n: 4, speed: 0.9, dir: 1 },
    'flash-int': { path: 'flashInt', color: '#57e389', n: 4, speed: 0.7, dir: 1 }
  };

  let refs = {};
  let root = null;

  /* ---------- 小工具 ---------- */
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const hex = (v, w) => '0x' + (v >>> 0).toString(16).toUpperCase().padStart(w || 8, '0');

  function el(tag, attrs, inner) {
    let s = '<' + tag;
    if (attrs) {
      for (const k in attrs) {
        if (attrs[k] !== null && attrs[k] !== undefined) s += ' ' + k + '="' + attrs[k] + '"';
      }
    }
    return inner === undefined ? s + '/>' : s + '>' + inner + '</' + tag + '>';
  }

  function polylineD(pts) {
    return pts.map((p, i) => (i ? 'L' : 'M') + p[0] + ' ' + p[1]).join(' ');
  }

  /* ================================================================
   * 构建 SVG
   * ================================================================ */
  function build(container) {
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 1120 760');
    svg.setAttribute('class', 'stage-svg');
    svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');

    const defs =
      '<defs>' +
      '<linearGradient id="gDie" x1="0" y1="0" x2="0" y2="1">' +
      '<stop offset="0" stop-color="#111c22"/><stop offset="1" stop-color="#0a1216"/></linearGradient>' +
      '<linearGradient id="gBlock" x1="0" y1="0" x2="0" y2="1">' +
      '<stop offset="0" stop-color="#16242c"/><stop offset="1" stop-color="#101a20"/></linearGradient>' +
      '<linearGradient id="gExt" x1="0" y1="0" x2="0" y2="1">' +
      '<stop offset="0" stop-color="#121c22"/><stop offset="1" stop-color="#0b1418"/></linearGradient>' +
      '<radialGradient id="gGlow"><stop offset="0" stop-color="#35e0d0" stop-opacity=".55"/>' +
      '<stop offset="1" stop-color="#35e0d0" stop-opacity="0"/></radialGradient>' +
      '<pattern id="pGrid" width="24" height="24" patternUnits="userSpaceOnUse">' +
      '<path d="M24 0H0V24" fill="none" stroke="#1a2b33" stroke-width="0.6"/></pattern>' +
      '<pattern id="pHatch" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">' +
      '<path d="M0 0V8" stroke="#ff5d5d" stroke-width="1.6" stroke-opacity=".5"/></pattern>' +
      '</defs>';

    /* ---------- MCU 芯片 ---------- */
    const die =
      '<g id="layer-die">' +
      /* 焊盘/引脚装饰 */
      sidePins(120, 14, 580, 456) +
      el('rect', { x: 120, y: 14, width: 580, height: 456, rx: 12, fill: 'url(#gDie)', stroke: '#24373f', 'stroke-width': 1.4 }) +
      el('rect', { x: 120, y: 14, width: 580, height: 46, rx: 12, fill: '#0f1a20', stroke: '#24373f' }) +
      el('rect', { x: 120, y: 46, width: 580, height: 14, fill: '#0f1a20' }) +
      '<text x="136" y="35" class="s-die-title">STM32F429IGT6</text>' +
      '<text x="136" y="50" class="s-die-sub">Cortex-M4F · 1MB Flash · 192KB SRAM · 64KB CCM</text>' +
      '<text id="dieImage" x="684" y="35" class="s-die-img" text-anchor="end">BL</text>' +

      /* 内核 */
      block('core', 142, 72, 154, 104, 'ARM Cortex-M4F', '180 MHz') +
      '<text x="219" y="152" class="s-block-note" text-anchor="middle">取指 / 执行</text>' +
      /* NVIC */
      block('nvic', 142, 186, 154, 42, 'NVIC', '82 IRQ') +
      /* SRAM */
      block('sram', 312, 72, 150, 104, 'SRAM 192KB', '0x2000_0000') +
      '<text x="387" y="152" class="s-block-note" text-anchor="middle">接收缓冲 / 状态</text>' +
      /* 内部 Flash */
      block('int-flash', 478, 72, 200, 104, '内部 Flash 1MB', '0x0800_0000') +
      '<text x="578" y="152" class="s-block-note" text-anchor="middle">BL 48K · PARAM 16K · APP 960K</text>' +

      /* 外设行 */
      block('usart1', 142, 252, 88, 76, 'USART1', '115200') +
      block('usart3', 238, 252, 88, 76, 'USART3', '115200') +
      block('spi2', 334, 252, 88, 76, 'SPI2', 'W25Q64') +
      block('dma', 430, 252, 88, 76, 'DMA1/2', '16 流') +
      block('rtos', 526, 252, 62, 76, 'RTOS', 'CMSIS') +
      block('iwdg', 596, 252, 82, 76, 'IWDG', '关闭') +

      /* CPU 上下文条 */
      el('rect', { x: 142, y: 344, width: 536, height: 112, rx: 8, fill: '#0c151a', stroke: '#1e323a' }) +
      '<text x="154" y="364" class="s-ctx-label">当前执行</text>' +
      '<text id="ctxFunc" x="212" y="364" class="s-ctx-func">—</text>' +
      '<text id="ctxImage2" x="666" y="364" class="s-ctx-img" text-anchor="end">—</text>' +
      '<text x="154" y="386" class="s-ctx-k">PC</text><text id="ctxAddr" x="186" y="386" class="s-ctx-v">—</text>' +
      '<text x="300" y="386" class="s-ctx-k">MSP</text><text id="ctxMsp" x="338" y="386" class="s-ctx-v">—</text>' +
      '<text x="470" y="386" class="s-ctx-k">VTOR</text><text id="ctxVtor" x="514" y="386" class="s-ctx-v">—</text>' +
      '<text x="154" y="408" class="s-ctx-k">SYSCLK</text><text id="ctxClk" x="212" y="408" class="s-ctx-v">—</text>' +
      '<text x="154" y="430" class="s-ctx-k">调用链</text>' +
      '<text id="ctxCall" x="212" y="430" class="s-ctx-call">—</text>' +
      '<text x="154" y="450" class="s-ctx-k">计数</text>' +
      '<text id="ctxCounters" x="212" y="450" class="s-ctx-call">UART3 0 B · SPI 0 B · FLASH 0 B</text>' +
      '</g>';

    /* ---------- 左侧 PC 串口 ---------- */
    const pc =
      '<g id="layer-pc">' +
      el('rect', { x: 6, y: 120, width: 98, height: 124, rx: 8, fill: '#0c151a', stroke: '#1e323a' }) +
      '<text x="55" y="142" class="s-node-title" text-anchor="middle">上位机</text>' +
      '<text x="55" y="160" class="s-node-sub" text-anchor="middle">串口助手</text>' +
      '<text x="55" y="182" class="s-node-sub" text-anchor="middle">USART1</text>' +
      '<text x="55" y="198" class="s-node-sub" text-anchor="middle">115200</text>' +
      '<circle id="pcLed" cx="55" cy="220" r="5" class="s-led"/>' +
      '<text x="55" y="238" class="s-node-sub" text-anchor="middle">日志</text>' +
      '</g>' +
      el('path', { d: polylineD(PATHS.uart1), class: 's-link', 'data-link': 'uart1' });

    /* ---------- OneNET 云 ---------- */
    const cloud =
      '<g id="layer-cloud">' +
      el('rect', { x: 760, y: 14, width: 334, height: 66, rx: 10, fill: '#0d1a20', stroke: '#1f3a42' }) +
      '<text x="776" y="38" class="s-node-title">OneNET 物联网平台</text>' +
      '<text x="776" y="56" class="s-node-sub">iot-api.heclouds.com : 80 (HTTP)</text>' +
      '<text x="776" y="72" class="s-node-sub">产品 FRfr9m3Ppg · 设备 OTA_Test_drive</text>' +
      '<circle id="cloudLed" cx="1074" cy="34" r="5" class="s-led"/>' +
      '</g>';

    /* ---------- ESP-01S ---------- */
    const esp =
      '<g id="layer-esp">' +
      el('rect', { x: 760, y: 100, width: 334, height: 158, rx: 10, fill: url_grad_ext(), stroke: '#24373f' }) +
      '<text x="776" y="124" class="s-node-title">ESP-01S  WiFi 模组</text>' +
      '<text id="espMode" x="776" y="146" class="s-node-sub">模式 —</text>' +
      '<text id="espLink" x="776" y="164" class="s-node-sub">链路 —</text>' +
      '<text x="776" y="190" class="s-node-sub">USART3 · PB10(TX) / PB11(RX)</text>' +
      '<text x="776" y="208" class="s-node-sub">CIPMUX=0 单连接 · CIPMODE=0 非透传</text>' +
      '<rect x="776" y="220" width="302" height="24" rx="5" fill="#0a1418" stroke="#1e323a"/>' +
      '<text id="espBuf" x="786" y="236" class="s-node-sub">s_ring 4096B · s_data 8192B</text>' +
      '<circle id="espLed" cx="1074" cy="120" r="5" class="s-led"/>' +
      '</g>';

    /* ---------- W25Q64 ---------- */
    const regions = (window.OTA_FACTS ? OTA_FACTS.extFlash.regions : []);
    let w25rows = '';
    regions.forEach((r, i) => {
      const y = 330 + i * 60;
      w25rows +=
        '<g class="w25row" data-region="' + r.id + '">' +
        el('rect', { x: 776, y: y, width: 302, height: 50, rx: 6, fill: '#0b1418', stroke: '#1a2b33' }) +
        el('rect', { x: 776, y: y, width: 4, height: 50, fill: r.color, opacity: '.85' }) +
        '<text x="790" y="' + (y + 18) + '" class="s-region-title">' + esc(r.name) + '</text>' +
        '<text x="790" y="' + (y + 34) + '" class="s-region-addr">' + hex(r.addr, 6) + ' · ' + (r.size / 1024) + ' KB</text>' +
        el('rect', { x: 790, y: y + 38, width: 274, height: 6, rx: 3, fill: '#132028' }) +
        '<rect id="ext-' + r.id + '" x="790" y="' + (y + 38) + '" width="0" height="6" rx="3" fill="' + r.color + '"/>' +
        '<text id="extTxt-' + r.id + '" x="1066" y="' + (y + 18) + '" class="s-region-state" text-anchor="end">idle</text>' +
        '</g>';
    });

    const w25 =
      '<g id="layer-w25">' +
      el('rect', { x: 760, y: 285, width: 334, height: 315, rx: 10, fill: '#0c151a', stroke: '#24373f' }) +
      '<text x="776" y="308" class="s-node-title">W25Q64  片外 SPI Flash</text>' +
      '<text x="1078" y="308" class="s-node-sub" text-anchor="end">8 MB · JEDEC 0xEF4017</text>' +
      w25rows +
      '</g>';

    /* ---------- 连线 ---------- */
    const links =
      '<g id="layer-links">' +
      el('path', { d: polylineD(PATHS.uart3), class: 's-link', 'data-link': 'uart3' }) +
      el('path', { d: polylineD(PATHS.spi2), class: 's-link', 'data-link': 'spi2' }) +
      el('path', { d: polylineD(PATHS.wifi), class: 's-link', 'data-link': 'wifi' }) +
      '<text x="742" y="172" class="s-link-label" text-anchor="end">USART3</text>' +
      '<text x="742" y="446" class="s-link-label" text-anchor="end">SPI2</text>' +
      '<text x="936" y="96" class="s-link-label">WiFi</text>' +
      '</g>';

    /* ---------- 片内 Flash 分区图 ---------- */
    const partition = buildPartitionStrip();

    /* ---------- 参数区 32 槽 ---------- */
    const slots = buildParamStrip();

    /* ---------- 数据帧浮层 ---------- */
    const frameBox =
      '<g id="layer-frame" class="s-frame" opacity="0" transform="translate(52,482)">' +
      '<rect id="frameBg" x="0" y="0" width="330" height="120" rx="8" fill="#07100f" stroke="#2c4b4b"/>' +
      '<text id="frameTitle" x="12" y="20" class="s-frame-title">—</text>' +
      '<g id="frameLines"></g>' +
      '</g>';

    /* ---------- 粒子层 ---------- */
    const fx = '<g id="layer-fx"></g>';

    svg.innerHTML = defs + links + pc + die + cloud + esp + w25 + partition + slots + frameBox + fx;
    container.appendChild(svg);
    root = svg;
    cacheRefs();
    return svg;
  }

  function url_grad_ext() { return 'url(#gExt)'; }

  function sidePins(x, y, w, h) {
    let s = '';
    for (let i = 0; i < 14; i++) {
      const py = y + 24 + i * 30;
      if (py > y + h - 10) break;
      s += '<rect x="' + (x - 8) + '" y="' + py + '" width="8" height="10" fill="#1b2c34"/>';
      s += '<rect x="' + (x + w) + '" y="' + py + '" width="8" height="10" fill="#1b2c34"/>';
    }
    return s;
  }

  function block(mod, x, y, w, h, title, sub) {
    return '<g class="s-block" data-mod="' + mod + '">' +
      '<rect class="s-block-bg" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="7" fill="url(#gBlock)" stroke="#22363e"/>' +
      '<rect class="s-block-glow" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="7" fill="none" stroke="#35e0d0" stroke-width="1.6" opacity="0"/>' +
      '<text x="' + (x + w / 2) + '" y="' + (y + (h > 60 ? 34 : 18)) + '" class="s-block-title" text-anchor="middle">' + esc(title) + '</text>' +
      '<text x="' + (x + w / 2) + '" y="' + (y + (h > 60 ? 50 : 34)) + '" class="s-block-sub" text-anchor="middle">' + esc(sub) + '</text>' +
      '</g>';
  }

  /* ---------- 片内 Flash 分区图 ---------- */
  function buildPartitionStrip() {
    const X = 40, Y = 626, W = 1054;
    /* 宽度按扇区数分配（非等比地址轴，图中已注明） */
    const wBL = 210, wPARAM = 150;
    const appX = X + wBL + wPARAM;
    const appW = W - wBL - wPARAM;

    let s = '<g id="layer-part">';
    s += '<text x="' + X + '" y="' + (Y - 6) + '" class="s-sec-title">片内 Flash 1MB 分区（宽度按扇区数量分配，非等比地址轴） · 上电取指起点恒为 0x0800_0000（BootLoader）</text>';

    /* BL */
    s += partBox('bl', X, Y, wBL, 64, 'BootLoader', '0x08000000 · 48KB · S0–S2', '#7ad7ff');
    /* PARAM */
    s += partBox('param', X + wBL, Y, wPARAM, 64, '参数区', '0x0800C000 · 16KB · S3', '#c792ea');
    /* APP */
    s += partBox('app', appX, Y, appW, 64, 'App A 槽（唯一可执行槽）', '0x08010000 · 960KB · S4–S11', '#57e389');

    /* APP 内部扇区刻度 */
    const s4w = appW * (64 / 960);
    s += '<line x1="' + (appX + s4w) + '" y1="' + (Y + 24) + '" x2="' + (appX + s4w) + '" y2="' + (Y + 64) + '" class="s-tick"/>';
    s += '<text x="' + (appX + s4w / 2) + '" y="' + (Y + 58) + '" class="s-tick-label" text-anchor="middle">S4</text>';
    for (let i = 0; i < 7; i++) {
      const x = appX + s4w + (appW - s4w) * (i / 7);
      if (i) s += '<line x1="' + x + '" y1="' + (Y + 40) + '" x2="' + x + '" y2="' + (Y + 64) + '" class="s-tick"/>';
      s += '<text x="' + (x + (appW - s4w) / 14) + '" y="' + (Y + 58) + '" class="s-tick-label" text-anchor="middle">S' + (5 + i) + '</text>';
    }

    /* 内容填充条 */
    s += '<rect id="partAppFill" x="' + (appX + 2) + '" y="' + (Y + 8) + '" width="0" height="12" rx="2" fill="#57e389" opacity=".5"/>';
    s += '<rect id="partAppErase" x="' + (appX + 2) + '" y="' + (Y + 8) + '" width="0" height="12" rx="2" fill="url(#pHatch)" opacity="0"/>';

    /* 地址轴标注（并入标题行，避免与下方参数槽重叠） */
    s += '</g>';
    return s;
  }

  function partBox(id, x, y, w, h, title, sub, color) {
    return '<g class="s-part" data-part="' + id + '">' +
      '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="6" fill="#0d171d" stroke="#22363e"/>' +
      '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="4" rx="2" fill="' + color + '"/>' +
      '<text x="' + (x + 8) + '" y="' + (y + 20) + '" class="s-part-title">' + esc(title) + '</text>' +
      '<text x="' + (x + 8) + '" y="' + (y + 36) + '" class="s-part-sub">' + esc(sub) + '</text>' +
      '<rect class="s-part-hl" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="6" fill="none" stroke="' + color + '" stroke-width="1.6" opacity="0"/>' +
      '</g>';
  }

  /* ---------- 参数区 32 槽 ---------- */
  function buildParamStrip() {
    const X = 55, Y = 708, W = 32, H = 34;
    let s = '<g id="layer-slots">';
    s += '<text x="40" y="' + (Y - 6) + '" class="s-sec-title">参数区 32 × 512B 槽位（每次保存只写下一个空槽，seq 递增）</text>';
    for (let i = 0; i < 32; i++) {
      const x = X + i * W;
      s += '<g class="s-slot" data-slot="' + i + '">' +
        '<rect id="slot' + i + '" x="' + x + '" y="' + Y + '" width="' + (W - 4) + '" height="' + H + '" rx="3" fill="#111c22" stroke="#1d2f37"/>' +
        '</g>';
      if (i % 4 === 0) {
        s += '<text x="' + (x + (W - 4) / 2) + '" y="' + (Y + H + 12) + '" class="s-slot-no" text-anchor="middle">' + i + '</text>';
      }
    }
    s += '<text x="1094" y="' + (Y + H + 12) + '" class="s-axis" text-anchor="end">seq 最大且 CRC32 正确的槽被采用</text>';
    s += '</g>';
    return s;
  }

  /* ================================================================
   * 引用缓存
   * ================================================================ */
  function cacheRefs() {
    const q = (id) => root.querySelector('#' + id);
    refs = {
      dieImage: q('dieImage'),
      ctxFunc: q('ctxFunc'), ctxAddr: q('ctxAddr'), ctxMsp: q('ctxMsp'),
      ctxVtor: q('ctxVtor'), ctxClk: q('ctxClk'), ctxCall: q('ctxCall'),
      ctxCounters: q('ctxCounters'), ctxImage2: q('ctxImage2'),
      espMode: q('espMode'), espLink: q('espLink'), espBuf: q('espBuf'),
      espLed: q('espLed'), cloudLed: q('cloudLed'), pcLed: q('pcLed'),
      partAppFill: q('partAppFill'), partAppErase: q('partAppErase'),
      frameBox: q('layer-frame'), frameTitle: q('frameTitle'), frameLines: q('frameLines'), frameBg: q('frameBg'),
      blocks: {}, links: {}, ext: {}, extTxt: {}, slots: []
    };
    root.querySelectorAll('.s-block').forEach((b) => { refs.blocks[b.getAttribute('data-mod')] = b; });
    root.querySelectorAll('.s-link').forEach((l) => { refs.links[l.getAttribute('data-link')] = l; });
    root.querySelectorAll('.s-part').forEach((p) => { refs['part-' + p.getAttribute('data-part')] = p; });
    (OTA_FACTS.extFlash.regions || []).forEach((r) => {
      refs.ext[r.id] = q('ext-' + r.id);
      refs.extTxt[r.id] = q('extTxt-' + r.id);
    });
    for (let i = 0; i < 32; i++) refs.slots.push(q('slot' + i));
    /* fx 层 */
    if (window.OTA_FX) OTA_FX.init(q('layer-fx'), PATHS, FLOW_DEF);
  }

  /* ================================================================
   * 渲染
   * ================================================================ */
  function setText(node, v) {
    if (node && node.textContent !== v) node.textContent = v;
  }

  function render(S) {
    if (!root) return;

    /* --- 模块高亮 --- */
    const mods = (S.step && S.step.mods) || [];
    for (const k in refs.blocks) {
      const on = mods.indexOf(k) >= 0;
      const g = refs.blocks[k];
      if (g.classList.contains('on') !== on) g.classList.toggle('on', on);
    }
    /* 外设状态文本 */
    if (refs.blocks.iwdg) {
      const t = refs.blocks.iwdg.querySelector('.s-block-sub');
      setText(t, S.intf.iwdg === 'off' ? '关闭' : '运行');
    }
    if (refs.blocks.dma) {
      const t = refs.blocks.dma.querySelector('.s-block-sub');
      setText(t, S.intf.dma === 'circular' ? 'CIRCULAR' : (S.intf.dma === 'off' ? 'off' : 'NORMAL'));
    }
    if (refs.blocks.usart3) {
      const t = refs.blocks.usart3.querySelector('.s-block-sub');
      const m = {
        abort: 'abort', 'idle-rx': 'IDLE-DMA', 'circ-dma': 'CYCLIC-DMA',
        off: 'off', ok: '115200'
      };
      setText(t, m[S.intf.usart3] || '115200');
    }

    /* --- 连线活跃 --- */
    const flows = (S.step && S.step.flows) || [];
    const linkOn = { uart1: false, uart3: false, spi2: false, wifi: false };
    flows.forEach((f) => {
      if (f.indexOf('uart1') === 0) linkOn.uart1 = true;
      if (f.indexOf('uart3') === 0) linkOn.uart3 = true;
      if (f.indexOf('spi') === 0) linkOn.spi2 = true;
      if (f.indexOf('wifi') === 0) linkOn.wifi = true;
    });
    for (const k in linkOn) {
      const l = refs.links[k];
      if (l && l.classList.contains('on') !== linkOn[k]) l.classList.toggle('on', linkOn[k]);
    }
    if (refs.espLed) refs.espLed.classList.toggle('on', S.esp.mode !== 'off' && linkOn.wifi);
    if (refs.cloudLed) refs.cloudLed.classList.toggle('on', S.intf.cloud === 'mqtt' || linkOn.wifi);
    if (refs.pcLed) refs.pcLed.classList.toggle('on', linkOn.uart1);

    /* --- 上下文 --- */
    const img = S.ctx.image === 'BL' ? 'BootLoader' : (S.ctx.image === 'APP1' ? 'App 1.0.0' : 'App 1.0.1');
    setText(refs.dieImage, S.ctx.image === 'BL' ? 'BL' : S.ctx.image);
    setText(refs.ctxImage2, img);
    setText(refs.ctxFunc, S.ctx.func || '—');
    setText(refs.ctxAddr, S.ctx.addr || '—');
    setText(refs.ctxMsp, S.ctx.msp || '—');
    setText(refs.ctxVtor, S.ctx.vtor || '—');
    setText(refs.ctxClk, S.ctx.clk || '—');
    const call = (S.step && S.step.call) ? S.step.call.join(' → ') : '—';
    setText(refs.ctxCall, call);
    setText(refs.ctxCounters,
      'UART3 ' + fmtB(S.counters.uart3) + ' · SPI ' + fmtB(S.counters.spi) + ' · FLASH ' + fmtB(S.counters.fl));

    /* --- ESP --- */
    const espModeTxt = {
      off: '模式 —', mqtt: '模式 AT+MQTT（常连）', 'raw-tcp': '模式 裸 TCP（CIPSTART/CIPSEND）'
    }[S.esp.mode] || '模式 —';
    setText(refs.espMode, espModeTxt);
    setText(refs.espLink, '链路 ' + (S.esp.link || '—'));
    setText(refs.espBuf, S.ipd
      ? '+IPD,' + S.ipd.len + ':  → s_data ' + Math.min(8192, S.ipd.len) + 'B'
      : 's_ring 4096B · s_data 8192B');

    /* --- 片外三区 --- */
    (OTA_FACTS.extFlash.regions || []).forEach((r) => {
      if (r.id === 'resource') return;
      const st = S.ext[r.id] || { mode: 'idle', frac: 0 };
      const bar = refs.ext[r.id];
      const txt = refs.extTxt[r.id];
      if (!bar) return;
      bar.setAttribute('width', String(Math.max(0, Math.min(1, st.frac)) * 274));
      const col = {
        idle: r.color, erase: '#ffb454', ready: r.color, write: r.color,
        valid: '#57e389', corrupt: '#ff5d5d', error: '#ff5d5d'
      }[st.mode] || r.color;
      bar.setAttribute('fill', col);
      const label = {
        idle: 'idle', erase: 'erasing…', ready: 'ready', write: 'writing…',
        valid: 'VALID', corrupt: 'SHA FAIL', error: 'FAIL'
      }[st.mode] || st.mode;
      setText(txt, label);
      txt.setAttribute('class', 's-region-state' + (st.mode === 'valid' ? ' ok' : (st.mode === 'corrupt' || st.mode === 'error' ? ' err' : (st.mode === 'erase' ? ' warn' : ''))));
    });

    /* --- 片内 A 槽 --- */
    const appW = 1054 - 210 - 150;
    const appX = 40 + 210 + 150;
    const fill = S.intf.app.fill == null ? 1 : S.intf.app.fill;
    const realFrac = (S.intf.app.ver && S.intf.app.ver.indexOf('1.0.1') >= 0 ? 94824 : 94820) / (960 * 1024);
    const shownW = Math.max(6, fill * realFrac * appW);
    if (refs.partAppFill) {
      refs.partAppFill.setAttribute('width', String(shownW));
      refs.partAppFill.setAttribute('fill', S.intf.app.state === 'writing' ? '#ffb454' : '#57e389');
    }
    if (refs.partAppErase) {
      const erasing = S.intf.app.state === 'erasing';
      refs.partAppErase.setAttribute('opacity', erasing ? '1' : '0');
      refs.partAppErase.setAttribute('width', String(erasing ? appW : 0));
    }
    ['bl', 'param', 'app'].forEach((k) => {
      const g = refs['part-' + k];
      if (!g) return;
      const hl = g.querySelector('.s-part-hl');
      const stepMods = (S.step && S.step.mods) || [];
      const active =
        (k === 'bl' && (stepMods.indexOf('int-flash') >= 0 || S.ctx.cpu === 'bl')) ||
        (k === 'param' && (stepMods.indexOf('param') >= 0)) ||
        (k === 'app' && (stepMods.indexOf('int-flash') >= 0 && S.ctx.cpu === 'bl'));
      if (hl) hl.setAttribute('opacity', active ? '1' : '0');
    });

    /* --- 参数槽 --- */
    const seq = S.intf.param.seq;
    refs.slots.forEach((r, i) => {
      if (!r) return;
      const used = i <= seq;
      const cur = i === seq;
      r.setAttribute('fill', cur ? '#c792ea' : (used ? 'rgba(199,146,234,.28)' : '#111c22'));
      r.setAttribute('stroke', cur ? '#e0c4f5' : '#1d2f37');
    });

    /* --- 数据帧浮层 --- */
    renderFrame(S);

    /* --- 粒子 --- */
    if (window.OTA_FX) OTA_FX.render(flows, S.t, S);
  }

  function renderFrame(S) {
    const box = refs.frameBox;
    if (!box) return;
    const f = S.frame;
    if (!f) {
      box.setAttribute('opacity', '0');
      return;
    }
    box.setAttribute('opacity', '1');
    setText(refs.frameTitle, f.title || '');
    const lines = f.lines || [];
    const setLines = (S._frameLines || []).join('\u0001') !== lines.join('\u0001');
    if (setLines) {
      S._frameLines = lines.slice();
      let html = '';
      lines.forEach((l, i) => {
        html += '<text x="12" y="' + (40 + i * 17) + '" class="s-frame-line">' + esc(l) + '</text>';
      });
      refs.frameLines.innerHTML = html;
    }
    const h = 34 + lines.length * 17;
    refs.frameBg.setAttribute('height', String(h));
  }

  function fmtB(n) {
    if (n >= 1024) return (n / 1024).toFixed(1) + 'K';
    return String(n);
  }

  /* ---------- 点击检查 ---------- */
  function bindInspect(handler) {
    if (!root) return;
    root.addEventListener('click', (ev) => {
      const t = ev.target.closest('[data-mod],[data-part],[data-region],[data-slot]');
      if (!t) return;
      handler({
        mod: t.getAttribute('data-mod'),
        part: t.getAttribute('data-part'),
        region: t.getAttribute('data-region'),
        slot: t.getAttribute('data-slot')
      });
    });
  }

  return { build, render, bindInspect, PATHS };
})();
