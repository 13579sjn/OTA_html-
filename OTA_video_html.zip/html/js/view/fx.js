/* =============================================================================
 * fx.js —— 数据流动粒子层
 *
 * 粒子的位置是时间的纯函数（phase = t·speed + i/n mod 1），不保存速度/位移状态。
 * 所以拖动时间轴时粒子会直接出现在"该时刻应在的位置"，不会出现残留拖尾或重复。
 * ========================================================================== */
'use strict';

window.OTA_FX = (function () {

  const NS = 'http://www.w3.org/2000/svg';
  let layer = null;
  let paths = {};
  let defs = {};
  let pools = {};      /* flowId -> [circle...] */
  let lens = {};       /* pathId -> {seg:[], total, pts:[]} */

  function measure(pts) {
    const seg = [];
    let total = 0;
    for (let i = 1; i < pts.length; i++) {
      const dx = pts[i][0] - pts[i - 1][0];
      const dy = pts[i][1] - pts[i - 1][1];
      const d = Math.sqrt(dx * dx + dy * dy);
      seg.push(d);
      total += d;
    }
    return { pts: pts, seg: seg, total: total };
  }

  function init(layerNode, pathDefs, flowDefs) {
    layer = layerNode;
    paths = pathDefs;
    defs = flowDefs;
    pools = {};
    lens = {};
    for (const k in paths) lens[k] = measure(paths[k]);
  }

  function poolFor(id) {
    if (pools[id]) return pools[id];
    const d = defs[id];
    if (!d || !lens[d.path] || !layer) return null;
    const arr = [];
    for (let i = 0; i < d.n; i++) {
      const c = document.createElementNS(NS, 'circle');
      c.setAttribute('r', '2.6');
      c.setAttribute('fill', d.color);
      c.setAttribute('filter', 'none');
      c.setAttribute('opacity', '0');
      layer.appendChild(c);
      arr.push(c);
    }
    pools[id] = arr;
    return arr;
  }

  function pointAt(pathId, u) {
    const L = lens[pathId];
    let dist = Math.max(0, Math.min(1, u)) * L.total;
    for (let i = 0; i < L.seg.length; i++) {
      if (dist <= L.seg[i] || i === L.seg.length - 1) {
        const f = L.seg[i] > 0 ? dist / L.seg[i] : 0;
        const a = L.pts[i], b = L.pts[i + 1];
        return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f];
      }
      dist -= L.seg[i];
    }
    return L.pts[L.pts.length - 1];
  }

  function render(activeFlows, t, S) {
    if (!layer) return;
    const active = {};
    (activeFlows || []).forEach((f) => { active[f] = true; });

    for (const id in defs) {
      const d = defs[id];
      const pool = poolFor(id);
      if (!pool) continue;
      const on = !!active[id];
      /* 没有活跃的流：把该池全部隐藏（一次遍历即可） */
      if (!on) {
        for (let i = 0; i < pool.length; i++) {
          if (pool[i].getAttribute('opacity') !== '0') pool[i].setAttribute('opacity', '0');
        }
        continue;
      }
      const n = pool.length;
      const base = (t * d.speed) / 1000;
      for (let i = 0; i < n; i++) {
        let u = (base + i / n) % 1;
        if (u < 0) u += 1;
        if (d.dir < 0) u = 1 - u;
        const p = pointAt(d.path, u);
        const c = pool[i];
        c.setAttribute('cx', p[0].toFixed(1));
        c.setAttribute('cy', p[1].toFixed(1));
        /* 头亮尾暗：让流向看得出来 */
        const fade = 0.25 + 0.75 * Math.sin(Math.PI * u);
        c.setAttribute('opacity', fade.toFixed(2));
        c.setAttribute('r', (2.2 + 1.1 * Math.sin(Math.PI * u)).toFixed(2));
      }
    }
  }

  return { init, render };
})();
