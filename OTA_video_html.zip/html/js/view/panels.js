/* =============================================================================
 * panels.js —— 右侧四个联动面板：代码 / 变量 / 日志 / Flash 分区 / 函数索引
 *
 * 全部由同一个 S（状态快照）驱动。任一时刻面板之间不允许出现互相矛盾的内容：
 * 它们读的是同一份 S，而不是各自维护的副本。
 * ========================================================================== */
'use strict';

window.OTA_PANELS = (function () {

  const S_ = () => window.OTA_STATE;
  let dom = {};
  let lastCodeKey = '';
  let lastLogLen = -1;
  let lastVars = {};
  let lastTab = 'code';
  let currentS = null;
  let ctx = { scenario: null, onJumpStep: null, onInspect: null };

  const esc = (s) => String(s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  function init(containers, options) {
    dom = containers;
    ctx = Object.assign(ctx, options || {});
    buildVarRows();
    buildFlashTable();
    buildIndexTable();
    bindTabs();
    bindCodeClick();
    renderInfo(null);
  }

  /* ---------------- 标签页 ---------------- */
  function bindTabs() {
    const tabs = dom.tabs.querySelectorAll('[data-tab]');
    tabs.forEach((b) => {
      b.addEventListener('click', () => switchTab(b.getAttribute('data-tab')));
    });
  }

  function switchTab(name) {
    lastTab = name;
    dom.tabs.querySelectorAll('[data-tab]').forEach((b) => {
      b.classList.toggle('active', b.getAttribute('data-tab') === name);
    });
    dom.bodies.forEach((b) => {
      b.classList.toggle('active', b.getAttribute('data-body') === name);
    });
    if (currentS) render(currentS, true);
  }

  /* ================================================================
   * 代码面板
   * ================================================================ */
  function renderCode(S) {
    const meta = dom.codeMeta;
    const snip = S.step && S.step.code ? (window.OTA_CODE.snippets[S.step.code] || null) : null;

    /* 头信息 */
    const proj = snip ? snip.project : '—';
    const projShort = proj === 'HAL_F429IGT6_bootloard' ? 'BootLoader'
      : (proj === 'HAL_F429IGT6_App' ? 'App 1.0.0' : (proj === 'HAL_F429IGT6_App_2' ? 'App 1.0.1' : proj));
    /* 只有真正的 C 函数才补 ()；汇编标签、#define 宏、结构体名不补 */
    const isCFunc = snip && !/\.(s|h)$/i.test(snip.file) && /^[A-Za-z_]\w*$/.test(snip.func);
    const fnText = snip ? (isCFunc ? snip.func + '()' : snip.func) : '';
    setHTML(meta, snip
      ? '<span class="badge-proj">' + esc(projShort) + '</span>' +
        '<span class="badge-file">' + esc(snip.file) + '</span>' +
        '<span class="badge-func">' + esc(fnText) + '</span>' +
        '<span class="badge-lines">L' + snip.from + '–' + snip.to + '</span>' +
        gradeBadge(S.step.g)
      : '<span class="muted">本步骤没有绑定源码片段</span>');

    if (!snip) {
      setHTML(dom.codeBody, '<div class="empty">—</div>');
      setHTML(dom.codeNote, '');
      lastCodeKey = '';
      return;
    }

    const key = snip.id + '|' + (S.step.hl || []).join('-');
    if (key !== lastCodeKey) {
      lastCodeKey = key;
      const hl = S.step.hl || [];
      const h0 = hl.length ? Math.min(hl[0], hl[1] === undefined ? hl[0] : hl[1]) : -1;
      const h1 = hl.length ? Math.max(hl[0], hl[1] === undefined ? hl[0] : hl[1]) : -1;

      let html = '';
      let prevNo = 0;
      snip.lines.forEach(([no, text]) => {
        if (prevNo && no > prevNo + 1) {
          html += '<div class="cl gap"><span class="ln">⋯</span><span class="tx">⋯</span></div>';
        }
        prevNo = no;
        const on = no >= h0 && no <= h1 ? ' hl' : '';
        html += '<div class="cl' + on + '" data-line="' + no + '" data-snip="' + snip.id + '">' +
          '<span class="ln">' + no + '</span>' +
          '<span class="tx">' + (esc(text) || '&nbsp;') + '</span></div>';
      });
      setHTML(dom.codeBody, html);

      /* 滚到高亮行 */
      const first = dom.codeBody.querySelector('.cl.hl');
      if (first) {
        const top = first.offsetTop - dom.codeBody.clientHeight / 2 + 40;
        dom.codeBody.scrollTop = Math.max(0, top);
      }
    }

    /* 步骤说明 */
    setHTML(dom.codeNote,
      '<div class="note-head"><b>' + esc(S.step.label) + '</b>' +
      '<span class="note-g">' + gradeText(S.step.g) + '</span></div>' +
      '<p>' + esc(S.step.note || '') + '</p>' +
      (snip.note ? '<p class="note-src">片段说明：' + esc(snip.note) + '</p>' : ''));
  }

  function gradeBadge(g) {
    if (!g) return '';
    return '<span class="grade g-' + g + '" title="' + gradeText(g) + '">' + g + '</span>';
  }

  function gradeText(g) {
    return g === 'A' ? '源码已证实' : (g === 'B' ? '根据源码推导' : (g === 'C' ? '建议方案 / 模拟' : '—'));
  }

  function bindCodeClick() {
    dom.codeBody.addEventListener('click', (ev) => {
      const row = ev.target.closest('.cl[data-line]');
      if (!row || !ctx.scenario) return;
      const snipId = row.getAttribute('data-snip');
      const line = parseInt(row.getAttribute('data-line'), 10);
      /* 找到使用该片段且高亮区间包含该行的步骤；找不到就退到"第一个使用该片段的步骤"，
         这样任何一行代码点下去都有反馈，不会出现"点了没反应" */
      let st = ctx.scenario.steps.find((s) => {
        if (s.code !== snipId || !s.hl || !s.hl.length) return false;
        const a = Math.min(s.hl[0], s.hl[1] === undefined ? s.hl[0] : s.hl[1]);
        const b = Math.max(s.hl[0], s.hl[1] === undefined ? s.hl[0] : s.hl[1]);
        return line >= a && line <= b;
      });
      if (!st) st = ctx.scenario.steps.find((s) => s.code === snipId);
      if (st && ctx.onJumpStep) ctx.onJumpStep(st.id);
    });
  }

  /* ================================================================
   * 变量面板
   * ================================================================ */
  function buildVarRows() {
    const defs = OTA_FACTS.varDefs;
    let html = '';
    defs.forEach((d) => {
      html += '<div class="vr" data-vk="' + d.k + '">' +
        '<div class="vk" title="' + esc(d.src) + '">' + esc(d.label) + '</div>' +
        '<div class="vv">—</div>' +
        '<div class="vs">' + esc(d.src) + '</div>' +
        '</div>';
    });
    /* 额外上下文行 */
    const extra = [
      { k: '_branch', label: '当前分支', src: 'boot_run() 分支' },
      { k: '_mode', label: '演示模式', src: 'scenario' },
      { k: '_progress', label: '下载 / 备份进度', src: 's_st.progress' }
    ];
    extra.forEach((d) => {
      html += '<div class="vr extra" data-vk="' + d.k + '">' +
        '<div class="vk">' + esc(d.label) + '</div><div class="vv">—</div>' +
        '<div class="vs">' + esc(d.src) + '</div></div>';
    });
    dom.varBody.innerHTML = html;
  }

  function fmtVar(S, k) {
    const v = S.vars;
    const st = S_();
    switch (k) {
      case 'boot_flag': return { text: v.boot_flag + ' · ' + st.flagName(v.boot_flag), cls: 'flag-' + v.boot_flag };
      case 'boot_count': return { text: String(v.boot_count), cls: v.boot_count >= 3 ? 'err' : '' };
      case 'version': return { text: st.fmtVer(v.version), cls: '' };
      case 'image_len': return { text: v.image_len + ' B', cls: v.image_len ? 'ok' : '' };
      case 'resume_offset': return { text: v.resume_offset + ' B', cls: v.resume_offset ? 'warn' : '' };
      case 'backup_status': return { text: v.backup_status + ' · ' + st.bkName(v.backup_status), cls: 'bk-' + v.backup_status };
      case 'ota_tid': return { text: v.ota_tid ? String(v.ota_tid) : '0（无待报）', cls: v.ota_tid ? 'warn' : '' };
      case 'dl_tid': return { text: v.dl_tid ? String(v.dl_tid) : '0', cls: '' };
      case 'dl_offset': return { text: num(v.dl_offset) + ' / ' + num(v.dl_total) + ' B', cls: '' };
      case 'dl_total': return { text: v.dl_total ? num(v.dl_total) + ' B' : '—', cls: '' };
      case 'blen': return { text: v.blen + ' / 256 B', cls: '' };
      case 'md5': return { text: v.md5, cls: /✓/.test(v.md5) ? 'ok' : (/✗|不匹配/.test(v.md5) ? 'err' : '') };
      case 'sha': return { text: v.sha, cls: /清除/.test(v.sha) ? '' : (v.sha === '—' ? '' : 'ok') };
      case 'state': return { text: st.stateName(v.state), cls: v.state === 'OTA_ST_ERROR' ? 'err' : (v.state === 'OTA_ST_NONE' ? 'warn' : '') };
      case 'ret': return { text: v.ret, cls: /^-/.test(v.ret) ? 'err' : (/^[01]$/.test(v.ret) ? 'ok' : '') };
      case '_branch':
        return { text: S.branch || (S.halted ? 'HALT' : (S.done ? '完成' : '—')), cls: S.halted ? 'err' : '' };
      case '_mode':
        return { text: S.suggestMode ? '建议方案模拟（非现有实现）' : '现有源码真实流程',
          cls: S.suggestMode ? 'warn' : 'ok' };
      case '_progress':
        return { text: Math.round(S.prog.dl * 100) + '% / ' + Math.round(S.prog.bk * 100) + '%', cls: '' };
      default: return { text: '—', cls: '' };
    }
  }

  function num(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }

  function renderVars(S) {
    const rows = dom.varBody.querySelectorAll('.vr');
    rows.forEach((r) => {
      const k = r.getAttribute('data-vk');
      const f = fmtVar(S, k);
      const vv = r.querySelector('.vv');
      if (vv.textContent !== f.text) {
        vv.textContent = f.text;
        vv.className = 'vv ' + (f.cls || '');
        vv.classList.add('pulse');
        setTimeout(() => vv.classList.remove('pulse'), 420);
      }
    });
    /* 变更统计 */
    let changed = 0;
    rows.forEach((r) => {
      const k = r.getAttribute('data-vk');
      const f = fmtVar(S, k);
      if (lastVars[k] !== undefined && lastVars[k] !== f.text) changed++;
      lastVars[k] = f.text;
    });
    if (dom.varCount) {
      dom.varCount.textContent = changed > 0 ? ('本步变更 ' + changed + ' 项') : '无变更';
      dom.varCount.classList.toggle('live', changed > 0);
    }
  }

  /* ================================================================
   * 日志面板
   * ================================================================ */
  function renderLog(S, force) {
    const logs = S.logs;
    if (!force && logs.length === lastLogLen) {
      /* 长度不变但内容可能被 live 改写？日志只增不改，直接返回 */
      return;
    }
    const from = Math.max(0, lastLogLen);
    if (force || logs.length < lastLogLen) {
      dom.logBody.innerHTML = '';
      lastLogLen = 0;
    }
    let html = '';
    for (let i = lastLogLen; i < logs.length; i++) {
      const l = logs[i];
      const st = S_();
      html += '<div class="lg ' + esc(l.cls) + '">' +
        '<span class="lt">' + st.fmtTime(l.t) + '</span>' +
        '<span class="lc">' + clsTag(l.cls) + '</span>' +
        '<span class="lm">' + esc(l.text) + '</span></div>';
    }
    if (html) dom.logBody.insertAdjacentHTML('beforeend', html);
    lastLogLen = logs.length;
    dom.logBody.scrollTop = dom.logBody.scrollHeight;
  }

  function clsTag(c) {
    const map = {
      boot: 'BL', app: 'APP', ota: 'OTA', http: 'HTTP', at: 'AT', rx: 'RX', spi: 'SPI',
      ok: 'OK', warn: 'WARN', err: 'ERR', info: '··'
    };
    return map[c] || '··';
  }

  /* ================================================================
   * Flash 分区面板
   * ================================================================ */
  function buildFlashTable() {
    const f = OTA_FACTS;
    let html = '';

    html += '<div class="ft-sec">STM32F429IGT6 内部 Flash · 1MB · 0x0800_0000</div>';
    html += '<div class="ft-table">';
    f.intFlash.regions.forEach((r) => {
      html += '<div class="ft-row" data-inspect="int:' + r.id + '">' +
        '<i style="background:' + r.color + '"></i>' +
        '<div class="ft-name">' + esc(r.name) + '<em>' + esc(r.sectors) + '</em></div>' +
        '<div class="ft-addr">' + hexAddr(r.addr) + '<em>' + (r.size / 1024) + ' KB</em></div>' +
        '<div class="ft-state" data-state="int-' + r.id + '">—</div>' +
        '</div>';
    });
    html += '</div>';

    html += '<div class="ft-sec">W25Q64 片外 SPI Flash · 8MB · JEDEC 0xEF4017</div>';
    html += '<div class="ft-table">';
    f.extFlash.regions.forEach((r) => {
      html += '<div class="ft-row" data-inspect="ext:' + r.id + '">' +
        '<i style="background:' + r.color + '"></i>' +
        '<div class="ft-name">' + esc(r.name) + '<em>' + (r.size / 1024) + ' KB</em></div>' +
        '<div class="ft-addr">' + hexAddr(r.addr) + '</div>' +
        '<div class="ft-state" data-state="ext-' + r.id + '">—</div>' +
        '</div>';
    });
    html += '</div>';

    html += '<div class="ft-sec">启动标志四态（Boot/partition.h:80–83）</div>';
    html += '<div class="ft-flags">';
    f.bootFlags.forEach((b) => {
      html += '<div class="flagrow" data-flag="' + b.v + '">' +
        '<b style="color:' + b.color + '">' + b.v + '</b>' +
        '<span class="fn">' + b.short + '</span>' +
        '<span class="fd">' + esc(b.blAction) + '</span></div>';
    });
    html += '</div>';

    html += '<div class="ft-sec">真实符号地址（来自两个工程的 .map 文件）</div>';
    html += '<div class="ft-table">';
    f.symbols.boot.concat(f.symbols.app).forEach((s, i) => {
      const proj = i < f.symbols.boot.length ? 'BL' : 'APP';
      html += '<div class="ft-row sym" data-inspect="sym:' + i + '">' +
        '<i style="background:' + (proj === 'BL' ? '#7ad7ff' : '#57e389') + '"></i>' +
        '<div class="ft-name">' + esc(s.name) + '<em>' + esc(s.note) + '</em></div>' +
        '<div class="ft-addr">' + s.addr + '</div>' +
        '<div class="ft-state">' + proj + '</div>' +
        '</div>';
    });
    html += '</div>';

    dom.flashBody.innerHTML = html;
    dom.flashBody.addEventListener('click', (ev) => {
      const row = ev.target.closest('[data-inspect]');
      if (row && ctx.onInspect) {
        const v = row.getAttribute('data-inspect').split(':');
        ctx.onInspect({ kind: v[0], id: v[1] });
      }
    });
  }

  function hexAddr(a) {
    let s = a.toString(16).toUpperCase().padStart(8, '0');
    return '0x' + s.slice(0, 4) + '_' + s.slice(4);
  }

  function renderFlash(S) {
    const q = (sel) => dom.flashBody.querySelector(sel);
    const set = (sel, txt, cls) => {
      const n = q(sel);
      if (!n) return;
      if (n.textContent !== txt) n.textContent = txt;
      n.className = 'ft-state ' + (cls || '');
    };
    set('[data-state="int-bl"]', S.ctx.cpu === 'bl' ? '执行中' : '只读', S.ctx.cpu === 'bl' ? 'on' : '');
    set('[data-state="int-param"]', 'seq=' + S.intf.param.seq + ' 有效',
      S.intf.param.state === 'ok' ? 'on' : '');
    const appTxt = {
      old: '旧版 1.0.0', run: '运行中', erasing: '擦除中…', writing: '写入中…', ok: '已写入'
    }[S.intf.app.state] || '—';
    set('[data-state="int-app"]', appTxt + ' · ' + (S.intf.app.ver || ''), S.intf.app.state === 'writing' || S.intf.app.state === 'erasing' ? 'warn' : 'on');

    ['staging', 'backup', 'recovery', 'resource'].forEach((id) => {
      const st = S.ext[id] || { mode: 'idle', frac: 0 };
      const label = {
        idle: 'idle', erase: '擦除中 ' + Math.round(st.frac * 100) + '%',
        ready: '就绪', write: '写入 ' + Math.round(st.frac * 100) + '%',
        valid: '✓ 有效', corrupt: '✗ 校验失败', error: '✗ 写失败'
      }[st.mode] || st.mode;
      const cls = st.mode === 'valid' ? 'on' : (st.mode === 'corrupt' || st.mode === 'error' ? 'err' : (st.mode === 'erase' || st.mode === 'write' ? 'warn' : ''));
      set('[data-state="ext-' + id + '"]', label, cls);
    });

    /* 当前 flag 行高亮 */
    dom.flashBody.querySelectorAll('[data-flag]').forEach((r) => {
      r.classList.toggle('on', parseInt(r.getAttribute('data-flag'), 10) === S.vars.boot_flag);
    });
  }

  /* ================================================================
   * 函数索引面板
   * ================================================================ */
  function buildIndexTable() {
    const idx = window.OTA_INDEX;
    if (!idx || !dom.indexBody) return;
    let html = '<div class="ft-sec">工程规模（不含 Drivers / Middlewares）</div><div class="idx-stats">';
    idx.stats.forEach((s) => {
      const short = s.project === 'HAL_F429IGT6_bootloard' ? 'BootLoader'
        : (s.project === 'HAL_F429IGT6_App' ? 'App 1.0.0' : 'App 1.0.1');
      html += '<div class="idx-stat"><b>' + short + '</b><span>' + s.files + ' 文件 · ' + s.lines + ' 行</span></div>';
    });
    html += '</div>';
    html += '<div class="ft-sec">函数索引（' + idx.functions.length + ' 个，行号来自实际文件）</div>';
    html += '<input id="idxFilter" class="idx-filter" placeholder="过滤：函数名 / 文件名 / 工程">';
    html += '<div class="idx-list" id="idxList">';
    idx.functions.forEach((fn, i) => {
      const short = fn.project === 'HAL_F429IGT6_bootloard' ? 'BL'
        : (fn.project === 'HAL_F429IGT6_App' ? 'APP' : 'APP2');
      html += '<div class="idx-row" data-i="' + i + '" data-key="' +
        esc((fn.func + ' ' + fn.file + ' ' + short).toLowerCase()) + '">' +
        '<span class="ip ' + short.toLowerCase() + '">' + short + '</span>' +
        '<span class="ifn">' + esc(fn.func) + '</span>' +
        '<span class="iff">' + esc(fn.file) + ':' + fn.line + '</span></div>';
    });
    html += '</div>';
    dom.indexBody.innerHTML = html;

    const filter = dom.indexBody.querySelector('#idxFilter');
    filter.addEventListener('input', () => {
      const q = filter.value.trim().toLowerCase();
      dom.indexBody.querySelectorAll('.idx-row').forEach((r) => {
        r.style.display = (!q || r.getAttribute('data-key').indexOf(q) >= 0) ? '' : 'none';
      });
    });

    dom.indexBody.querySelector('#idxList').addEventListener('click', (ev) => {
      const row = ev.target.closest('.idx-row');
      if (!row) return;
      const fn = idx.functions[parseInt(row.getAttribute('data-i'), 10)];
      /* 在当前场景里找引用该函数的步骤 */
      if (!ctx.scenario) return;
      const st = ctx.scenario.steps.find((s) => {
        const sn = s.code ? window.OTA_CODE.snippets[s.code] : null;
        return sn && sn.func === fn.func;
      }) || ctx.scenario.steps.find((s) => {
        return (s.call || []).some((c) => c.indexOf(fn.func) >= 0);
      });
      if (st && ctx.onJumpStep) {
        ctx.onJumpStep(st.id);
      } else if (ctx.onInspect) {
        ctx.onInspect({ kind: 'func', id: fn.func, fn: fn });
      }
    });
  }

  /* ================================================================
   * 信息抽屉（点击芯片模块 / 分区 / 槽）
   * ================================================================ */
  const MOD_INFO = {
    core: { t: 'ARM Cortex-M4F 内核', d: '取指、执行、异常入口。BL 与 App 是两段独立代码，通过设置 MSP + VTOR 完成控制权转移。' },
    nvic: { t: 'NVIC 中断控制器', d: 'BL 里把 USART1 / DMA2 的中断优先级从 0 改成 5，避免抢占 SysTick（优先级 15）导致 HAL_Delay 计时不准；跳转前会用 ICER/ICPR/IP 全部清零。' },
    sram: { t: 'SRAM 192KB', d: '接收缓冲、OTA 状态快照、HTTP 请求缓冲都在这里。http_client_request_once() 的三个大缓冲改为 static 就是为了避开任务栈溢出。' },
    'int-flash': { t: '内部 Flash 1MB', d: '上电取指起点。BL 48KB + 参数区 16KB + App A 槽 960KB。只有 BootLoader 会擦写 A 槽。' },
    usart1: { t: 'USART1 — 日志', d: 'PA9/PA10，115200 8-N-1。BL 用阻塞发送打印 boot_log；App 侧用 DMA 发送（uart_printf）。' },
    usart3: { t: 'USART3 — ESP-01S', d: 'PB10/PB11，115200。平时是 IDLE-DMA + 512B 缓冲做文本解析；OTA 期间切成 CIRCULAR DMA + 4096B 做二进制接收，由 esp01s 独占。' },
    spi2: { t: 'SPI2 — W25Q64', d: '片选 PB12。驱动内部按 256B 页自动跨页写，写前会做 0xFF 预检（不满足就走整扇区读改写慢路径）。' },
    dma: { t: 'DMA1 / DMA2', d: 'USART1 RX=DMA2_Stream2、TX=DMA2_Stream7；USART3 RX=DMA1_Stream1（OTA 期间 CIRCULAR）、TX=DMA1_Stream3。跳转前 16 个流全部关断并清标志。' },
    rtos: { t: 'FreeRTOS', d: 'defaultTask 栈 1536 字；otaTask 由 ota_task_request() 懒创建，栈同样 1536 字（曾因 512 字把栈打爆）。' },
    iwdg: { t: 'IWDG', d: 'BOOT_WDG_ENABLE=0 → BL 侧整个看门狗实现体被 #if 跳过。App 侧 ota_feed_watchdog() 直接写 IWDG->KR，不依赖 HAL_IWDG 模块。' }
  };

  function renderInfo(payload) {
    if (!dom.infoBody) return;
    if (!payload) {
      dom.infoBody.innerHTML = '<div class="info-empty">点击主画面里的芯片模块、Flash 分区、W25Q64 区间或参数槽，这里显示它对应的真实源码与说明。</div>';
      return;
    }
    let title = '';
    let body = '';

    if (payload.kind === 'mod' || payload.mod) {
      const id = payload.id || payload.mod;
      const m = MOD_INFO[id] || { t: id, d: '—' };
      title = m.t; body = '<p>' + esc(m.d) + '</p>';
      body += '<div class="info-kv"><span>模块 ID</span><b>' + esc(id) + '</b></div>';
    } else if (payload.part || payload.kind === 'int') {
      const id = payload.id || payload.part;
      const r = OTA_FACTS.intFlash.regions.find((x) => x.id === id);
      if (r) {
        title = r.name;
        body = '<p>' + esc(r.desc) + '</p>' +
          kv('起始地址', hexAddr(r.addr)) + kv('大小', (r.size / 1024) + ' KB') +
          kv('扇区', r.sectors) + kv('写入方式', r.write) + kv('擦除方式', r.erase);
      }
    } else if (payload.region || payload.kind === 'ext') {
      const id = payload.id || payload.region;
      const r = OTA_FACTS.extFlash.regions.find((x) => x.id === id);
      if (r) {
        title = r.name;
        body = '<p>' + esc(r.desc) + '</p>' +
          kv('片外地址', hexAddr(r.addr)) + kv('大小', (r.size / 1024) + ' KB');
        const use = {
          staging: ['ota_download_try() / dl_on_data()', 'w25q16_write(EXT_STAGING_ADDR + offset, …)'],
          backup: ['ota_backup_current_app()', 'w25q16_write(EXT_BACKUP_ADDR + copied, …)'],
          recovery: ['ota_init_recovery_if_empty()', 'w25q16_write(EXT_RECOVERY_ADDR + copied, …)'],
          resource: ['（未被 OTA 使用）', '—']
        }[id];
        if (use) body += kv('App 侧写入者', use[0]) + kv('调用', use[1]);
      }
    } else if (payload.kind === 'slot') {
      title = '参数槽 #' + payload.id;
      body = '<p>每槽 512B：magic(4B) + seq(4B) + ota_param_t（内含 CRC32）。保存时写下一个空槽，读取时取 seq 最大且 CRC 正确的槽。</p>' +
        kv('槽地址', hexAddr(0x0800C000 + payload.id * 512)) +
        kv('写入函数', 'param_area_save()  Boot/param_area.c:146') +
        kv('读取函数', 'param_area_load()  Boot/param_area.c:105');
    } else if (payload.kind === 'sym') {
      const list = OTA_FACTS.symbols.boot.concat(OTA_FACTS.symbols.app);
      const s = list[payload.id];
      if (s) {
        title = s.name;
        body = kv('地址', s.addr) + kv('说明', s.note) + kv('来源', s.src) +
          '<p>该地址来自 Keil 链接产生的 .map 文件；与串口日志里打印的 vec[0]/vec[1] 完全一致，可作为"源码—链接—运行"三者互证的证据。</p>';
      }
    } else if (payload.kind === 'func' && payload.fn) {
      const fn = payload.fn;
      title = fn.func + '()';
      body = kv('工程', fn.project) + kv('文件', fn.file) + kv('行号', String(fn.line)) +
        kv('签名', fn.fileLine) + kv('static', fn.static ? '是' : '否');
    }
    dom.infoBody.innerHTML = '<div class="info-title">' + esc(title) + '</div>' + body;
  }

  function kv(k, v) {
    return '<div class="info-kv"><span>' + esc(k) + '</span><b>' + esc(v) + '</b></div>';
  }

  /* ================================================================
   * 总渲染
   * ================================================================ */
  function render(S, force) {
    currentS = S;
    /* 场景对象随状态一起进来：代码行 / 索引行点击需要它来定位步骤 */
    if (S && S.scenario) ctx.scenario = S.scenario;
    if (lastTab === 'code' || force) renderCode(S);
    if (lastTab === 'vars' || force) renderVars(S);
    if (lastTab === 'log') renderLog(S, force);
    if (lastTab === 'flash' || force) renderFlash(S);
  }

  function setHTML(node, html) {
    if (node && node.__h !== html) {
      node.__h = html;
      node.innerHTML = html;
    }
  }

  function reset() {
    lastCodeKey = '';
    lastLogLen = -1;
    lastVars = {};
  }

  return { init, render, renderInfo, switchTab, reset };
})();
