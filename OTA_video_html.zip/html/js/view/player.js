/* =============================================================================
 * player.js —— 视频播放器式控制栏
 *
 * 只做一件事：把用户操作翻译成 OTA_TIMELINE 的调用，并把 clock 状态画到控件上。
 * 它不直接改状态机，也不直接改动画 —— 保证"播放/拖动/单步"共享同一条时间轴。
 * ========================================================================== */
'use strict';

window.OTA_PLAYER = (function () {

  const TL = () => window.OTA_TIMELINE;
  let dom = {};
  let scn = null;
  let dragging = false;

  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  function init(container, options) {
    dom = {
      root: container,
      btnPlay: container.querySelector('#btnPlay'),
      btnPrevScene: container.querySelector('#btnPrevScene'),
      btnNextScene: container.querySelector('#btnNextScene'),
      btnPrevStep: container.querySelector('#btnPrevStep'),
      btnNextStep: container.querySelector('#btnNextStep'),
      btnRestart: container.querySelector('#btnRestart'),
      track: container.querySelector('#track'),
      bands: container.querySelector('#trackBands'),
      marks: container.querySelector('#trackMarks'),
      fill: container.querySelector('#trackFill'),
      head: container.querySelector('#trackHead'),
      timeCur: container.querySelector('#timeCur'),
      timeTotal: container.querySelector('#timeTotal'),
      speed: container.querySelector('#speedGroup'),
      pct: container.querySelector('#pct'),
      sceneList: options && options.sceneList ? options.sceneList : null,
      scenSel: options && options.scenSel ? options.scenSel : null
    };
    bind();
    TL().on(onClock);
  }

  function bind() {
    dom.btnPlay.addEventListener('click', () => TL().toggle());
    dom.btnRestart.addEventListener('click', () => TL().restart());
    dom.btnPrevScene.addEventListener('click', () => TL().jumpScene(-1));
    dom.btnNextScene.addEventListener('click', () => TL().jumpScene(1));
    dom.btnPrevStep.addEventListener('click', () => TL().jumpStep(-1));
    dom.btnNextStep.addEventListener('click', () => TL().jumpStep(1));
    dom.speed.addEventListener('click', (ev) => {
      const b = ev.target.closest('[data-speed]');
      if (!b) return;
      TL().setSpeed(parseFloat(b.getAttribute('data-speed')));
    });

    /* 拖动 / 点击时间轴 */
    const seekFromEvent = (ev) => {
      const r = dom.track.getBoundingClientRect();
      const x = Math.max(0, Math.min(r.width, ev.clientX - r.left));
      const ratio = r.width > 0 ? x / r.width : 0;
      TL().seek(ratio * dom.track.__duration, 'drag');
    };
    dom.track.addEventListener('pointerdown', (ev) => {
      dragging = true;
      dom.track.setPointerCapture(ev.pointerId);
      TL().pause();
      seekFromEvent(ev);
      dom.track.classList.add('dragging');
    });
    dom.track.addEventListener('pointermove', (ev) => {
      if (!dragging) return;
      seekFromEvent(ev);
    });
    const endDrag = (ev) => {
      if (!dragging) return;
      dragging = false;
      dom.track.classList.remove('dragging');
      try { dom.track.releasePointerCapture(ev.pointerId); } catch (e) { /* ignore */ }
    };
    dom.track.addEventListener('pointerup', endDrag);
    dom.track.addEventListener('pointercancel', endDrag);

    /* 键盘 */
    document.addEventListener('keydown', (ev) => {
      const tag = (ev.target.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea') return;
      switch (ev.key) {
        case ' ': ev.preventDefault(); TL().toggle(); break;
        case 'ArrowRight': ev.preventDefault(); TL().nudge(ev.shiftKey ? 10000 : 2000); break;
        case 'ArrowLeft': ev.preventDefault(); TL().nudge(ev.shiftKey ? -10000 : -2000); break;
        case 'PageDown': ev.preventDefault(); TL().jumpScene(1); break;
        case 'PageUp': ev.preventDefault(); TL().jumpScene(-1); break;
        case '.': case '>': TL().jumpStep(1); break;
        case ',': case '<': TL().jumpStep(-1); break;
        case 'Home': TL().seek(0, 'home'); break;
        case 'End': TL().seek(TL().duration, 'end'); break;
        default: break;
      }
    });
  }

  /* 载入场景：重建场景带与事件标记 */
  function load(scenario) {
    scn = scenario;
    dom.track.__duration = scenario.total;
    dom.timeTotal.textContent = window.OTA_STATE.fmtTime(scenario.total);

    let bands = '';
    scenario.scenes.forEach((sc, i) => {
      const l = (sc.t0 / scenario.total) * 100;
      const w = ((sc.t1 - sc.t0) / scenario.total) * 100;
      bands += '<div class="band" style="left:' + l.toFixed(4) + '%;width:' + w.toFixed(4) + '%;' +
        'background:linear-gradient(180deg,' + hexA(sc.color, .30) + ',' + hexA(sc.color, .10) + ')" ' +
        'title="' + esc(sc.no + '. ' + sc.title) + '"></div>';
    });
    dom.bands.innerHTML = bands;

    let marks = '';
    scenario.markers.forEach((m) => {
      const l = (m.t / scenario.total) * 100;
      marks += '<div class="mark" style="left:' + l.toFixed(4) + '%" data-step="' + esc(m.stepId) + '" title="' +
        esc(m.label) + '"></div>';
    });
    dom.marks.innerHTML = marks;
    dom.marks.querySelectorAll('.mark').forEach((mk) => {
      mk.addEventListener('click', (ev) => {
        ev.stopPropagation();
        TL().jumpToStep(mk.getAttribute('data-step'));
      });
    });

    /* 场景列表（左侧/顶部场景选择） */
    if (dom.sceneList) {
      let html = '';
      scenario.scenes.forEach((sc) => {
        html += '<button class="scene-chip" data-t="' + sc.t0 + '" data-id="' + sc.id + '">' +
          '<b>' + String(sc.no).padStart(2, '0') + '</b>' + esc(sc.title) + '</button>';
      });
      dom.sceneList.innerHTML = html;
      dom.sceneList.querySelectorAll('.scene-chip').forEach((b) => {
        b.addEventListener('click', () => {
          TL().seek(parseFloat(b.getAttribute('data-t')), 'scene-chip');
          TL().pause();
        });
      });
    }
    if (dom.scenSel) {
      dom.scenSel.innerHTML = scenario.scenes.map((sc) =>
        '<option value="' + sc.t0 + '">' + String(sc.no).padStart(2, '0') + ' · ' + esc(sc.title) + '</option>'
      ).join('');
    }
    onClock({ t: TL().time, playing: TL().playing, speed: TL().getSpeed(), duration: scenario.total });
  }

  function hexA(hex, a) {
    const h = hex.replace('#', '');
    const r = parseInt(h.slice(0, 2), 16);
    const g = parseInt(h.slice(2, 4), 16);
    const b = parseInt(h.slice(4, 6), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
  }

  function onClock(c) {
    const dur = c.duration || 1;
    const ratio = Math.max(0, Math.min(1, c.t / dur));
    dom.fill.style.width = (ratio * 100).toFixed(3) + '%';
    dom.head.style.left = (ratio * 100).toFixed(3) + '%';
    dom.timeCur.textContent = window.OTA_STATE.fmtTimeMs(c.t);
    dom.pct.textContent = Math.round(ratio * 100) + '%';

    dom.btnPlay.classList.toggle('playing', c.playing);
    dom.btnPlay.setAttribute('aria-label', c.playing ? '暂停' : '播放');
    dom.btnPlay.querySelector('.ico').textContent = c.playing ? '❚❚' : '▶';

    dom.speed.querySelectorAll('[data-speed]').forEach((b) => {
      b.classList.toggle('active', parseFloat(b.getAttribute('data-speed')) === c.speed);
    });

    if (scn && dom.sceneList) {
      const sc = window.OTA_STATE.sceneAt(scn, c.t);
      dom.sceneList.querySelectorAll('.scene-chip').forEach((b) => {
        b.classList.toggle('on', sc && b.getAttribute('data-id') === sc.id);
      });
      if (dom.scenSel && sc) dom.scenSel.value = String(sc.t0);
    }
  }

  return { init, load };
})();
