/* =============================================================================
 * app.js —— 装配层
 *
 * 把"场景 → 时间 → 状态 → 各视图"这条链路接起来：
 *   OTA_TIMELINE.on(...) → OTA_STATE.build(scn, t) → OTA_STAGE.render / OTA_PANELS.render
 * 视图层只读 S，不互相调用，也不各自维护时间。
 * ========================================================================== */
'use strict';

(function () {

  const TL = window.OTA_TIMELINE;
  const ST = window.OTA_STATE;
  const SC = window.OTA_SCENARIOS;

  let scenario = null;
  let currentS = null;
  let lastStepId = '';
  let lastSceneId = '';
  let renderQueued = false;

  const $ = (id) => document.getElementById(id);

  /* ------------------------------------------------------------------ */
  /* 初始化                                                             */
  /* ------------------------------------------------------------------ */
  function boot() {
    /* 1. 场景 */
    const params = new URLSearchParams(location.search);
    const wantId = params.get('scenario') || 'normal';
    scenario = SC.get(wantId) || SC.get('normal');

    /* 2. 主画面 */
    OTA_STAGE.build($('stage'));
    OTA_STAGE.bindInspect(onInspect);

    /* 3. 面板 */
    const bodies = Array.prototype.slice.call(document.querySelectorAll('[data-body]'));
    OTA_PANELS.init({
      tabs: $('tabs'),
      bodies: bodies,
      codeMeta: $('codeMeta'),
      codeBody: $('codeBody'),
      codeNote: $('codeNote'),
      varBody: $('varBody'),
      varCount: $('varCount'),
      logBody: $('logBody'),
      flashBody: $('flashBody'),
      indexBody: $('indexBody'),
      infoBody: $('infoBody')
    }, {
      onJumpStep: (id) => { TL.jumpToStep(id); },
      onInspect: onInspect
    });

    /* 4. 播放器 */
    OTA_PLAYER.init($('player'), { sceneList: $('sceneList') });
    OTA_PLAYER.load(scenario);

    /* 5. 场景下拉 */
    buildScenarioSelect();
    applyScenarioChrome();

    /* 6. 时钟订阅 */
    TL.on(() => queueRender());

    /* 7. 起播位置 */
    TL.load(scenario, parseFloat(params.get('t') || '0'));
    OTA_PLAYER.load(scenario);

    renderNow();

    /* 7b. 面板深链（便于分享/自动截图） */
    const wantTab = params.get('tab');
    if (wantTab) OTA_PANELS.switchTab(wantTab);

    if (params.get('autoplay') === '1') {
      TL.play();
    }

    /* 8. 自检 */
    if (params.get('selftest') === '1') {
      runSelftest();
    }

    document.body.classList.add('ready');
  }

  /* ------------------------------------------------------------------ */
  /* 场景切换                                                           */
  /* ------------------------------------------------------------------ */
  function buildScenarioSelect() {
    const sel = $('scenarioSel');
    const list = SC.list();
    let html = '';
    let groupReal = '<optgroup label="现有源码真实流程（A/B）">';
    let groupSuggest = '<optgroup label="建议方案模拟（C · 当前工程未实现）">';
    list.forEach((d) => {
      const opt = '<option value="' + d.id + '">' + esc(d.short) + ' — ' + esc(d.title) + '</option>';
      if (d.mode === 'suggest') groupSuggest += opt;
      else groupReal += opt;
    });
    html = groupReal + '</optgroup>' + groupSuggest + '</optgroup>';
    sel.innerHTML = html;
    sel.value = scenario.id;
    sel.addEventListener('change', () => {
      const next = SC.get(sel.value);
      if (!next) return;
      scenario = next;
      OTA_PANELS.reset();
      OTA_PLAYER.load(scenario);
      TL.load(scenario, 0);
      applyScenarioChrome();
      renderNow();
      TL.play();
      /* 同步到 URL，便于分享/复现 */
      try {
        const u = new URL(location.href);
        u.searchParams.set('scenario', scenario.id);
        u.searchParams.delete('t');
        u.searchParams.delete('autoplay');
        history.replaceState(null, '', u.toString());
      } catch (e) { /* file:// 下可能不支持，忽略 */ }
    });
  }

  function applyScenarioChrome() {
    const badge = $('modeBadge');
    if (scenario.mode === 'suggest') {
      badge.textContent = '建议方案模拟 · 非现有实现';
      badge.className = 'modeBadge suggest';
      document.body.classList.add('is-suggest');
    } else {
      badge.textContent = '现有源码真实流程';
      badge.className = 'modeBadge real';
      document.body.classList.remove('is-suggest');
    }
    $('scenDesc').textContent = scenario.desc;
    $('scenTitle').textContent = scenario.title;
    const t = $('scenStats');
    if (t) {
      t.textContent = scenario.steps.length + ' 步 · ' + scenario.scenes.length + ' 场景 · 总时长 ' +
        ST.fmtTime(scenario.total);
    }
  }

  /* ------------------------------------------------------------------ */
  /* 渲染                                                               */
  /* ------------------------------------------------------------------ */
  function queueRender() {
    if (renderQueued) return;
    renderQueued = true;
    requestAnimationFrame(() => {
      renderQueued = false;
      renderNow();
    });
  }

  function renderNow() {
    const t = TL.time;
    const S = ST.build(scenario, t);
    currentS = S;

    OTA_STAGE.render(S);

    /* 面板：代码面板只在步骤变化时重建（内部已做 key 比较） */
    OTA_PANELS.render(S, lastStepId !== (S.step ? S.step.id : ''));

    /* 顶部信息 */
    if (S.scene && S.scene.id !== lastSceneId) {
      lastSceneId = S.scene.id;
      $('hSceneNo').textContent = String(S.scene.no).padStart(2, '0');
      $('hScene').textContent = S.scene.title;
      document.documentElement.style.setProperty('--scene-color', S.scene.color);
    }
    if (S.step && S.step.id !== lastStepId) {
      lastStepId = S.step.id;
      $('hStep').textContent = S.step.label;
      $('stageStepTitle').textContent = S.step.label;
      $('stageStepNote').textContent = S.step.note || '';
      renderCallChips(S);
      const g = S.step.g || 'A';
      const gb = $('hGrade');
      gb.textContent = g + ' · ' + (g === 'A' ? '源码已证实' : (g === 'B' ? '根据源码推导' : '建议方案/模拟'));
      gb.className = 'gradeBadge g-' + g;
    }
    $('hProgress').textContent = Math.round(S.overall * 100) + '%';
    $('hProgressBar').style.width = (S.overall * 100).toFixed(2) + '%';
  }

  function renderCallChips(S) {
    const box = $('callChain');
    const call = (S.step && S.step.call) || [];
    let html = '';
    call.forEach((c, i) => {
      html += (i ? '<span class="arrow">→</span>' : '') +
        '<button class="chip" data-call="' + esc(c) + '">' + esc(c) + '</button>';
    });
    box.innerHTML = html;
    box.querySelectorAll('.chip').forEach((b) => {
      b.addEventListener('click', () => {
        const name = b.getAttribute('data-call').replace(/\(.*$/, '');
        /* 在当前场景里找第一个包含该函数的步骤 */
        const st = scenario.steps.find((s) => (s.call || []).some((c) => c.indexOf(name) >= 0));
        if (st) TL.jumpToStep(st.id);
      });
    });
  }

  function onInspect(payload) {
    if (payload.mod) payload = { kind: 'mod', id: payload.mod };
    else if (payload.part) payload = { kind: 'int', id: payload.part };
    else if (payload.region) payload = { kind: 'ext', id: payload.region };
    else if (payload.slot !== undefined && payload.slot !== null) payload = { kind: 'slot', id: payload.slot };
    OTA_PANELS.renderInfo(payload);
    const drawer = $('infoDrawer');
    if (drawer) drawer.classList.add('has');
  }

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /* ------------------------------------------------------------------ */
  /* 自检（#selftestLog 会被 --dump-dom 读到，作为真实测试证据）          */
  /* ------------------------------------------------------------------ */
  function runSelftest() {
    const log = [];
    let pass = 0, fail = 0;
    const ok = (name, cond, detail) => {
      if (cond) { pass++; log.push('PASS  ' + name + (detail ? '  — ' + detail : '')); }
      else { fail++; log.push('FAIL  ' + name + (detail ? '  — ' + detail : '')); }
    };

    /* 1. 片段存在性 */
    let missing = [];
    SC.list().forEach((d) => {
      const s = SC.get(d.id);
      s.steps.forEach((st) => {
        if (st.code && !window.OTA_CODE.snippets[st.code]) missing.push(d.id + '/' + st.id + ':' + st.code);
        if (st.code && st.hl) {
          const sn = window.OTA_CODE.snippets[st.code];
          const a = Math.min(st.hl[0], st.hl[1] === undefined ? st.hl[0] : st.hl[1]);
          const b = Math.max(st.hl[0], st.hl[1] === undefined ? st.hl[0] : st.hl[1]);
          if (sn && (a < sn.from || b > sn.to)) missing.push(d.id + '/' + st.id + ' hl 越界 ' + a + '-' + b + ' vs ' + sn.from + '-' + sn.to);
        }
      });
    });
    ok('所有步骤引用的源码片段存在且行号区间合法', missing.length === 0, missing.join('; ') || '—');

    /* 2. 场景 id 合法 */
    let badScene = [];
    SC.list().forEach((d) => {
      const s = SC.get(d.id);
      s.steps.forEach((st) => {
        if (!OTA_FACTS.scenes.some((x) => x.id === st.scene)) badScene.push(d.id + '/' + st.id);
      });
    });
    ok('所有步骤的 scene 都在 facts.scenes 中定义', badScene.length === 0, badScene.join('; ') || '—');

    /* 3. 时间轴连续性 */
    let contOk = true, contDetail = '';
    SC.list().forEach((d) => {
      const s = SC.get(d.id);
      let t = 0;
      s.steps.forEach((st) => {
        if (Math.abs(st.t0 - t) > 0.001) { contOk = false; contDetail += d.id + '/' + st.id + ' '; }
        t = st.t1;
      });
      if (Math.abs(t - s.total) > 0.001) { contOk = false; contDetail += d.id + ':total '; }
    });
    ok('每个场景的 step 时间轴首尾相接、总时长一致', contOk, contDetail || '—');

    /* 4. 状态求值可重复（同样输入 → 同样输出） */
    const a1 = JSON.stringify(ST.build(scenario, scenario.total * 0.42));
    const a2 = JSON.stringify(ST.build(scenario, scenario.total * 0.42));
    ok('同一时刻两次求值结果完全一致（可重复）', a1 === a2,
      a1 === a2 ? 'len=' + a1.length : 'diff');

    /* 5. 跳跃求值等价于顺序重放（0 → 中段 → 末段 结果相同） */
    const total = scenario.total;
    const jump = JSON.stringify(ST.build(scenario, Math.floor(total * 0.7)));
    ST.build(scenario, 0);
    ST.build(scenario, 1000);
    const re = JSON.stringify(ST.build(scenario, Math.floor(total * 0.7)));
    ok('跳跃求值与顺序重放结果一致（时间轴可安全拖动）', jump === re, '');

    /* 6. 终态检查 */
    if (scenario.id === 'normal' || scenario.id === 'truncate') {
      const S = ST.build(scenario, total);
      ok('正常场景终态：boot_flag=NORMAL', S.vars.boot_flag === 0, 'flag=' + S.vars.boot_flag);
      ok('正常场景终态：version=0x010001', S.vars.version === 0x010001, 'ver=0x' + S.vars.version.toString(16));
      ok('正常场景终态：backup_status=VALID', S.vars.backup_status === 2, 'bk=' + S.vars.backup_status);
      ok('正常场景终态：片内 A 槽为 1.0.1 且已写入', S.intf.app.ver === '1.0.1' && S.intf.app.fill === 1, '');
      ok('正常场景终态：栈顶/向量表指向 App A 槽', S.ctx.vtor === '0x08010000', S.ctx.vtor);
    }
    if (scenario.id === 'fail-staging-sha') {
      const S = ST.build(scenario, total);
      ok('回滚场景终态：版本回退到 1.0.0', S.vars.version === 0x010000, '0x' + S.vars.version.toString(16));
      ok('回滚场景终态：flag 复位 NORMAL 且备份清空', S.vars.boot_flag === 0 && S.vars.backup_status === 0, '');
      ok('回滚场景：暂存区标记为损坏', S.ext.staging.mode === 'corrupt', S.ext.staging.mode);
    }
    if (scenario.id === 'fail-halt') {
      const S = ST.build(scenario, total);
      ok('挂死场景终态：cpu=halt 且进入 boot_halt', S.ctx.cpu === 'halt' && S.halted === true, S.ctx.func);
    }
    if (scenario.id === 'fail-md5') {
      const S = ST.build(scenario, total);
      ok('MD5 失败终态：返回 -5 且 A 槽未被改写', S.vars.ret === '-5' && S.vars.boot_flag === 0, S.vars.ret);
    }
    if (scenario.id === 'fail-w25q') {
      const S = ST.build(scenario, total);
      ok('Flash 写失败终态：返回 -4', S.vars.ret === '-4', S.vars.ret);
    }
    if (scenario.id === 'fail-notask') {
      const S = ST.build(scenario, total);
      ok('无任务终态：返回 1 且状态 NONE', S.vars.ret === '1' && S.vars.state === 'OTA_ST_NONE', '');
    }
    if (scenario.id === 'suggest-ab') {
      const S = ST.build(scenario, total);
      ok('建议场景：全程标记为 C（模拟）', S.suggestMode === true, '');
    }

    /* 7. 关键事实一致性（facts 与源码片段互相印证） */
    const f = OTA_FACTS;
    ok('片内分区不重叠且总长 = 1MB',
      (f.intFlash.regions.reduce((a, r) => a + r.size, 0) === 0x100000),
      f.intFlash.regions.reduce((a, r) => a + r.size, 0).toString(16));
    ok('片外四区首尾相接且每区 960KB',
      f.extFlash.regions.every((r, i) => i === 0 || r.addr === f.extFlash.regions[i - 1].addr + f.extFlash.regions[i - 1].size),
      '');
    ok('扇区表 12 项且总长 1MB',
      f.sectors.length === 12 && f.sectors.reduce((a, s) => a + s.size, 0) === 0x100000, '');
    ok('App 起始地址与分区表一致（0x08010000）', f.intFlash.regions[2].addr === 0x08010000, '');

    /* 8. DOM 渲染检查 */
    ok('代码面板已渲染出代码行', document.querySelectorAll('#codeBody .cl').length > 0,
      document.querySelectorAll('#codeBody .cl').length + ' 行');
    ok('时间轴已渲染出场景带', document.querySelectorAll('#trackBands .band').length > 0,
      document.querySelectorAll('#trackBands .band').length + ' 段');
    ok('事件标记已渲染', document.querySelectorAll('#trackMarks .mark').length > 0,
      document.querySelectorAll('#trackMarks .mark').length + ' 个');
    ok('SVG 主画面已生成模块', document.querySelectorAll('.s-block').length >= 10,
      document.querySelectorAll('.s-block').length + ' 个');

    const box = $('selftestLog');
    if (box) {
      box.hidden = false;
      box.innerHTML = '<h3>自检结果：' + pass + ' 通过 / ' + fail + ' 失败</h3>' +
        '<pre>' + log.join('\n') + '</pre>';
      box.setAttribute('data-pass', String(pass));
      box.setAttribute('data-fail', String(fail));
    }
    /* 供 --dump-dom 精确读取 */
    const mark = document.createElement('div');
    mark.id = 'selftestSummary';
    mark.textContent = 'SELFTEST pass=' + pass + ' fail=' + fail;
    document.body.appendChild(mark);

    console.log('[selftest] pass=' + pass + ' fail=' + fail);
    log.forEach((l) => console.log(l));
  }

  /* ------------------------------------------------------------------ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
